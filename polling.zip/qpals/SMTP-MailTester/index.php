<form method="post" action="#">
<table width="60%">
<tr><td>SMTP Host Name:</td><td> <input type="text" name="hname" value="<?php if(!empty($_POST['hname'])){ echo $_POST['hname'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>SMTP PORT:</td><td> <input type="text" name="port" value="<?php if(!empty($_POST['port'])){ echo $_POST['port'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>SMTP Secure:</td><td> <input type="text" name="secure" value="<?php if(!empty($_POST['secure'])){ echo $_POST['secure'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>SMTP USERNAME:</td><td> <input type="text" name="uname" value="<?php if(!empty($_POST['uname'])){ echo $_POST['uname'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>SMTP PASSWORD:</td><td> <input type="password" name="pwd" value="<?php if(!empty($_POST['pwd'])){ echo $_POST['pwd'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>To Email:</td><td> <input type="text" name="to" value="<?php if(!empty($_POST['to'])){ echo $_POST['to'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>Email Subject:</td><td> <input type="text" name="sub" value="<?php if(!empty($_POST['sub'])){ echo $_POST['sub'];} ?>"/></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td>Email Body:</td><td> <textarea name="body"><?php if(!empty($_POST['body'])){ echo $_POST['body'];} ?></textarea></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td colspan="2"><input type="submit" name="submit" value="Send EMail"/></td></tr>
</table>
</form>
<?php

if(!empty($_POST['submit'])){

$hostname  	= !empty($_POST['hname']) 	? $_POST['hname'] : "smtp.gmail.com";
$port  		= !empty($_POST['port']) 	? $_POST['port'] : 25;
$secure  	= !empty($_POST['secure']) 	? $_POST['secure'] : 25;
$username  	= !empty($_POST['uname']) 	? $_POST['uname'] : "svsteja1991@gmail.com";
$pwd  		= !empty($_POST['pwd']) 	? $_POST['pwd'] : "qvertbcglzpxmunh";
$to  		= !empty($_POST['to']) 		? $_POST['to'] : "";
$sub  		= !empty($_POST['sub']) 	? $_POST['sub'] : "Test Subject";
$body  		= !empty($_POST['body']) 	? $_POST['body'] : "Test Body Test Body Test Body";


	include("class.phpmailer.php"); 
			
			$mail             = new PHPMailer();

//			$mail->IsSMTP();
			$mail->IsMail();
			$mail->SMTPAuth   = true;                  // enable SMTP authentication
			$mail->SMTPSecure = $secure;                 // sets the prefix to the servier
			$mail->Host       = $hostname;      // sets GMAIL as the SMTP server
			$mail->Port       = $port;                   // set the SMTP port for the GMAIL server
			$mail->Username   = $username;  // GMAIL username
			$mail->Password   = $pwd;            // GMAIL password

			$mail->AddReplyTo($username,"Test User Name");

			$mail->From       = $username;
			$mail->FromName   = "Test User Name";
			$mail->Sender	  ="Test User Name";
			$mail->Subject    = $sub;

			$mail->Body       = $body;                      //HTML Body
			$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
			$mail->WordWrap   = 50; // set word wrap

			//$mail->MsgHTML($body)
			
			$mail->AddAddress($to);
			//print_r($mail);
			$mail->IsHTML(true); // send as HTML
			//$mail->Send();
			if(!$mail->Send()) {
				 echo "<font color='red'><b>Mailer Error: " . $mail->ErrorInfo."</b></font>";
				return false;
			}else {
				echo "<font color='green'><h1 align='center'>Mail Sent successfully</h1></font>";
			}
}

//print_r(phpinfo());
?>
