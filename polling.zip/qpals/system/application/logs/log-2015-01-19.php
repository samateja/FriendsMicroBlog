<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-01-19 15:10:10 --> Config Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:10:10 --> URI Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Router Class Initialized
DEBUG - 2015-01-19 15:10:10 --> No URI present. Default controller set.
DEBUG - 2015-01-19 15:10:10 --> Output Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Security Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Input Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 15:10:10 --> Language Class Initialized
DEBUG - 2015-01-19 15:10:10 --> Loader Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: form_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: url_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: array_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: html_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: captcha_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: string_helper
DEBUG - 2015-01-19 15:10:11 --> Helper loaded: cookie_helper
DEBUG - 2015-01-19 15:10:11 --> Controller Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Database Driver Class Initialized
ERROR - 2015-01-19 15:10:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\qpals\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2015-01-19 15:10:11 --> Form Validation Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Session Class Initialized
DEBUG - 2015-01-19 15:10:11 --> A session cookie was not found.
DEBUG - 2015-01-19 15:10:11 --> Session routines successfully run
DEBUG - 2015-01-19 15:10:11 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:11 --> Initializing MessageQueue
DEBUG - 2015-01-19 15:10:11 --> File loaded: D:/wamp/www/qpals/system/application/views/frontendHeader.php
DEBUG - 2015-01-19 15:10:11 --> File loaded: D:/wamp/www/qpals/system/application/views/frontendFooter.php
DEBUG - 2015-01-19 15:10:11 --> File loaded: D:/wamp/www/qpals/system/application/views/homeView.php
DEBUG - 2015-01-19 15:10:11 --> Final output sent to browser
DEBUG - 2015-01-19 15:10:11 --> Total execution time: 0.9025
DEBUG - 2015-01-19 15:10:12 --> Config Class Initialized
DEBUG - 2015-01-19 15:10:12 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:10:12 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:10:12 --> URI Class Initialized
DEBUG - 2015-01-19 15:10:12 --> Router Class Initialized
ERROR - 2015-01-19 15:10:12 --> 404 Page Not Found --> videos
DEBUG - 2015-01-19 15:10:51 --> Config Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:10:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:10:51 --> URI Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Router Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Output Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Security Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Input Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 15:10:51 --> Language Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Loader Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: form_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: url_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: array_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: html_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: captcha_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: string_helper
DEBUG - 2015-01-19 15:10:51 --> Helper loaded: cookie_helper
DEBUG - 2015-01-19 15:10:51 --> Controller Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Database Driver Class Initialized
ERROR - 2015-01-19 15:10:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\qpals\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2015-01-19 15:10:51 --> Form Validation Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Session Class Initialized
DEBUG - 2015-01-19 15:10:51 --> A session cookie was not found.
DEBUG - 2015-01-19 15:10:51 --> Session routines successfully run
DEBUG - 2015-01-19 15:10:51 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:51 --> Initializing MessageQueue
DEBUG - 2015-01-19 15:10:51 --> Final output sent to browser
DEBUG - 2015-01-19 15:10:51 --> Total execution time: 0.1250
DEBUG - 2015-01-19 15:10:56 --> Config Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:10:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:10:56 --> URI Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Router Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Output Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Security Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Input Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 15:10:56 --> Language Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Loader Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: form_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: url_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: array_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: html_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: captcha_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: string_helper
DEBUG - 2015-01-19 15:10:56 --> Helper loaded: cookie_helper
DEBUG - 2015-01-19 15:10:56 --> Controller Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Database Driver Class Initialized
ERROR - 2015-01-19 15:10:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\qpals\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2015-01-19 15:10:56 --> Form Validation Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Session Class Initialized
DEBUG - 2015-01-19 15:10:56 --> A session cookie was not found.
DEBUG - 2015-01-19 15:10:56 --> Session routines successfully run
DEBUG - 2015-01-19 15:10:56 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:56 --> Initializing MessageQueue
DEBUG - 2015-01-19 15:10:56 --> Final output sent to browser
DEBUG - 2015-01-19 15:10:56 --> Total execution time: 0.1295
DEBUG - 2015-01-19 15:10:58 --> Config Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:10:58 --> URI Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Router Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Output Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Security Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Input Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 15:10:58 --> Language Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Loader Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: form_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: url_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: array_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: html_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: captcha_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: string_helper
DEBUG - 2015-01-19 15:10:58 --> Helper loaded: cookie_helper
DEBUG - 2015-01-19 15:10:58 --> Controller Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Database Driver Class Initialized
ERROR - 2015-01-19 15:10:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\qpals\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2015-01-19 15:10:58 --> Form Validation Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Session Class Initialized
DEBUG - 2015-01-19 15:10:58 --> A session cookie was not found.
DEBUG - 2015-01-19 15:10:58 --> Session routines successfully run
DEBUG - 2015-01-19 15:10:58 --> Model Class Initialized
DEBUG - 2015-01-19 15:10:58 --> Initializing MessageQueue
DEBUG - 2015-01-19 15:10:58 --> Final output sent to browser
DEBUG - 2015-01-19 15:10:58 --> Total execution time: 0.1325
DEBUG - 2015-01-19 15:11:08 --> Config Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:11:08 --> URI Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Router Class Initialized
ERROR - 2015-01-19 15:11:08 --> 404 Page Not Found --> qpals
DEBUG - 2015-01-19 15:11:08 --> Config Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:11:08 --> URI Class Initialized
DEBUG - 2015-01-19 15:11:08 --> Router Class Initialized
ERROR - 2015-01-19 15:11:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2015-01-19 15:11:12 --> Config Class Initialized
DEBUG - 2015-01-19 15:11:12 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:11:12 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:11:12 --> URI Class Initialized
DEBUG - 2015-01-19 15:11:12 --> Router Class Initialized
ERROR - 2015-01-19 15:11:12 --> 404 Page Not Found --> qpals123
DEBUG - 2015-01-19 15:11:23 --> Config Class Initialized
DEBUG - 2015-01-19 15:11:23 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:11:23 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:11:23 --> URI Class Initialized
DEBUG - 2015-01-19 15:11:23 --> Router Class Initialized
ERROR - 2015-01-19 15:11:23 --> 404 Page Not Found --> qpals123.com
DEBUG - 2015-01-19 15:11:25 --> Config Class Initialized
DEBUG - 2015-01-19 15:11:25 --> Hooks Class Initialized
DEBUG - 2015-01-19 15:11:25 --> Utf8 Class Initialized
DEBUG - 2015-01-19 15:11:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 15:11:25 --> URI Class Initialized
DEBUG - 2015-01-19 15:11:25 --> Router Class Initialized
ERROR - 2015-01-19 15:11:25 --> 404 Page Not Found --> qpals123.com
