    <?php $this->load->view('frontendHeader');
    $sessionlog=$this->session->userdata('userID');
    ?>
    
    <style type='text/css'>
    .cancel{
    float:left;
    }
    .confirm{
    float:right;
    }
    </style>
    
    <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
    <div class="clear" style="height: 150px;"></div>
    <div class="container">
    
    <div class="span12">
    <div class="row">
    
    <div class="modal-body" style="width:490px; margin:0 auto; min-height:490px; overflow:hidden;">
    <div id="nonResult" style="color:red; margin-left: 160px"></div><br/>
    <h4 style="text-align:center; border-bottom:1px solid #cccccc; padding-bottom:5px;">Complete your Registration</h4>
    <div id="nonResult" style="color:red; margin-left: 160px"></div><br/>
    <table width="100%" cellpadding="5">
    <tr>
    <td width="50%"> <input type="text" style="width:215px;" class="inputstle" placeholder="First Name" name="firstName" id="nfirstName" />
    </td>
    <td> <input style="width:215px;" type="text" class="inputstle" placeholder="Last Name" name="lastName" id="nlastName"  /> </td>
    </tr>
    
    
    
    <tr>
    <td colspan="2"> <input type="text" style="width:462px;"  class="inputstle" disabled placeholder="Email" name="userEmail" value = "<?php echo $emailID; ?>" id="nuserEmail" /> 
    <input type="hidden" name="usergrpID" value ="<?php echo $grpID; ?>" id="nusergrpID" /> 
    </td>
    
    </tr>
    
    <tr><td colspan="2">
    
   You may add other email addresses later to your account. <br>
   Please choose your password.
    </td></tr>
   
    <tr><td colspan="2">
    
    </td></tr>
    <tr>
    <td colspan="2"> <input style="width:462px;"  type="password" class="inputstle" placeholder="Password" name="userPassword" id="nuserPassword" onkeypress="submitForm4(event)"   /> </td>
    </tr>
    
    
    
    <tr>
    <td colspan="2"><i>By clicking Register, I accept the Qpals <a href="<?php echo base_url();?>terms" target="_blank">Terms of Use</a> and 
    <a href="<?php echo base_url();?>privacyPolicy" target="_blank">Privacy Policy.</a></i></td>
    </tr>
    
    
    
    <tr>
    <!--
    <td  align="left" >  
    <button aria-hidden="true" data-dismiss="modal" href="#myModal_login" style="padding:10px 0; margin-top:0px;" role="button"  data-toggle="modal" class="butn b_blue" id="signin" onclick="return onSignIn();"> LOG IN</button>
    
    </td>
    -->
    
    <td   style="vertical-align:top;">  
    <!-- <button style="padding:10px 0; margin-top:0px;float:left" class="butn b_blue" id="signin" onclick="return onSignIn();"> LOG IN</button>
    -->
    <button style="margin-top:0px; padding:10px 0; color:#5d5d5d;float:right" class="butn b_yellow" id="register" onclick="return onNonRegister();">Register</button>
    </td>
    </tr>
    </table>					   
    
    </div>
    
    
    
    
    </div>  
    </div>
    
    </div>
    <div class="clear" style="height: 150px;"></div>
    
    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
