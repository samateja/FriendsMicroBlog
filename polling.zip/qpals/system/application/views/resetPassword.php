  
 <?php $this->load->view('frontendHeader');?>
  <style type="text/css">
body {
font-family: Arial, Helvetica, sans-serif;
font-size: 14px;


}
p {
padding: 6px 5px;
text-align: justify;
}
</style>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  <div class="clear" style="height:130px"></div>
   <div class="container">
        <div class="row">
           <h3 style="margin-bottom:25px; margin-top:25px;">Reset Password</h3>
           <?php 
             $email=$this->uri->segment(3);
           
           ?>
             <div id="resultReset" style="color:red;"></div><br/>
            <table width="100%" cellpadding="5">                   
                                
			<tr>
				<td> 
				<input type="password" class="span4" placeholder="Password" name="passwordVal" id="passwordVal"  />
				</td>
			</tr>
								
		<tr>
			<td>
			 <input type="password" class="span4" placeholder="Confirm Password" name="confirmPasswordVal" id="confirmPasswordVal"  /> 
			</td>
		</tr>
								
							
		<tr>
		<td  >  
		<button  style="margin-top:0px; padding:10px 0; color:#5D5D5D;" class="butn b_yellow" onclick="return resetPassword();">
		Submit</button> 
		</td>
	</tr>
	
	<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
			<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
		
		<tr>
			<td>
			 &nbsp;
			</td>
		</tr>
				
	
  </table> 				   
				   
	</div>       
   </div>
 
 
  <script>
  
      function resetPassword(){        

    	$(document).ready(function(){

    	var emailVal="<?php echo $this->uri->segment(3);?>";
       	var base_url="<?php echo base_url('resetPassword/resetpass');?>";
       	var passwordVal=$('#passwordVal').val();       	
       	var confirmPasswordVal=$('#confirmPasswordVal').val();
    	 $.post(base_url,{emailVal:emailVal,passwordVal:passwordVal,confirmPasswordVal:confirmPasswordVal},function(response){
        	     //alert(response);
        	     if(response==1){
        	    	  window.location = "<?php echo base_url('home')?>";
        	     }else{
        	    	 $("#resultReset").html(response);
        	     }
           });
    });  
 }
  
  </script>
 
 
 
	      
   
    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
