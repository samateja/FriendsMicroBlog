
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Welcome to QPals</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="cytrion" >

<!-- Le styles -->
<link href="<?php echo base_url();?>css/style_inner.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">

<link href="<?php echo base_url();?>css/style_logout.css" rel="stylesheet">


<script src="<?php echo base_url();?>js/jquery.js"></script>

<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<![endif]-->

<style> 

.navbar .nav_l > li > a.classactive {
color: #dedd20;
}
.inputstle{
font-size:13px !important;
}
</style>

<script>
function get_settings() {
$(".toggle_wrapper").fadeToggle();
}
/*$(document).ready(function(){
document.getElementById("email").focus();
$('#loginBtn').click(function(){
alert('sdfds');
//$('#email').focus();
if(document.getElementById("email").value=="")
{

document.getElementById("email").focus();
alert("hello");
}
});	
});*/
function setFocus()
{
document.getElementById("email").focus();
}
</script>
<script>
/*function testAttribute(element, attribute) {
var test = document.createElement(element);
if (attribute in test) {
return true;
}
else 
return false;
}
*/
/*window.onload = function() {
if (!testAttribute('input', 'autofocus'))
document.getElementById('email').focus(); 
//for browser has no autofocus support, set focus to Text2.
}*/
</script> 
</head>

<body >



<!-- --------------------------TOP BAR---------------------------------   -->


<div class="container">
<div class="row" style="position: fixed;background-color: #ffffff;z-index: 1000;">
<div class="header_logout">
<div class="container">
<div class="row">
<div class="span3"  style="margin-top:28px;"> 
<a href="<?php echo base_url();?>">
<img src="<?php echo base_url();?>images/logo_logout.png" width="147" height="69" alt=""> 
</a>
</div>
<div class="span8 pull-right">
<div class="navbar">
<div class="navbar-inner">             
<ul class="nav_l">
<li> 
	<a href="http://www.qpals.com">Home</a>
<!-- <a href="<?php echo base_url();?>home" <?php if($active=="home"){?>class="classactive"<?php }?>>Home</a> -->
</li>
<li> <a href="<?php echo base_url();?>home#c" class="sada">About</a></li>
<li> <a href="http://www.qpals.com/faqs"> FAQ's </a>
	<!-- <a href="<?php echo base_url();?>faqs" <?php if($active=="faqs"){?>class="classactive"<?php }?>>FAQ's</a> --></li>
<li> <a href="#myModal" role="button" id="loginBtn" data-toggle="modal" href="#"> Login </a></li>                   
</ul>
</div>                
</div>
</div>
</div>
</div>
</div>         
</div>

</div>


<!-- -------------------------- END TOP BAR---------------------------------   -->



<!-- -------------------------- BEGIN HEADER---------------------------------   -->

<!-- -------------------------- END HEADER---------------------------------   -->




<div class="container-fluid">
<div class="row-fluid">
<div class="">


<!-- Modal  popup start-->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-header" style="border-bottom:none !important;">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 id="myModalLabel" style="color:#606060">Log In Details</h4>
</div>
<div class="modal-body" style="padding-top:0px">
<div id="result" style="color:red; margin-left: 160px"></div><br/>
<table width="100%" cellpadding="5">                   

<tr>
<td colspan="2"> <input type="text" class="span12 inputstle" placeholder="Email" name="email" id="email" autofocus="autofocus"  />
</td>
</tr>

<tr>
<td colspan="2"> <input type="password" class="span12 inputstle" placeholder="Password" name="password" id="password" onkeypress="submitForm(event)" /> 
</td>
</tr>

<tr>
<td style="vertical-align:top;">
<a aria-hidden="true" data-dismiss="modal"  href="#forgotPassword" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0;color:#5D5D5D;">
<i style="text-decoration: underline;">Forgot Password?</i></a> 


</td>
<td  style="vertical-align:top;" align="right">
<button style="padding:10px 0; margin-top:0px;" class="butn b_blue" id="signin" onclick="return onSignIn();"> LOG IN</button>
</td>
</tr>

<tr>
<td width="400">
<div class="f_bold"> Log In with Facebook? </div>
</td>
<td>
<div class="f_bold"> New User? </div>
</td>
</tr>
<tr>
<td style="vertical-align:top;">  
<a href="<?php echo base_url().'home/fbLogin'; ?>">
<img src="<?php echo base_url();?>images/login_facebook.png" width="230" height="40" alt="" />
</a> 
</td>
<td  align="right" style="vertical-align:top;">  
<button aria-hidden="true" data-dismiss="modal"  href="#myModal_register" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0; color:#5D5D5D;" class="butn b_yellow">
REGISTER NOW</button> 
</td>
</tr>
</table>					   

</div>

</div><!-- end of login popup -->

<!-- Added by Padmaja  -->
<div id="myModal_login" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-header" style="border-bottom:none !important;">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 id="myModalLabel" style="color:#606060">Log In Details</h4>
</div>
<div class="modal-body" style="padding-top:0px">
<div id="result3" style="color:red; margin-left: 160px"></div><br/>
<table width="100%" cellpadding="5">                   

<tr>
<td colspan="2"> <input type="text" class="span12 inputstle" placeholder="Email" name="email" id="email1"  />
</td>
</tr>

<tr>
<td colspan="2"> <input type="password" class="span12 inputstle" placeholder="Password" name="password" id="password1" onkeypress="submitForm2(event)" /> 
</td>
</tr>

<tr>
<td style="vertical-align:top;">
<a aria-hidden="true" data-dismiss="modal"  href="#forgotPassword" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0;color:#5D5D5D;">
<i style="text-decoration:underline">Forgot Password?</i></a> 


</td>
<td  style="vertical-align:top;" align="right">
<button style="padding:10px 0; margin-top:0px;" class="butn b_blue" id="signin" onclick="return onSignIn1();"> LOG IN</button>
</td>
</tr>

<tr>
<td width="400">
<div class="f_bold"> Log In with Facebook? </div>
</td>
<td>
<div class="f_bold"> New User? </div>
</td>
</tr>
<tr>
<td style="vertical-align:top;">  
<a href="<?php echo base_url().'home/fbLogin'; ?>">
<img src="<?php echo base_url();?>images/login_facebook.png" width="230" height="40" alt="" />
</a> 
</td>
<td  align="right" style="vertical-align:top;">  
<button aria-hidden="true" data-dismiss="modal"  href="#myModal_register" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0; color:#5D5D5D;" class="butn b_yellow">
REGISTER NOW</button> 
</td>
</tr>
</table>					   

</div>

</div>


<div id="myModal_register" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h5 id="myModalLabel">Register Now</h5>
</div>
<div class="modal-body">
<div id="result1" style="color:red; margin-left: 160px"></div><br/>
<table width="100%" cellpadding="5">
<tr>
<td width="50%"> <input type="text" class="span12 inputstle" placeholder="First Name" name="firstNmae" id="firstName" />
</td>
<td> <input type="text" class="span12 inputstle" placeholder="Last Name" name="lastName" id="lastName"  /> </td>
</tr>



<tr>
<td colspan="2"> <input type="text" class="span12 inputstle" placeholder="Email" name="userEmail" id="userEmail" /> </td>
</tr>

<tr>
<td colspan="2"> <input type="password" class="span12 inputstle" placeholder="Password" name="userPassword" id="userPassword" onkeypress="submitForm1(event)"   /> </td>
</tr>



<tr>
<td colspan="2"><i>By clicking Register, I accept the Qpals <a href="<?php echo base_url();?>terms" target="_blank">Terms of Use</a> and 
<a href="<?php echo base_url();?>privacyPolicy" target="_blank">Privacy Policy.</a></i></td>
</tr>



<tr>

<td  align="left" >  
<button aria-hidden="true" data-dismiss="modal" href="#myModal_login" style="padding:10px 0; margin-top:0px;" role="button"  data-toggle="modal" class="butn b_blue" id="signin" onclick="return onSignIn();"> LOG IN</button>

</td>
<td   style="vertical-align:top;">  
<!-- <button style="padding:10px 0; margin-top:0px;float:left" class="butn b_blue" id="signin" onclick="return onSignIn();"> LOG IN</button>
-->
<button style="margin-top:0px; padding:10px 0; color:#5d5d5d;float:right" class="butn b_yellow" id="register" onclick="return onRegister();">REGISTER</button>
</td>
</tr>
</table>					   

</div>

</div><!-- end of register popup -->			
<!-- Modal-register  popup end-->
<div id="forgotPassword" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h5 id="myModalLabel" style="text-decoration: underline;">Forgot Password</h5>
</div>

<div class="modal-body">
<div id="result2" style="color:red; margin-left: 110px"></div><br/>
<table width="100%" cellpadding="5">
<tr>
<td>
<input type="text" class="span12" placeholder="Email" name="emailId" id="emailId" />
</td>								
</tr>			

<tr>					
<td  align="right" style="vertical-align:top;">  
<button style="margin-top:0px; padding:10px 0; color:#5d5d5d;" class="butn b_yellow" id="forgotPasswordSubmit">SUBMIT</button>
</td>
</tr>		
</table>					   

</div>

</div>
</div>      
</div>    

</div>


<!-- used ajax to login -->

<script type="text/javascript">

function onSignIn(){             
var email=$('#email').val();
var password=$('#password').val();
//alert('dsf');
$.ajax({            
type: "POST",
url: "<?php echo base_url('home/login')?>",
data: ({email: email, password: password }),

success: function(response){ 
alert(response);
if(response==1){
var groupSession="<?php echo $this->session->userdata('redirectGroupUrl');?>";
if(groupSession !=""){

window.location = "<?php echo $this->session->userdata('redirectGroupUrl');?>";   
}else{

window.location = "<?php echo base_url('qwall/qwallView')?>";
}
}else{
$("#result").html(response);
}
}  
}); 


}
/*Added by padmaja*/
function onSignIn1(){             
var email=$('#email1').val();
var password=$('#password1').val();
//alert('dsf');
$.ajax({            
type: "POST",
url: "<?php echo base_url('home/login')?>",
data: ({email: email, password: password }),

success: function(response){ 
//alert(response);
if(response==1){
var groupSession="<?php echo $this->session->userdata('redirectGroupUrl');?>";
if(groupSession !=""){

window.location = "<?php echo $this->session->userdata('redirectGroupUrl');?>";   
}else{

window.location = "<?php echo base_url('qwall/qwallView')?>";
}
}else{
$("#result3").html(response);
}
}  
}); 


}
</script>

<script type="text/javascript">
function onRegister(){
//alert('asd');
var firstName=$('#firstName').val();
var lastName =$('#lastName').val();
var userEmail=$('#userEmail').val();
var userPassword =$('#userPassword').val();



$.ajax({
type: "POST",
url : "<?php echo base_url('home/userRegistration')?>",
data: ({firstName:firstName,lastName:lastName,email:userEmail,password:userPassword}),

success: function(responseReg){ 
//alert(responseReg);                
if(responseReg==1){
window.location = "<?php echo base_url('qwall/qwallView')?>";
}else{
$("#result1").html(responseReg);
}

}
});
} 



</script>
<script type="text/javascript">
function onNonRegister(){
//alert('asd');
var firstName=$('#nfirstName').val();
var lastName =$('#nlastName').val();
var userEmail=$('#nuserEmail').val();
var userPassword =$('#nuserPassword').val();


$.ajax({
type: "POST",
url : "<?php echo base_url('home/userRegistration')?>",
data: ({firstName:firstName,lastName:lastName,email:userEmail,password:userPassword}),

success: function(responseReg){ 
// alert(responseReg);                
if(responseReg==1){
window.location = "<?php echo base_url('groups/mygroups')?>";
}else{
$("#nonResult").html(responseReg);
}

}
});
} 



</script>

<script type="text/javascript">
$('#forgotPasswordSubmit').click(function(){

var EmailId = $('#emailId').val();            


$.ajax({
type: "POST",
url : "<?php echo base_url('home/forgotPassword')?>",
data: ({EmailId:EmailId}),

success: function(responseReg){                 

$("#result2").html(responseReg);

}
});


});

</script>


<script>
function submitForm(e)
{
//alert('asd');
e = e || window.event;
var keycode;
if (window.event){
//this check fails in mozilla/
//so the variable keycode is undefined
keycode = event.which ? window.event.which : window.event.keyCode;
}
if(!keycode){keycode = e.which}
//solves the issue
if(e.which==13){
onSignIn();
}
}
function submitForm2(e)
{
//alert('asd');
e = e || window.event;
var keycode;
if (window.event){
//this check fails in mozilla/
//so the variable keycode is undefined
keycode = event.which ? window.event.which : window.event.keyCode;
}
if(!keycode){keycode = e.which}
//solves the issue
if(e.which==13){
onSignIn1();
}
}
function submitForm1(e)
{

e = e || window.event;
var keycode;
if (window.event){
//this check fails in mozilla/
//so the variable keycode is undefined
keycode = event.which ? window.event.which : window.event.keyCode;
}
if(!keycode){keycode = e.which}
//solves the issue
if(e.which==13){
onRegister();
}
}
function submitForm4(e)
{

e = e || window.event;
var keycode;
if (window.event){
//this check fails in mozilla/
//so the variable keycode is undefined
keycode = event.which ? window.event.which : window.event.keyCode;
}
if(!keycode){keycode = e.which}
//solves the issue
if(e.which==13){
onRegister();
}
}

</script>
 <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
    <div class="clear" style="height: 150px;"></div>
    <div class="container">
    
    <div class="span12">
    <div class="row">
    

    
    </div>
    
		<h4>Tips and Tricks</h4>
		<ol>
<li> Are friends adding you to QPals groups using different email addresses for you?  Add your other email addresses as secondary emails in Edit Profile and you’ll get all your groups in one QPals account.</li>
<li>Want to follow other QPals users and see their public Qs?  Click on a Q creator’s profile photo on a Q or in Find Pals, read his or her public bio and tap on follow. </li>
<li>Creating a Q, but can’t remember who is in a group?  Tap on the eye (OO) just before the group name and we’ll show you everyone in that group.   </li> 
<li>Always asking the same question to the same group (e.g. ‘which shoe should I buy’ to ‘my BFFs’)?  Go to settings, pick a default question (or create your own) and a default group.  You’ll send out Qs even faster. </li>
<li>Like lots of votes and chatty friends?  Post your Qs on all your favorite social networks (QPals, Facebook, Twitter and Pinterest) while creating them. </li>
<li>Want to follow a really cool Q?  Tap it as a ‘Favorite’ (HEART ICON HERE) and come back easily to chat and track votes. </li>
<li>Want a fun and quicker way to create Qs?  Scroll down to see all of our popular QPals questions – we give you fun icons and automatically enter questions and even some answers. </li>
<li>Need more than 2 answers for a one photo Q (e.g. ‘Want to see the 2pm, 4pm or 6pm movie’)?  You can add up to 4 different answers when if your Q has only one (or no) photo. </li>
<li>Always add a note to your Q – you’ll get the conversation started. </li>
</ol>
    
    
    </div>  
    </div>
    
    </div>
    <div class="clear" style="height: 150px;"></div>
    
    <!-- -------------------------- END CONTAINER---------------------------------   -->

<!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
