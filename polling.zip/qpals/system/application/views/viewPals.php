    <?php $bucket = $this->config->item("bucket");?>
  <?php $this->load->view('headerView');?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
  <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_profile">
          
          <?php 
          
          if($palsData)
          {
          	$displayName = $palsData[0]['displayName'];
			$biography   = $palsData[0]['biography'];
			//$thumb	     = base_url()."Uploads/ProfilePictures/".$palsData[0]['thumb'];
			if($palsData[0]['thumb'] != 'avatar_thumb.png'){
				$thumb		=$this->_S3Url.$palsData[0]['thumb'];
			}else{
				$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			}
			//$thumb	     = 'http://'.$bucket.'.s3.amazonaws.com/'.$palsData[0]['thumb'];
          }
          
          ?>
        
        
               <div class="span5 devider_span">
                   <h4><?php echo $displayName;?></h4> 
	                   <table width="100%" class="form_profile">
	                     <tr>
	                       <td> <img src="<?php echo $thumb;?>" width="355" height="355" alt="" /> </td>
	                     </tr>
	                     <tr> 
	                       <td></td>                     
	                     </tr>                   
	                   </table>
	                   
	                   <h4 style="color:#ffcc33;">Bio</h4> 
	                   
	                    <table width="100%" class="form_profile">
	                     <tr>
                         <td><div class="man_findpals"><?php echo $displayName;?></div>  </td>                     
                        </tr>
                        
                        <tr>
                          <td>&nbsp;</td>                        
                        </tr>
                        
                        <tr>
                          <td><img src="<?php echo base_url();?>images/icon_about_findpals.png" width="28" height="28" alt="" /> <?php echo $biography;?></td>                        
                        </tr>
                        
                        <tr>
                        <td>
                        <span id="showStatus">
                        <?php if($getFollowStatus) {
                        	$followStatus=0;
                        ?>
                          <button class="butn b_findpals span11" onclick="return setFollowStatus(<?php echo $followStatus; ?>)" style="background-color:#8D8888">Following </button>
                          <?php }else{ 
                          $followStatus=1;
                          	?>
                          <button class="butn b_findpals span11" onclick="return setFollowStatus(<?php echo $followStatus; ?>)">FOLLOW ME </button> 
                          <?php } ?>
                          </span>
                          </td>                       
                        </tr>
	                                     
	                   </table>
	                   
   
               </div>  
               
               
              <div class="span7">
                    <div id="tabs_findpals">
								 <ul class="tabs" id="tabsnav">
								  <li><a href="#tab-1" class="tab menu-internal">Q Created (<?php echo $countOfPalsQ;?>)</a></li>
								  <li><a href="#tab-2" class="tab menu-internal">Following (<?php echo $countOfFollowing;?>)</a></li>
								  <li><a href="#tab-3" class="tab menu-internal">Followers (<?php echo $countOfFollowers;?>)</a></li>								  
								 </ul>
								 
								 <div id="tab-1">
						<?php if($getIsPublicCount && !$getReceivedQCount){?>	     
                          <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;">
                                <ul>
								  <?php 
								  if($getIsPublicCount && !$getReceivedQCount){					
                                  foreach($getIsPublic as $getIsPublic){
						
						           $qId      =$getIsPublic['ID'];
						           $time1    = $getIsPublic['timeStamp'];
						           $time1   =date("Y-m-d H:i:s", strtotime($getIsPublic['timeStamp']." UTC"));
					               $time2   = date('Y-m-d H:i:s');
					               $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
						           $qsn      =$getIsPublic['name'];
						
					    $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						$quserId           =$getIsPublic['user_ID'];
						$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
						
					   if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
						}else{
							$uname=NULL;
						}
						
						$qImageData=$this->getdatamodel->getQImages($qId);
						
						if($qImageData){													
								$imgName=$qImageData[0]['thumb'];
								if($imgName){							
								$thumb=$this->_S3Url.$imgName;
								
								}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
								}
								
								}else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
						}
						
						
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url()."/qwall/viewQ/".$qId;?>">
                                   <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />
                                   </a>
                                   <br>
                                   <div>
                                   <div class="question"><?php echo $qsn;?></div> 
                                   <div class="comment_bg_findpals"> <p><?php echo $responseCount;?></p></div> 
                                   <div class="fleft" style="font-style:italic"><?php echo $qAge;?> ago by <span class="bold_italic"><?php echo $uname; ?></span></div> 
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{
					            echo "No Q's available.";
				         }
								  
								  ?>
								  </ul>
								  
							</div> 
							
							<?php }?> 
							
							
							<?php if(!$getIsPublicCount && $getReceivedQCount){?>
							    
							       <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;">
                                <ul>
								  <?php 
								  if(!$getIsPublicCount && $getReceivedQCount){					
                                  foreach($getReceivedQ as $getReceivedQ){
						
						       		$qId      =$getReceivedQ['QpalId'];
						            $time1    = $getReceivedQ['timeStamp'];
						            $time1   =date("Y-m-d H:i:s", strtotime($getReceivedQ['timeStamp']." UTC"));
					                $time2   = date('Y-m-d H:i:s');
					                $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
						            $qsn      =$getReceivedQ['quename'];
						//$qArr['responseCount']=0;
					               $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						           if($getAggregateVotes){
							       $opt1 = $getAggregateVotes[0]['opt1'];
					               $opt2 = $getAggregateVotes[0]['opt2'];
					               $opt3 = $getAggregateVotes[0]['opt3'];
					               $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						$quserId          =$getReceivedQ['QpalUserId'];
						$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
					   if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
						}else{
							$uname='';
						}
						
						$qImageData=$this->getdatamodel->getQImages($qId);
						
                             if($qImageData){													
								$imgName=$qImageData[0]['thumb'];
								if($imgName){							
								$thumb=$this->_S3Url.$imgName;
								
								}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
								}
								
								}else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
						}
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url()."/qwall/viewQ/".$qId;?>">
                                   <img src="<?php echo $thumb;?>" width="200" height="200" alt="" /></a><br>
                                   <div>
                                   <div class="question"><?php echo $qsn;?></div> 
                                   <div class="comment_bg_findpals"> <p><?php echo $responseCount;?></p></div> 
                                   <div class="fleft" style="font-style:italic"><?php echo $qAge;?> ago by <span class="bold_italic"><?php echo $uname; ?></span></div> 
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{
					            echo "No Q's available.";
				         }
								  
								  ?>
								  </ul>
								  
							</div> 
							 
							 
							<?php }?>
															     
						<?php if($getIsPublicCount && $getReceivedQCount){?>
						
						       <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;">
                                <ul>
								  <?php 
								  if($getIsPublicCount && $getReceivedQCount){					
                                  foreach($getPublicReceived as $getPublicReceived){
						
                                  $qId      =$getPublicReceived['QpalId'];
						          $time1    = $getPublicReceived['timeStamp'];
						          $time1   =date("Y-m-d H:i:s", strtotime($getPublicReceived['timeStamp']." UTC"));
					              $time2   = date('Y-m-d H:i:s');
					              $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
						          $qsn     =$getPublicReceived['quename'];
						//$qArr['responseCount']=0;
					              $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						$quserId          =$getPublicReceived['QpalUserId'];
						
					$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
					   if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
						}else{
							$qArr['uname']='';
						}
						
						$qImageData=$this->getdatamodel->getQImages($qId);
						
                             if($qImageData){													
								$imgName=$qImageData[0]['thumb'];
								if($imgName){							
								$thumb=$this->_S3Url.$imgName;
								
								}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
								}
								
								}else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
							
						}
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url()."/qwall/viewQ/".$qId;?>">
                                    
                                   <img src="<?php echo $thumb;?>" width="200" height="200" alt="" /></a><br>
                                   <div>
                                   <div class="question"><?php echo $qsn;?></div> 
                                   <div class="comment_bg_findpals"> <p><?php echo $responseCount;?></p></div> 
                                   <div class="fleft" style="font-style:italic"><?php echo $qAge;?> ago by <span class="bold_italic"><?php echo $uname; ?></span></div> 
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{
					            echo "No Q's available.";
				         }
								  
								  ?>
								  </ul>
								  
							</div> 
						
					<?php } ?>     
					</div><!-- end of tab 1 -->
								 
						<div id="tab-2">
							<div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;">
                                <ul>
								  <?php 
								  if($getFollowingPals){						  	
								  	foreach($getFollowingPals as $getFollowingPals){ 
								    $fUserId     =$getFollowingPals['followers_ID'];
						            $userData              =$this->getdatamodel->getUserDetailsByUserID($fUserId);
						            if($userData[0]['thumb'] != 'avatar_thumb.png'){
						            	$thumb		=$this->_S3Url.$userData[0]['thumb'];
						            }else{
						            	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
						            }
						           // $thumb	   = 'http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName = $userData[0]['displayName'];
						            
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url()."/findPals/viewPals".$fUserId;?>">
                                   <img src="<?php echo  $thumb;?>" width="200" height="200" alt=""/></a><br>
                                   <div>
                                   <div class="question"><?php echo  $displayName;?></div>                                
                                  
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{
					            echo "No Q's available.";
				         }
								  
								  ?>
								  </ul>
								  <?php //echo $this->pagination->create_links();?>   
							</div>
							 
					</div>
								 
								 <div id="tab-3">
								 <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;">
								  <ul>
								  <?php 
								  if($getPalFollowers){//if received Q's								  	
								  	foreach($getPalFollowers as $getPalFollowers){ 
								    $usrArr['fUserId']=$getPalFollowers['user_ID'];
						            $userData            =$this->getdatamodel->getUserDetailsByUserID($usrArr['fUserId']);
								  	 if($userData[0]['thumb'] != 'avatar_thumb.png'){
						            	$thumb		=$this->_S3Url.$userData[0]['thumb'];
						            }else{
						            	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
						            }
						            //$thumb	 ='http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName=$userData[0]['displayName'];
						            
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                     <a href="<?php echo base_url()."findPals/viewPals/".$usrArr['fUserId'];?>">
                                   <img src="<?php echo  $thumb;?>" width="200" height="200" alt=""/></a><br>
                                   <div>
                                   <div class="question"><?php echo  $displayName;?></div>                                
                                  
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{
					            echo "No Q's available.";
				         }
								  
								  ?>
								  </ul>
								 </div>
								</div> 
								
								 
								</div>                    
                    </div>
               </div> 
        </div>      
      </div>    
     
  
  
  <!-- set status -->
  
  <script>

    function setFollowStatus(followStatus){

        var friendId=<?php echo $this->uri->segment(3);?>

        var base_url="<?php echo base_url('findPals/setFollowStatus');?>";
       
        $.post(base_url,{friendId:friendId,followStatus:followStatus},function(response){

            
          $('#showStatus').html(response);
                 
           });
    }
  
  </script>

 <script type="text/javascript">

$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs_findpals > div').hide(); // hide all child divs
  jQuery('#tabs_findpals div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs_findpals > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs_findpals li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });

</script>
 <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>

    <?php $this->load->view('footerView');?>
