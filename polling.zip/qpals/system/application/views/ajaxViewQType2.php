 <?php	$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
  ?>
 
 <div class="row" id="viewQtype2">       
         <?php 
                
                   foreach($getOptionCount as $row){			
		            $optionCountGet=$row['optionName'];//count of options				 
	               }
	              foreach($getImgCount as $row){			
		           $imgCountGet=$row['thumb'];//count of options				 
	               }
	               
               
                
                
           ?>
           <div style="width:290px;height:350px; overflow:hidden;" class="span3 thumbs_group"> 
               <div style="position:relative">               
                 
                 <?php
                 
                 if($getQOptions){
        		
        		foreach($getQOptions as $row){
        			$imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
        		    if($imgNamethumb){
					$thumb=$this->_S3Url.$imgNamethumb;
					$image=$this->_S3Url.$imgNamePhoto;
					$isDefaultImage=FALSE;
					break;
					}else{
					$thumb=base_url()."Uploads/QImages/default_thumb.png";
					$image=base_url()."Uploads/QImages/default.png";
					$isDefaultImage=TRUE;	
					}
        		}
        		
        		
        		
        	}
                 
                 
                 $i=1;
                 foreach($getQOptions as $row){                 	
                   
                 $optionId=$row['ID'];	
                 $option=$row['optionName'];
                 if($option!=""){
                 $optionName=$row['optionName'];
                 }else{
                 $optionName="";
                 }
                 
                 $getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					if($getCountQVotesOptions[0]['qCount']>0){
					$isVoted	     = TRUE;	
					}else{
					$isVoted	     = FALSE;
					}
					 
                  ?>
                 <button <?php if($isVoted==TRUE) {?>class="btn_answer<?php echo $i;?> answer_yes"<?php } else { ?> class="btn_answer<?php echo $i;?>" <?php  }?> onclick="return voteOption(<?php echo $optionId; ?>);">
                 	<?php echo $row['optionName']; ?>
                 </button>
                 <?php
                 $i++; }
                 ?>
                  </div>  
                 <a class="group1" href="<?php echo $image;?>">
                 <img src="<?php echo $thumb;?>" width="290" height="290" alt="" />
                  </a> 
                  <?php if($optionCountGet <=2) { //for two options
                    $oCount = 0;
	                $getAggregateVotes = NULL;
	                //$qId=$this->uri->segment(3);
                  	foreach($getQOptions as $row){
                  	$optionId=$row['ID'];
                  	$optionName=$row['optionName'];
                  	$idName = "PB_".$oCount;
                  	                 	
                  	if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					
					}//end of else
                  	
                  	
                  ?>                  
                  <table class="table_rows" cellpadding="4" style="margin-top:1px;">
                       <tr>
                         <td width="80">
                         <span class="f_bold"><?php echo $optionName;?></span> </td>
                         <td> 
                          <?php if($resPerc!=0) { ?> 
                         <div class="progress_wrap">
                          <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $optionName;?>');"><div></div></div>                         
                        
                         </div>
                         <?php }else{?>
                         <div class="progress_wrap">
                          
                          <div class="progress_no_cross"></div>
                          &nbsp; &nbsp;  <span class="f_bold"><?php echo $resPerc.'%';?></span>
                         </div>
                         <?php }?>
                         </td>
                       </tr>
                                           
                       
                  </table>
                  
                  <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script>
                    <?php $oCount++;} } ?>
                    
                 </div> 
                 <!-- end of 2 options -->
                    
                  <!-- progress bar -->
                  <?php if($optionCountGet >2)  {//more than two options
                  	$oCount = 0;
	                $getAggregateVotes = NULL;
	                //$qId=$this->uri->segment(3);
                  	foreach($getQOptions as $row){
                  	$optionId=$row['ID'];
                  	$optionName=$row['optionName'];
                  	$idName = "PB_".$oCount;                  	
                  	if ($getAggregateVotes == NULL)
					{
					
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					
					}//end of else
                  ?>  
                  <!-- jquery script for progress bar -->
                  
                    
                    <div class="span6">
                       <table class="table_rows" cellpadding="4" style="margin-top:10px;">
	                       <tr>
	                         <td width="140">
	                         <span class="f_bold"><?php echo $optionName;?></span>
	                         </td>
	                         <td>
	                         <?php if($resPerc!=0) { ?>
	                           <div class="progress_wrap">
	                           <!-- progress bar -->
	                           
	                             <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $optionName;?>');"><div></div></div>
	                            <div class="progress_no_cross"></div>  &nbsp; &nbsp;
	                             <span class="f_bold"> <?php //echo $resPerc.'%';?> </span> 
	                        </div>
	                        <?php }else{ ?>
	                        
	                        <div class="progress_wrap">	                          
	                           
	                           <div class="progress_no_cross"></div>  &nbsp; &nbsp;
	                           <span class="f_bold"> <?php echo $resPerc.'%';?> </span> 
	                        </div>
	                        <?php }?>
	                        </td>
	                       </tr>
	                       
	                       <tr> <td colspan="2"></td></tr>
	                       <tr> <td colspan="2"></td></tr>               
	                       
	                   </table>
                                         
                    </div>
                     <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script>
                   <?php $oCount++; }} ?> 
              <!-- Progress bar End -->

              </div> 