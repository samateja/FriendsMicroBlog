<?php
include(BASEPATH.'application/libraries/facebook.php');
 
		
		// Init facebook api.
 $facebook = new Facebook(array(
  'appId'  => '211768959034139',
  'secret' => '67ceb1305539925168b5065561f22833'  
 ));
 
 $user = $facebook->getUser();
 
 
  $params = array(
  'scope'=> 'email,read_stream, publish_stream',  
  'display'=>'popup'
 );

  $loginUrl = $facebook->getLoginUrl($params);
  $user = $facebook->getUser();
  $fbid=$facebook->getUser(); 
  if (!$user)
		{
      header("location:$loginUrl"); 
		}else{
		
			 $fbid=$facebook->getUser(); 
			 $access_token=$facebook->getAccessToken();
             //echo $access_token;die;
             	
		}	
	?>
	
	