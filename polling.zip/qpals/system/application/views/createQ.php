  
  <?php $this->load->view('headerView');?>
 
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery.Jcrop.min.css" />
  <script src="<?php echo base_url();?>js/jquery.Jcrop.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.form.js"></script>
  <script src="<?php echo base_url();?>js/modernizr.js"></script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
 <form name="form" id="form" enctype="multipart/form-data"  method="POST">
 <div id="createQPage1"> 
 <div class="container-fluid">
      <div class="row-fluid">
    
        <div class="container content_inner h_line_red">
               <div  class="span5 devider_span">
                   <h4 class="red">Question<span class="txt_n" style="">&nbsp;[Type your question or pick a QPals question]</span> </h4> 
	          
	          
	          <table class="table_rows">
                <!-- <tr>
                    <td>
                       <input type="text" id="questionName1" name="questionName1"  placeholder="Type here" class="span10" />
                     </td>                
                </tr>-->
                
                <tr>
                  <td>
                   <div style="float:left;" class="span12" onclick="get_question()">
                   <!-- <span id="replaceQuestion"> -->
                   <?php 
                   $userId=$this->session->userdata('userID');
                   $userData=$this->getdatamodel->getUserDetailsByUserID($userId);
                   $defaultGroup= $userData[0]['defaultGroup_ID'];
                   $questionId=$userData[0]['defaultQuestion_ID'];
                   $defaultQuestionId=$userData[0]['defaultQuestion_ID'];
                   //echo $defaultQuestionId;
                   if($defaultQuestionId){
						$userDefaultQuestion=$this->getdatamodel->getQuestionByID($defaultQuestionId);						
						$presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];						
					if($presetQuestion_Id==0){
						$userDefaultQsnId=$userDefaultQuestion[0]['ID'];	
						}else{
						$getPresetImage=$this->getdatamodel->getQuestionName($presetQuestion_Id);
						if($getPresetImage){
						 $getIconImageDisplay=$getPresetImage[0]['image'];
						 //echo $getIconImageDisplay;die;
						 $presetImage=base_url()."Uploads/predefinedIcons/".$getIconImageDisplay;
						}
						
						$presetOption1=$getPresetImage[0]['opt1'];
						$presetOption2=$getPresetImage[0]['opt2'];
						$userDefaultQsnId= $userDefaultQuestion[0]['presetQuestion_Id'];	
						}
						$userDefaultQsn= $userDefaultQuestion[0]['name'];
						//echo $userDefaultQsn;
					}
                   
                   ?>
                   <?php if($questionId){
                   	if($userDefaultQsn) { ?>
                   <input type="text" id="questionName"  name="questionName" value="<?php echo $userDefaultQsn;?>"   style="font-style:italic" placeholder="Type here" class="span11" width="100px;" />
                   <?php }else{ ?>
                   <input type="text"  id="questionName" name="questionName"  style="font-style:italic" placeholder="Type here" class="span11" width="100px;" />
                   <?php }}else{ ?>
                    <input type="text"  id="questionName" name="questionName"  style="font-style:italic" placeholder="Type here" class="span11" width="100px;" />
                   <?php } ?>
                   
                    
                      <div style="float:right;">
                      <img src="<?php echo base_url();?>images/select_arrow.png" width="12" height="12" alt="" />
                      </div>
                     </div> 
                       <div style="position:relative;">                                    
                        <div id="questionbox" class="select_box span11" style="display:none; position:absolute; top:48px; left:0px; overflow:auto;height:200px">
                            <ul id='uItem'>
                            <?php if($presetQuestions){
                              	foreach($presetQuestions as $rec){
                              		
                              	$questionId	= $rec['ID'];
                              	$getIconImage = $rec['icon'];
                              	if($getIconImage){
                              	$icon=base_url()."Uploads/predefinedIcons/".$getIconImage;
                              	}else{
                              	$icon=base_url()."Uploads/predefinedIcons/default-icon.png";	
                              	}
                              ?>
                              <li id="<?php echo $rec['ID'];?>">
                              <div data-toggle="modal" href="#rcbians" class="img_q_icon">
                              <img src="<?php echo $icon;?>" />
                              </div>                              
                              <p class="fleft"><?php echo $rec['questionDesc'];?></p>                             
                              <p class="group_count"></p> 
                             </li> 
                             <?php }} ?>
                             <?php 
                             if($userAddeddQuestions){
					         foreach($userAddeddQuestions as $rec){ 
					         	$icon=base_url()."Uploads/predefinedIcons/default-icon.png";	
					         
					         	?>
					            <li>
                              <div data-toggle="modal" href="#rcbians" class="img_q_icon">
                              <img src="<?php echo $icon;?>" />
                              </div>                              
                              <p class="fleft"><?php echo $rec['name'];?></p>
                              
                              <p class="group_count"></p> 
                             </li> 
					        <?php }} ?>                              
                            </ul>
                        </div> 
                       </div>
                       
                       <input type="hidden" name="selectedQId" id="selectedQId" value=""></input>                   
                   </td>                
                 </tr>	                
                 
	          </table>

               </div>  
               
               
        <div class="span7">
           <div style="margin-left:30px;" id="replaceImgOpt">               
              <h4 class="red">Answer<span class="txt_n">
               [Add up to 4 photos and/or answers]</span>
               </h4>
             <table>
               <tr>
               
               <!-- image 1 start -->
                 <td>
                 
                 <?php 
                       //echo $defaultQuestionId;         
                
                 if($defaultQuestionId!=0 && $presetQuestion_Id!=0){                  
                 ?>
                 <?php if( $getIconImageDisplay) {?>
                 
                  <div class="img_fill_frame" id="qImage1" style="display:none;">
                     <div class="img_fill_add">                     
                     <span id="image_preview1">
                     <a data-toggle="modal" href="#image1Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                    
                 <div class="img_fill_frame" id="showQImage1">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage1();">
                     </div> 
                      <img id="showCroppedImg" src="<?php echo $presetImage;?>" width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image1"  name="image1" style="display:none" />
                    <br/>
                    <?php } else {?>
                    <div class="img_fill_frame" id="qImage1">
                     <div class="img_fill_add">                     
                     <span id="image_preview1">
                     <a data-toggle="modal" href="#image1Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                     
                       
                  <!-- to display the cropped image -->
                     <div class="img_fill_frame" id="showQImage1" style="display:none">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage1();">
                     </div> 
                      <img id="showCroppedImg" src="" width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image1"  name="image1" style="display:none" />
                    <br/>
                     
                    <?php } ?>
                    
                    <?php if($presetOption1) {?>
                    <input type="text" name="answer1" style="font-style:italic;text-align: center;" id="answer1" class="span10" placeholder="Answer" value="<?php echo $presetOption1;?>" ></input>
                  <?php }else{ ?>
                   <input type="text" name="answer1" style="font-style:italic;text-align: center;" id="answer1" class="span10" placeholder="Answer"></input>
                  <?php } ?>
                 <?php } else{ ?>
                 <!-- to upload an image -->
                     <div class="img_fill_frame" id="qImage1">
                     <div class="img_fill_add">                     
                     <span id="image_preview1">
                     <a data-toggle="modal" href="#image1Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                    
                  <!-- to display the cropped image -->
                     <div class="img_fill_frame" id="showQImage1" style="display:none">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage1();">
                     </div> 
                      <img id="showCroppedImg" src="" width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image1"  name="image1" style="display:none" />
                    <br/>
                    
                    <input type="text" name="answer1" style="font-style:italic;text-align: center;" id="answer1" class="span10" placeholder="Answer" ></input>
                   <?php } ?>
                  </td>
                  
               <!-- image 1 end -->   
                  
                  
               <!-- image 2 start -->  
                  
                              
                  <td>
                      <!-- to upload an image -->
                     <div class="img_fill_frame" id="qImage2">
                     <div class="img_fill_add">                     
                     <span id="image_preview2">
                     <a data-toggle="modal" href="#image2Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                    
                  <!-- to display the cropped image -->
                     <div class="img_fill_frame" id="showQImage2" style="display:none">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage2();">
                     </div> 
                      <img id="showCroppedImg1" src="" width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image2"  name="image2" style="display:none" />
                     <br/>
                    <?php if($defaultQuestionId && $presetQuestion_Id!=0) { if($presetOption2) {?>
                    <input type="text" style="font-style:italic;text-align: center;"  name="answer2" id="answer2" class="span10" placeholder="Answer" value="<?php echo $presetOption2;?>"></input>
                    <?php } else{ ?>
                    <input type="text" style="font-style:italic;text-align: center;"  name="answer2" id="answer2" class="span10" placeholder="Answer" ></input>
                    <?php } }else{ ?>
                     <input type="text" style="font-style:italic;text-align: center;"  name="answer2" id="answer2" class="span10" placeholder="Answer" ></input>
                    <?php } ?>
                  </td> 
                  
             <!-- image 2 end --> 
                              
                              
             <!-- image 3 start -->  
                  
                              
                  <td>
                      <!-- to upload an image -->
                     <div class="img_fill_frame" id="qImage3">
                     <div class="img_fill_add">                     
                     <span id="image_preview2">
                     <a data-toggle="modal" href="#image3Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                    
                  <!-- to display the cropped image -->
                     <div class="img_fill_frame" id="showQImage3" style="display:none">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage3();">
                     </div> 
                      <img id="showCroppedImg2" src=""  width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image3"  name="image3" style="display:none" />
                     <br/>
                    <input type="text" style="font-style:italic;text-align: center;" name="answer3" id="answer3" class="span10" placeholder="Answer" ></input>
                  </td> 
                  
             <!-- image 3 end -->  
                             
                 <!-- image 4 start -->  
                  
                              
                  <td>
                      <!-- to upload an image -->
                     <div class="img_fill_frame" id="qImage4">
                     <div class="img_fill_add">                     
                     <span id="image_preview3">
                     <a data-toggle="modal" href="#image4Popup">
                     <img src="<?php echo base_url();?>images/img_fill_add.png"  width="31" height="31" alt="" />
                     </a>                    
                     </span>
                     </div>
                    </div>
                    
                  <!-- to display the cropped image -->
                     <div class="img_fill_frame" id="showQImage4" style="display:none">
                     <div class="img_fill_img">
                     <div class="img_cross">
                      <img width="22" height="22" alt=""  src="<?php echo base_url();?>images/icon_cross_red.png" onclick="return deleteQImage4();">
                     </div> 
                      <img id="showCroppedImg3" src="" width="100" height="100"></img>                    
                     </div>
                    </div>
                    
                    <input type="file" id="image4"  name="image4" style="display:none" />
                     <br/>
                    <input type="text" style="font-style:italic;text-align: center;" name="answer4" id="answer4" class="span10" placeholder="Answer" ></input>
                  </td> 
                  
             <!-- image 4 end -->                            
            </tr>
                           
                           <tr>
                             <td colspan="5">
                                
                                <input type="checkbox" id="statusImg" name="simage" style="margin-top:0px" onclick='validate()' value="image">
                                 <i id="textColor" style="cursor:pointer">Proceed without an image</i>
                                
                               
                              </td>                           
                           </tr>
                           
                           
                            <tr>
                             <td colspan="5">
                             
                              <input type="checkbox" id="statusOpt" name="ex2_a" style="margin-top:0px" onclick='validatechk()'  value="ans">
                             <i id="textColorchk" style="cursor:pointer"> Proceed without an answer (chat only)</i>
                             </td>                           
                           </tr>
                           
                           
                           
                      </table>
                    </div>
                  </div>
                 </div> 
        </div>      
      </div> 
      
       <div class="container-fluid">
         <div class="row-fluid">
             <div class="container">
               <!--<div class="fleft" style="margin-top:15px;"> <a href="#"><< Back </a>	</div>  -->
              
               <div class="pull-right"> 
                   <button id="btn_send" type="button" class="butn b_red" onclick="return proceed();">PROCEED</button> 
               </div>            
             </div>         
         </div>   
   </div>   
  </div>


   <!-- image 1 popup start-->
 <div style="border-radius:0px; border:none;" id="image1Popup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > 
	<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" />
 </div>
		<div style="padding:15px;" class="modal-body">
			<input type="file" id="image_file" />
			<div id="showImageCropping" style="display:none;">
            <h1>Source</h1>
            <div id="image_input"></div>
            <h1>Crop</h1>
            <img id="image_output" style="border:1px solid #000"/>
            <button id="" class="butn" aria-hidden="true" data-dismiss="modal" onclick="return submitCroppedImage();" style="background-color:#ee5253">SUBMIT</button>
            </div>
            <!-- <textarea id="image_source" style="height:100px;width:200px"></textarea> -->		
	 </div>
</div> 
   
<!-- image 1 popup end-->



   <!-- image 2 popup start-->
 <div style="border-radius:0px; border:none;" id="image2Popup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > 
	<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" />
 </div>
		<div style="padding:15px;" class="modal-body">
			<input type="file" id="image_file1" />
			<div id="showImageCropping1" style="display:none;">
            <h1>Source</h1>
            <div id="image_input1"></div>
            <h1>Crop</h1>
            <img id="image_output1" style="border:1px solid #000"/>
            <button id="" class="butn" aria-hidden="true" data-dismiss="modal" onclick="return submitCroppedImage1();" style="background-color:#ee5253">SUBMIT</button>
            </div>
            <!-- <textarea id="image_source" style="height:100px;width:200px"></textarea> -->		
	 </div>
</div> 
   
<!-- image 2 popup end-->


<!-- image 3 popup start-->
 <div style="border-radius:0px; border:none;" id="image3Popup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > 
	<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" />
 </div>
		<div style="padding:15px;" class="modal-body">
			<input type="file" id="image_file2" />
			<div id="showImageCropping2" style="display:none;">
            <h1>Source</h1>
            <div id="image_input2"></div>
            <h1>Crop</h1>
            <img id="image_output2" style="border:1px solid #000"/>
            <button id="" class="butn" aria-hidden="true" data-dismiss="modal" onclick="return submitCroppedImage2();" style="background-color:#ee5253;">SUBMIT</button>
            </div>
            <!-- <textarea id="image_source" style="height:100px;width:200px"></textarea> -->		
	 </div>
</div> 
   
<!-- image 3 popup end-->


<!-- image 4 popup start-->
 <div style="border-radius:0px; border:none;" id="image4Popup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > 
	<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" />
 </div>
		<div style="padding:15px;" class="modal-body">
			<input type="file" id="image_file3" />
			<div id="showImageCropping3" style="display:none;">
            <h1>Source</h1>
            <div id="image_input3"></div>
            <h1>Crop</h1>
            <img id="image_output3" style="border:1px solid #000"/>
            <button id="" class="butn" aria-hidden="true" data-dismiss="modal" onclick="return submitCroppedImage3();" style="background-color:#ee5253;">SUBMIT</button>
            </div>
            <!-- <textarea id="image_source" style="height:100px;width:200px"></textarea> -->		
	 </div>
</div> 
   
<!-- image 4 popup end-->



<!-- createQ second Page start-->


  <div style="display:none;" id="createQPage2">
  
          <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_red">
               <div class="span7 devider_span">
                   <h4 class="red" >Q Details <span class="txt_n" style="font-style:italic">[Overview]</span> </h4> 
	          
	          
	          <table class="table_rows">
                <tr>
                   <td>
                    <div class="question fleft" id="qQuestionDisplay">
                    
                    </div>
                   </td>                
                </tr>	
                
                <tr>
                   <td>   
                    <div class="thumb_answers fleft">
                      <ul>
                        <?php //if((isset($_POST['simage']))){?>
                         <li>
                       
                            <img src="" id="qImageDisplay1" width="105" height="105" alt="" />
                             <div id="qDisplayOption1"></div>
                          
                            </li>
                          <li>
                            <img src="" id="qImageDisplay2" width="105" height="105" alt="" /> 
                            <div id="qDisplayOption2"></div> 
                           </li>
                          <li>
                          <img src="" id="qImageDisplay3" width="105"  height="105" alt="" /> 
                          <div id="qDisplayOption3"></div> 
                          </li>
                          <li>
                          <img src="" id="qImageDisplay4" width="105" height="105" alt="" />
                          <div id="qDisplayOption4"></div> 
                          </li>   
                             <?php // }?>                           
                      </ul>	                        
	                 </div>
	                </td>                
                </tr> 
                
                <tr>
                  <td>
                      <div style="margin-top:30px;"><input style="font-style:italic;width:465px" type="text" name="add_notes" id="add_notes" style="width:88%;" placeholder="Add notes" maxlength="100" /></div>                  
                  </td>                
                </tr> 
                 
	          </table>

               </div>  
               
               
               <div class="span5">
                  <h4 class="red">Send To <span class="txt_n" style="font-style:italic">[Select at least one of the following ] </span> </h4>
                      <table class="table_rows">
                           <tr>
                              <td colspan="2"><div class="question">Group</div></td>                           
                           </tr>
                           
                           <tr>
                             <td colspan="2">  
                             <?php 
                             $getUriSegment=$this->uri->segment(3);
                             
                             ?>
                             <div>
                                <div   style="float:left;"onclick="getselect()"   class="select_btn">
                                <?php if($defaultGroup!=0 && $getUriSegment!="groupId") {
                                	
                                   $getDefaultGroupName=$this->getdatamodel->getGroupDetailsById($defaultGroup);
                                   $defaultGroupName=$getDefaultGroupName[0]['name'];
                                ?>
                                 <div id="displaySelectedGroup"><?php echo $defaultGroupName;?></div>
                                <?php }elseif(($defaultGroup!=0 || $defaultGroup==0) && $getUriSegment=="groupId"){
                                	
                                       $getDefaultGroupName=$this->getdatamodel->getGroupDetailsById($uriGroupId);
                                       $defaultGroupName=$getDefaultGroupName[0]['name'];
                                	?>
                                	<div id="displaySelectedGroup"><?php echo $defaultGroupName;?></div>
                                	
                               <?php  }elseif($defaultGroup==0 && $getUriSegment!="groupId")  { ?>
                                  <div id="displaySelectedGroup">Select Group </div>
                                  <?php } ?>
                                  <div style="float:right;"><img src="<?php echo base_url();?>images/select_arrow.png" width="12" height="12" alt="" /></div> </div> 
                                   <div style="position:relative;">                                    
                                    <div id="selectbox" class="select_box" style="position:absolute; top:48px; left:0px;">
                                     <ul id='groupItem'> 
                                     <li> 
                                       <div data-toggle="modal"></div>
                                        <p class="fleft">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Select Group&nbsp; </p>
                                        <p class="group_count"></p> 
                                     </li>                                                                                  
                                          <?php 
                                          $sessionlog=$this->session->userdata('userID');
                                          $userGroups=$this->getdatamodel->getUserGroups($sessionlog);
                                          if($userGroups){
                                          foreach ($userGroups as $rec){                                          		
                                          $groupId=$rec['ID'];
						                  $totalCount=$this->getdatamodel->getGroupMemnbersCount($groupId);
						                  if($totalCount>1){
							              $groupName=$rec['name'];
							              $membersCount=$totalCount;
						                  }
                                          ?>
                                        <li > 
                                           <div onclick="showGroupsModal(<?php echo $groupId;?>);" class="eye_icon"></div>
                                           <p class="fleft" id="<?php if(!empty($groupId)){ echo $groupId;} else { echo '';}?>"><?php if(!empty($groupName)){echo $groupName;}else { echo '';}?></p>
                                           <p class="group_count"><?php if(!empty($membersCount)){echo $membersCount;}else { echo '';}?></p> 
                                            </li>
                                           <?php }} ?>
                                                                                    
                                        </ul>
                                        <?php if($defaultGroup!=0 && $getUriSegment!="groupId") { ?>
                                        <input type="hidden" name="selectedGroupId" id="selectedGroupId" value="<?php echo $defaultGroup;?>"></input>
                                        <?php }elseif(($defaultGroup!=0 || $defaultGroup==0) && $getUriSegment=="groupId") { ?>
                                        <input type="hidden" name="selectedGroupId" id="selectedGroupId" value="<?php echo $uriGroupId;?>"></input>
                                        <?php }elseif($defaultGroup==0 && $getUriSegment!="groupId")  {?>
                                         <input type="hidden" name="selectedGroupId" id="selectedGroupId" value=""></input>
                                        <?php }?>
                                    </div> 
                                   </div> 
                                     <div style="float:left;">&nbsp; </div>  
                             </div>

                             
                                                    
                             </td> 
                                        
                           </tr>
                           
                           <tr>
                             <td colspan="2"><div class="question">Social Media</div> </td>                           
                           </tr>
                           
                           <tr>
                              <td colspan="2">
                                <table width="100%" cellpadding="4"  style="font-style:italic;">
                                  <tr>
                                     <td width="200"> 
                                     <input type="checkbox" name="ex2_a" id="isPublic" style="margin-top:0px">
                                     <input type="hidden" name="hiddenFbId" id="hiddenFbId"></input>
                                      Post on <span style="font-weight:bold">QPals</span>
                                    </td>
                                    
                                      <td> 
                                      <input type="checkbox" id="isFbShare" onclick="return facebookShare();" style="margin-top:0px"/> 
                                       Post on <span style="font-weight:bold">Facebook</span>
                                     </td>                                  
                                  </tr> 
                                  
                                  <tr>
                                     <td> <input type="checkbox" id="isTwitterShare" onclick="return twitterShare();" style="margin-top:0px"/>
                                      Post on <span style="font-weight:bold">Twitter</span>
                                      </td>
                                      <td> 
                                       <input type="checkbox" id="isPinterestShare" style="margin-top:0px" /> 
                                       Post on <span style="font-weight:bold">Pinterest</span>
                                      </td>
                                      <input type="hidden" name="insertedQId" id="insertedQId"></input>                                  
                                  </tr>
                                                                 
                                </table>                              
                              </td>                           
                           </tr>
                                             
                      </table>
                  </div>
                 </div> 
        </div>      
      </div>    


   
    <!-- -------------------------- END CONTAINER---------------------------------   -->

  
    <div class="container-fluid">
         <div class="row-fluid">
             <div class="container">
               <div class="fleft" style="margin-top:15px;"> <a onclick="return createQPage1();" style="cursor:pointer"><< Back </a>	</div>
              
               <div class="pull-right" id="changeSend"> 
                   <button id="btn_send" type="button" class="butn b_red" onclick="return createQValidation();">SEND</button> 
               </div>            
             </div>         
         </div>   
   </div>
        
  
  
  
  
  </div>

</form>

 <!--  
modals -->
<div style="border-radius:0px; border:none;" id="rcbians" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div  data-dismiss="modal" class="close" style="" >
		<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" /></div>
					  <div style="padding:15px;" class="modal-body">
					     
                   				   
					   
					  </div>
			
					</div> 
 
 <!--  
modals -->

<!-- createQ second Page  end-->








<!-- display an Image priview for poup 1 -->

<script type="text/javascript">
$(function() {
    $("#image_file").on("change", function()
    {  
    	var avatar = $("#image_file").val();
        var extension = avatar.split('.').pop().toUpperCase();
        
        if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
            avatarok = 0;
            alert("invalid extension "+extension);
        }else{
         $('#showImageCropping').show();         
        
        }
    });
});
function validate() {
//alert("sdfdsfsdfds");
	//return false;
        if (document.getElementById('statusImg').checked) {
            //alert("checked");
            document.getElementById("textColor").style.color = "#ee5253";
        } else {
        	document.getElementById("textColor").style.color = "";
            //alert("You didn't check it! Let me check it for you.")
        }
    }
function validatechk() {
	//alert("sdfdsfsdfds");
		//return false;
	        if (document.getElementById('statusOpt').checked) {
	            //alert("checked");
	            document.getElementById("textColorchk").style.color = "#ee5253";
	        } else {
	        	document.getElementById("textColorchk").style.color = "";
	            //alert("You didn't check it! Let me check it for you.")
	        }
	    }
</script>

<!-- script for cropping an Image -->

<script>
 var inputFile = document.getElementById('image_file');
 inputFile.addEventListener('click', function() {this.value = null;}, false);
 inputFile.addEventListener('change', readData, false);

function readData(evt) {
	evt.stopPropagation();
	evt.preventDefault();
	var file = evt.dataTransfer !== undefined ? evt.dataTransfer.files[0] : evt.target.files[0];
	var reader = new FileReader();
	reader.onload = (function(theFile) {
	return function(e) {
		var image = new Image();
		image.src = e.target.result;
		image.onload = function() {
		var canvas = document.createElement('canvas');
		canvas.width = 300;
		canvas.height = image.height * (300 / image.width);
		var ctx = canvas.getContext('2d');
		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

		$('#image_input').html(['<img src="', canvas.toDataURL("image/jpeg"), '"/>'].join(''));
		
		var img = $('#image_input img')[0];
		var canvas = document.createElement('canvas');

		$('#image_input img').Jcrop({
			bgColor: 'black',
			bgOpacity: .6,
			setSelect: [0, 0, 400, 400],
			aspectRatio: 1,
			onSelect: imgSelect,
			onChange: imgSelect
		});

		function imgSelect(selection) {
			canvas.width = canvas.height = 400;

			var ctx = canvas.getContext('2d');
			ctx.drawImage(img, selection.x, selection.y, selection.w, selection.h, 0, 0, canvas.width, canvas.height);
		
			$('#image_output').attr('src', canvas.toDataURL("image/jpeg"));
			$('#image_source').text(canvas.toDataURL("image/jpeg"));
			
		}
		}
	}
	})(file);
	reader.readAsDataURL(file);
}

 //submit the cropped image1
  function submitCroppedImage(){	 
	 var cropImage=$('#image_output').attr("src");	
	 //alert(cropImage);
	 $('#showCroppedImg').attr('src', cropImage); 
	 //$('#qImageDisplay1').attr('src', cropImage);	
	 $('#showQImage1').show();	 
	 $('#qImage1').hide();
	

	  
  }

  //delete cropped image 
  function deleteQImage1(){
	  $("#showCroppedImg").attr("src"," ");
	  $('#qImageDisplay1').attr("src"," ");	  
	  $('#qImage1').show(); 
	  $("#showQImage1").hide();
	 
  }

</script>

  



<!-- display an Image priview for poup 1 end-->






<!-- display an Image priview for poup 2 -->

<script type="text/javascript">
$(function() {
    $("#image_file1").on("change", function()
    {  
    	var avatar = $("#image_file1").val();
        var extension = avatar.split('.').pop().toUpperCase();
        
        if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
            avatarok = 0;
            alert("invalid extension "+extension);
        }else{
         $('#showImageCropping1').show();         
        
        }
    });
});
</script>

<!-- script for cropping an Image -->

<script>
 var inputFile = document.getElementById('image_file1');
 inputFile.addEventListener('click', function() {this.value = null;}, false);
 inputFile.addEventListener('change', readData1, false);

function readData1(evt) {
	evt.stopPropagation();
	evt.preventDefault();
	var file = evt.dataTransfer !== undefined ? evt.dataTransfer.files[0] : evt.target.files[0];
	var reader = new FileReader();
	reader.onload = (function(theFile) {
	return function(e) {
		var image = new Image();
		image.src = e.target.result;
		image.onload = function() {
		var canvas = document.createElement('canvas');
		canvas.width = 300;
		canvas.height = image.height * (300 / image.width);
		var ctx = canvas.getContext('2d');
		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

		$('#image_input1').html(['<img src="', canvas.toDataURL("image/jpeg"), '"/>'].join(''));
		
		var img = $('#image_input1 img')[0];
		var canvas = document.createElement('canvas');

		$('#image_input1 img').Jcrop({
			bgColor: 'black',
			bgOpacity: .6,
			setSelect: [0, 0, 400, 400],
			aspectRatio: 1,
			onSelect: imgSelect,
			onChange: imgSelect
		});

		function imgSelect(selection) {
			canvas.width = canvas.height = 400;

			var ctx = canvas.getContext('2d');
			ctx.drawImage(img, selection.x, selection.y, selection.w, selection.h, 0, 0, canvas.width, canvas.height);
		
			$('#image_output1').attr('src', canvas.toDataURL("image/jpeg"));
			$('#image_source1').text(canvas.toDataURL("image/jpeg"));
			
		}
		}
	}
	})(file);
	reader.readAsDataURL(file);
}

 //submit the cropped image1
  function submitCroppedImage1(){	 
	 var cropImage=$('#image_output1').attr("src");	
	 
	 $('#showCroppedImg1').attr('src', cropImage); 
	 $('#qImageDisplay2').attr('src', cropImage);	 
	 $('#showQImage2').show();	 
	 $('#qImage2').hide(); 
  }

  //delete cropped image 
  function deleteQImage2(){
	  $("#showCroppedImg1").attr("src"," ");
	  $('#qImageDisplay2').attr("src"," ");	  
	  $("#showQImage2").hide();
	  $('#qImage2').show(); 
  }

</script>

  



<!-- display an Image priview for poup 2 end-->




<!-- display an Image priview for poup 3 -->

<script type="text/javascript">
$(function() {
    $("#image_file2").on("change", function()
    {  
    	var avatar = $("#image_file2").val();
        var extension = avatar.split('.').pop().toUpperCase();
        
        if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
            avatarok = 0;
            alert("invalid extension "+extension);
        }else{
         $('#showImageCropping2').show();         
        
        }
    });
});
</script>

<!-- script for cropping an Image -->

<script>
 var inputFile = document.getElementById('image_file2');
 inputFile.addEventListener('click', function() {this.value = null;}, false);
 inputFile.addEventListener('change', readData2, false);

function readData2(evt) {
	evt.stopPropagation();
	evt.preventDefault();
	var file = evt.dataTransfer !== undefined ? evt.dataTransfer.files[0] : evt.target.files[0];
	var reader = new FileReader();
	reader.onload = (function(theFile) {
	return function(e) {
		var image = new Image();
		image.src = e.target.result;
		image.onload = function() {
		var canvas = document.createElement('canvas');
		canvas.width = 300;
		canvas.height = image.height * (300 / image.width);
		var ctx = canvas.getContext('2d');
		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

		$('#image_input2').html(['<img src="', canvas.toDataURL("image/jpeg"), '"/>'].join(''));
		
		var img = $('#image_input2 img')[0];
		var canvas = document.createElement('canvas');

		$('#image_input2 img').Jcrop({
			bgColor: 'black',
			bgOpacity: .6,
			setSelect: [0, 0, 400, 400],
			aspectRatio: 1,
			onSelect: imgSelect,
			onChange: imgSelect
		});

		function imgSelect(selection) {
			canvas.width = canvas.height = 400;

			var ctx = canvas.getContext('2d');
			ctx.drawImage(img, selection.x, selection.y, selection.w, selection.h, 0, 0, canvas.width, canvas.height);
		
			$('#image_output2').attr('src', canvas.toDataURL("image/jpeg"));
			$('#image_source2').text(canvas.toDataURL("image/jpeg"));
			
		}
		}
	}
	})(file);
	reader.readAsDataURL(file);
}

 //submit the cropped image1
  function submitCroppedImage2(){	 
	 var cropImage=$('#image_output2').attr("src");	
	 
	 $('#showCroppedImg2').attr('src', cropImage);
	 $('#qImageDisplay3').attr('src', cropImage); 	 
	 $('#showQImage3').show();	 
	 $('#qImage3').hide(); 
  }

  //delete cropped image 
  function deleteQImage3(){
	  $("#showCroppedImg2").attr("src"," ");
	  $('#qImageDisplay3').attr("src"," ");	  
	  $("#showQImage3").hide();
	  $('#qImage3').show(); 
  }

</script>

  



<!-- display an Image priview for poup 3 end-->


<!-- display an Image priview for poup 4 -->

<script type="text/javascript">
$(function() {
    $("#image_file3").on("change", function()
    {  
    	var avatar = $("#image_file3").val();
        var extension = avatar.split('.').pop().toUpperCase();
        
        if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
            avatarok = 0;
            alert("invalid extension "+extension);
        }else{
         $('#showImageCropping3').show();         
        
        }
    });
});
</script>

<!-- script for cropping an Image -->

<script>
 var inputFile = document.getElementById('image_file3');
 inputFile.addEventListener('click', function() {this.value = null;}, false);
 inputFile.addEventListener('change', readData3, false);

function readData3(evt) {
	evt.stopPropagation();
	evt.preventDefault();
	var file = evt.dataTransfer !== undefined ? evt.dataTransfer.files[0] : evt.target.files[0];
	var reader = new FileReader();
	reader.onload = (function(theFile) {
	return function(e) {
		var image = new Image();
		image.src = e.target.result;
		image.onload = function() {
		var canvas = document.createElement('canvas');
		canvas.width = 300;
		canvas.height = image.height * (300 / image.width);
		var ctx = canvas.getContext('2d');
		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

		$('#image_input3').html(['<img src="', canvas.toDataURL("image/jpeg"), '"/>'].join(''));
		
		var img = $('#image_input3 img')[0];
		var canvas = document.createElement('canvas');

		$('#image_input3 img').Jcrop({
			bgColor: 'black',
			bgOpacity: .6,
			setSelect: [0, 0, 400, 400],
			aspectRatio: 1,
			onSelect: imgSelect,
			onChange: imgSelect
		});

		function imgSelect(selection) {
			canvas.width = canvas.height = 400;

			var ctx = canvas.getContext('2d');
			ctx.drawImage(img, selection.x, selection.y, selection.w, selection.h, 0, 0, canvas.width, canvas.height);
		
			$('#image_output3').attr('src', canvas.toDataURL("image/jpeg"));
			$('#image_source3').text(canvas.toDataURL("image/jpeg"));
			
		}
		}
	}
	})(file);
	reader.readAsDataURL(file);
}

 //submit the cropped image1
  function submitCroppedImage3(){	 
	 var cropImage=$('#image_output3').attr("src");	
	 
	 $('#showCroppedImg3').attr('src', cropImage);
	 $('#qImageDisplay4').attr('src', cropImage); 	 
	 $('#showQImage4').show();	 
	 $('#qImage4').hide(); 
  }

  //delete cropped image 
  function deleteQImage4(){
	  $("#showCroppedImg3").attr("src"," ");
	  $('#qImageDisplay4').attr("src"," ");	  
	  $("#showQImage4").hide();
	  $('#qImage4').show(); 
  }

</script>

  



<!-- display an Image priview for poup 4 end-->









  <script>
   function get_settings() {
   	$(".toggle_wrapper").fadeToggle();
   }


   function getselect() {
   	 $("#btn_send").toggleClass("b_red");
   	 $("#btn_send").toggleClass("strike_s");
   	 $("#selectbox").fadeToggle(200);            
   	 }


   function get_question() {
   	 
      $("#questionbox").fadeToggle(200);           
   	
   }


   $(document).ready(function () {//jquery for drop down select box
   	  $(".select_box ul li").click(function () {
   		$("#questionbox").fadeToggle(200);  
   	   $(this).addClass("select");    	
    
   	   $(".select_box ul li.select").siblings().removeClass("select")

   	   $(this).addClass("select");  	   
   	      
   	        
   });
   });
</script>


   
  <!-- jquery to show selected question in the text box and display images and options for selected questions-->  
   <script>   
    $(document).ready(function(){

        $('#uItem li').click(function(){

        	 var question = $.trim($(this).text()); 
        	 var questionId=$(this).attr("id");        	       	 
        	 $('#questionName').val(question);
        	 var questionDispalyName=$('#questionName').val();
        	 $('#qQuestionDisplay').text(questionDispalyName);
             $('#selectedQId').val(questionId);
        	 if(questionId !=""){
        		 var base_url="<?php echo base_url('qCreate/fetchPredefinedOptions');?>";
                 $.post(base_url,{questionId:questionId},function(response){

                     var data=response;                     
                     var arr = data.split('/');
                     $('#answer1').val(arr[0]);                    
                     $('#answer2').val(arr[1]);
                     $('#qDisplayOption1').html(arr[0]);
                     $('#qDisplayOption2').html(arr[1]);
                   });

                 var base_url="<?php echo base_url('qCreate/fetchPredefinedIcons');?>";

                 $.post(base_url,{questionId:questionId},function(response){

                     var img=response;                    
                     if(img!=""){
                     $('#showCroppedImg').attr('src', img);
                    $('#qImageDisplay1').attr('src', img);
                     $('#showQImage1').show();
                     $('#qImage1').hide(); 
                     }
                   });
            	 
        	 }
        	
          });

      });
   </script>
   
   
   <script>

   $('#groupItem li .fleft').click(function(){

  	 var groupName = $.trim($(this).text()); 
  	 
  	 var groupId=$(this).attr("id");
  	 //alert(groupId);
  	 $('#selectedGroupId').val(groupId);
  	  var data=groupName;                     
     //var data1 = data.substring(0,data.length - 1); 
     //alert(arr);    	       	 
  	 $('#displaySelectedGroup').text(data);
  	 $("#selectbox").fadeToggle(200); 
  	
    });
   
   </script>
   
   
   <!-- below is the jquery script for q validations before clicking procceed -->
   
   <script>
   
       function proceed(){

           var questionName=$('#questionName').val();
           var img1        =$('#showCroppedImg').attr('src');
           var img2        =$('#showCroppedImg1').attr('src');
           var img3        =$('#showCroppedImg2').attr('src');
           var img4        =$('#showCroppedImg3').attr('src');
           var opt1        =$('#answer1').val(); 
           var opt2        =$('#answer2').val();
           var opt3        =$('#answer3').val(); 
           var opt4        =$('#answer4').val(); 

           //alert(img1);

            if(questionName==""){
                alert("Please enter a question.");
                return false;
            }

            if($('#statusImg').prop('checked')!=true && $('#statusOpt').prop('checked')!=true 
               && opt1=="" && opt2=="" && opt3=="" && opt4=="" && $('#showCroppedImg').attr('src')=="" 
               && $('#showCroppedImg1').attr('src')=="" && $('#showCroppedImg2').attr('src')==""
               && $('#showCroppedImg3').attr('src')==""){            	
               alert('Please add one or more images and answers or check Proceed with an image and Proceed without an answer.');
               return false;
            }else if($('#statusImg').prop('checked')!=true && $('#statusOpt').prop('checked')==true
            		&& opt1=="" && opt2=="" && opt3=="" && opt4=="" && $('#showCroppedImg').attr('src')=="" 
                    && $('#showCroppedImg1').attr('src')=="" && $('#showCroppedImg2').attr('src')==""
                    && $('#showCroppedImg3').attr('src')==""){

                alert('Please add Images or check boxes for Proceed without an image.');
                return false;
            }else if($('#statusImg').prop('checked')==true && $('#statusOpt').prop('checked')!=true
            		&& opt1=="" && opt2=="" && opt3=="" && opt4=="" && $('#showCroppedImg').attr('src')=="" 
                    && $('#showCroppedImg1').attr('src')=="" && $('#showCroppedImg2').attr('src')==""
                    && $('#showCroppedImg3').attr('src')==""){
                    alert('Please add answers or check Proceed without an answer.');
                    return false;
            }


            if($('#statusOpt').prop('checked')!=true
               && (opt1 !="" && opt2 ==""  && opt3 ==""  && opt4 =="")){

                alert('Please add an answer below each image or check Proceed without an answer');
                return false;
            }else if((opt1 =="" && opt2 ==""  && opt3 ==""  && opt4 =="") && 
                    ($('#showCroppedImg').attr('src')!="" 
                    || $('#showCroppedImg1').attr('src')!="" || $('#showCroppedImg2').attr('src')!=""
                    || $('#showCroppedImg3').attr('src')!="") && 
                    ($('#statusOpt').prop('checked')!=true)){

                alert('Please add an answer below each image or check Proceed without an answer');
                return false;
            }else if(($('#showCroppedImg').attr('src')=="" 
                    && $('#showCroppedImg1').attr('src')=="" && $('#showCroppedImg2').attr('src')==""
                    && $('#showCroppedImg3').attr('src')=="") && 
                    (opt1 !="" || opt2 !=""  || opt3 !=""  || opt4 !="") &&
                    ($('#statusImg').prop('checked')!=true)){
                  alert('You have not uploaded the images. Please upload the images or select Proceed without an image.');
                  return false;
            }
           
            proceedtoNextPage();
           
           
       }

       function proceedtoNextPage(){

    	   var cropImage=$('#showCroppedImg').attr("src");
    	  // alert(cropImage);
    	   if(cropImage){
    	   $('#qImageDisplay1').attr('src', cropImage);
    	   }	

    	   var questionDispalyName=$('#questionName').val();
      	 $('#qQuestionDisplay').text(questionDispalyName);
           
           $('#createQPage2').show();
           $('#createQPage1').hide();

           var answer1=$('#answer1').val();
           var answer2=$('#answer2').val();
           var answer3=$('#answer3').val();
           var answer4=$('#answer4').val();
           
           $('#qDisplayOption1').html(answer1);
           $('#qDisplayOption2').html(answer2);
           $('#qDisplayOption3').html(answer3);
           $('#qDisplayOption4').html(answer4);

           if($('#showCroppedImg').attr('src')=="" && answer1!=""){
               var img="<?php echo base_url().'Uploads/ProfilePictures/avatar.png'?>";               
        	   $('#qImageDisplay1').attr('src', img);
        	   
           }

           if($('#showCroppedImg1').attr('src')=="" && answer2!=""){
               var img="<?php echo base_url().'Uploads/ProfilePictures/avatar.png'?>";               
        	   $('#qImageDisplay2').attr('src', img);
        	   
           }

           if($('#showCroppedImg2').attr('src')=="" && answer3!=""){
               var img="<?php echo base_url().'Uploads/ProfilePictures/avatar.png'?>";               
        	   $('#qImageDisplay3').attr('src', img);
        	   
           }

           if($('#showCroppedImg3').attr('src')=="" && answer4!=""){
               var img="<?php echo base_url().'Uploads/ProfilePictures/avatar.png'?>";               
        	   $('#qImageDisplay4').attr('src', img);
        	   
           }

           
           
       }


       function createQPage1(){
    	   $('#createQPage2').hide();
           $('#createQPage1').show();

          
       }
   
   </script>
   
   
   <script>
   
    function createQValidation(){
    	var groupId     =$('#selectedGroupId').val();
    	var groupSelect =$.trim($('#displaySelectedGroup').text());
         //alert(groupSelect);
    	if(groupId==0 && $('#isPublic').prop('checked')!=true && $('#isFbShare').prop('checked')!=true
    	    && $('#isTwitterShare').prop('checked')!=true && $('#isPinterestShare').prop('checked')!=true && groupSelect=="Select Group")
        {
            alert("Please select at least one group or social network to send your Q");
            return false;
    	}
    	createQ();
    }
   
   </script>
   
   <script>
   
     function createQ(){

        
    	 var questionName=$('#questionName').val();
    	 var groupId     =$('#selectedGroupId').val();
    	 //alert(groupId);
         var fbId= $('#hiddenFbId').val();            
           
           
         if($('#statusImg').prop('checked')!=true){
             var isNoImg=1;
         }else{
        	 var isNoImg=0;
         }

         if($('#statusOpt').prop('checked')!=true){
            var isNoAns =1;
         }else{
        	var isNoAns =0;
         }


         if($('#isPublic').prop('checked')==true){
             var isPublic =1;
             var accessType=1;
          }else{
         	var isPublic =0;
         	var accessType=0;
          }

         if($('#isFbShare').prop('checked')==true){
             var isFbShare =1;
            
          }else{
         	var isFbShare =0;
         	var fbId=0;
          }

         


         if($('#isTwitterShare').prop('checked')==true){
             var isTwitterShare =1;
          }else{
         	var isTwitterShare =0;
          }

         if($('#isPinterestShare').prop('checked')==true){
             var isPinterestShare =1;
          }else{
         	var isPinterestShare =0;
          }

         
    	 
         var img1        =$('#showCroppedImg').attr('src');
         var img2        =$('#showCroppedImg1').attr('src');
         var img3        =$('#showCroppedImg2').attr('src');
         var img4        =$('#showCroppedImg3').attr('src');
         var opt1        =$('#answer1').val(); 
         var opt2        =$('#answer2').val();
         var opt3        =$('#answer3').val(); 
         var opt4        =$('#answer4').val(); 
         var notes       =$('#add_notes').val();
         var base_url    ="<?php echo base_url('qCreate/insertQ');?>";
         var userId      ="<?php echo $this->session->userdata('userID');?>";

          //alert(img1);
          //alert(img2);
        


         $.ajax({
             type: "POST",
             url : base_url,
             data: ({questionName:questionName,isNoImg:isNoImg,isNoAns:isNoAns,accessType:accessType,isFbShare:isFbShare,isTwitterShare:isTwitterShare,
            	 isPinterestShare:isPinterestShare,opt1:opt1,opt2:opt2,opt3:opt3,opt4:opt4,userId:userId,groupId:groupId,img1:img1,img2:img2,img3:img3,img4:img4,fbId:fbId,notes:notes}),           
            
               success: function(responseReg){               
             
               // $('btn_send').
                if(responseReg!=""){
                //alert(responseReg); 
                    var vInputString = responseReg;
                    var vArray = vInputString.split("@");
                    var vRest=vArray[0];
                    var vRes = vArray[1];
                    var vRes1 =vArray[2];
                	 //alert(vRes);              	
                	var url1 = "<?php echo base_url('qwall/qwallView/1');?>";
           			window.location = url1;
           			//return false;
                	 if($('#isPinterestShare').prop('checked')==true){
                    	pintrestShare(vRes,vRes1,vRest);
                	 }
                	

                }
             
         }
      });
         
  }  


  </script>
   
   

   <!--below script for stylish checkboxes -->
   	<script src="<?php echo base_url();?>js/jquery.screwdefaultbuttonsV2.js"></script>
   	<script type="text/javascript">
   		$(function(){

   			$('input:radio').screwDefaultButtons({
   				image: 'url("../images/radioSmall.jpg")',
   				width: 43,
   				height: 43
   			});

   			


   		});
   	</script>
   	
   	<!--above script for stylish checkboxes -->
   	
   	<style type="text/css">
          
          	.styledRadio, .styledCheckbox {
   			display: inline-block;
   		}

      </style>
   
   <!-- script for facebook share -->
   
   <script>
   window.fbAsyncInit = function() {
	   var base_url="<?php echo base_url()."qCreate/createQ";?>";
	    FB.init({
	      appId      : '<?php echo $this->config->item('appId');?>', // App ID
	      channelUrl : base_url, // Channel File
	      status     : true, // check login status
	      cookie     : true, // enable cookies to allow the server to access the session
	      xfbml      : true  // parse XFBML
	    });
 }
      function facebookShare(){    	 
          
    	  FB.login(function(response) {
   		   if (response.authResponse) 
   		   {    
   		    	getUserInfo();
     			} else 
     			{     		
     	    	 console.log('User cancelled login or did not fully authorize.');
      			}
   		 },{scope: 'email,read_stream,publish_stream'});
      }



      function getUserInfo() {
    	
  	    FB.api('/me', function(response) {

  	    fbId=response.id;
  	    $('#hiddenFbId').val(fbId);	  	 
  	      	  
  	  	  	    
        });

       
      }

   // Load the SDK asynchronously
      (function(d){
         
         var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
         if (d.getElementById(id)) {return;}
         js = d.createElement('script'); js.id = id; js.async = true;
         js.src = "//connect.facebook.net/en_US/all.js";
         ref.parentNode.insertBefore(js, ref);
       }(document));
   </script>
  
  
   <script>

      function twitterShare(){    	  
     	  var base_url="<?php echo base_url()."qCreate/twitterLogin";?>";
     	  //alert(base_url);
    	  window.open(base_url,"",
    	  "width=800, height=480,scrollbars, location=1");window.opener.location.reload(true);
      }
   
   </script>
   
   
   <script>

   function htmlspecialchars(str) {
	   return str.replace('&', '&amp;').replace('"', '&quot;').replace("'", '&#039;').replace('<', '&lt;').replace('>', '&gt;');
	 }

     function pintrestShare(vRes,vRes1,qId){
    	var image=htmlspecialchars(vRes);
    	var question=htmlspecialchars(vRes1);
    	var link=window.location.protocol+"//"+window.location.host+"/qwall/viewQ/"+qId;
    	
    	var url=htmlspecialchars(link);
    	window.open("http://www.pinterest.com/pin/create/button/?url="+url+"&media="+image+"&description="+question,"_blank");
     }
     function showGroupsModal(val)
     {
         //alert(val);
          $("#rcbians").modal("show");
         //var htmlStatic = "text coming from controller"+val;
         //$(".modal-body").html(htmlStatic);
            var base_url    ="<?php echo base_url('qCreate/getGroupMembers');?>";
            $.post(base_url,{val:val},function(response){
        	  $(".modal-body").html(response);

           });
        
     }
         
   
   </script>
  


    <?php $this->load->view('footerView');?>
