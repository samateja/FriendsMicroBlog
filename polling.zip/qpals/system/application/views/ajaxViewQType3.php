 
 <!-- Added by Padmaja 13-05-2014 -->
 <?php	$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
  ?>
    <link rel="stylesheet" href="<?php echo base_url();?>css/colorbox.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="<?php echo base_url();?>js/jquery.colorbox.js"></script>
		<script>
			$(document).ready(function(){
			
				$(".group1").colorbox({rel:'group1'});
						
					$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
 <div class="row" id="viewQtype3">
        <?php 
        $oCount = 0;
	    $getAggregateVotes = NULL;
	   
        foreach($getQOptions as $row) {
        	       $optionId=$row['ID'];	
                   $optionName=$row['optionName'];
					if($optionName){
					$option  =$row['optionName'];	
					}else{
					$option  ='';	
					}	
			        $imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
					if($imgNamethumb){
					$thumb=$this->_S3Url.$imgNamethumb;
					$image=$this->_S3Url.$imgNamePhoto;
					
					}else{
					$thumb=base_url()."Uploads/QImages/default_thumb.png";
					$image=base_url()."Uploads/QImages/default.png";
					
					}
					
					
	                $idName = "PB_".$oCount;
	                if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{			
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					
					}//end of else
					
                    $getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					if($getCountQVotesOptions[0]['qCount']>0){
					$isVoted	     = TRUE;	
					}else{
					$isVoted	     = FALSE;
					}
        	
        	?>
           <div class="span3 thumbs_group"> 
                <div style="position:relative">
                   <button <?php if($isVoted==TRUE) {?>class="answer_yes answer_tick_yes"<?php }else{ ?>class="btn_answer2 answer_tick"<?php }?> onclick="return voteAnswer(<?php echo $optionId; ?>);">
                   </button>
                 </div>  
                  <a class="group1" href="<?php echo $image;?>">
                  <img src="<?php echo $thumb;?>" width="290" height="290" alt="" />
                   </a>                   
                   <table class="table_rows" cellpadding="4" style="margin-top:10px;">
                      <tr>
                         <td class="f_bold"><?php echo $option;?></td>                       
                       </tr>
                       
                       <tr>
                         <td> 
                         <?php if($resPerc!=0) { ?>
                          <div class="progress_wrap">
                            <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $optionName;?>');"><div></div></div>
                            <div class="progress_yes_cross"></div>
                             &nbsp; &nbsp;
                            <span class="f_bold"><?php //echo $resPerc.'%';?></span> 
                             </div>
                             <?php }else{?>
                             <div class="progress_wrap">
                            <div class=""></div>
                            <div class="progress_yes_cross"></div>
                             &nbsp; &nbsp;
                            <span class="f_bold"><?php echo $resPerc.'%';?></span> 
                             </div>
                             <?php }?>
                         </td>
                       </tr>
               
                      </table>
                    </div>
                    <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script> 
                    
             <?php $oCount++; } ?>
              </div>
              
              
              
              
              
    