  
  <?php $this->load->view('headerView');?>
 
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
   <style type="text/css">


		
		#tabs {
      margin-top: 2em;		
		}
		
		#tabs ul li {
		border-bottom:1px solid #339999;
		width:33%;
		}
		
		#tabs ul li.tab_active {
      border-top:1px solid #339999;
      border-left:1px solid #339999;
      border-right:1px solid #339999;
      border-bottom: 1px solid #339999;		
		
		}
		
		#tabs ul li a {
      color: #339999;
      	
		}

		
 
    </style>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  <?php 
  $groupId=$this->uri->segment(3);?>
  
  <form method="post" id="editGroup" action="<?php echo base_url()."groups/updateGroup/$groupId"; ?>" enctype="multipart/form-data">
 <div class="container-fluid">
  <div class="alert alert-success" id="successMessage" style="display:none;">Successfully updated</div>
      <div class="row-fluid">
        <div class="container content_inner h_line_blue">
        <?php 
        if($groupData){
        	$gName		= $groupData[0]['name'];
        	if($groupData[0]['thumb'] != 'group_thumb.png'){
        		$thumb		=$this->_S3Url.$groupData[0]['thumb'];
        	}else{
        		$thumb= base_url()."Uploads/GroupImages/group_thumb.png";
        	}
        	//$thumb     = 'http://'.$bucket.'.s3.amazonaws.com/'.$groupData[0]['thumb'];
        	//$thumb      = base_url()."Uploads/GroupImages/".$groupData[0]['thumb'];
        }
        
        ?>
               <div class="span5 devider_span">
                   <h4 class="f_blue">Group name</h4> 
	                   <table width="100%" class="form_profile">
	                     <tr>
	                       <td>
	                       <input name="groupName" id="groupName" value="<?php echo $gName;?>" type="text" class="span9" />
	                        <span style="color: red;" id="groupValidity"></span>
	                       </td>
	                     </tr>
	                                  
	                   </table>
	                   
	                   <h4 class="f_blue">Group Photo </h4> 
	                   
	                  
	                  <table class="form_profile">
	                     <tr>
	                       <td>
	                       <div class="img_profile" >
	                        <div class="img_cross_blue">
	                        <img onclick="return deleteGroupImage();" width="22" height="22" alt="" src="<?php echo base_url();?>images/icon_cross_blue.png">
	                        </div>
	                        <span id="groupImageShow">
	                        <img width="105" height="105" alt="" src="<?php echo $thumb;?>" id="previewHolder" >
	                        </span>
	                        <input type="file" name="groupImage" id="groupImage"  class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg"></input>
	                        </div>
	                        </td>
	                     </tr>
	                   
	                   </table> 
	                   <div class="clear" style="height: 191px;"></div>                   
	                   <h4 class="f_blue">Group Pals</h4>
	                   
	                   <div class="tab_grouppals">
	                      <ul>
	                         <?php 
                           if($registeredGroupMemberesData){
						   foreach ($registeredGroupMemberesData as $groupMember){
						 // print_r($groupMember);  
						// print_r($groupMember);die;	
						    $name = $groupMember['firstName'];
						    $deldEmail = $groupMember['email'];
							$memberId= $groupMember['ID'];
						   	if($groupMember['thumb'] != 'avatar_thumb.png'){
								$thumb		=$this->_S3Url.$groupMember['thumb'];
							}else{
								$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							}
							//$thumb= 'http://'.$bucket.'.s3.amazonaws.com/'.$groupMember['thumb'];
							$photo= $this->_S3Url.$groupMember['photo'];
							$isCreator=$groupMember['isCreator'];
							$userType= 1;
						      
						      ?>                               
                               
                               <li>  
                                  <table>
					                     <tr>
					                       <td>
					                       <div class="img_grouppals">
					                        <div class="img_cross_blue">
					                        <img onclick="return deleteRegisteredMembers(<?php echo $memberId;?>,'<?php echo $gName;?>','<?php echo $name;?>','<?php echo $deldEmail;?>')" width="22" height="22" alt="" src="<?php echo base_url();?>images/icon_cross_blue.png">
					                        </div> 
					                        <img width="80" height="80" alt="" src="<?php echo $thumb;?>"></div>  
				                            
				                            	<span class="f_italic f_blue"> <?php echo $name;?></span>                     
					                        </td>
				                   
				 	                     </tr>
					                   </table> 
                               </li>
                                                           
                               <?php }}?>
                               
                               <?php if($nonregisteredGroupMembersData) {
                               	foreach ($nonregisteredGroupMembersData as $nonRegGroupMember){
                               $nonRegId= $nonRegGroupMember['ID'];		
                               $name= $nonRegGroupMember['name'];
                               $email= $nonRegGroupMember['email'];							   
							   $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							   $photo= base_url()."Uploads/ProfilePictures/avatar.png";
			                   $userType= 2;
                               ?>
                               
                               
                                <li>  
                                  <table>
					                     <tr>
					                       <td>
					                       <div class="img_grouppals">
					                        <div class="img_cross_blue">
					                        <img onclick="return deleteNonRegisteredMembers(<?php echo $nonRegId;?>,'<?php echo $name;?>','<?php echo $email;?>','<?php echo $gName;?>')" width="22" height="22" alt="" src="<?php echo base_url();?>images/icon_cross_blue.png">
					                        </div> 
					                        <img width="80" height="80" alt="" src="<?php echo $thumb;?>"></div>  
				                            
				                            	<span class="f_italic f_blue"> <?php echo $name;?></span>                     
					                        </td>
				                   
				 	                     </tr>
					                   </table> 
                               </li> 
                               <?php }}?>
                               
                               <?php if($fbGroupMembersData){
                               	foreach ($fbGroupMembersData as $fbGroupMemberData){
                               	$name = $fbGroupMemberData['name'];
							    $FBID= $fbGroupMemberData['FBID'];;
							    $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							    $photo= base_url()."Uploads/ProfilePictures/avatar.png";
							    $userType= 3;
                               	?>
                               	
                               	<li>  
                                  <table>
					                     <tr>
					                       <td>
					                       <div class="img_grouppals">
					                        <div class="img_cross_blue">
					                        <img  width="22" height="22" alt="" src="<?php echo base_url();?>images/icon_cross_blue.png">
					                        </div> 
					                        <img width="80" height="80" alt="" src="<?php echo $thumb;?>"></div>  
				                            
				                            	<span class="f_italic f_blue"> <?php echo $name;?></span>                     
					                        </td>
				                   
				 	                     </tr>
					                   </table> 
                               </li>  
                               <?php }}?>
	                      </ul>
	                   </div>
	                
                      </div> 
               
               
               <div class="span7">
                 <h4 class="f_blue">Add Pals
                   <div class="pull-right" id="showFollowingSearch">
                    <input type="text" name="searchInFollowing" id="searchInFollowing" placeholder="Type name/email/following" class="search_input" />
                    <img  onclick="return searchFollowing();" src="<?php echo base_url();?>/images/search_group.png"></img>
                     </div>
                     
                     <div class="pull-right" id="showFollowerSearch" style="display:none;">
                    <input type="text" name="searchInFollower" id="searchInFollower" placeholder="Type name/email/follower" class="search_input" />
                    <img  onclick="return searchFollower();" src="<?php echo base_url();?>/images/search_group.png"></img>
                     </div>
                   </h4>
                    <div id="tabs">
								 <ul class="tabs" id="tabsnav">
								  <li><a href="#tab-1" class="tab menu-internal" onclick="return showFollowing();">Following (<?php echo $countOfFollowing;?>)</a></li>
								  <li><a href="#tab-2" class="tab menu-internal" onclick="return showFollower();">Followers (<?php echo $countOfFollowers;?>)</a></li>
								 <!--  <li><a href="#tab-3" class="tab menu-internal">Facebook (186)</a></li>
							    -->
							    </ul>
								 
								 <div id="tab-1">
								     
                           <div class="list_addpals" id="divFollowingPals">
                              <ul>
                                <?php 
								  if($followingPals){//if received Q's								  	
								  	foreach($followingPals as $rec){
								  		 
								    $fUserId=$rec['followers_ID'];
			                        $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
								  	 if($userData[0]['thumb'] != 'avatar_thumb.png'){
			                        	$thumb		=$this->_S3Url.$userData[0]['thumb'];
			                        }else{
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }
						            //$thumb= 'http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName= $userData[0]['displayName'];	
						            if($registeredGroupMemberesData){
						            foreach ($registeredGroupMemberesData as $groupMember){
							           $groupMemberArr[]	= $groupMember['ID'];							           
							           
						             }
						             
						             if(in_array($fUserId,$groupMemberArr)){
						             	$checked=1;
						             }else{
						             	$checked=0;
						             }
						           }else{
						           	$checked=0;
						           }
						            
								  ?>
                                <li>
                                   <table cellpadding="4">
									 <tr>
										<td><input type="checkbox" name="checkFollowing[]" id="checkFollowing" value="<?php echo $fUserId;?>"  <?php if($checked==1) {?>checked<?php }?>/></td>
										<td><img src="<?php echo $thumb;?>" width="40" height="40" alt="" /></td>
										<td><?php echo $displayName; ?></td>
									</tr>
								</table>                                
                                </li>
                               <?php }}?>
                            </ul>                           
                           </div>   								     
								     
								 </div>
								 
								 <div id="tab-2">
								  <div class="list_addpals" id="divFollowerPals">
                              <ul>
                               <?php 
								  if($followers){//if received Q's								  	
								  	foreach($followers as $rec){ 
								  		
								  	$fUserId=$rec['user_ID'];
				                    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				                    //$thumb =
								  	 if($userData[0]['thumb'] != 'avatar_thumb.png'){
			                        	$thumb		=$this->_S3Url.$userData[0]['thumb'];
			                        }else{
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }
						            //$thumb   ='http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName=$userData[0]['displayName'];

								  	 if($registeredGroupMemberesData){
						            foreach ($registeredGroupMemberesData as $groupMember){
							           $groupMemberArr[]	= $groupMember['ID'];							           
							           
						             }
						             
						             if(in_array($fUserId,$groupMemberArr)){
						             	$checked=1;
						             }else{
						             	$checked=0;
						             }
								   }else{
								   	$checked=0;
								   }
						             ?>
                                <li>
                                   <table cellpadding="4">
									 <tr>
										<td><input type="checkbox" name="checkFollower[]" id="checkFollower" value="<?php echo $fUserId;?>" <?php if($checked==1) {?>checked<?php }?>/></td>
										<td><img src="<?php echo $thumb;?>" width="40" height="40" alt="" /></td>
										<td><?php echo $displayName; ?></td>
									</tr>
								</table>                                
                                </li>
                               <?php }
								  }?>
                            </ul>                           
                           </div> 
								 </div>
								 
								 <div id="tab-3">
								  <h3>Tab 3</h3>
								   <p>Facebook(95)</p>
								 </div>
							</div> 						
						
							<div class="pull-right">
			                 <span>
                             &nbsp;
			                </span> 
				          <br>
				         </div> 
				         
				         <div>
			   <table width="100%" class="form_profile">
	                     <tr>
	                       <td width="100" class="lable_profile">Email</td>
	                       <td width="40">
	                       <img src="<?php echo base_url();?>images/icon_email.png" width="28" height="28" alt="" />
	                       </td>
	                       <td>
	                       <input type="text" placeholder="Enter Email" name="customEmail[]" value="" style="width:100%">                      
	                       
	                        <div  class="icon_add">
	                        <div id="addemail">
	                         <div data-toggle="tooltip" data-placement="bottom" title="ADD MORE"> 
	                        <span id="addButton" ><img  onclick="return allValidations()" src="<?php echo base_url();?>images/icon_add.png" width="22" height="22" alt="" style="padding-right:24px;" /></span>
	                      </div></div>
	                      
	                      </div> 
	                       </td>
	                     </tr>
	                     
	                     <tr>
	                     <td width="100" class="lable_profile">&nbsp;</td>
	                     <td width="40"></td>
	                     <td>
	                     <div id="TextBoxesGroup">
	                      <div id="TextBoxDiv1" >
	                      
                          
                         </div>
                         </div>
                         </td>
	                     </tr>
	                  </table>
			</div> 
							
                    </div>
               </div> 
        </div>      
      </div>    

      
      
         <div class="container-fluid">
         <div class="row-fluid">
             <div class="container">
               <div class="pull-right"> 
                 <button class="butn">CANCEL</button>  
                 <button class="butn b_blue" type="button" name="updateGroup" onclick="return validateGroup();">Update</button> 
               </div>            
             </div>         
         </div>   
   </div>
  </form>
  
  <!-- delete registered member -->
  
  <script>
  
    function deleteRegisteredMembers(memberId,gName,deldName,deldEmail){

        $(document).ready(function(){

           var groupId=<?php echo $this->uri->segment(3);?>		   
   		   var base_url="<?php echo base_url('groups/deleteGroupMember');?>";
   		   $.post(base_url,{groupId:groupId,memberId:memberId,gName:gName,deldName:deldName,deldEmail:deldEmail},function(response){
      	    //$('#groupImageShow').html(response);
   			location.reload(true); 
   			//return false;  			
   			  
         });
        }); 
    }
  </script>
  
  <!-- delete non registered group memebrs -->
  <script>
       function readURL(input) {
           if (input.files && input.files[0]) {
               var reader = new FileReader();
               reader.onload = function(e) {
                   $('#previewHolder').attr('src', e.target.result);
               }

               reader.readAsDataURL(input.files[0]);
           }
       }
       $("#groupImage").change(function() {
           //alert("sdfdsf");
           readURL(this);
       });
   </script>
  <script>
  
    function deleteNonRegisteredMembers(nonRegId,dNname,dNemail,gName){
    	 $(document).ready(function(){

             var groupId=<?php echo $this->uri->segment(3);?>		   
     		   var base_url="<?php echo base_url('groups/deleteNonRegGroupMember');?>";
     		   $.post(base_url,{groupId:groupId,nonRegId:nonRegId,dNname:dNname,dNemail:dNemail,gName:gName},function(response){
        	    //$('#groupImageShow').html(response);
     			location.reload(true);  
				//return false;			
     			  
           });
          });
    }
  </script>
  
  
   <!-- delete Image -->  
   <script>

     function deleteGroupImage(){

    	 $(document).ready(function(){
  		   
  		   var groupId=<?php echo $this->uri->segment(3);?>		   
  		   var base_url="<?php echo base_url('groups/deleteGroupImage');?>";
        	   $.post(base_url,{groupId:groupId},function(response){
          	    $('#groupImageShow').html(response);  
             });

  	 });

     }
   
   </script>
  
   
   <!-- following script -->
   <script type="text/javascript">

     function showFollowing(){

         $(document).ready(function(){

           $('#showFollowingSearch').show();
           $('#showFollowerSearch').hide();

        });

     }
   
   
   </script>
   
   <script type="text/javascript">

   function searchFollowing(){
      
	   $(document).ready(function(){
		   var searchFriend=$('#searchInFollowing').val();
		   var groupId=<?php echo $this->uri->segment(3);?>		   
		   var base_url="<?php echo base_url('groups/searchFollowing');?>";
      	   $.post(base_url,{searchFriend:searchFriend,groupId:groupId},function(response){
        	    $('#divFollowingPals').html(response);  
           });

	 });


   }
   
   
   </script>
   
   
   <!--end of following script -->
   
   <!-- follower script -->
   
   
   <script type="text/javascript">

     function showFollower(){

         $(document).ready(function(){

           $('#showFollowingSearch').hide();
           $('#showFollowerSearch').show();

        });

     }
   
   
   </script>
   
   
   <script type="text/javascript">

   function searchFollower(){
      
	   $(document).ready(function(){
		   var searchFriend=$('#searchInFollower').val();
		   var groupId=<?php echo $this->uri->segment(3);?>		   
		   var base_url="<?php echo base_url('groups/searchFollower');?>";
      	   $.post(base_url,{searchFriend:searchFriend,groupId:groupId},function(response){
        	    $('#divFollowerPals').html(response);  
           });

	 });


   }
   
   
   </script>
   
   
    <!-- end of follower script -->   
    
    
    
     <!-- add custom email -->
  <script type="text/javascript">
  function validate()
	{ 
		var custonEmail = document.getElementsByName("customEmail[]");		
		
	    for(var i=0;i< custonEmail.length; i++) {	    				
			if(custonEmail[i].value == ""){				
				alert('The email field is required.');			
				custonEmail[i].focus();
				return false;
			}

			var EmailId = custonEmail[i].value;
			var emailfilter = /(([a-zA-Z0-9\-?\.?]+)@(([a-zA-Z0-9\-_]+\.)+)([a-z]{2,3}))+$/;
			if((EmailId != "") && (!(emailfilter.test(EmailId ) ) )) {
			   
			    alert('Please enter your valid email address.');
			    return false;
			}			   
			
		}
		return true;
   }

  
  

  function allValidations()
  {	
	var success =  validate();
	if(success){		
	addRow();
	}
	
  }

  function addRow(){		
	    $('#TextBoxDiv1').append('<div><input type="text" style="width:100%;"  name="customEmail[]" id="customEmail"></div>');	            
	  }
  </script>
 
    
    
    
    
    <!-- Group Validation -->
    
   <script type="text/javascript">

     function validateGroup(){

       $(document).ready(function(){

    	   var groupName=$('#groupName').val();
           
           if(groupName==""){
               alert('Please enter Group Name');
               return false;
           }      
        
         
         var groupId=<?php echo $this->uri->segment(3);?>		   
         var base_url="<?php echo base_url('groups/validateGroup');?>";
         var groupImage=$('#groupImage').val();       
         
      	 $.ajax({
               url: base_url,
               type: 'post',
               data: { groupName: groupName,groupId:groupId,groupImage:groupImage },
               success:function(data){                   
	                 if(data){
		                 alert(data);
	                	 //$('#groupValidity').html(data);
	                	 return false;
	                 }else{//if valid data
	                	 document.getElementById("editGroup").submit();
	                	 $('#successMessage').show(10);
	                 } 
                 }
           });

        
           
        });
       
     }

   </script>
    
 
    
    
    
    
    
   
  <script type="text/javascript">

$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });





</script>
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>

    <?php $this->load->view('footerView');?>