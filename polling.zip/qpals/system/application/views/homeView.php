  
  <?php $this->load->view('frontendHeader');?>
  <script>
  $(".sada").click(function(e){
	    var targetOffset= $("#c").offset().top;
	    $('html, body').animate({scrollTop: targetOffset}, 500);
	    e.preventDefault();    
	});	  
  $(document).ready(function(){
 /* $('#video').on('click', function() {
	    $(this).html('');
	});*/
  $('#video').click(function(){
	  var video = '<iframe src="'+ $(this).attr('data-video') +'" style="width:940px;height:537px" ></iframe>';
	  $('#QpalsImg').hide();
	  $(this).replaceWith(video); 
	  });
  });
  </script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
   <div class="container" style="margin-top: 125px;">
        <div class="row">
        <div style="position: relative; left: 0; top: 0;">
  <img src="<?php echo base_url();?>videos/Qpalsmp4.jpg" style="position: relative; top: 0; left: 0;" id="QpalsImg"/>
  <img src="<?php echo base_url();?>images/video_play.png" style="position: absolute; top: 3px;left: 0;cursor:pointer " id="video" data-video="videos/Qpals-final.mp4"/>
</div>
 <div class="container">
        <div class="row">
         
         <div class="container" style="margin-top:24px;margin-left:80px">
         
          <div class="span4 txt_center">
               
          </div>
          <div class="span6 txt_center">
               
                <div> <a href="https://www.indiegogo.com/projects/qpals-vote-follow-and-chat-with-bffs-and-others" >
          <div class="span4 txt_center"style="margin-left:67%">
 
            <div style="color:#000000;margin-top:30px; font-size:18px;width: 177px;
margin: 30px auto;margin-left:-121px">Check Out Our Indiegogo campaign!</div>

          <div class="span4 txt_center" style="float:right;margin-top:-110px">
			   
           <div> <img src="<?php echo base_url();?>images/indegogo.png" width="170" height="92" alt="">  </div>
          
          </div> 
                  
        </div>
          </div>
         </div>
             </a>      
               
               
               
          </div>
         
        </div>      
      </div>
      


        <!--  <div id="video">video</div>
         <div class="image_tn"><a href="videos/Qpals-final.mp4" data-webm="<?php echo base_url();?>images/play_icon.png" class="html5lightbox"><img src="<?php echo base_url();?>videos/Qpalsmp4.jpg"></a></div>
         <div>
         
         <img src="<?php echo base_url();?>images/play_icon.png"  alt="">
          <video style="width:940px;"   poster="videos/Qpalsmp4.jpg" controls>
            <source src="videos/Qpals-final.mp4" type="video/mp4">
            <source src="videos/Qpals-final.ogg" type="video/ogg">
          
          </video>
         </div>
             -->      
        </div>      
    </div>
    <div class="container">
        <div class="row">
         <div class="container" style="margin-top:40px;">
         
          <div class="span4 txt_center">
            <div><img src="<?php echo base_url();?>images/icon_createping.png" width="170" height="190" alt="">   </div>
             <div style="font-size:30px; color:#c40000; font-family:roboto-bold;">Create a Q</div>  
             <div  style="color:#000000;margin-top:30px; font-size:18px; width: 212px;text-align: center;
margin: 30px auto;"> Create a poll using photos, questions and answers.</div>     
          </div>
          
          <div class="span4 txt_center">
           <div><img src="<?php echo base_url();?>images/icon_friendsreply.png" width="170" height="190" alt=""></div>
         
           
            <div style="font-size:30px; color:#b4b312; font-family:roboto-bold;">Your friend's reply</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;width: 177px;
margin: 30px auto;"> Your friends reply using our free apps or by email. </div>
          </div>
          
          
          <div class="span4 txt_center">
           <div> <img src="<?php echo base_url();?>images/icon_results.png" width="170" height="190" alt="">  </div>
            
            <div style="font-size:30px; color:#c40000; font-family:roboto-bold;">Get Results</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;width: 225px;
margin: 30px auto;"> Get results and chat with your friends. </div>
          </div>         
        
         </div>
                   
        </div>      
      </div>
      
			  
			  <div class="container-fluid">
		  <div class="row-fluid">
			<div class="span2">
			  <!--Sidebar content-->
			</div>
			<div class="span10">
			  <!--Body content-->
			</div>
		  </div>
		</div>
      
      
      
      
         <div class="container">
        <div class="row">
         <div class="container" style="margin-top:40px;">
          <div class="row">
            <div style="margin-left:10px;" class="span4">
              <img src="<?php echo base_url();?>images/pic_iphone.png" width="387" height="748" alt="">            
            </div>
            
             <div style="margin-left:40px; width:590px;" class="span8" id="c">
              <div style="color:#cccb32; font-size:46px; font-family:roboto-bold; margin-bottom:40px; margin-top:20px;">
              ABOUT US
              </div>
 
              <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;">
           Like most of you, we like to share photos and polls with our friends.  With a close group of private friends or through popular social networks, like Facebook, Twitter and Pinterest.  We also wanted to make it easier for friends to make group decisions (e.g. where to go for dinner tonight), but couldn't find a cool and easy way to do it quickly.  So we scratched our heads and developed QPals - it's an easy and fun way to poll your friends with all kinds of questions.  You can also just chat with them, if you like.
              </p>
              
              <br>
					
					 <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;">
					Simply send a "Q" to your close group of friends or to all your friends and followers on popular social networks. Your close friends will get an alert and you'll get your answer instantly - it's faster and more fun than texting or calling all your friends one by one. 
					</p>
					
					<br>
					
					<p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;">
					We're already working on the next version of QPals, with even more cool features. If you have any ideas that you love to have added, please let us know by emailing us at <a href="mailto:ideas@qpals.com" target="_blank" style="color:#333333;text-decoration: underline !important;">ideas@qpals.com.</a>
					 </p>
  
  
              <table style="margin-top:2em;" cellpadding="4">
                <tbody><tr>
			<!--
                  <td> <a href="https://www.facebook.com/qpalsapp.india?ref=hl" target="_blank">  <img src="<?php echo base_url();?>images/icon_facebook.png" width="81" height="82" alt="" />  </a> </td>
                  <td> <a href=" https://twitter.com/qpalsappindia" target="_blank">  <img src="<?php echo base_url();?>images/icon_twitter.png" width="81" height="82" alt="" />    </a> </td>
                  <td> <a href="https://plus.google.com/113050843251767726227/" target="_blank">  <img src="<?php echo base_url();?>images/icon_gplus.png" width="81" height="82" alt="" />  </a></td>               
                -->
                </tr>              
              </tbody></table>
             </div>          
          </div>
         </div>
         </div>
         </div>
         
         <!--
	       <div class="container" style="background-color:#f3f3f3; padding-bottom:40px; margin-top:60px;">
	        <div class="row">
	         <div class="container" style="margin-top:40px;">
	          <div class="row">
	         
	          <div class="span8">
               <img src="<?php echo base_url();?>images/saying.png" width="328" height="132" alt="" />
               
               <br>
               <div class="row">
               
               
               <div style="margin-left:10px;" class="span4 box_quotes">
                <div style="padding:35px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="">
                   <div style="" class="heading_quotes">i Love it</div>
                   <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;margin-top: 20px;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>  
                </div>             
               </div>
               
               
               <div style="margin-left:10px;" class="span4 box_quotes">
                <div style="padding:35px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="">
                   <div style="" class="heading_quotes">best app</div>
                   <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;margin-top: 20px;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum </p>  
                </div>             
               </div>

               </div>	          
	          </div>
	          
	          
	          
	          <div class="span3" style="width:250px;">
	           <div class="row">
               <div class="box_quotes">
                <div style="padding:35px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="">
                   <div style="" class="heading_quotes">best app</div>
                  
                  <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;margin-top: 20px;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>  
                </div>             
               </div>
             
               
                <div class="box_quotes box_green">
                <div style="padding:35px;">
                   <img src="<?php echo base_url();?>images/stars_green.png" width="148" height="37" alt="">
                   <div style="" class="heading_quotes">best app</div>
                    <div style="height: 42px;" class="clear"></div>
                   <p style="font-size:16px; line-height:30px; text-align:justify;  color:#333333;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>  
                </div>             
               </div> 
               </div>              
               
	          </div>

	          </div>
	         </div>
	        </div>
	       </div>
		-->
    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
