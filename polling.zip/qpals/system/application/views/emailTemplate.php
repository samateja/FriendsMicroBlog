<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body style="padding:0px; margin:0px; font-size:12px; color:#333333; background-color:#eeeeee;">
<div id="email-wrapper" style="width:600px; background-color:#ffffff; height:auto; font-family:arial,sans-serif;  margin:0 auto;" >

<div style="margin-top:15px; margin-bottom:15px;">
</div>
   <div id="email-header" style="width:100%; height:110px; background-color:#575656;">
    <div style="float:left; padding:25px; padding-top:45px; padding-left:20px;">
     <div style="float:left;"><img src="<?php echo base_url();?>images/logo_email.png" width="100" height="46" alt="" /> </div>   <div style="color:#ffffff; font-style:italic; float:left; font-weight:bold; padding-top:15px; padding-left:22px;">
     &quot;Poll the world, or just a few close friends. It&#39;s easy, fun and free.&quot;</div>   </div>
        
   </div>
   <div id="mail-text" style="float:left; width:100%;"><div style="padding-top:15px; padding-bottom:15px;">
    
    <div style="padding-left:20px; padding-right:20px;"> 
    <p><?php echo $message;?></p>
    <br>
   </div> 
  
 </div>
   
   
   
   </div>
   <div id="email-footer" style="background-color:#575757; width:100%; height:40px; float:left;">
     <div style="padding-left:20px; padding-right:20px;"><table width="100%">
        <tr>
          <td  style="color:#ffffff; text-align:left; font-style:italic; font-size:16px; padding-top:10px; padding-bottom:10px; font-size:10px; ">Copyright &copy; 2014 QPals. All rights reserved.</td> 
          <td align="right"> <img style="margin-right:10px;" src="<?php echo base_url();?>images/thumb-03.png" width="42" height="21" alt="" /></td>       
        </tr>  
        
        
  
     </table>   
     </div>
   </div>
   
   <div style="padding-left:20px; padding-right:20px; margin-top:20px; float:left; padding-bottom:10px;">Get the best QPals experience with our mobile apps</div>
   
   <div style="padding-left:20px; padding-right:20px; clear:both; margin-bottom:15px;"> <a href="https://itunes.apple.com/us/app/qpals/id863931895?mt=8" target="_blank"><img src="<?php echo base_url();?>images/icon_appstore.png" width="125" height="40" alt="" /></a>  &nbsp; &nbsp;   <a href="https://play.google.com/store/apps/details?id=com.adttech.qpals" target="_blank"><img src="<?php echo base_url();?>images/icon_googleplay.png" width="125" height="40" alt="" /> </a>&nbsp; &nbsp; <a href="http://www.windowsphone.com/en-us/store/app/qpals/805a90fa-8f52-4178-9076-ac71441576ec" target="_blank"><img src="<?php echo base_url();?>images/icon_windows.png" width="125" height="40" alt="" /></a> </div>   
   
</div>
</body>
</html>