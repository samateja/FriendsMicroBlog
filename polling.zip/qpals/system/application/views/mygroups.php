  
  <?php $this->load->view('headerView');?>
	<!--  Added by Padmaja -->
 
    
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
	<style type="text/css">
	#searchAllGroup:focus{
/*text-align:left;*/
}	
</style>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
 <div class="container-fluid">
      <div class="row-fluid" id="showGroup">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;">
        
        <div class="row">
        <?php if($userGroups){$i=1; 
        	foreach($userGroups as $userGroup){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($userGroup['user_ID'], $userGroup['group_ID']);
			if($isNewGroupActivity){
				$isNew=$isNewGroupActivity[0]['isNew'];
			}else{
				$isNew=0;
			}
			$gName			= $userGroup['name'];
			//echo$thumb			= $userGroup['thumb'];
			if($userGroup['thumb'] != 'group_thumb.png'){
				$thumb			= $this->_S3Url.$userGroup['thumb'];
			}else{
				$thumb= base_url()."Uploads/GroupImages/group_thumb.png";
			}
			//$thumb			= base_url()."Uploads/GroupImages/".$userGroup['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($userGroup['ID']);
			$url='groups/viewGroup/'.$userGroup['ID'];
        ?>
                 
           
                    <div class="span3 thumbs_group asd"> 
                    <a href="<?php echo base_url($url);?>">
                    <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />
                    </a>                    
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php //echo $gName;
                        $countString=strlen($gName);
                        if($countString > 15){
                        $groupName= substr($gName, 0,15);
                      	 $groupName =strtoupper($groupName);
                        echo $groupName.'...';
                        }else{
                        $gName = strtoupper($gName);
                        echo $gName;
                        }
                        ?></div></td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group" style="font-style:italic"><span class="f_bold_italic"><?php echo $membersCount;?></span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>                
                 <?php if($i%4==0){echo "</div><div class='row'>";}?>  
             
              
          <?php $i++;}}else{ ?>
          <div style="top:40%;left:40%;position:absolute;color:#339999">
           You have no groups 
           </div>
          <?php } ?>    
              
          </div>      
           </div> 
        </div> 
        
        
      <div class="row-fluid" id="showICreated" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;">
        
        <div class="row">
        <?php
       
        if($groupsCreatedDetails){$j=1; 
        	foreach($groupsCreatedDetails as $groupCreated){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupCreated['user_ID'], $groupCreated['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
			$gName			= $groupCreated['name'];
			$thumb			= $groupCreated['thumb'];
        	if($groupCreated['thumb'] != 'group_thumb.png'){
				$thumb			= $this->_S3Url.$groupCreated['thumb'];;
			}else{
				$thumb= base_url()."Uploads/GroupImages/group_thumb.png";
			}
			
			//$thumb			= base_url()."Uploads/GroupImages/".$groupCreated['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($groupCreated['ID']);
			$url='groups/viewGroup/'.$groupCreated['ID'];
        ?>
                 
           
                    <div class="span3 thumbs_group sdf"> 
                     <a href="<?php echo base_url($url);?>"><img src="<?php echo $thumb;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                      <td> <div class="question"><?php //echo $gName;
                        $countString=strlen($gName);
                        if($countString > 15){
                        $groupName= substr($gName, 0,15);
                      	 $groupName =strtoupper($groupName);
                        echo $groupName.'...';
                        }else{
                        $gName = strtoupper($gName);
                        echo $gName;
                        }
                        ?></div></td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group"><span class="f_bold_italic"><?php echo $membersCount;?></span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>                
                   
             <?php if($j%4==0){echo "</div><div class='row'>";}?>  
              
          <?php $j++;}}else{ ?>
           <div style="top:40%;left:40%;position:absolute;color:#339999">
           You have no groups 
           </div>
          <?php }?>    
              
          </div>      
           </div> 
        </div> 
        
        
        
        
         <div class="row-fluid" id="showJoinedGroups" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;">
        
        <div class="row">
        <?php if($groupsJoinedDetails){ $k=1;
        	foreach($groupsJoinedDetails as $groupJoined){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupJoined['user_ID'], $groupJoined['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
			$gName			= $groupJoined['name'];
        	if($groupJoined['thumb'] != 'group_thumb.png'){
				$thumb			= $this->_S3Url.$groupJoined['thumb'];
			}else{
				$thumb= base_url()."Uploads/GroupImages/group_thumb.png";
			}
			//$thumb			= $this->_S3Url.$groupJoined['thumb'];
			//$thumb			= base_url()."Uploads/GroupImages/".$groupJoined['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($groupJoined['ID']);
			$url='groups/viewGroup/'.$groupJoined['ID'];
        ?>
                 
           
                    <div class="span3 thumbs_group"> 
                     <a href="<?php echo base_url($url);?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />
                      </a>                    
                       
                      <table class="table_rows">
                     <tr>
                      <td> <div class="question"><?php //echo $gName;
                        $countString=strlen($gName);
                        if($countString > 15){
                        $groupName= substr($gName, 0,15);
                      	 $groupName =strtoupper($groupName);
                        echo $groupName.'...';
                        }else{
                        $gName = strtoupper($gName);
                        echo $gName;
                        }
                        ?></div></td>                       
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group"><span class="f_bold_italic"><?php echo $membersCount;?></span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>                
                   
             <?php if($k%4==0){echo "</div><div class='row'>";}?>  
              
          <?php $k++;}}else{ ?>
          <div style="top:40%;left:40%;position:absolute;color:#339999">
           You have no groups 
           </div>
          <?php }?>    
              
          </div>      
           </div> 
        </div>      
      
      </div>


   <!-- script for showall groups -->
   
   <script type="text/javascript">

     function showAllGroup(){
           
      $(document).ready(function(){
    	  $('#allGroups').html('<li class="select" style="cursor:pointer;" onclick="return showAllGroup()">Show All</li>');
    	  $('#ICreated').html('<li  style="cursor:pointer;" onclick="return showIcreated()">I Created</li>');
    	  $('#IJoined').html('<li  style="cursor:pointer;" onclick="return showJoinedGroups()">I Joined</li> ');  
    	  $('#showGroup').show();
    	  $('#showAllSearch').show();
    	  $('#showICreated').hide();
      	  $('#showCreatedSearch').hide();
    	  $('#showJoinedGroups').hide();
    	  $('#showIJoinedSearch').hide();
      });
         
         
     }

   </script>
   
   <script type="text/javascript">

     function searchAllGroups(){
      
         $(document).ready(function(){

             var searchText=$('#searchAllGroup').val();
            
             var base_url="<?php echo base_url('groups/searchGroups');?>"; 
             $.post(base_url,{searchText:searchText},function(response){
               	 
                 $('#showGroup').html(response);
               });

          });
     }  
   
   </script>
   
   <!-- script for Icreated -->
   
  <script>
    function showIcreated(){
        
        $(document).ready(function(){
          $('#allGroups').html('<li  style="cursor:pointer;" onclick="return showAllGroup()">Show All</li>');
          $('#ICreated').html('<li style="cursor:pointer;" class="select" onclick="return showIcreated()">I Created</li>');
          $('#IJoined').html('<li  style="cursor:pointer;" onclick="return showJoinedGroups()">I Joined</li> ');
          $('#showGroup').hide();
      	  $('#showAllSearch').hide();
      	  $('#showICreated').show();
      	  $('#showCreatedSearch').show();
      	  $('#showJoinedGroups').hide();
    	  $('#showIJoinedSearch').hide();
      });
    }
  </script>
  
  
  <script type="text/javascript">

     function searchCreatedGroups(){
      
         $(document).ready(function(){

             var searchText=$('#searchCreatedGroup').val();
            
             var base_url="<?php echo base_url('groups/searchCreatedGroup');?>"; 
             $.post(base_url,{searchText:searchText},function(response){
               	 
                 $('#showICreated').html(response);
               });

          });
     }  
   
   </script>
   
   
   <!-- script for I joined -->
   
   <script>
    function showJoinedGroups(){
        
        $(document).ready(function(){
          $('#allGroups').html('<li  style="cursor:pointer;" onclick="return showAllGroup()">Show All</li>');
          $('#ICreated').html('<li  style="cursor:pointer;" onclick="return showIcreated()">I Created</li>');
          $('#IJoined').html('<li  style="cursor:pointer;" class="select" onclick="return showJoinedGroups()">I Joined</li> ');
          $('#showGroup').hide();
      	  $('#showAllSearch').hide();
      	  $('#showICreated').hide();
      	  $('#showCreatedSearch').hide();
      	  $('#showJoinedGroups').show();
      	  $('#showIJoinedSearch').show();
      });
    }
  </script>
  
  <script type="text/javascript">

     function searchJoinedGroups(){
      
         $(document).ready(function(){

             var searchText=$('#searchJoinedGroup').val();
            
             var base_url="<?php echo base_url('groups/searchJoinedGroup');?>"; 
             $.post(base_url,{searchText:searchText},function(response){
               	 
                 $('#showJoinedGroups').html(response);
               });

          });
     }  
   
   </script>
<?php if(!empty($enableJS)){?>
<script>
  $( document ).ready(function() {
	  showIcreated();
	  });
  </script>
<?php }?>


    <?php $this->load->view('footerView');?>
