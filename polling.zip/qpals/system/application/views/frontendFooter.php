  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
      
        <div class="container-fluid footer_bg">
      <div class="row-fluid">
        <div class="container">
         <div class="span6">        
        
 		      <div class="footer_home">
		        <ul>
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>home#c" class="sada" >About</a></li>
                <li><a href="<?php echo base_url();?>faqs">FAQ's</a></li>
                <li><a href="#myModal" role="button"  data-toggle="modal" style="margin-left: -9px;">Login</a></li>		        
		        </ul>
		        
		        <div style="clear:both; font-size:18px; color:#ffffff; padding-top:45px; "> Copyright © 2014 QPals. All rights reserved. </div>
		      </div>            
           </div> 
           
             <div class="span6 pull-right"> <div style="float:right;"> 
             <div style="color:#ffffff; margin-bottom:18px; font-size:30px;">Available on: </div>
               <div> <a href="https://itunes.apple.com/us/app/qpals/id863931895?mt=8" target="_blank">
               <img src="<?php echo base_url();?>images/app_iphone.png" width="130" height="44" alt=""></a>   &nbsp;  &nbsp;
               <a href="https://play.google.com/store/apps/details?id=com.adttech.qpals" target="_blank"><img src="<?php echo base_url();?>images/app_android.png" width="130" height="44" alt=""></a> 
               &nbsp;  &nbsp;
               
               <a href="http://www.windowsphone.com/en-us/store/app/qpals/805a90fa-8f52-4178-9076-ac71441576ec" target="_blank"><img src="<?php echo base_url();?>images/app_windows.png" width="130" height="44" alt=""></a>
               
                  </div>             
             </div> 
             </div>          
            
        </div>      
      </div>    
    </div> 
     <!-- -------------------------- END CONTAINER---------------------------------   -->     
      
      



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
    <script src="<?php echo base_url();?>js/bootstrap-transition.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-alert.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-modal.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-dropdown.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tab.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tooltip.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-popover.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-button.js"></script>
  	<script src="<?php echo base_url();?>js/bootstrap-collapse.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-carousel.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-typeahead.js"></script>


   
   <script type="text/javascript">





$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



</script>
    
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>
  </body>
</html>
