  
  <?php $this->load->view('headerView');?>
  
  	<!--  Added by Padmaja -->

  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
 <div class="container-fluid">
   
   
      <div class="row"  id="showMessage" style="display:none;">         
       <div class="alert alert-success" id="successMessage"></div>
                    	
    </div>
 
 
      <div class="row-fluid">
      
      <?php 
      
      if($groupData){
      	
      	$gName		= $groupData[0]['name'];
       $thumb      = $this->_S3Url.$groupData[0]['photo'];
      //	$thumb      = base_url()."Uploads/GroupImages/".$groupData[0]['photo'];
      if($groupData[0]['photo'] != 'group.png'){
				$thumb			= $this->_S3Url.$groupData[0]['photo'];
			}else{
				$thumb= base_url()."Uploads/GroupImages/group_thumb.png";
			}
      	
      }
      
      ?>
      
      
        <div class="container content_inner h_line_profile">
               <div class="span5 devider_span">
                   <h4 class="f_black"><?php if(!empty($gName)) {echo 	$gName;} elseif(empty($gName)){ echo '';} ?></h4> 
                    <div class="man_group">  <span class="bold_italic"><?php if(!empty($membersCount)) {echo $membersCount;}elseif(empty($membersCount)){ echo '';}?></span> Pals </div>
                    
                         <div class="row">
	                   
	                         <div class="style_bigprofile">
	                         <img src="<?php if(!empty($thumb)) {echo $thumb;}else{ echo $thumb;}?>" width="355" height="355" alt="" /> 
	                         </div>
	                       
	                       </div>
	              
	                   
	                   <h4 class="f_blue">Group Pals</h4> 
	                   
	                   <div class="tab_grouppals">
	                         <ul>
                              
                         <?php 
                           if($registeredGroupMemberesData){
						   foreach ($registeredGroupMemberesData as $groupMember){
						      	
						    $name = $groupMember['displayName'];
							$memberId= $groupMember['ID'];
							$thumb= $this->_S3Url.$groupMember['thumb'];
							if($groupMember['thumb'] != 'avatar_thumb.png'){
								$thumb		=$this->_S3Url.$groupMember['thumb'];
							}else{
								$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							}
							$photo= $this->_S3Url.$groupMember['photo'];
							$isCreator=$groupMember['isCreator'];
							$userType= 1;
						      
						      ?> 
                               <li>
                                 <table width="100%">
	                                <tr>
					                   <td>
					                     <a href="<?php echo base_url();?>findPals/viewPals/<?php echo $memberId;?>">
					                     <img src="<?php echo $thumb;?>" width="80" height="80" alt="" />
					                     </a>
					                     </td>
					                   </tr>
				                     
					                    <tr>
				                         <td>
				                         <?php if($isCreator==1){?>
				                         <div class="f_italic  f_blue"><?php echo $name?></div>
				                         <?php }else{ ?>
				                         <div class="f_italic"><?php echo $name;?></div>
				                         <?php }?>
				                         </td>
					                     </tr>
	                                     
	                              </table>                              
                               </li>                              
                               <?php }}?>
                               
                               <?php if($nonregisteredGroupMembersData) {
                               	foreach ($nonregisteredGroupMembersData as $nonRegGroupMember){
                               //	echo "sadsad";die;	
                               $name= $nonRegGroupMember['name'];							   
							   $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							   $photo= base_url()."Uploads/ProfilePictures/avatar.png";
			                   $userType= 2;
                               ?>
                                 <li>
                                 <table width="100%">
	                                <tr>
					                   <td>
					                     <img src="<?php echo $thumb;?>" width="80" height="80" alt="" />
					                     </td>
					                   </tr>
				                     
					                    <tr>
				                         <td>				                         
				                         <div class="f_italic"><?php echo $name;?></div>
				                         
				                         </td>
					                     </tr>
	                                     
	                              </table>                              
                               </li>  
                               <?php }}?>
                               
                               <?php if($fbGroupMembersData){
                               	foreach ($fbGroupMembersData as $fbGroupMemberData){
                               	$name = $fbGroupMemberData['name'];
							    $FBID= $fbGroupMemberData['FBID'];
							    $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							    $photo= base_url()."Uploads/ProfilePictures/avatar.png";
							    $userType= 3;
                               	?>
                               	
                               	 <li>
                                 <table width="100%">
	                                <tr>
					                   <td>
					                     <img src="<?php echo $thumb;?>" width="80" height="80" alt="" />
					                     </td>
					                   </tr>
				                     
					                    <tr>
				                         <td>				                         
				                         <div class="f_italic"><?php echo $name;?></div>
				                         
				                         </td>
					                     </tr>
	                                     
	                              </table>                              
                               </li> 
                               <?php }}?>
                                		
                              </ul>
                         	                   
	                   </div>
	                   
	             

	                   
               </div>  
               
               
               <div class="span7">
               
               <div class="row">
                 <div class="pull-right">
                <button type="button" class="butn b_blue" onclick="return redirectToCreateQ()">               
                 
                 CREATE Q
                
                </button>
                 </div>
               </div>
               
                 <h4 class="f_blue">Q Posts</h4>
                 
                 
                  <div style="overflow:auto;height:800px;">
                    <?php echo $qPosts;?>	
                  </div>                 
                 
               </div> 
        </div>      
      </div>   
      
      <script>
      
        function redirectToCreateQ(){
        	window.location.href='<?php echo base_url();?>qCreate/createQ/groupId/<?php echo $showGroupId;?>';
        }
      </script>
       

<script type="text/javascript">





$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });





</script>
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>
  <!-- delete Group -->
  <script>

     function deleteGroup(groupId){
         

         var retVal = confirm("Do you want to continue ?");
         if( retVal == true ){
        	 var base_url="<?php echo base_url('groups/deleteGroup');?>"; 

        	 $.post(base_url,{groupId:groupId},function(response){
               	 $('#showMessage').show();  
                 $('#successMessage').html(response);
                 var redirect_url="<?php echo base_url('groups/mygroups');?>";
                 setTimeout("window.location.href='<?php echo base_url('groups/mygroups');?>';",2000);
               });
        	 return true;
         }else{
             return false;
         }
     }
  
  </script>

    <?php $this->load->view('footerView');?>
