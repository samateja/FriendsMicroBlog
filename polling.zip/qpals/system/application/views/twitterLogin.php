<?php
//end of adding url share points
$this->load->database();
session_start();
// Init facebook api.
require_once('twitter/config.php');
require_once('twitter/twitteroauth/twitteroauth.php');
/* If access tokens are not available redirect to connect page. */

/* If access tokens are not available redirect to connect page. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
   
    header('Location: twitter/clearsessions.php');
}
/* Get user access tokens out of the session. */
//$access_token = $_SESSION['access_token'];

/* Create a TwitterOauth object with consumer/user tokens. */
$connection = new TwitterOAuth('egSTwKE7UIojoaITioN7ug','b5qHBSt5WTRATxLQ4SIiIaAI2ispeZqlbjFLpQOiQ','899435864-j8uC0mXvO1DQaAiGvr8JQWw1wTmegAavduNLRa2d','WkLMnmPNFRfq6O77H8TgIuzUjc0MeNq0Bpwv6Z43mX21K');
$access_token = $_SESSION['access_token'];
$connection1 = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
//$connection1->post('statuses/update', array('status' => date(DATE_RFC822)));
//$connection1->post('statuses/update', array('status' => 'welcome to Qpals'));



$params = array(
    'status' => sprintf('test status message %s', time()),
    
);


$response = $connection1->post(
    'statuses/update',
    $params
);
