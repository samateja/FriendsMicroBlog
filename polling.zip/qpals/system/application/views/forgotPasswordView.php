<?php 
$newPasswordErr=form_error('newPassword');
$confPasswordErr=form_error('confirmPassword');
?>
<html>
<head>
<script src="<?php echo base_url();?>system/js/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>system/js/passstrenghify.js" type="text/javascript"></script>
<script>
$(document).ready(function(){    
	    // Sets a minimum of 5 chars.
	    $('#newPassword').passStrengthify();
	    $('#confirmPassword').passStrengthify();
	  
	});
</script>
</head>
<body>
<div style="margin: 0px auto;width:100%;text-align: center;">
<h2>Forgot paassword</h2>
<form method="post" action="">
<?php if(isset($errorMsg)){
echo $errorMsg;
}?>
<?php if(isset($succMsg)){
echo $succMsg;
}?>
<table width="50%" align="center" <?php if(isset($errorMsg) || isset($succMsg)){?> style="display:none;" <?php }?>>
<tr>
<td>New password:</td>
<td>
<?php 
$newPassword=isset($formData['newPassword'])?$formData['newPassword']:"";
$data = array(
    		     'name'         => 'newPassword',
    			 'id'           => 'newPassword',
    			 'value'        => $newPassword,
    			 'maxlength'    => '12',
				 'class'       => 'textfield1'
				);
echo form_password($data);
?>

</td>
</tr>
<?php if($newPasswordErr){?>
<tr>
<td>&nbsp;</td>
<td><?php echo $newPasswordErr;?></td>
</tr>
<?php }?>
<tr>
<td>Confirm Password</td>
<td>
<?php 
$confirmPassword=isset($formData['newPassword'])?$formData['newPassword']:"";
$data = array(
    		     'name'         => 'confirmPassword',
    			 'id'           => 'confirmPassword',
    			 'value'        => $confirmPassword,
    			 'maxlength'    => '12',
				 'class'       => 'textfield1'
				);
echo form_password($data);?>
</td>
</tr>
<?php if($confPasswordErr){?>
<tr>
<td>&nbsp;</td>
<td><?php echo $confPasswordErr;?></td>
</tr>
<?php }?>
<tr>
<td colspan="2" align="center">
<input type="submit" name="submit" value="Submit" />
</td>
</tr>
</table>
</form>
</div>
</body>
</html>