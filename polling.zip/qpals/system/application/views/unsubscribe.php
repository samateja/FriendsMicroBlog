    <?php $this->load->view('frontendHeader');
    $sessionlog=$this->session->userdata('userID');?>
   <style type='text/css'>
   .cancel{
   float:left;
   }
   .confirm{
   float:right;
   }
   </style>
   <script  type="text/javascript">
  
	   function addEmailAlerts(id){
		   $(document).ready(function () {
			   			// alert(id);
			   
			   //$('#confirm').attr("disabled", true);
			   	var base_url="<?php echo base_url('unsubscribe/registeredEmailAlerts');?>";
			   	var url1="<?php echo base_url().'home';?>";
			   	//alert(url1);
			    	var sessionlog="<?php echo $sessionlog;?>";
			    	$.post(base_url,{id:id},function(response){
			                  //alert(response);
			                  alert("unsubscribed successfully");
			                  window.location = url1;
			         });
			 
			 
		   });
	   }

	   function addNonRegEmailAlerts(nonRegID){
		   $(document).ready(function () {
			   //$('#confirm').attr("disabled", true);
			 //alert(nonRegID);
			   	var base_url="<?php echo base_url('unsubscribe/unRegisteredEmailAlerts');?>";
			    	var sessionlog="<?php echo $sessionlog;?>";
			    	var url1="<?php echo base_url().'home';?>";
			    	//alert(url1);
			    	$.post(base_url,{nonRegID:nonRegID},function(response){
			                  //alert(response);
			                  alert("unsubscribed successfully");
			                  window.location = url1;
			         });
			 
			 
		   });
	   }
	   function goToPage(url)
	   {
	   	window.location=url;
	   }
   </script>
   
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
    <div class="clear" style="height: 150px;"></div>
     <div class="container">
         <div class="row">
               <h3 style="margin-bottom:25px; margin-top:25px;"></h3>
     			<h4>Unsubscribe</h4>
  
  <div style="text-align:justify">
<p>“You will not receive invitations or other communications from your friends or be able to use your QPals account fully if you unsubscribe.</p><br> 
<p style="float:left">Please confirm that you wish to unsubscribe &nbsp;</p> &nbsp;<p class="f_bold_italic" style="float:left"><?php if(!empty($emil)){echo $emil;}?>.</p> <p style="float:left"> It may take a couple of days to update our records.”</p> 
</div>
 <div class="clear" style="height: 30px;"></div>

<?php if(!empty($NonRegId)){
?>
<button class="butn b_blue" id="confirm" onclick="addNonRegEmailAlerts(<?php echo $NonRegId;?>);"> CONFIRM</button>&nbsp;
<?php }else{?>
<button class="butn b_blue" id="confirm" onclick="addEmailAlerts(<?php echo $Id;?>);"> CONFIRM</button>&nbsp;
<?php }

$url= base_url()."home";?>
<button class="butn" onclick="javascript:goToPage('<?php echo $url;?>')" > CANCEL</button>

         </div>       
       </div>
<div class="clear" style="height: 150px;"></div>

    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
