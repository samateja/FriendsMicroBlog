  
  <?php $this->load->view('headerView');?>
  <?php	$bucket = $this->config->item("bucket");
	
  ?>
  <?php //if($active!=4){?>
  <script>

  </script>
  <?php //}?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
 <div class="container-fluid">
      <div class="row-fluid" id="showQs" style="display:none;">
        <div class="container content_inner h_line_profile"  style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($showAllQs) { $i=1;
                        
                       foreach($showAllQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group ad"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                      <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>"><img src="<?php echo $thumb;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class=""><?php echo $qAge;?>  by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($i%4==0){echo "</div><div class='row'>";}?>  
                   <?php $i++;} } ?>         
                 </div>
                  
              </div> 
        </div>  
        
         <div class="row-fluid" id="showICreated" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($iCreated) { $j=1;
                        
                       foreach($iCreated as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];	
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group dfffffffff"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                     <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />
                      </a>                    
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class=""><?php echo $qAge;?> by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($j%4==0){echo "</div><div class='row'>";}?>  
                   <?php $j++;} } ?>         
                 </div>
                  
              </div> 
        </div>
        
        
        <div class="row-fluid" id="showIReplied" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($iReplied) { $k=1;
                        
                       foreach($iReplied as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group das"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                      <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />                    
                      </a> 
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class=""><?php echo $qAge;?>  by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($k%4==0){echo "</div><div class='row'>";}?>  
                   <?php $k++;} } ?>         
                 </div>
                  
              </div> 
        </div>
        
        
        <div class="row-fluid" id="showFavorites" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($favorites) { $l=1;
                        
                       foreach($favorites as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group ert"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />                    
                      </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class=""><?php echo $qAge;?> by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($l%4==0){echo "</div><div class='row'>";}?>  
                   <?php $l++;} } ?>         
                 </div>
                  
              </div> 
        </div>
        
        
        
         <div class="row-fluid" id="showFollowed" style="display:none;">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($followed) { $m=1;
                        
                       foreach($followed as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group jkio"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />                    
                      </a> 
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class=""><?php echo $qAge;?> by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($m%4==0){echo "</div><div class='row'>";}?>  
                   <?php $m++;} } ?>         
                 </div>
                  
              </div> 
        </div>
        
        
        
        <div class="row-fluid" id="showPublicQs">
        <div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($publicQs) { $n=1;
                        
                       foreach($publicQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['firstName'];
							$dname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
							$dname="";
						}
						
				
                 ?>           
                    <div class="span3 thumbs_group sdf"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     <a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>">
                      <img src="<?php echo $thumb;?>" width="200" height="200" alt="" />                    
                      </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question"><?php  $countString=strlen($qsn);
                        if($countString > 20){
                        $qsnDesc= substr($qsn, 0,20);
                      	 //$qsnDesc =strtoupper($qsnDesc);
                        echo $qsnDesc.'...';
                        }else{
                        echo $qsn;	
                       }?></div>
                        
                              <div class="comment_bg_qwall"> <p><?php echo $responseCount;?></p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                                             <td><div style="font-style:italic;"><?php echo $qAge;?> by <span class="f_bold_italic"><?php echo $dname;?></span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> 
                       <?php if($n%4==0){echo "</div><div class='row'>";}?>  
                   <?php $n++;} } ?>         
                 </div>
                  
              </div> 
        </div>
        
        
     </div>    
      

    <script type="text/javascript">
    //show all
    function showAllQs(){
    	$(document).ready(function(){
    		$('#displayAllQs').html('<li class="select" onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');

            //search
            
            $('#searchInShowAll').show();        	
        	$('#searchInICreated').hide();
        	$('#searchInIReplied').hide();
        	$('#searchInFavorites').hide();
        	$('#searchInFollowed').hide();
        	
           $('#showQs').show();
           $('#showICreated').hide();
   		  $('#showIReplied').hide();
   		
   		$('#showFavorites').hide();
   		$('#showFollowed').hide();
   		$('#showPublicQs').hide();

         });
    }
    //show I created
    
    function showICreated(){
        
    	$(document).ready(function(){
        	$('#displayAllQs').html('<li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li class="select" onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');

            $('#searchInShowAll').hide();        	
         	$('#searchInICreated').show();
         	$('#searchInIReplied').hide();
         	$('#searchInFavorites').hide();
         	$('#searchInFollowed').hide();

        	
    		$('#showICreated').show();
    		$('#showIReplied').hide();
    		$('#showQs').hide();
    		$('#showFavorites').hide();
    		$('#showFollowed').hide();
    		$('#showPublicQs').hide();
         });
    }

    //show I replied
    
    function showIReplied(){

    	$(document).ready(function(){

    		$('#displayAllQs').html('<li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li  onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li class="select" onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');


        	$('#searchInShowAll').hide();        	
         	$('#searchInICreated').hide();
         	$('#searchInIReplied').show();
         	$('#searchInFavorites').hide();
         	$('#searchInFollowed').hide();

        	
    		$('#showIReplied').show();
    		$('#showICreated').hide();
    		$('#showQs').hide();
    		$('#showFavorites').hide();
    		$('#showFollowed').hide();
    		$('#showPublicQs').hide();
     
         });

    }

    //show favorites
    
    function showFavorites(){

    	$(document).ready(function(){
    		$('#displayAllQs').html('<li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li  onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li  onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li  class="select" onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');


        	$('#searchInShowAll').hide();        	
         	$('#searchInICreated').hide();
         	$('#searchInIReplied').hide();
         	$('#searchInFavorites').show();
         	$('#searchInFollowed').hide();
        
        $('#showFavorites').show();
    	$('#showIReplied').hide();
		$('#showICreated').hide();
		$('#showQs').hide();
		$('#showFollowed').hide();
		$('#showPublicQs').hide();
    	});
    }

    //followed
    
    function showFollowed(){

    	$(document).ready(function(){
    		$('#displayAllQs').html('<li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li  onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li  onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li   onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li class="select" onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');

        	$('#searchInShowAll').hide();        	
         	$('#searchInICreated').hide();
         	$('#searchInIReplied').hide();
         	$('#searchInFavorites').hide();
         	$('#searchInFollowed').show();
        
        $('#showFollowed').show();
        $('#showFavorites').hide();
    	$('#showIReplied').hide();
		$('#showICreated').hide();
		$('#showQs').hide();
		$('#showPublicQs').hide();
    	});
    }


    //public Qs
    
    function showPublicQs(){

    	$(document).ready(function(){
    		$('#displayAllQs').html('<li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>');
        	$('#displayPublicQs').html('<li class="select" onclick="return showPublicQs()" style="cursor:pointer;">Public</li>');
        	$('#displayICreated').html('<li  onclick="return showICreated()" style="cursor:pointer;">I Created</li>');
        	$('#displayIReplied').html('<li  onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>');
        	$('#displayFavorites').html('<li   onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>');
        	$('#displayFollowed').html('<li  onclick="return showFollowed()" style="cursor:pointer;">Followed</li>');
        $('#showFollowed').hide();
        $('#showFavorites').hide();
    	$('#showIReplied').hide();
		$('#showICreated').hide();
		$('#showQs').hide();
		$('#showPublicQs').show();
    	});
    }
    
    </script>
    
    <!-- search all Q's -->
    
    <script>
       function searchAllQs(){
           
    	   $(document).ready(function(){

               var searchText=$('#searchAll').val();
               
               var base_url="<?php echo base_url('qwall/qwallSearchAllQs');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
                //alert(response);	 
                   $('#showQs').html(response);
                 });

            });
       }


     function searchICreated(){
           
    	   $(document).ready(function(){

               var searchText=$('#searchCreatedText').val();
               
               var base_url="<?php echo base_url('qwall/qwallSearchIcreated');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
                //alert(response);	 
                   $('#showICreated').html(response);
                 });

            });
       }


     function searchIReplied(){
         
  	   $(document).ready(function(){

             var searchText=$('#searchRepliedText').val();
             
             var base_url="<?php echo base_url('qwall/qwallSearchIReplied');?>"; 
             $.post(base_url,{searchText:searchText},function(response){
              //alert(response);	 
                 $('#showIReplied').html(response);
               });

          });
     }


     function searchFavorites(){
         
    	   $(document).ready(function(){

               var searchText=$('#searchFavoritesText').val();
               
               var base_url="<?php echo base_url('qwall/qwallSearchFavourites');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
                //alert(response);	 
                   $('#showFavorites').html(response);
                 });

            });
       }


     function searchFollowed(){
         
  	   $(document).ready(function(){

             var searchText=$('#searchFollowedText').val();
             
             var base_url="<?php echo base_url('qwall/qwallSearchFollowed');?>"; 
             $.post(base_url,{searchText:searchText},function(response){
              //alert(response);	 
                 $('#showFollowed').html(response);
               });

          });
     }
     function refreshComments(){
 		window.location.reload();
 	 }
     
    </script>
<?php if(!empty($enableJS)){?>
<script>
  $( document ).ready(function() {
	  showICreated();
	  });
  </script>
<?php }?>

    <?php $this->load->view('footerView');?>