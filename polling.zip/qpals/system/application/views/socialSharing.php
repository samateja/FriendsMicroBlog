<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Welcome to QPals</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="cytrion" >

    <!-- Le styles -->
    <link href="<?php echo base_url();?>css/style_inner.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
     
       <link href="<?php echo base_url();?>css/style_logout.css" rel="stylesheet">

 
     <script src="<?php echo base_url();?>js/jquery.js"></script>

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../assets/js/html5shiv.js"></script>
    <![endif]-->

 
 
 <script>
function get_settings() {
	$(".toggle_wrapper").fadeToggle();
}
</script>
  </head>


  <body>



    <!-- --------------------------TOP BAR---------------------------------   -->
    
    
   <div class="container-fluid nopadding">
         <div class="row-fluid">
          <div class="header_logout">
             <div class="container-fluid">
             <div class="row-fluid" style="margin-top:51px;">
             <div class="span5"> <img src="<?php echo base_url();?>images/logo_logout.png" width="311" height="147" alt="" /> </div>
             <div class="span7">
             <div class="navbar">
               <div class="navbar-inner">             
                  <ul class="nav_l">
                     <li> <a href="<?php echo base_url();?>home">Home</a></li>
                      <li> <a href="<?php echo base_url();?>about">About</a></li>
                       <li> <a href="<?php echo base_url();?>faqs">FAQ's</a></li>
                        <li> <a href="#myModal" role="button"  data-toggle="modal" href="#">Login </a></li>                  
                  </ul>
                 </div>                
                </div>
               </div>
               </div>
              </div>
             </div>         
         </div>
       	
    </div>
    
    
      <!-- -------------------------- END TOP BAR---------------------------------   -->
    
    
    
       <!-- -------------------------- BEGIN HEADER---------------------------------   -->
    <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div style="width:100%; background-color:#4e4131; height:862px;"></div>
                   
        </div>      
      </div>
     <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div class="container-fluid" style="margin-top:40px;">
          <div class="span4 txt_center">
            <div><img src="<?php echo base_url();?>images/icon_createping.png" width="170" height="190" alt="" />   </div>
             <div style="font-size:30px; color:#ff3234; font-family:roboto-bold;">Create a Ping</div>  
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Create a 'ping' a photo/question combo poll - on your phone or online.</div>     
          </div>
          <div class="span4 txt_center">
           <div><img src="<?php echo base_url();?>images/icon_friendsreply.png" width="170" height="190" alt="" /></div>
         
           
            <div style="font-size:30px; color:#cccb35; font-family:roboto-bold;">Create a Ping</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Your friends reply using our free apps (or from Facebook if you posted your ping on your Wall). </div>
          </div>
          <div class="span4 txt_center">
           <div> <img src="<?php echo base_url();?>images/icon_results.png" width="170" height="190" alt="" />  </div>
            
            <div style="font-size:30px; color:#ff3234; font-family:roboto-bold;">Get Results</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Get results and comments from your friends. </div>
          </div>         
        
         </div>
                   
        </div>      
      </div>
      
      
         <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div class="container-fluid" style="margin-top:40px;">
          <div class="row-fluid">
            <div class="span4">
              <img src="<?php echo base_url();?>images/pic_iphone.png" width="387" height="748" alt="" />            
            </div>
             <div class="span8">
              <div style="color:#cccb32; font-size:46px; font-family:roboto-bold; margin-bottom:40px; margin-top:20px;">ABOUT US</div>
 
              <p style="font-size:20px; line-height:26px; text-align:justify;  color:#333333;"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum. </p>
              <table style="margin-top:2em;" cellpadding="4">
                <tr>
                  <td> <a href="#"><img src="<?php echo base_url();?>images/icon_facebook_home.png" width="80" height="80" alt="" /></a> </td>
                  <td> <a href="#"><img src="<?php echo base_url();?>images/icon_twitter_home.png" width="80" height="80" alt="" /> </a> </td>
                  <td> <a href="#"></td>               
                </tr>              
              </table>
             </div>          
          </div>
         </div>
         </div>
         </div>
         
         
	       <div class="container-fluid nopadding" style="background-color:#f3f3f3; padding-bottom:40px;">
	        <div class="row-fluid">
	         <div class="container-fluid" style="margin-top:40px;">
	          <div class="row-fluid">
	         
	          <div class="span9">
               <img src="<?php echo base_url();?>images/text_quotes.png" width="507" height="193" alt="" />
               
               <br>
               <div class="row-fluid">
               
               
               <div class="span6 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">i Love it</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div>
               
               
               <div class="span6 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum </div>  
                </div>             
               </div>
               
               
               </div>	          
	          </div>


	          <div class="span3">
	           <div class="row-fluid">
               <div class="span12 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div>
               </div>
               
                <div class="row-fluid">
               
                <div class="span12 box_quotes box_green">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars_green.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div> 
               </div>              
               
	          </div>
	          
	          </div>
	         </div>
	        </div>
	       </div>
     <!-- -------------------------- END HEADER---------------------------------   -->
    
    
    
      <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
    <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_blue">
               
					                
					<!-- Modal  popup start-->
					<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-header">
					    
					   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					   </a>
					    <h5 id="myModalLabel">Log In Details</h5>
					  </div>
					  <div class="modal-body">
					   <div id="result" style="color:red; margin-left: 160px"></div><br/>
                    <table width="100%" cellpadding="5">
					  <tr>
						<td colspan="2">
						 <input type="text" class="span12" name="email" id="email" placeholder="Email"  />
						  </td>
					  </tr>
								
					<tr>
					 <td colspan="2">
					 <input type="password" class="span12" name="password" id="password" placeholder="Password"   /> 
					 </td>
					</tr>
								
					<tr>
					 <td style="vertical-align:top;"></td>
					<td  style="vertical-align:top;" align="right">
					<button style="padding:10px 0; margin-top:0px;" class="butn b_blue" id="signin">
					 LOG IN</button>
					 </td>
					</tr>
								
								
					<tr>
					<td style="vertical-align:top;"></td>
					<td  align="right" style="vertical-align:top;"> 
				    <button aria-hidden="true" data-dismiss="modal"  href="#myModal_register" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0; color:#5D5D5D;" class="butn b_yellow">
				    REGISTER NOW</button> 
				    </td>
					</tr>
				 </table>					   
			</div>
			
		</div>


       <div id="myModal_register" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				  <h5 id="myModalLabel">
					 Please provide your email to vote,leave comments,following this Q <br/>
					 and create your own Q's on Twitter and elsewhere.
				</h5>
			</div>
			
		    <div class="modal-body">
		    <div id="result1" style="color:red; margin-left: 160px"></div><br/>
			   <table width="100%" cellpadding="5">
				<tr>
				<td colspan="2">
				<input type="text" class="span12" name="displayName" id="displayName" placeholder="Screen Name (optional)"  />
				</td>
				</tr>
								
				<tr>
				 <td colspan="2">
				 <input type="text" class="span12" placeholder="Email" name="userEmail" id="userEmail"   />
				</td>
			 </tr>
								
			    <tr>
					<td></td>
					<td  align="right" style="vertical-align:top;">
				   <button style="margin-top:0px; padding:10px 0; color:#5d5d5d;" class="butn b_yellow" id="register">
				   REGISTER</button>
				    </td>
			</tr>
			</table>					   
		</div>
	</div>
<!-- Modal-register  popup end-->
       
        </div>      
      </div>    

   
   
    <!-- -------------------------- END CONTAINER---------------------------------   -->




      <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
      
          <div class="container-fluid footer_bg nopadding">
      <div class="row-fluid">
        <div class="container-fluid">
         <div class="span6">        
        
 		      <div class="footer_home">
		        <ul>
                <li><a href="<?php echo base_url();?>home">Home</a></li>
                <li><a href="<?php echo base_url();?>about">About</a></li>
                <li><a href="<?php echo base_url();?>faqs">FAQ's</a></li>
                <li> <a href="#myModal" role="button"  data-toggle="modal">Login</a></li>		        
		        </ul>
		        
		        <div style="clear:both; font-size:24px; color:#ffffff; padding-top:45px; ">&copy; Copyright © 2013 QPals. All rights reserved. </div>
		      </div>            
           </div> 
           
             <div class="span6 pull-right"> <div style="float:right;"> <div style="color:#e8a9b2; margin-bottom:18px; font-size:30px;">Available on: </div>
               <div> <a href="#">
               <img src="<?php echo base_url();?>images/app_iphone.png" width="248" height="83" alt="" /></a>   &nbsp;  &nbsp;
               <a href="#"><img src="<?php echo base_url();?>images/app_android.png" width="248" height="83" alt="" /></a>    <!--&nbsp;  &nbsp; <a href="#"><img src="img/app_windows.png" width="248" height="83" alt="" /></a>   -->   </div>             
             </div> 
             </div>          
            
        </div>      
      </div>    
    </div> 
    
     <!-- -------------------------- END CONTAINER---------------------------------   --> 
     
     
     <!-- jquery Ajax for login -->
     
     <script type="text/javascript">
       $('#signin').click(function(){       
           var email=$('#email').val();
           var password=$('#password').val();
          //alert('dsf');
           $.ajax({            
               type: "POST",
               url: "<?php echo base_url('socialSharing/login')?>",
               data: ({email: email, password: password }),
             
               success: function(response){
                   if(response==1){
                	   window.location = "<?php echo $this->session->userdata('redirectUrl');?>";
                   }else{
                   $("#result").html(response);
                   }
               }  
           }); 
                       
       });
     </script>
     
     <!-- jquery ajax for registration -->
     
      <script type="text/javascript">
        $('#register').click(function(){
            //alert('asd');
           
            var userEmail=$('#userEmail').val();           
            var displayName=$('#displayName').val();
           

            $.ajax({
                type: "POST",
                url : "<?php echo base_url('socialSharing/userRegistration')?>",
                data: ({email:userEmail,displayName:displayName}),

                success: function(responseReg){                 
                alert(responseReg);
                $("#result1").html(responseReg);
                
            }
            });
           

         });
        
     </script>
     
     
     
     
      
        
     <!-- code to load the popup on page load --> 
    <script type="text/javascript">
    $(window).load(function(){
        $('#myModal').modal('show');
    });
   </script>



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
    <script src="<?php echo base_url();?>js/bootstrap-transition.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-alert.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-modal.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-dropdown.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tab.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tooltip.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-popover.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-button.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-collapse.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-carousel.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-typeahead.js"></script>


    <script src="assets/js/holder/holder.js"></script>
   <script type="text/javascript">


   $("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });

</script>
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
     </script>
  </body>
</html>
