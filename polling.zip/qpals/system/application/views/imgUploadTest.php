<?php

?>
<html>
<head></head>
<body>
<form method="post" action="<?php echo base_url();?>api/profileImageUpload" enctype="multipart/form-data">
<?php $data = array(
	               'name'  	=> 'profileImage',
	               'id'    	=> 'profileImage',
	               'value' 	=> ""
				   );
				   echo form_upload($data);
				   ?>
<br/>
<input type="hidden" name="userId" value="2" />
<input type="submit" name="submit" value="Submit" >
</form>
</body>
</html>