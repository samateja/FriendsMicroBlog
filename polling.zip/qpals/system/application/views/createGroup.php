  
  <?php $this->load->view('headerView');
   $bucket = $this->config->item("bucket");?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <style>
  #tabs ul li {
  border-bottom: 1px solid #339999;
  width: 33%;
  }
  
  </style>
  <script type="text/javascript">

  var followingArray=new Array();
  var selectedFollowingArray=new Array();
  var userArray=new Array();

  </script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
 <form method="post" id="form1" action="<?php echo base_url()."groups/insertGroup"; ?>" enctype="multipart/form-data">
  <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_blue">
        
        <div class="row">
         <?php if(isset($successMessage)){ ?>
               <div class="alert alert-success"><?php echo $successMessage;?></div>
               	
               <?php 
               $redirectUrl=base_url().'groups/mygroups';
               header("Refresh:3;url=$redirectUrl");
               }?>  
               
               <?php if(isset($errormessage)){ ?>
               <div class="alert alert-error"><?php echo $errormessage;?></div>
               	
               <?php 
              $redirectUrl=base_url().'groups/createGroup';
              //header("Refresh:2;url=$redirectUrl");
               }?>  
        </div>
        <div class="row">
               <div class="span5 devider_span">
                   <h4 class="f_blue">Group Name</h4> 
	                   <table width="100%" class="form_profile">
	                     <tr>
	                       <td>
	                       <input name="groupName" style="font-style:italic" maxlength="30" id="groupName" placeholder="Type here" type="text" class="span9" /><br/>
	                       <span style="color: red;" id="groupValidity"></span>
	                       </td>
	                     </tr>
	                                  
	                   </table>
	                   
	                   <h4 class="f_blue">Group Photo </h4> 
	                   
	                  
	                  <table class="form_profile">
	                     <tr>
	                       <td><div class="img_profile">
	                        <div class="img_cross_blue">
	                        
	                        </div> 
	                        
	                        <input type="file" name=groupImage id="groupImage"></input>
	                        </div> 
	                        </td>
	                     </tr>
	                   
	                   </table>  
	                   
                    </div> 
               
               
               <div class="span7">
                 <h4 class="f_blue">Add Pals  <div class="pull-right">
                  
                  <span id="showFollowingSearch">
                  <input type="text" name="searchInFollowing" id="searchInFollowing" placeholder="Type name/email/following" class="search_input" />
                   <img  onclick="return searchfollwing()" src="<?php echo base_url();?>/images/search_group.png"></img>
                  </span>
                  
                  <span id="showFollowerSearch" style="display:none;">
                  <input type="text" name="searchInFollower" id="searchInFollower" placeholder="Type name/email/follower" class="search_input" />
                   <img  onclick="return searchfollower()" src="<?php echo base_url();?>/images/search_group.png"></img>
                  </span>
                  
                   </div>
                   </h4>
                    <div id="tabs">
								 <ul class="tabs" id="tabsnav">
								  <li><a href="#tab-1" class="tab menu-internal" onclick="return showFollowing()">Following (<?php echo $countOfFollowing;?>)</a></li>
								  <li><a href="#tab-2" class="tab menu-internal" onclick="return showFollower()">Followers (<?php echo $countOfFollowers;?>)</a></li>
								  <!-- <li><a href="#tab-3" class="tab menu-internal">Facebook (186)</a></li>
							   -->
							    </ul>
				<!-- tab 1 start -->
								 
					<div id="tab-1">								     
                         <div class="list_addpals" id="followingdiv">
                            <ul>
                                  <?php 
								  if($followingPals){//if received Q's								  	
								  	foreach($followingPals as $rec){
								  		 
								    $fUserId=$rec['followers_ID'];
			                        $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
			                        if($userData[0]['thumb'] != 'avatar_thumb.png'){
			                        	$thumb		=$this->_S3Url.$userData[0]['photo'];
			                        }else{
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }
						           // $thumb= 'http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName= $userData[0]['displayName'];					            
								    	
								  ?>                         
                               <li>
                                   <table cellpadding="4">
                                   <script>
                                   followingArray.push(<?php echo $fUserId?>);
                                    </script>
									<tr>
									 <td><input type="checkbox" name="checkedFollowing[]" id="<?php echo $fUserId;?>" value="<?php echo $fUserId;?>" onclick="return isFollowingChecked(<?php echo $fUserId;?>)"/></td>
									 <td><img src="<?php echo $thumb;?>" width="40" height="40" alt="" /></td>
									  <td><?php echo $displayName;?></td>
									</tr>
								 </table>                                
                              </li> 
                            <?php } }else{
                            echo "No Following available.";
                            }?>
                                                       
                            </ul>                           
                          </div>   								     
					</div>
				<!-- tab 1 end -->	
				
				<!-- tab 2 start -->		 
				 <div id="tab-2">
								  
					<div class="list_addpals" id="followersdiv">
                            <ul>
                                   <?php 
								  if($followers){//if received Q's								  	
								  	foreach($followers as $rec){ 
								  		
								  	$fUserId=$rec['user_ID'];
				                    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
								  	 if($userData[0]['thumb'] != 'avatar_thumb.png'){
			                        	$thumb		=$this->_S3Url.$userData[0]['photo'];
			                        }else{
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }
						            //$thumb   ='http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName=$userData[0]['displayName'];							    
						             ?>                         
                               <li>
                                   <table cellpadding="4">
									<tr>
									 <td><input type="checkbox" name="checkedFollowers[]" id="<?php echo $fUserId;?>" value="<?php echo $fUserId;?>" /></td>
									 <td><img src="<?php echo $thumb;?>" width="40" height="40" alt="" /></td>
									  <td><?php echo $displayName;?></td>
									</tr>
								 </table>                                
                              </li> 
                            <?php } }else{
                            echo "No Followers available.";
                            }?>
                                                       
                            </ul>                           
                          </div>			  
								  
								  
				</div>
				<!-- tab 2 end -->
								 
								 <div id="tab-3">
								  <h3>Tab 3</h3>
								   <p>Facebook(95)</p>
								 </div>
							</div> 
							
			<div class="pull-right">
			<span>
                 &nbsp;
			</span> 
				<br>
				
			</div> 
			
			
			
			
			<div>
			   <table width="100%" class="form_profile">
	                     <tr>
	                       <td width="100" class="lable_profile">Email</td>
	                       <td width="40">
	                       <img src="<?php echo base_url();?>images/icon_email.png" width="28" height="28" alt="" />
	                       </td>
	                       <td>
	                       <input type="text" placeholder="Enter Email" name="customEmail[]" value="" style="width:100%">                      
	                       
	                        <div  class="icon_add">
	                        <div id="addemail">
	                         <div data-toggle="tooltip" data-placement="bottom" title="ADD MORE"> 
	                        <span id="addButton" ><img  onclick="return allValidations()" src="<?php echo base_url();?>images/icon_add.png" width="22" height="22" alt="" style="padding-right:24px;" /></span>
	                      </div></div>
	                      
	                      </div> 
	                       </td>
	                     </tr>
	                     
	                     <tr>
	                     <td width="100" class="lable_profile">&nbsp;</td>
	                     <td width="40"></td>
	                     <td>
	                     <div id="TextBoxesGroup">
	                      <div id="TextBoxDiv1" >
	                      
                          
                         </div>
                         </div>
                         </td>
	                     </tr>
	                  </table>
			</div>                   
                    </div>
                    
                  </div>
               </div> 
        </div>      
      </div>    

      
      
         <div class="container-fluid">
         <div class="row-fluid">
             <div class="container">
               <div class="pull-right"> 
                 <button class="butn">CANCEL</button> 
                  <button class="butn b_blue" type="button"  name="createGroup" onclick="return validateGroup();">CREATE</button> 
               </div>            
             </div>         
         </div>   
   </div>
  </form> 
   
 
 
  <script type="text/javascript">

  // lets add the selected members 
     function isFollowingChecked(id){

 		//check if the member has already been added to the list 
 		
 		if ($.inArray(id,selectedFollowingArray)== -1 )
 		{
 	 	   	  	selectedFollowingArray.push(id);
 		}
 		else
 		{
 	 		// remove the member from the list
 	 		selectedFollowingArray.splice( $.inArray(id, selectedFollowingArray), 1 );
 	 		
 		}

 		//alert(selectedFollowingArray);
 		//alert(followingArray);
	         
  }

  </script>


 <!-- following script -->

  <script type="text/javascript">

   function showFollowing(){	  
	  
		  $(document).ready(function(){			  
			  $('#showFollowingSearch').show();
	           $('#showFollowerSearch').hide();
			 

		});
   }
  
  </script>
  
  
  <script type="text/javascript">
     function searchfollwing(){   
      
        $(document).ready(function(){
            var searchFriend=$('#searchInFollowing').val();
            var base_url="<?php echo base_url('groups/searchFriendInFollowing');?>";
            	 $.post(base_url,{searchFriend:searchFriend},function(response){
              	    $('#followingdiv').html(response);  
                 });
            
            
            
         });
     }
  </script>
  
  <!-- end of following script -->
  
  <!-- follower script -->
  <script type="text/javascript">

   function showFollower(){
	  
		  $(document).ready(function(){	
			 		  
			  $('#showFollowingSearch').hide();
			  $('#showFollowerSearch').show();
			 

		});
   }
  
  </script>
  
  
  <script type="text/javascript">

    function searchfollower(){
         
    	$(document).ready(function(){

            var searchFriend=$('#searchInFollower').val();
            var base_url="<?php echo base_url('groups/searchFriendInFollower');?>";
            	 $.post(base_url,{searchFriend:searchFriend},function(response){
              	    $('#followersdiv').html(response);  
                 });              
            
         });
    }
  
  </script>
 
 <!-- end of follower script--> 
  
  
  
  
  
  
  <!-- add custom email -->
  <script type="text/javascript">
  function validate()
	{ 
		var custonEmail = document.getElementsByName("customEmail[]");		
		
	    for(var i=0;i< custonEmail.length; i++) {	    				
			if(custonEmail[i].value == ""){				
				alert('The email field is required.');			
				custonEmail[i].focus();
				return false;
			}

			var EmailId = custonEmail[i].value;
			var emailfilter = /(([a-zA-Z0-9\-?\.?]+)@(([a-zA-Z0-9\-_]+\.)+)([a-z]{2,3}))+$/;
			if((EmailId != "") && (!(emailfilter.test(EmailId ) ) )) {
			   
			    alert('Please enter your valid email address.');
			    return false;
			}			   
			
		}
		return true;
   }

  
  

  function allValidations()
  {	
	var success =  validate();
	if(success){		
	addRow();
	}
	
  }

  function addRow(){		
	    $('#TextBoxDiv1').append('<div><input type="text" style="width:100%;"  name="customEmail[]" id="customEmail"></div>');	            
	  }
  </script>
  
 
  
  <!-- validate group -->
  
  <script type="text/javascript">

  function validateGroup(){

	  var groupName=$('#groupName').val();

	  $(document).ready(function(){
      
	        if(groupName==""){
		        alert('please enter Group Name');
		        return false;
	        }
	        var count_checked_Following = $("[name='checkedFollowing[]']:checked").length; // count the checked rows
	        var count_checked_Follower  = $("[name='checkedFollowers[]']:checked").length; // count the checked rows
	        var custonEmail = document.getElementsByName("customEmail[]");
	        
	        
	        if(count_checked_Following == 0 && count_checked_Follower == 0 && custonEmail[0].value == "") 
	        {
	            alert("Please select atleast one member.");
	            return false;
	        }
	        
	        var base_url="<?php echo base_url('groups/groupValidations');?>";
	        var groupImage=$('#groupImage').val();
	        	 $.ajax({
	                 url: base_url,
	                 type: 'post',
	                 data: { groupName: groupName,groupImage:groupImage },
	                 success:function(data){
		                 if(data){
		                	 //$('#groupValidity').html(data);
		                	 alert(data);
		                 }else{//if valid data		                	 
		                	document.getElementById("form1").submit();
		                	 
		                 }   
	                   }
	             });
		        

	        

	});
  }

  </script>
  
  
  
     <script type="text/javascript">
$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});

/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });
</script>
    
     
  <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>

    <?php $this->load->view('footerView');?>
