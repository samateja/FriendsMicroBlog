  <?php $bucket = $this->config->item("bucket");?>
   <link href=" <?php echo base_url();?>js/DataTable/css/demo_page.css"" rel="stylesheet" />
<link href=" <?php echo base_url();?>js/DataTable/css/demo_table.css"" rel="stylesheet" />
<script type="text/javascript" language="javascript" src=" <?php echo base_url();?>js/DataTable/js/jquery.dataTables.js""></script>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example1').dataTable( {
					"sPaginationType1": "full_numbers",
						"bInfo" : false,
						"bFilter": false
						} );
			} );
		</script>	
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example2').dataTable( {
					"sPaginationType2": "full_numbers",
						"bInfo" : false,
						"bFilter": false
				} );
			} );
		</script>
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').dataTable( {
					"sPaginationType": "full_numbers",
					"bInfo" : false,
					"bFilter": false
				} );
			} );
		</script>
 <div class="row-fluid" id="mostActive">
        <div class="container content_inner h_line_findPals" >
         <table class="table table-bordered" id="example2">
			  
			<thead>
				<tr><th></th></tr>
				
			</thead>
			<tbody>
			
			<tr>
			 <td> 
			
			  <div class="row">
			 <?php if($mostActive) { 
                 	    $i=1;                        
                       foreach($mostActive as $res){
                       $userID=$res['user_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=$getUserDetails[0]['thumb'];
                        if($getUserDetails[0]['thumb'] != 'avatar_thumb.png'){
				  	    	$UserThumbImage=$this->_S3Url.$getUserDetails[0]['thumb'];
				  	    }else{
				  	    	$UserThumbImage= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
				  	    }	
				  	   }else{
				  	  $displayName   ='';
				  	 // $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                 
                    <div class="span3 thumbs_group"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                   
                       <?php if($i%4==0){echo "</div></td></tr><tr><td> <div class='row'>";}?>  
                   <?php $i++;} } ?>         

			
			</tbody>
		</table>
        </div></div>
        