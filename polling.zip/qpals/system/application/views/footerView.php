  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
      
       <div class="container-fluid">
      <div class="row-fluid">
        <div class="container">
 		      <div class="footer">
		        <p class="pull-right">  
		        <img src="<?php echo base_url();?>images/logo_footer.png" width="65" height="35" alt="" />  <!--  <a href="#">Back to top</a> --></p>
		        <p align="center" style="font-style: italic;"> Copyright &copy; 2014 QPals. All rights reserved.</p>
		        <p align="left" style="margin-top:-26px;">
		        <i style="float:left"><a href="<?php echo base_url();?>termsofUse/terms" target="_blank">Terms of Use</a></i><br/>
		        <i style="float:left;margin-left: 10px;margin-top: -13px;"><a href="<?php echo base_url();?>policy/privacyPolicy" target="_blank">Privacy Policy</a></i><br/>
		        <i style="float:left;margin-left: 188px;margin-top: -32px;"><a href="<?php echo base_url();?>dmca/dmcaNotice" target="_blank">DMCA Notice</a></i>
		        </p>
		      </div>            
                  
        </div>      
      </div>    
    </div> 
    
     <!-- -------------------------- END CONTAINER---------------------------------   -->     
      
      



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
    <script src="<?php echo base_url();?>js/bootstrap-transition.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-alert.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-modal.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-dropdown.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tab.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-tooltip.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-popover.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-button.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-collapse.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-carousel.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-typeahead.js"></script>


   
   <script type="text/javascript">





$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



</script>
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>
  </body>
</html>