  
  <?php $this->load->view('frontendHeader');?>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div style="width:100%; background-color:#4e4131; height:862px;"></div>
                   
        </div>      
      </div>
     <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div class="container-fluid" style="margin-top:40px;">
          <div class="span4 txt_center">
            <div><img src="<?php echo base_url();?>images/icon_createping.png" width="170" height="190" alt="" />   </div>
             <div style="font-size:30px; color:#ff3234; font-family:roboto-bold;">Create a Ping</div>  
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Create a 'ping' a photo/question combo poll - on your phone or online.</div>     
          </div>
          <div class="span4 txt_center">
           <div><img src="<?php echo base_url();?>images/icon_friendsreply.png" width="170" height="190" alt="" /></div>
         
           
            <div style="font-size:30px; color:#cccb35; font-family:roboto-bold;">Create a Ping</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Your friends reply using our free apps (or from Facebook if you posted your ping on your Wall). </div>
          </div>
          <div class="span4 txt_center">
           <div> <img src="<?php echo base_url();?>images/icon_results.png" width="170" height="190" alt="" />  </div>
            
            <div style="font-size:30px; color:#ff3234; font-family:roboto-bold;">Get Results</div> 
             <div style="color:#000000;margin-top:30px; font-size:18px;"> Get results and comments from your friends. </div>
          </div>         
        
         </div>
                   
        </div>      
      </div>
      
      
         <div class="container-fluid nopadding">
        <div class="row-fluid">
         <div class="container-fluid" style="margin-top:40px;">
          <div class="row-fluid">
            <div class="span4">
              <img src="<?php echo base_url();?>images/pic_iphone.png" width="387" height="748" alt="" />            
            </div>
             <div class="span8">
              <div style="color:#cccb32; font-size:46px; font-family:roboto-bold; margin-bottom:40px; margin-top:20px;">
              ABOUT US
              </div>
 
              <p style="font-size:20px; line-height:26px; text-align:justify;  color:#333333;">
              Like most of you, we like to share photos with our friends. Either with a close group of selected friends or all of our Facebook friends. We also wanted to find out what our friends thought about a cool set of shoes or a slick new gadget before we brought them, but couldn't find a cool and easy way to do it quickly. So we scratched our heads and developed Qpals - it's an extremely easy and fun way to poll your friends with all kinds of questions.

Simply send a "Q" to your close group of friends or to all your Facebook friends. If they have their phones on and respond, you'll get your answer instantly - it's faster and more fun then texting or calling all your friends one by one. Plus your friends can add their own comments..no more fighting with the cashier for refunds!

We're already working on the next version of Qpls, with even more cool features. If you have any ideas that you love to have added, please let us know by emailing us at ideas @qpals.com
              </p>
              <table style="margin-top:2em;" cellpadding="4">
                <tr>
                  <td> <a href="#"><img src="<?php echo base_url();?>images/icon_facebook_home.png" width="80" height="80" alt="" /></a> </td>
                  <td> <a href="#"><img src="<?php echo base_url();?>images/icon_twitter_home.png" width="80" height="80" alt="" /> </a> </td>
                  <td> <a href="#"></td>               
                </tr>              
              </table>
             </div>          
          </div>
         </div>
         </div>
         </div>
         
         
	       <div class="container-fluid nopadding" style="background-color:#f3f3f3; padding-bottom:40px;">
	        <div class="row-fluid">
	         <div class="container-fluid" style="margin-top:40px;">
	          <div class="row-fluid">
	         
	          <div class="span9">
               <img src="<?php echo base_url();?>images/text_quotes.png" width="507" height="193" alt="" />
               
               <br>
               <div class="row-fluid">
               
               
               <div class="span6 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">i Love it</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div>
               
               
               <div class="span6 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit,Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lorem ipsum </div>  
                </div>             
               </div>
               
               
               </div>	          
	          </div>


	          <div class="span3">
	           <div class="row-fluid">
               <div class="span12 box_quotes">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div>
               </div>
               
                <div class="row-fluid">
               
                <div class="span12 box_quotes box_green">
                <div style="padding:50px;">
                   <img src="<?php echo base_url();?>images/stars_green.png" width="148" height="37" alt="" />
                   <div style="" class="heading_quotes">best app</div>
                   <div class="para_quotes">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </div>  
                </div>             
               </div> 
               </div>              
               
	          </div>
	          
	          </div>
	         </div>
	        </div>
	       </div>
   
    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
