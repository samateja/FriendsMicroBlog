<?php
/**
 * @file
 * User has successfully authenticated with Twitter. Access tokens saved to session and DB.
 */

/* Load required lib files. */
session_start();
require_once('twitteroauth/twitteroauth.php');
require_once('config.php');
print_r($_SESSION['access_token']);
/* If access tokens are not available redirect to connect page. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
   
    header('Location: ./clearsessions.php');
}
/* Get user access tokens out of the session. */
//$access_token = $_SESSION['access_token'];

/* Create a TwitterOauth object with consumer/user tokens. */
$connection = new TwitterOAuth('egSTwKE7UIojoaITioN7ug','b5qHBSt5WTRATxLQ4SIiIaAI2ispeZqlbjFLpQOiQ','899435864-j8uC0mXvO1DQaAiGvr8JQWw1wTmegAavduNLRa2d','WkLMnmPNFRfq6O77H8TgIuzUjc0MeNq0Bpwv6Z43mX21K');
$access_token = $_SESSION['access_token'];
$connection1 = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
//$connection1->post('statuses/update', array('status' => date(DATE_RFC822)));
//$connection1->post('statuses/update', array('status' => 'welcome to Qpals'));



$params = array(
    'status' => sprintf('test status message %s', time()),
    
);


$response = $connection1->post(
    'statuses/update',
    $params
);

//var_dump($response);



/* If method is set change API call made. Test is called by default. */
//$content = $connection->get('account/verify_credentials');
/* Some example calls */
//$connection->get('users/show', array('screen_name' => 'cytrion1'));
//$connection->post('statuses/update', array('status' => date(DATE_RFC822)));
//$connection->post('statuses/destroy', array('id' => 5437877770));
//$connection->post('friendships/create', array('id' => 9436992));
//$connection->post('friendships/destroy', array('id' => 9436992));

/* Include HTML to display on the page */
include('html.inc');
