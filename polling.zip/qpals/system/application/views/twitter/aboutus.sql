-- phpMyAdmin SQL Dump
-- version 3.5.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2014 at 03:05 PM
-- Server version: 5.5.35-0ubuntu0.12.10.2
-- PHP Version: 5.4.6-1ubuntu1.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `OCV`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE IF NOT EXISTS `aboutus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `text`) VALUES
(1, '<h1><span style="color:#0000FF"><span style="font-family:lucida sans unicode,lucida grande,sans-serif">Privacy Policy:</span></span></h1>\n\n<p>&nbsp;</p>\n\n<table class="table_form" style="-webkit-text-stroke-width:0px; background-color:rgb(255, 255, 255); border-collapse:collapse; border-spacing:0px; color:rgb(51, 51, 51); font-family:arial,sans-serif; font-size:14px; font-style:normal; font-variant:normal; font-weight:normal; letter-spacing:normal; line-height:20px; max-width:100%; orphans:auto; text-align:start; text-indent:0px; text-transform:none; white-space:normal; widows:auto; width:99%; word-spacing:0px">\n	<tbody>\n		<tr>\n			<td>\n			<p><span style="color:#0000FF"><span style="font-family:lucida sans unicode,lucida grande,sans-serif">Policy last updated February 4, 2014 This is the Privacy Policy for the www.ourcityloyalty.com website and any browser-based media player or application using ourcityloyalty or the (collectively and individually hereinafter referred to as the &ldquo;Service&rdquo;), which is owned or operated by MBD Marketing Group LLC (the &quot;Company&quot; or &quot;we&quot; or &quot;us&quot;). Your California Privacy Rights California Civil Code Section 1798.83 permits customers who are California residents to request certain information regarding our disclosure of personal information to third parties for such third parties&#39; direct marketing purposes. To make such a request, please write to: OurCityLoyalty, Privacy Administration Dept. 476 Stoneybrook Rd, Newtown PA 19140 Your Acceptance of this Privacy Policy By using the Service, including, without limitation, signing up for offers and/or continuing to receive information from the Company, you signify your acceptance of this Privacy Policy, and you expressly consent to our use and disclosure of your personal information in accordance with this Privacy Policy. This Privacy Policy is subject to the Terms of Use posted on the Service. Information We Collect. We collect information that may personally identify you (such as your name, address, telephone number, email address, billing information, or other data which can be reasonably linked to such information) only if you choose to share such information with us. For example, we may collect personal information from you when you register on the Service, subscribe to one of our services, interact with one of our services, and at other times. We also collect credit card information in connection with any purchase you make on or through the Service. The decision to provide this information is optional; however, if you decide not to register or provide such information, you may not be able to use certain features of the Service or other service.</span></span></p>\n			</td>\n		</tr>\n	</tbody>\n</table>\n');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
