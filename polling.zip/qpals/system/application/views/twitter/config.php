<?php

/**
 * @file
 * A single location to store configuration.
 */

//define('CONSUMER_KEY', 'GwnLXTJAHsME4Yj5UTBkLg');
//define('CONSUMER_SECRET', 'RZOMgRUkG6UEGvvUxaQo8YFvfx84SYfOkgK1jwfPWzg');
define('CONSUMER_KEY', 'po4sgiuHERRkQKHHRxTRlg');
define('CONSUMER_SECRET', 'aiIj84HWLfd7pEbUhdrkevei9PaGTdmaqPg2ElXUfiA');
define('OAUTH_CALLBACK', base_url().'qCreate/twitterCallback');

