  
  <?php $this->load->view('headerView');?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
 
  <link href=" <?php echo base_url();?>js/DataTable/css/demo_page.css"" rel="stylesheet" />
<link href=" <?php echo base_url();?>js/DataTable/css/demo_table.css"" rel="stylesheet" />
<script type="text/javascript" language="javascript" src=" <?php echo base_url();?>js/DataTable/js/jquery.dataTables.js""></script>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example1').dataTable( {
					"sPaginationType1": "full_numbers",
						"bInfo" : false,
						"bFilter": false
						} );
			} );
		</script>	
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example2').dataTable( {
					"sPaginationType2": "full_numbers",
						"bInfo" : false,
						"bFilter": false
				} );
			} );
		</script>
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').dataTable( {
					"sPaginationType": "full_numbers",
					"bInfo" : false,
					"bFilter": false
				} );
			} );
		</script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
 <div class="container-fluid">
     <!--  <div class="row-fluid" id="mostPopular">
        <div class="container content_inner h_line_findPals"  >
           
                 <div class="row">
                 <?php if($mostPopular) { 
                 	    $i=1;                        
                       foreach($mostPopular as $res){
                       $userID=$res['followers_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                    <div class="span3 thumbs_group"> 
                      <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div>
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
			
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> </span><span style="font-style:italic">Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?></span><span> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                       <?php if($i%4==0){echo "</div><div class='row'>";}?>  
                   <?php $i++;} } ?>         
                 </div>
                  
              </div> 
        </div>  -->
        <!-- MostPopular -->
        	<div class="row-fluid" id="mostPopular">
        <div class="container content_inner h_line_findPals" > 
          <table class="table table-bordered" id="example1">
			
			<thead>
				<tr><th></th></tr>
				
			</thead>
			<tbody>
			

			
			 <td> 
		
			  <div class="row">
			 <?php if($mostPopular) { 
                 	    $i=1;                        
                       foreach($mostPopular as $res){
                       $userID=$res['followers_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                 
                    <div class="span3 thumbs_group"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                   
                       <?php if($i%4==0){echo "</div></td></tr><tr><td><div class='row'>";}?>  
                   <?php $i++;} } ?>         

			
			</tbody>
		</table>
        </div></div>
        <!-- 
          <div class="row-fluid" id="mostActive" style="display:none;">
        <div class="container content_inner h_line_findPals"  style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($mostActive) { 
                 	    $i=1;                        
                       foreach($mostActive as $res){
                       $userID=$res['user_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                    <div class="span3 thumbs_group"> 
                      <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div>
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?></span><span> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                       <?php if($i%4==0){echo "</div><div class='row'>";}?>  
                   <?php $i++;} } ?>         
                 </div>
                  
              </div> 
        </div> 
        -->
        <!-- Most active -->
          <div class="row-fluid" id="mostActive" style="display:none;">
        <div class="container content_inner h_line_findPals" >
         <table class="table table-bordered" id="example2">
			  
			<thead>
				<tr><th></th></tr>
				
			</thead>
			<tbody>
			
			<tr>
			 <td> 
			
			  <div class="row">
			 <?php if($mostActive) { 
                 	    $i=1;                        
                       foreach($mostActive as $res){
                       $userID=$res['user_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                 
                    <div class="span3 thumbs_group"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                   
                       <?php if($i%4==0){echo "</div></td></tr><tr><td> <div class='row'>";}?>  
                   <?php $i++;} } ?>         

			
			</tbody>
		</table>
        </div></div>
        
        <!-- 
          <div class="row-fluid" id="newPals" style="display:none;">
        <div class="container content_inner h_line_findPals"  style="overflow:auto;height:600px;">
           
                 <div class="row">
                 <?php if($newPals) { 
                 	    $i=1;                        
                       foreach($newPals as $res){
                       $userID=$res['ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>           
                    <div class="span3 thumbs_group"> 
                      <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div>
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                       <?php if($i%4==0){echo "</div><div class='row'>";}?>  
                   <?php $i++;} } ?>         
                 </div>
               
              </div> 
        </div> 
        
      -->
   
             
           <div class="row-fluid" id="newPals"  style="display:none;">
			   <div class="container content_inner h_line_findPals" >      
        <table class="table table-bordered" id="example">
			  
			<thead>
				<tr><th></th></tr>
				
			</thead>
			<tbody>
			
			<tr>
			 <td> 
			
			  <div class="row">
			<?php if($newPals) { 
                 	    $i=1;                        
                       foreach($newPals as $res){
                       $userID=$res['ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    $UserThumbImage=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				
                 ?>         
                 
                    <div class="span3 thumbs_group"> 
                      <!-- <div class="img_cross_qwall">
                      <img width="34" height="34" src="img/cross_green.png" alt=""></img>
                      </div> -->
                     
                      <a href="<?php echo base_url().'findPals/viewPals/'.$userID.'';?>"><img src="<?php echo $UserThumbImage;?>" width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question"><?php echo $displayName;?></div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic"><?php echo $countOfFollowers?> Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic"><?php echo $countOfQCreated;?> Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div> 
                   
                       <?php if($i%4==0){echo "</div></td></tr><tr><td><div class='row'>";}?>  
                   <?php $i++;} } ?>         

			
			</tbody>
		</table>
    </div></div>
    </div><!-- end -->     
       
    
        <!-- show most popular -->
        <script type="text/javascript">

          function showMostPopular(){

        	  $(document).ready(function(){
          		$('#displayMostPopular').html('<li style="cursor:pointer;" class="select"onclick="return showMostPopular()">Most Popular</li>');
          		$('#displayMostActive').html('<li  style="cursor:pointer;" onclick="return showMostActive()">Most Active</li>');
        		$('#displayNewPals').html('<li   style="cursor:pointer;" onclick="return showNewPals()">New Pals</li>');
          		$('#mostActive').hide();
          		 $('#mostPopular').show();
          		$('#newPals').hide();
                  //search
                  
               $('#searchInMostPopular').show();        	
               $('#searchInMostActive').hide();
               $('#searchInNewPals').hide();
               });
          }

          function showMostActive(){

        	  $(document).ready(function(){
        		    $('#displayMostPopular').html('<li style="cursor:pointer;" onclick="return showMostPopular()">Most Popular</li>');
            		$('#displayMostActive').html('<li style="cursor:pointer;" class="select" onclick="return showMostActive()">Most Active</li>');
            		$('#displayNewPals').html('<li  style="cursor:pointer;" onclick="return showNewPals()">New Pals</li>');
                    $('#mostActive').show();
                    $('#mostPopular').hide();
                    $('#newPals').hide();
                    //search
                    
                 $('#searchInMostPopular').hide();        	
                 $('#searchInMostActive').show();	
                 $('#searchInNewPals').hide();
                 });
          }

          function showNewPals(){

        	  $(document).ready(function(){
        		    $('#displayMostPopular').html('<li style="cursor:pointer;" onclick="return showMostPopular()">Most Popular</li>');
            		$('#displayMostActive').html('<li  style="cursor:pointer;" onclick="return showMostActive()">Most Active</li>');
            		$('#displayNewPals').html('<li style="cursor:pointer;" class="select" onclick="return showNewPals()">New Pals</li>');
                	
                    $('#mostActive').hide();
                    $('#mostPopular').hide();
                    $('#newPals').show();
                    //search
                    
                 $('#searchInMostPopular').hide();        	
                 $('#searchInMostActive').hide();	
                 $('#searchInNewPals').show();
                 });
          }

       </script>
        
      <!-- search Most popular -->

    <script>
       function searchMostPopularPals(){
           
    	   $(document).ready(function(){

               var searchText=$('#searchMostPopular').val();               
               var base_url="<?php echo base_url('findPals/findPalsSearchMostPopular');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
                	 
                   $('#mostPopular').html(response);
                 });

            });
       }

      </script>
      
    <!-- search most active -->
         <script>
       function searchMostActivePals(){
           
    	   $(document).ready(function(){

               var searchText=$('#searchMostActive').val(); 
                           
               var base_url="<?php echo base_url('findPals/findPalsSearchMostActive');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
            	     
                   $('#mostActive').html(response);
                 });

            });
       }

      </script>
      
      <!-- search new pals -->
         <script>
       function searchNewPals(){
           
    	   $(document).ready(function(){

               var searchText=$('#searchNewPals').val(); 
                           
               var base_url="<?php echo base_url('findPals/findPalsSearchNewPals');?>"; 
               $.post(base_url,{searchText:searchText},function(response){
            	     
                   $('#newPals').html(response);
                 });

            });
       }

      </script>


    <?php $this->load->view('footerView');?>
