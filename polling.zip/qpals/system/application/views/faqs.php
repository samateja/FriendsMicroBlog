    <?php $this->load->view('frontendHeader');?>
   
    <script>
    $(document).ready(function(){
    	$(".toggle_minus").hide();
    $('.toggle_plus').click(function(){
    	if(document.getElementById('toggle_plus').style.display == "block"){
        	alert("asdasd");
    	$(".toggle_plus").hide();
    	$(".toggle_minus").show();
    	}else{
    		$(".toggle_minus").hide();
    		$(".toggle_plus").show();
        }
    });
    });
    </script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
     <div class="container">
         <div class="row">
           
           <h3 style="margin-bottom:25px; margin-top:25px;">Frequently Asked Questions</h3>
           
           
           <div class="accordion" id="accordion2">
           
				  
				   <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_1" id="toggle_plus1" style="cursor:pointer"></div>
				        <div class="toggle_minus" id="toggle_minus1" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_1" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_1">
				        What is QPals?
				      </a>
				    </div>
				    <div id="collapse_1" class="accordion-body collapse">
				      <div class="accordion-inner">
				      QPals is a fast and fun way to poll and chat instantly with your friends. 
				          It also makes group decisions (e.g. ‘which movie should we watch’) a lot easier. 
				           You can also follow other interesting users, be followed and make new friends.  
				           Right now, we offer free QPals app for the iPhone, Android, Windows phones and you can use any phone with a web browser.  Even if you don't have a web browser on your phone, you can join your friends online using our website, www.QPals.com.
                      </div>
				    </div>
				  </div>
				  
				  
				  
				  
				   <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2" style="cursor:pointer"></div>
				        <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2">
				       Why should I join QPals?
				      </a>
				    </div>
				    <div id="collapse_2" class="accordion-body collapse">
				      <div class="accordion-inner">
				      Need your friends' help in making a decision?   “Should I buy the red shoes or the black ones?” “Where are we going for happy hour?” "Which movie are we watching tonight" “Who is up for poker Friday night?”  With QPals, and a few clicks, you can send a "Q" to a private group of your close friends or to all your friends and followers on popular social networks.  If your friends keep their push notification turned on for QPals, you'll get your answer instantly – it's faster and more fun than texting or calling all your friends one by one.  Plus you and your friends can chat and change your votes before making any group decision.   It sure beats the dreaded ‘reply to all’ email chain.
                      </div>
				    </div>
				  </div>
				  
				  
				  <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" data-toggle="collapse" data-parent="#accordion2" href="#collapse_3" style="cursor:pointer"></div>
				        <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_3" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_3">
				        How does QPals work?
				      </a>
				    </div>
				    <div id="collapse_3" class="accordion-body collapse">
				      <div class="accordion-inner">
				      It’s simple.  Create a Q – a photo-poll with a question and up to 4 photos and answers – and send it to a private group of close friends and/or post it on your favorite social networks.  Your private group friends get an alert (typically a push notification), look at your Q and respond, giving you almost instant feedback.  Everyone can vote (including you), chat and change their votes.
                      </div>
				    </div>
				  </div>
				  
				  <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class=" accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_4" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_4" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_4">
				        Is QPals really free?
				      </a>
				    </div>
				    <div id="collapse_4" class="accordion-body collapse">
				      <div class="accordion-inner">
				     QPals is free to register, install and use.  We may display advertisements, get sponsors or provide premium features in the future but the current features will always be free for individual users.  Please remember, however, that you are responsible for any data connection charges or other charges that you incur from your mobile service provider 
                      </div>
				    </div>
				  </div>

				  <div class="accordion-group">
				    <div class="accordion-heading">
				       <div style="cursor:pointer" class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_5" style="cursor:pointer"></div>
				       <div style="cursor:pointer" class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_5" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_5">
				       Can i delete a group?
				      </a>
				    </div>
				    <div id="collapse_5" class="accordion-body collapse">
				      <div class="accordion-inner">
				     If you are the Group Creator for a Group, you may delete that Group in the Groups screen.
                      </div>
				    </div>
				  </div>
				  
				    <div class="accordion-group">
				    <div class="accordion-heading">
				       <div style="cursor:pointer" class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_6" style="cursor:pointer"></div>
				       <div  style="cursor:pointer" class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_6" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_6">
				       Can I delete another member from a Group?
				      </a>
				    </div>
				    <div id="collapse_6" class="accordion-body collapse">
				      <div class="accordion-inner">
				   If you are the Group Creator for a Group, you may add or delete another member from the group.  If you are not the Group Creator, then you may delete only yourself from the Group.
                      </div>
				    </div>
				  </div>
				  
				   <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_7" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_7" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_7">
				      Can I remove myself from a Group?
				      </a>
				    </div>
				    <div id="collapse_7" class="accordion-body collapse">
				      <div class="accordion-inner">
				  If you are not the Group Creator, then you may delete only yourself from the Group in the Groups screen.
                      </div>
				    </div>
				  </div>
				  
				     <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_8" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_8" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_8">
				    Does QPals work throughout the world?
				      </a>
				    </div>
				    <div id="collapse_8" class="accordion-body collapse">
				      <div class="accordion-inner">
				Yes.  Anyone with an email address can register on QPals.  Even without a mobile phone, you can still be active on QPals using our website, www.QPals.com.  Users who do not have a supported mobile phone, but have a data connection (i.e. can receive emails and open a web browser), will receive alerts in the form of emails and should configure their mobile phones to receive QPals alert emails.
                      </div>
				    </div>
				  </div>
				  
				    <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_9" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_9" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_9">
				    Which mobile phones are supported (i.e. have a QPals app)?
				      </a>
				    </div>
				    <div id="collapse_9" class="accordion-body collapse">
				      <div class="accordion-inner">
				 Currently we have free QPals apps for the iPhone, Android and Windows phones.  
                      </div>
				    </div>
				  </div>
				  
				     <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_10" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_10" style="cursor:pointer"></div>
  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_10">
				       I don’t know if the friends I want to add to my QPals group have iPhones, Android or Windows phones – can I still invite them?
				      </a>
				    </div>
				    <div id="collapse_10" class="accordion-body collapse">
				      <div class="accordion-inner">
YES.  Anyone who can access the web from his or her data-connected phone or has a computer with an internet connection can use QPals.                        </div>
				    </div>
				  </div>
				  
				     <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_11" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_11" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_11">
				   Why do you need my email address during registration?  
				      </a>
				    </div>
				    <div id="collapse_11" class="accordion-body collapse">
				      <div class="accordion-inner">
				  We need your email address to communicate with you pursuant to our Privacy Policy.  Primarily we use your email address so we can assign you a unique user id.  We ask for other or secondary email addresses you use or which your friends use to contact you so we can alert you through the QPals app if one of your friends adds you to his or her groups using an email address that is not the one which you used to register.  This also helps prevent requests for you to register multiple QPals accounts.  Don't worry - we will never sell any personally identifiable information about you (including your email address) without your express consent. 
                      </div>
				    </div>
				  </div>
				  
				     <div class="accordion-group">
				    <div class="accordion-heading">
				       <div class="toggle_plus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_12" style="cursor:pointer"></div>
				       <div class="toggle_minus" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_12" style="cursor:pointer"></div>
				       <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_12">
				   How can I get an infringing or objectionable photograph removed?
				      </a>
				    </div>
				    <div id="collapse_12" class="accordion-body collapse">
				      <div class="accordion-inner">
				We follow the federal Digital Millennium Copyright Act (DMCA) by responding to notices of alleged infringement that comply with the DMCA and other applicable laws.  Please review our DMCA Notice and follow instructions.   We may remove or disable access to potentially infringing material residing on a website or database for applications that is controlled or operated by QPals.  In such event, we will make a good-faith attempt to contact the person who submitted the affected material so that they may make a counter notification, also in accordance with the DMCA.  We also want to provide a pleasant experience on QPals, and may, in our sole judgment or discretion, remove material or terminate user accounts that post material which is obscene or otherwise harmful to other users.
                      </div>
				    </div>
				  </div>
				  
				  
				  
				  
            </div>


         </div>       
       </div>
      

    <!-- -------------------------- END CONTAINER---------------------------------   -->
    
    <?php $this->load->view('frontendFooter');?>
