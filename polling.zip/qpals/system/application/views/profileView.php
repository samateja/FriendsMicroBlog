  
  <?php $this->load->view('headerView');
  $bucket = $this->config->item("bucket");?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
  <?php 
    $bucket = $this->config->item("bucket");
  if($userData){
  	$firstName	= $userData[0]['firstName'];  	
	$lastName	= $userData[0]['lastName'];
    $displayName= $userData[0]['displayName'];
	$biography	= $userData[0]['biography'];
	$email	    = $userEmail;
	$userlocation= $userData[0]['locationName'];
	if($userlocation){
		$location	= $userlocation;
	}else{
		$location= "";
	}

	$userGender = $userData[0]['gender'];
	if($userGender){
	$gender		= $userGender;
	}else{
	$gender	    = "";
	}
	//$photo		= base_url()."Uploads/ProfilePictures/".$userData[0]['photo'];
	//$thumb		= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
	$photo		=$userData[0]['thumb'];
	if($userData[0]['thumb'] != 'avatar.png'){
		$photo		=$this->_S3Url.$userData[0]['thumb'];
	}else{
		$photo= base_url()."Uploads/ProfilePictures/avatar.png";
	}
	$thumb		= $this->_S3Url.$userData[0]['thumb'];
	
  }
   
  ?>
  <div class="row">
             <div style="text-align:right; padding-right:203px; padding-bottom:5px;font-style:italic" class="bold_italic"> <a href="<?php echo base_url('profile/editProfile');?>">Edit Profile</a></div>
           </div>
    <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_profile">
               <div class="span5 devider_span">
                   <h3><?php echo $displayName; ?></h3> 
                        
                          <div class="row">
	                   
	                         <div class="style_bigprofile"><img src="<?php echo $photo;?>" width="355" height="355" alt="" /> </div>
	                       
	                       </div>
	                   
	                   <h4>Bio</h4> 
	                   
	                    <table width="100%" class="form_profile">
	                     <tr>
	                       <td width="35"><img src="<?php echo base_url();?>images/icon_small_profile.png" width="28" height="28" alt="" /> </td>
	                       <td><?php echo $displayName;?> </td>
	                        
	                     </tr>
	                     
	                      <tr>
	                       <td> <img src="<?php echo base_url();?>images/icon_about.png" width="28" height="28" alt="" /> </td>
	                       <td><?php echo $biography;?></td>
	                        
	                     </tr>
	                                     
	                   </table>
	                   
                      <h4>Private Information</h4> 
                      
                       <table width="100%" class="form_profile">
                       
	                     <tr>
	                       <td width="35"><img src="<?php echo base_url();?>images/icon_email.png" width="28" height="28" alt="" /></td>
	                       <td><?php echo $email;?></td>
	                     </tr>
	                     
	                     
	                     <tr>
	                       <td><img src="<?php echo base_url();?>images/icon_location.png" width="28" height="28" alt="" /></td>
	                       <td><?php echo $location;?></td>
	                     </tr>
	                     
	                      <tr>
	                       <td><img src="<?php echo base_url();?>images/icon_gender.png" width="28" height="28" alt="" /></td>
	                       <td><?php 
	                       if($gender==1){
	                       	
	                       	echo "Male";
	                       }elseif($gender==2){
	                       	echo "Female";
	                       }else{
	                       	echo "";
	                       }
	                       ?>
	                       </td>
	                     </tr>
	                                     
	                   </table>
	                   
                      <!--<h4>Private Information</h4> 
                      
                      <table cellpadding="4">
                       <tr>
                         <td><a href="#"><img src="<?php echo base_url();?>images/icon_inner_facebook.png" width="40" height="40" alt="" /></a></td>
                         <td><a href="#"><img src="<?php echo base_url();?>images/icon_inner_twitter.png" width="40" height="40" alt="" /></a></td>
                          <td><a href="#"><img src="<?php echo base_url();?>images/icon_inner_pinterest.png" width="40" height="40" alt="" /></a></td>                       
                       </tr>
                      </table>-->
	                   
	                   
               </div>  
               
               
               <div class="span7">
                    <div id="tabs">
								 <ul class="tabs" id="tabsnav">
								  <li><a href="#tab-1" class="tab menu-internal">Q Created (<?php echo $iCreated;?>)</a></li>
								  <li><a href="#tab-2" class="tab menu-internal">Q Received (<?php echo $iRecieved;?>)</a></li>
								  <li><a href="#tab-3" class="tab menu-internal">Following (<?php echo $countOfFollowing;?>)</a></li>
								  <li><a href="#tab-4" class="tab menu-internal">Followers (<?php echo $countOfFollowers;?>)</a></li>
								 </ul>
								 
								 <div id="tab-1" style="float:left">
								     
                          <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden; float:left">
                                <ul>
								  <?php 
								  if($Icreated){//if received Q's								  	
								  	foreach($Icreated as $rec){ 
								    $qId=$rec['ID'];
								    $qsn=$rec['name'];
								    $time1 = $rec['timeStamp'];
						            $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					                $time2 = date('Y-m-d H:i:s');
					                $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					                $userId=$rec['user_ID'];
								  	$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						            if($qCreatorDetails){
			                       $uname=$qCreatorDetails[0]['displayName'];
						           }else{
							       $uname="";
						           }
						           $qImageData=$this->getdatamodel->getQImages($qId);
						           //print_r($qImageData);die;
								  	if($qImageData){
							          $imgName=$qImageData[0]['thumb'];
							           if($imgName){
								        $photo=$this->_S3Url.$imgName;
							          }else{
								      $photo=base_url()."Uploads/QImages/default_thumb.jpg";
							        }
								  	}
								  	  	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
									if($getAggregateVotes){
										$opt1 = $getAggregateVotes[0]['opt1'];
								        $opt2 = $getAggregateVotes[0]['opt2'];
								        $opt3 = $getAggregateVotes[0]['opt3'];
								        $opt4 = $getAggregateVotes[0]['opt4'];
								        
									    if ($opt3 == NULL)
								        {
									      $opt3 = 0;
								        }
								
								        if ($opt4 == NULL)
								        {
									      $opt4 = 0;
								        }
								        
									   if ($opt2 == NULL)
								        {
									      $opt2 = 0;
								        }
								        
								        $result = ($opt1+$opt2+$opt3+$opt4);
								        $responseCount=$result;
									}else{
										$responseCount=0;
									}	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url();?>/qwall/viewQ/<?php echo $qId; ?>"><img src="<?php echo $photo;?>" width="200" height="200" alt="" /></a><br>
                                   <div>
                                   <div class="question"><?php echo $qsn;?></div> 
                                   <div class="comment_bg"> <p><?php if(!empty($responseCount)){echo $responseCount;} elseif(empty($responseCount)) { echo $responseCount;};?></p></div> 
                                   <div class="fleft" style="font-style:italic"><?php echo $qAge;?> ago by <span class="bold_italic"><?php echo $uname; ?></span></div> 
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{ ?>
							
							<li>
                                    <div style="top:50%;left:60%;position:absolute;color:#999a8a">
                                    No Created Q's for user.
                                </div>
                              </li>
							
							<?php 
					            //echo "No Q's available.";
				               }
								  
						 ?>
								  </ul>
								  <?php //echo $this->pagination->create_links();?>   
							</div>  								     
								     
								 </div>
								 
						<div id="tab-2">
							<div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden; float:left">
                                <ul>
								  <?php 
								  if($receivedQ){//if received Q's								  	
								  	foreach($receivedQ as $rec){ 
								   $qId=$rec['ID'];
								    $qsn=$rec['name'];
								    $time1 = $rec['timeStamp'];
						            $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					                $time2 = date('Y-m-d H:i:s');
					                $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					               	$userId=$rec['user_ID'];
								  	$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						            if($qCreatorDetails){
			                       $uname=$qCreatorDetails[0]['displayName'];
						           }else{
							       $uname="";
						           }
						           $qImageData=$this->getdatamodel->getQImages($qId);
								  	if($qImageData){
							          $imgName=$qImageData[0]['photo'];
							           if($imgName){
								        $photo=$this->_S3Url.$imgName;
							          }else{
								      $photo=base_url()."Uploads/QImages/default_thumb.jpg";
							        }
								  	}
								     	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
									if($getAggregateVotes){
										$opt1 = $getAggregateVotes[0]['opt1'];
								        $opt2 = $getAggregateVotes[0]['opt2'];
								        $opt3 = $getAggregateVotes[0]['opt3'];
								        $opt4 = $getAggregateVotes[0]['opt4'];
								        
									    if ($opt3 == NULL)
								        {
									      $opt3 = 0;
								        }
								
								        if ($opt4 == NULL)
								        {
									      $opt4 = 0;
								        }
								        
									   if ($opt2 == NULL)
								        {
									      $opt2 = 0;
								        }
								        
								        $result = ($opt1+$opt2+$opt3+$opt4);
								        $responseCount=$result;
									}else{
										$responseCount=0;
									}		
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url();?>/qwall/viewQ/<?php echo $qId; ?>">
                                    <img src="<?php echo $photo;?>" width="200" height="200" alt="" />
                                    </a>
                                    <br>
                                   <div>
                                   <div class="question"><?php echo $qsn;?></div> 
                                   <div class="comment_bg sd"> <p><?php if(!empty($responseCount)){echo $responseCount;}elseif(empty($responseCount)) { echo $responseCount;};?></p></div> 
                                   <div class="fleft"><?php echo $qAge;?> ago by <span class="bold_italic"><?php echo $uname; ?></span></div> 
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{ ?>
					           <li>
                                    <div style="top:50%;left:60%;position:absolute;color:#999a8a">
                                    No Received Q's for user.
                                </div>
                              </li>
				              <?php  }
								  
								  ?>
								  </ul>
								  <?php //echo $this->pagination->create_links();?>   
							</div>
							 
					</div>
								 
								 <div id="tab-3">
								 <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;float:left">
								  <ul>
								  <?php 
								  if($followingPals){//if received Q's								  	
								  	foreach($followingPals as $rec){ 
								    $fUserId=$rec['followers_ID'];
			                        $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
			                       // print_r($userData);
			                      //  echo $userData[0]['thumb'];
			                        if($userData[0]['thumb'] == 'avatar_thumb.png'){
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }else{
			                        	$thumb=$this->_S3Url.$userData[0]['thumb'];
			                        }
						           // $thumb= 'http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $display= $userData[0]['displayName'];
						            
								    	
								  ?>
								  	<li>
                                    <div class="thumbs_list">
                                   <a href="<?php echo base_url();?>findPals/viewPals/<?php echo $fUserId;?>">
                                     <img src="<?php echo  $thumb;?>" width="200" height="200" alt=""/>
                                   </a>
                                  <br>
                                   <div>
                                   <div class="question"><?php echo  $display;?></div>                                
                                  
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{ ?>
					             <li>
                                    <div style="top:50%;left:60%;position:absolute;color:#999a8a">
                                    You are not following any one.
                                </div>
                              </li>
				                <?php  }
								  
								  ?>
								  </ul>
								 </div>
								</div> 
								 <div id="tab-4">
								  <div class="thumbs_group" style="overflow: scroll; width: 600px; height: 900px;overflow-x: hidden;float:left">
								  <ul>
								  <?php 
								  if($followers){//if received Q's								  	
								  	foreach($followers as $rec){ 
								  		
								  	$fUserId=$rec['user_ID'];
				                    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
								  	if($userData[0]['thumb'] != 'avatar_thumb.png'){
			                        	$thumb		=$this->_S3Url.$userData[0]['thumb'];
			                        }else{
			                        	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
			                        }
						           // $thumb   ='http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
						            $displayName=$userData[0]['displayName'];							    
						             ?>
								  	<li>
                                    <div class="thumbs_list">
                                    <a href="<?php echo base_url();?>findPals/viewPals/<?php echo $fUserId;?>">
                                     <img src="<?php echo  $thumb;?>" width="200" height="200" alt=""/>
                                     </a>
                                     <br>
                                   <div>
                                   <div class="question"><?php echo  $displayName;?></div>                                
                                  
                                   </div> 
                                </div>
                              </li>
								  		
								  <?php } ?>                             
                             
							<?php }else{ ?>
					             <li>
                                    <div style="top:50%;left:60%;position:absolute;color:#999a8a">
                                     You don't have any followers.
                                </div>
                              </li>
				               <?php  }
								  
								  ?>
								  </ul>
								 </div>
								 </div>
								 
								</div>                    
                    </div>
               </div> 
        </div>      
      </div>    

   <!--   Added by Padmaja -->
   
  <?php if('#'){?>
      <!-- Account Preferences start -->
   
  <div style="border-radius:0px; border:none;" id="accountPreferences" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > <img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" /></div>
		<div style="padding:15px;" class="modal-body">
			<table cellpadding="5">
			<tr>
			 <td colspan="2" style="font-family:roboto-bold; font-size:16px;">
			 Email Notifications
		     <div class="pull-right"> 
		     <?php 
		     $userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
		     $isEmailAlerts	= $userData[0]['isEmailAlerts'];
		     ?>
		     <input type="checkbox"  name="emailAlerts" id="emailAlerts" <?php if($isEmailAlerts==1) {?>checked="checked"<?php }?>onclick="addEmailAlerts();" />
		     </div>
		    </td>
		</tr>
		
		
		<tr>
		 <td colspan="2" style="font-family:roboto-bold;  font-size:16px;">Default Question</td>
		</tr>
		
		<tr>
		 <td> 
		 <input type="radio" name="ex2_a" id="" onclick="return noDefaultQuestion();">
		 </td>
		<td>No Default Question</td>
		</tr>
		
		
		<?php 
		$presetQuestions=$this->getdatamodel->getPresetQuestions();
		if($presetQuestions){
			foreach($presetQuestions as $rec){
				$questionId=$rec['ID'];
				$question  = $rec['questionDesc'];
				$userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$userQuestionId= $userData[0]['defaultQuestion_ID'];
               
			   $userDefaultQuestion=$this->getdatamodel->getQuestionByID($userQuestionId);					
			   $presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];
			   if($presetQuestion_Id==0){
				$userDefaultQsnId = 0;	
				}else{
				$userDefaultQsnId = $userDefaultQuestion[0]['presetQuestion_Id'];	
				}
				
		?>						
		<tr>
		 <td> 
		 <input type="radio" name="ex2_a" id="<?php echo $questionId;?>" <?php if($questionId==$userDefaultQsnId) {?>checked="checked"<?php }?> onclick="return setDefaultQuestion(<?php echo $questionId;?>);">
		 </td>
		<td><?php echo $question;?></td>
		</tr>
		
		<?php } }?>						
		
		<?php 
		   
		  $userAddeddQuestions=$this->getdatamodel->getQuestionsByUserId($sessionlog);
		  if($userAddeddQuestions){
		  	foreach($userAddeddQuestions as $rec){
		  		
		  		$questionId	= $rec['ID'];
				$question	= $rec['name'];
		  	   $userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$userQuestionId= $userData[0]['defaultQuestion_ID'];
               
			   $userDefaultQuestion=$this->getdatamodel->getQuestionByID($userQuestionId);					
			   $presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];
			   if($presetQuestion_Id==0){
				$userDefaultQsnId =$userDefaultQuestion[0]['ID'];	
				}else{
				$userDefaultQsnId = $userDefaultQuestion[0]['presetQuestion_Id'];	
				}
		?>
		
		<tr>
		 <td> 
		 <span id="showAddCustomQues">
		 <input type="radio" name="ex2_a" id="<?php echo $questionId;?>" <?php if($questionId==$userDefaultQsnId) {?> checked="checked"<?php }?> onclick="return setCustomDefaultQuestion(<?php echo $questionId;?>);">
		 
		 </td>
		<td><?php echo $question;?></span></td>
		</tr>
		
		
		<?php } } ?>
								
		<tr>
		<td><input type="radio" name="ex2_a" id="" onclick="return setCustomQuestion();">  
		</td> 
		<td>Custom question: </td>  
		</tr>
		
		
		<tr>		  
           <td colspan="2">          
           <span id="showCustomQuestion" style="display:none;">
           <input class="span3" type="text" placeholder="Type your question here" name="customQuestion" id="customQuestion">
           &nbsp;
           <button onclick="return addCustomQuestion();">
		   Submit</button>
           </span>
           </td>           
        </tr>
        
								
		<tr>
           <td colspan="2" style="font-family:roboto-bold;  font-size:16px;">Default Group</td>								
		</tr>
		
		<tr>
		<td> <input type="radio" name="ex2_a1" id="ex2_a1" onclick="return setNoDefaultGroup();" > </td>
         <td>No Default Group</td>								
		</tr>
		
		
		<?php 
		$userGroups=$this->getdatamodel->getUserGroupsList($sessionlog);
		if($userGroups){
			foreach($userGroups as $group){
				$groupId	= $group['ID'];
				$groupName= $group['name'];
				$userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$defaultGroup	= $userData[0]['defaultGroup_ID'];
		?>					
		<tr>
		<td> <input type="radio" name="ex2_a1" id="ex2_a1" <?php if($defaultGroup==$groupId) { ?>checked="checked"<?php } ?> onclick="return setDefaultGroup(<?php echo $groupId;?>);"> </td>
         <td><?php echo $groupName;?></td>								
		</tr>								
		<?php } } ?>						
			</table>
           	   
		</div>
			
	 </div> 
   <?php }?>
       <!-- Account Preferences End -->
    <!-- -------------------------- END CONTAINER---------------------------------   -->
 <script type="text/javascript">

$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });

</script>
 <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>
<!-- scrolling -->



    <?php $this->load->view('footerView');?>
