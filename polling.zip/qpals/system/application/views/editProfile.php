  
  <?php $this->load->view('headerView');?>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  <?php  
  //$bucket = $this->config->item("bucket");
  $S3Url     = $this->config->item('S3Url');
  if($userData){
  	$firstName	= $userData[0]['firstName'];  	
	$lastName	= $userData[0]['lastName'];
    $displayName= $userData[0]['displayName'];
	$biography	= $userData[0]['biography'];
	$email	    = $userEmail;
	$userlocation= $userData[0]['locationName'];
	if($userlocation){
		$location	= $userlocation;
	}else{
		$location= "";
	}

	$userGender = $userData[0]['gender'];
	if($userGender){
	$gender		= $userGender;
	}else{
	$gender	    = "";
	}
	
	$photo		= $this->_S3Url.$userData[0]['photo'];
	$isthumb    = $userData[0]['thumb'];
	
	if($userData[0]['thumb'] != 'avatar_thumb.png'){
	$thumb		= $this->_S3Url.$userData[0]['thumb'];
	}else{
	$thumb		=base_url()."Uploads/ProfilePictures/avatar.png";
	}
	
  }
   
  ?>
   <form method="post" enctype="multipart/form-data" action="">
 <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner h_line_profile">
        
        <div class="row">
         <?php if(isset($successMessage)){ ?>
               <div class="alert alert-success"><?php echo $successMessage;?></div>
               	
               <?php $redirectUrl=base_url().'profile/viewProfile';
               header("Refresh:3;url=$redirectUrl");
               }
               ?>  
               
               <?php if(isset($errormessage)){ ?>
               <div class="alert alert-error"><?php echo $errormessage;?></div>
               	
               <?php $redirectUrl=base_url().'profile/editProfile';
               //header("Refresh:2;url=$redirectUrl");
               }?>  
        </div>
          <div class="row">
          
          
        
               <div class="span5 devider_span">
                         
                   <h4>Name</h4>                   
	                   <table width="100%" class="form_profile">
	                     <tr>
	                       <td>
	                       <input type="text" style="width:90%;" name="firstName" value="<?php echo $firstName;?>">
	                       <span style="color: red;"><?php echo form_error('firstName'); ?></span>
	                       </td>
	                       
	                     </tr>
	                     <tr> 
	                       <td>
	                       <input type="text" style="width:90%;" name="lastName" value="<?php echo $lastName;?>">
	                       <span style="color: red;"><?php echo form_error('lastName');?></span>
	                       </td>                     
	                     </tr>                   
	                   </table>
	                   
	                   <h4>Photo</h4> 
	                   
	                    <table width="100%" class="form_profile">
	                     <tr>
	                       <td><div class="img_profile"> 
	                       <div class="img_cross" id="deleteImage">
	                       <?php if($isthumb !="avatar_thumb.png"){?>
	                       <img src="<?php echo base_url();?>images/icon_cross.png" width="22" height="22" alt="" />
	                       <?php } ?>
	                       </div> 	                       
	                       <div id="showImage"><img src="<?php echo $thumb;?>" width="105" height="105" alt="" /></div></div>
	                       <div>
	                       <input type="file" name="profileImage" id="profileImage"></input><br />
	                      
	                       </div> 
	                       </td>
	                     </tr>
	                                     
	                   </table>
	                   
                      <!-- <h4>Share</h4> 
                      
                       <table width="30%" class="form_profile">
	                     <tr>
	                       <td><img src="<?php echo base_url();?>images/icon_inner_facebook.png" width="40" height="40" alt="" />  </td>
	                       <td><img src="<?php echo base_url();?>images/icon_inner_twitter.png" width="40" height="40" alt="" /></td>
	                       <td><img src="<?php echo base_url();?>images/icon_inner_pinterest.png" width="40" height="40" alt="" /></td>
	                     </tr>
	                                     
	                   </table>
	                   -->
	                   
               </div>  
               
               
               <div class="span7">
                    <h4>Bio</h4> 
                    
                    <table width="100%" class="form_profile">
	                     <tr>
	                       <td class="lable_profile" width="100">Profile ID</td>
	                       <td width="40"><img src="<?php echo base_url();?>images/icon_small_profile.png" width="28" height="28" alt="" /></td>
	                       <td>
	                       <input type="text" style="width:100%;" name="displayName" value="<?php echo $displayName;?>">
	                       <span style="color: red;"><?php echo form_error('displayName');?></span>
	                       </td>
	                     </tr>
	                     
	                       <tr>
	                       <td class="lable_profile">About</td>
	                       <td><img src="<?php echo base_url();?>images/icon_about.png" width="28" height="28" alt="" /></td>
	                       <td><input type="text" style="width:100%;" name="biography" value="<?php echo $biography; ?>" placeholder="Tell ur followers about yourself"></td>
	                     </tr>
	                                    
	                   </table>
	                   
	                   <h4>Private Information</h4> 
	                   
	                     <table width="100%" class="form_profile">
	                     <tr>
	                       <td width="100" class="lable_profile">Email</td>
	                       <td width="40"><img src="<?php echo base_url();?>images/icon_email.png" width="28" height="28" alt="" /></td>
	                       <td><input type="text" style="width:100%;" name="email" value="<?php echo $email;?>" readonly>
	                       
	                        <div  class="icon_add">
	                        <div id="addemail">
	                         <div data-toggle="tooltip" data-placement="bottom" title="ADD SECONDARY EMAIL ADDRESS"> 
	                        <span id="addButton" ><img  onclick="return show()" src="<?php echo base_url();?>images/icon_add.png" width="22" height="22" alt="" style="padding-right:24px;" /></span>
	                      </div></div>
	                      
	                      </div> 
	                       </td>
	                     </tr>
	                     
	                     <?php 
	                     if($displaySecondaryEmails){
						  echo $displaySecondaryEmails;
							
						}
	                     ?>
	                     
	                     <tr>
	                     <td width="100" class="lable_profile">&nbsp;</td>
	                     <td width="40"></td>
	                     <td>
	                     <div id="TextBoxesGroup">
	                      <div id="TextBoxDiv1" style="display:none;">
	                      
                          <span ><input type='text' id='textbox1' style="width:100%;" name='secondaryEmail[]' placeholder="Secondary Email" /></span>
                         </div>
                         </div>
                         </td>
	                     </tr>
	                     
	                       <tr>
	                       <td class="lable_profile">Location</td>
	                       <td><img src="<?php echo base_url();?>images/icon_location.png" width="28" height="28" alt="" /></td>
	                       <td><input type="text" style="width:100%;" name="location" value="<?php echo $location;?>"></td>
	                     </tr>
	                     
                        <tr>
	                       <td class="lable_profile">Gender</td>
	                       <td><img src="<?php echo base_url();?>images/icon_gender.png" width="28" height="28" alt="" /></td>
	                       <td><div style="float:left;margin-top: 8px;">Male&nbsp;&nbsp;</div><div style="float:left;margin-top: 5px;"><input type="radio" name="gender" value="1" <?php if($gender==1){ ?>checked<?php }?>></input></div>&nbsp;&nbsp;&nbsp;
	                       <div style="float:left;margin-top: 8px;">Female&nbsp;&nbsp;</div><div style="float:left;margin-top: 5px;"><input type="radio" name="gender" value="2" <?php if($gender==2){ ?>checked<?php }?>></input></div>
	                       </td>
	                     </tr>
	                                    
	                   </table>
	                   
                     <h4>Change Password</h4> 
                     
                      <table width="100%" class="form_profile" style="margin-bottom:0px;">
	                     <tr>
	                       <td width="100" class="lable_profile">Current</td>
	                       <td width="40"><img src="<?php echo base_url();?>images/icon_lock.png" width="28" height="28" alt="" /></td>
	                       <td>
	                       <input type="password" style="width:100%;" name="currentPassword" placeholder="Current password">
	                        <span style="color: red;"><?php echo form_error('currentPassword');?></span>
	                       </td>
	                     </tr>
	                      <tr> <td>
	                       <?php if(isset($errormssge)){ ?>
              				 <div class="alert alert-error"><?php echo $errormssge;?></div>
               	
              			 <?php $redirectUrl=base_url().'profile/editProfile';
              			 //header("Refresh:2;url=$redirectUrl");
              				 }?> <td>
              				 </td></tr> 
	                       <tr>
	                       <td class="lable_profile">New</td>
	                       <td width="40"><img src="<?php echo base_url();?>images/icon_lock.png" width="28" height="28" alt="" /></td>
	                       <td>
	                       <input type="password" style="width:100%;" name="newPassword"  placeholder="New password">
	                        <span style="color: red;"><?php echo form_error('newPassword');?> </span>
	                       </td>
	                     </tr>
	                     
                        <tr>
	                       <td class="lable_profile">Confirm</td>
	                       <td width="40"><img src="<?php echo base_url();?>images/icon_lock.png" width="28" height="28" alt="" /></td>	
	                       <td>
	                       <input type="password" style="width:100%;" name="confirmPassword" placeholder="Confirm password">
	                         <span style="color: red;"><?php echo form_error('confirmPassword');?></span>
	                       </td>
	                     </tr>
	                                    
	                   </table>

               </div> 
           </div>
        </div>      
      </div>    
    </div>
     

   
   <div class="container-fluid">
         <div class="row-fluid">
             <div class="container">
               <div class="pull-right"> 
                 <button class="butn">CANCEL</button> 
                 <button class="butn profile" type="submit" name="updateProfile">SAVE</button>  
                 <!-- <input type="submit" name="updateProfile" value="SAVE" class="butn profile"> -->
               </div>            
             </div>         
         </div>   
   </div>
   </form>
   
    <!-- -------------------------- END CONTAINER---------------------------------   -->
  <script type="text/javascript">
$("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});

</script>
    
     
     <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>


<!-- start of dynamic jquery text box -->
<script>
 
	function validate()
	{ 
		var secondaryEmail = document.getElementsByName("secondaryEmail[]");		
		
	    for(var i=0;i< secondaryEmail.length; i++) {	    				
			if(secondaryEmail[i].value == ""){				
				alert('The email field is required.');			
				secondaryEmail[i].focus();
				return false;
			}

			var EmailId = secondaryEmail[i].value;
			var emailfilter = /(([a-zA-Z0-9\-?\.?]+)@(([a-zA-Z0-9\-_]+\.)+)([a-z]{2,3}))+$/;
			if((EmailId != "") && (!(emailfilter.test(EmailId ) ) )) {
			   
			    alert('Please enter your valid email address.');
			    return false;
			}			   
			
		}
		return true;
     }

   function show(){//first to show hidden div and replace an add icon
	 $('#TextBoxDiv1').show();		 
	 $('#addButton').html('<img onclick="return allValidations()" src="<?php echo base_url();?>images/icon_add.png" width="22" height="22" alt="" style="padding-right:24px;">');	
   }
   
   function allValidations()
   {	
	var success =  validate();
	if(success){		
	addRow();
	}
	
 }


   function addRow(){		
    $('#TextBoxDiv1').append('<div><input type="text" style="width:100%;"  name="secondaryEmail[]" id="secondaryEmail" placeholder="Secondary Email"></div>');	            
  }

</script>



<!-- end of jquery text box -->

<!-- delete secondary Email -->
 
 <script>
   function deleteSecEmail(id){ 
	   
	   $(document).ready(function(){	   
			   	         
	        	var retVal = confirm("Do you want to continue ?");
	        	   if( retVal == true ){
	        		   var base_url="<?php echo base_url('profile/deleteSecEmail');?>";

	                   $.post(base_url,{id:id},function(response){
	                	   $('#secEmail_'+id).html('');   
	                   });
	        		  return true;
	        	   }else{        	      
	        		  return false;
	        	   }          
	           
	      
	   });  
   }
 </script> 



<!-- delete an image -->

  <script type="text/javascript">

    $(document).ready(function(){

        $('#deleteImage').click(function(){ 
        	var retVal = confirm("Do you want to continue ?");
        	   if( retVal == true ){
        	      //alert("Are you sure you want to delete");
        	      var base_url="<?php echo base_url('profile/editProfile');?>";        	         
                  $.post(base_url,{isDelProfilePic:1},function(response){
                  	//alert(response.text);  
                    $('#showImage').html('<img src="<?php echo  base_url()."Uploads/ProfilePictures/avatar_thumb.png";?>" width="105" height="105" alt="" />');
                  });
        		  return true;
        	   }else{        	      
        		  return false;
        	   }          
            });
       });

  </script>



    <?php $this->load->view('footerView');?>
