  
  <?php $this->load->view('headerView');?>
  <link rel="stylesheet" href="<?php echo base_url();?>scroll.css" type="text/css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/progressbar.css">
  <script type="text/javascript" src="<?php echo base_url();?>js/progressbar.js"></script>
   
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  
     <div class="container-fluid">
      <div class="row-fluid">
        <div class="container content_inner row h_line_green"> 
                
                <h2 style="margin-top:5px;">DMCA NOTICE</h2>      
                
                <p>We follow the federal Digital Millennium Copyright Act (DMCA) by responding to notices of alleged infringement that comply with the DMCA and other applicable laws.  Please review our DMCA Notice and follow instructions.   We may remove or disable access to potentially infringing material residing on a website or database for applications that is controlled or operated by QPals.  In such event, we will make a good-faith attempt to contact the person who submitted the affected material so that they may make a counter notification, also in accordance with the DMCA.  We also want to provide a pleasant experience on QPals, and may, in our sole judgment or discretion, remove material or terminate user accounts that post material which is obscene or otherwise harmful to other users.</p>
               
               <p>Before you serve a Notice of Infringing Material or Counter-Notification, you may wish to consult an intellectual property attorney who can better advise you of your rights and obligations under the DMCA and other applicable laws. The following notice requirements are intended to comply with the DMCA, and do not constitute legal advice.</p>
               <br/>
               <p><b>Notice of Infringing Material</b></p>
               
               <p>To file a notice of infringing material on a website or database for applications that is controlled or operated by QPals, please provide us with the following details:</p>
               <p>             
                  1. Identification of the copyrighted work claimed to have been infringed, or if multiple copyrighted works are covered by a single notification, a representative list of such works at that site (for example: title, author, any registration or tracking number, URL);
                </p>
                
                <p>
                2. Reasonably sufficient detail of the material that is claimed to be infringing or to be the subject of infringing activity and that is to be removed or access to which is to be disabled, and reasonable sufficient information to permit us to locate the material (for example, a screenshot, author, group, time and date of posting);
                
                </p>
                
                <p>
                
                  3. Your contact information so that we can contact you (for example, your address, telephone number, email address);</p>
                
                <p>
                4. A statement that you have a good faith belief that the use of the material identified in (1) is not authorized by the copyright owner, its agent, or the law;
                
                </p>
                
                <p>
                5. A statement that the information in the notification is accurate, and under penalty of perjury, that you are authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.
                
                </p>
                
                <p>
                6. Your physical or electronic signature.
                
                </p>
                <br/>
                
                <p>Please send this notice to:</p>
                
                <p>By Mail:  DMCA Agent: Parag Patel</p>
                <p>The Everest Law Group, APC</p>
                <p>6303 Owensmouth Avenue, 10th Floor,</p>
                <p>Woodland Hills, CA 91367</p>
                <p>By Fax: Attn: DMCA Agent, QPals</p>
                <p>+1 213 341 6602</p>
                <p>By Email: dmca@QPals.com</p>
                <br/>
                <p><b>Counter-Notification</b></p> 
                 
                 <p>After we receive a written Notification properly containing the information as outlined in 1 through 6 above: </p>  
                 <p>1. We shall remove or disable access to the material that is alleged to be infringing; </p>
                 <p>2. We shall forward the written DMCA notice to take down to such alleged infringer; </p>
                 <p>3. We shall take reasonable steps to promptly notify the alleged infringer that it has removed or disabled access to the material.</p>
                 
                 <p>We enforce a policy that provides for the termination in appropriate circumstances of the accounts of users who are repeat infringers.</p>  
                 <p><u>Counter Notification:</u></p>
                 <p>1. Identification of the material that has been removed or to which access has been disabled and the location at which the material appeared before it was removed or disabled;</p>
                 <p>2. A statement, under penalty of perjury, that you have a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material in question;</p>
                 <p>3. Your name, address and telephone number;</p>
                 <p>4. A statement that you consent to the jurisdiction of the Federal District Court for judicial district in which your address is located or, if your address is outside of the USA, for any judicial district in which QPals may be found and that you will accept service of process from the person who submitted a notice in compliance with the section (c)(1)(C) of the DMCA, as generally described above;</p>
                 <p>5. Your physical or electronic signature.</p>
               </div>
              
              </div>            
         </div>       
       </div>
                
                
        
               
               
           

           

         
    <?php $this->load->view('footerView');?>
