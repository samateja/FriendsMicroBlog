  
  <?php $this->load->view('headerView');?>
  <?php $bucket = $this->config->item("bucket");
 
  ?>
 
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/progressbar.css">
  <script type="text/javascript" src="<?php echo base_url();?>js/progressbar.js"></script>
 <!--
  <script type="text/javascript" src="<?php echo base_url();?>js/modernizr.js"></script>
  <script defer src="<?php echo base_url();?>js/jquery.flexslider.js"></script>
  <link rel="stylesheet" href="<?php echo base_url();?>css/flexslider.css" type="text/css" /> 
   -->
	<!-- Added by Padmaja 13-05-2014 -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/colorbox.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="<?php echo base_url();?>js/jquery.colorbox.js"></script>
		<script>
			$(document).ready(function(){
			
				$(".group1").colorbox({rel:'group1'});
						
					$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
		<script>
			window.setTimeout(function() {
				$(".alert-message").fadeTo(60000000, 0).slideUp(1000, function(){
					$(this).remove(); 
				});
			}, 5000);
		</script>
  <!-- -------------------------- BEGIN CONTAINER---------------------------------   -->
  		
   <div id="wait"></div>
   <div class="container-fluid" id="refreshData">
      <div class="row-fluid">
        <div class="container content_inner row h_line_green">
       
       <?if ($shownotification == 1) { ?>
		   <div class="alert alert-surprise fade in alert-message" role="alert">
      <button type="button" class="close" data-dismiss="alert" style="margin-right:-3px"><span aria-hidden="true"></span><span class="sr-only"></span>x</button>
      <h4 style="text-align:center">Welcome to Qpals</h4>
      <br>
      <p>We sent you an email with user name and password.Please check your inbox(or spam filter and add Qpals as a safe sender).</p>
      
    </div>
       <?php } ?>
       
                 <?php
                  
                 $voteSourceGet=$this->uri->segment(4);
                 if($getPrivateGroupMembers){
                 	if($voteSourceGet!=""){
                 	//even the vote source is from social networks if he is a group member still the vote source is 1
                 	$voteSource=1;
                 	}else{
                 	//for group members vote source is 1
                 	$voteSource=1;	
                 	}
                 }else if($voteSourceGet!="" && !$getPrivateGroupMembers){
                 	//3-facebook,4-twitter,5-pinterest and not a private group
                 	$voteSource=$this->uri->segment(4);
                 }else{
                 	//public Qs
                 	$voteSource=2;
                 } 
                 
                 if($userData){
                 	$qId=$this->uri->segment(3);                 	
                 	$qCreatorDisplayName = $userData[0]['displayName'];
                 	
                 	// Added by padmaja
                 	//echo$userData[0]['thumb'];die;
                 	//$qCreatorProfileImageThumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
                  if($userData[0]['thumb'] != 'avatar_thumb.png'){
                  	//echo "asdas";
                  	$qCreatorProfileImageThumb		= $this->_S3Url.$userData[0]['thumb'];
                  }else{
                  	$qCreatorProfileImageThumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
                  }
                 	
                 	$getQdatails=$this->getdatamodel->getQdetails($qId);
                 	$questionDescription= $getQdatails[0]['name'];                 	
                 	$time1          = $getQdatails[0]['timeStamp'];
					$time2          = date('Y-m-d H:i:s');
					$qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);					
					$qCreatorId	    = $qcreatorUserId;
					
					
                 }
                
                 $sessionlog=$this->session->userdata('userID');
               
                if(!$sessionlog && $sourceType!=""){
						$link = $_SERVER['REDIRECT_URL'];
						$this->session->set_userdata(array('redirectUrl'=> $link));
					redirect('socialSharing');
					}
		
				if(!$sessionlog){
					//echo $sessionlog;
					redirect('home');
				}
                
                 //echo $userID;
               
                 $getFavouriteStatus=$this->getdatamodel->getFavouriteStatus($qId,$sessionlog);
                 			  
                 if($getFavouriteStatus){
			      $likeStatus	                = 1;	
			     }else{
			      $likeStatus	                = 0;	
			     }
                 ?>
                 
          <div class="row">
             <div class="question" style="font-size:24px;">
               <?php echo $questionDescription;?>
             </div>  
             <div style="clear:both;"> 
              <div class="fleft">
             
              <img src="<?php echo $qCreatorProfileImageThumb;?>" style="cursor:pointer;" width="60" height="60" alt="" onclick="return viewPal(<?php echo $qCreatorId?>);" />
            
              </div>
             <div class="fright">
              <div class="fleft">
                <img src="<?php echo base_url();?>images/icon_refresh.png" width="30" height="27" alt="" style="margin-top: 4px;float:right;margin-right: 8px;cursor:pointer" id="iconRefresh" onclick="return refreshComments();"/>
                </div>&nbsp;
                    <?php if($likeStatus==0) {
              $setStatus=1;
              ?> 
              <div class="fleft" id="showFavouriteStatus">
               <img src="<?php echo base_url();?>images/heart_inactive.png" style="margin-right:8px; margin-top:3px;cursor:pointer" width="34" height="34"  onclick="return setFavourites('<?php echo $qId;?>','<?php echo $sessionlog;?>','<?php echo $setStatus;?>');"></img>
              </div>&nbsp;
              <?php }elseif($likeStatus==1) { 
              $setStatus=0;
              	?>
              <div class="fleft" id="showFavouriteStatus">
               <img src="<?php echo base_url();?>images/heart_active.png" style="margin-right:8px; margin-top:3px;cursor:pointer" width="34" height="34"  onclick="return setFavourites('<?php echo $qId;?>','<?php echo $sessionlog;?>','<?php echo $setStatus;?>');"></img>
              </div>&nbsp;
               
              <?php } ?>
              <?php if($qCreatorId==$sessionlog) {?>
              
              <div class="fleft">
               <img src="<?php echo base_url();?>images/icon_trash.png" width="34" height="34" style="cursor:pointer" onclick="return deleteQ(<?php echo $qId;?>);" style="margin-left: 13px;"></img>
                </div>&nbsp;
               <?php } ?>
              
            
              
                </div>
                
              <div class="fleft f_italic" style="margin-left:10px; margin-top:8px;">
               <span class="f_bold_italic"><a style="text-decoration:none;"href="<?php echo base_url()."findPals/viewPals/$qCreatorId";?>"><?php echo $qCreatorDisplayName;?></a></span> <br>
                <span class="f_bold"><?php echo $qAge;?></span>&nbsp; </div>
               </div>  
                
                     
                       
          </div>            
                       
                
                <?php 
                
                   foreach($getOptionCount as $row){			
		            $optionCountGet=$row['optionName'];//count of options				 
	               }
	              foreach($getImgCount as $row){			
		           $imgCountGet=$row['thumb'];//count of options				 
	               }
	               
               
                 //echo $imgCountGet;
                
           ?>
                              
        <?php
            
        if($optionCountGet==0 && $imgCountGet==0){//qtype1
        ?>
        <div class="row">  
        </div>
        <?php }else if($imgCountGet > 0 && $optionCountGet ==0){ //only image and no options
        	?>
        	<div class="row">
        	<?php 
        	//echo "asd";
               if($getQOptions){
        		
        		foreach($getQOptions as $row){
        			$imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
        		    if($imgNamethumb){
					$thumb=$this->_S3Url.$imgNamethumb;
					$image=$this->_S3Url.$imgNamePhoto;
					$isDefaultImage=FALSE;
					//break;
					}else{
					$thumb=base_url()."Uploads/QImages/default_thumb.png";
					$image=base_url()."Uploads/QImages/default.png";
					$isDefaultImage=TRUE;	
					}
        		
        		
        		
        		
        	?>
        	
        	
        	       
        
         
		<div  class="span3 thumbs_group"> 
      
                 <a class="group1" href="<?php echo $image;?>">
                 <img src="<?php echo $thumb;?>" width="290" height="290" alt="" />
                  </a>                   
                
            </div> 
                    
        
        
        
          <?php }} ?>
          </div>
          <?php }else if(($imgCountGet==0 || $imgCountGet==1) && $optionCountGet > 0){//q type=2
                  
        	if($getQOptions){
        		
        		foreach($getQOptions as $row){
        			$imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
        		    if($imgNamethumb){
					$thumb=$this->_S3Url.$imgNamethumb;
					$image=$this->_S3Url.$imgNamePhoto;
					$isDefaultImage=FALSE;
					break;
					}else{
					$thumb=base_url()."Uploads/QImages/default_thumb.png";
					$image=base_url()."Uploads/QImages/default.png";
					$isDefaultImage=TRUE;	
					}
        		}
        		
        		
        		
        	}
        	
        	
       ?>
       <?php if($imgNamethumb) { ?>  
 <!-- Commented By Padmaja       
        <div style="border-radius:0px; border:none;" id="img_pop" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > 
		  <img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" />
		</div>
		<div style="padding:15px;" class="modal-body">
			<img src="<?php echo $image;?>" width="350" height="350" alt="" />		   
	    </div>
			
		</div> -->
		<?php } ?>			        
        <div class="row" id="viewQtype2">       
        
           <div style="width:290px;height:350px; overflow:hidden;" class="span3 thumbs_group"> 
               <div style="position:relative">               
                 
                 <?php
                 $i=1;
                 foreach($getQOptions as $row){
				
                 $optionId=$row['ID'];	
                 $option=$row['optionName'];
                 if($option!=""){
                 $optionName=$row['optionName'];
                 }else{
                 $optionName="";
                 }
                 
                 $getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					if($getCountQVotesOptions[0]['qCount']>0){
					$isVoted	     = TRUE;	
					}else{
					$isVoted	     = FALSE;
					} 
                 
                  ?>
                 <button <?php if($isVoted==TRUE) {?>class="btn_answer<?php echo $i;?> answer_yes"<?php } else { ?> class="btn_answer<?php echo $i;?>" <?php  }?> onclick="return voteOption(<?php echo $optionId; ?>);">
                 	<?php echo $row['optionName']; ?>
                 </button>
                 <?php
                 $i++; }
                 ?>
                  </div>  
 	  
                 <a class="group1" href="<?php echo $image;?>">
                 <img src="<?php echo $thumb;?>" width="290" height="290" alt="" />
                  </a> 
                  <?php if($optionCountGet <=2) { //for two options
                 
                    $oCount = 0;
	                $getAggregateVotes = NULL;
	                $qId=$this->uri->segment(3);
                  	foreach($getQOptions as $row){
                  	$optionId=$row['ID'];	
                    $option=$row['optionName'];
                  	$optionName=$row['optionName'];
                  	$idName = "PB_".$oCount;
                  	                 	
                  	if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					//$evaPerc[]    =$aggResult;
					//print_r($evaPerc);die;
					}//end of else
                  	
                  	
                  ?>                  
                  <table class="table_rows" cellpadding="4" style="margin-top:1px;">
                       <tr>
                         <td width="80">
                         <span class="f_bold"><?php echo $optionName;?></span> </td>
                         <td> 
                          <?php if($resPerc!=0) { ?> 
                         <div class="progress_wrap">
                          <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $option;?>');"><div></div></div>                         
                        
                         </div>
                         <?php }else{?>
                         <div class="progress_wrap">
                          
                          <div class="progress_no_cross"></div>
                          &nbsp; &nbsp;  <span class="f_bold"><?php echo $resPerc.'%';?></span>
                         </div>
                         <?php }?>
                         </td>
                       </tr>
                                           
                       
                  </table>
                  
                  <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script>
                    <?php $oCount++;} } ?>
                    
                 </div> 
                 <!-- end of 2 options -->
                    
                  <!-- progress bar -->
                  <?php if($optionCountGet >2)  {//more than two options
                  	$oCount = 0;
	                $getAggregateVotes = NULL;
	                $qId=$this->uri->segment(3);
                  	foreach($getQOptions as $row){
                  	$optionId=$row['ID'];	
                    $option=$row['optionName'];
                  	$optionName=$row['optionName'];
                  	$idName = "PB_".$oCount;                  	
                  	if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					//$evaPerc[]    =$aggResult;
					//print_r($evaPerc);die;
					}//end of else
                  ?>  
                  <!-- jquery script for progress bar -->
                  
                    
                    <div class="span6">
                       <table class="table_rows" cellpadding="4" style="margin-top:10px;">
	                       <tr>
	                         <td width="140">
	                         <span class="f_bold"><?php echo $optionName;?></span>
	                         </td>
	                         <td>
	                         <?php if($resPerc!=0) { ?>
	                           <div class="progress_wrap">
	                           <!-- progress bar -->
	                           
	                             <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $option;?>');"><div></div></div>
	                            <div class="progress_no_cross"></div>  &nbsp; &nbsp;
	                             <span class="f_bold"> <?php //echo $resPerc.'%';?> </span> 
	                        </div>
	                        <?php }else{ ?>
	                        
	                        <div class="progress_wrap">	                          
	                           
	                           <div class="progress_no_cross"></div>  &nbsp; &nbsp;
	                           <span class="f_bold"> <?php echo $resPerc.'%';?> </span> 
	                        </div>
	                        <?php }?>
	                        </td>
	                       </tr>
	                       
	                       <tr> <td colspan="2"></td></tr>
	                       <tr> <td colspan="2"></td></tr>               
	                       
	                   </table>
                                         
                    </div>
                     <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script>
                   <?php $oCount++; }} ?> 
              <!-- Progress bar End -->

              </div> 
              
              <!-- Group chat and social sharing -->
                <?php //if($getSocialComments!="" ){?>
             <!--  <div id="note" class="f_bold">Note :</div>-->
             
               				<?php 
		                //     	echo $qcreatorNotes;
		                  //   }
                ?>
		            <div class="row" style="margin-top:2em; margin-bottom:1em; ">
		             <div class="span12">
		                 <div class="tabs_groups">
		                    <ul>
		                    <?php if($getPrivateGroupMembers){
		                    foreach($getPrivateGroupMembers as $rec){
			 	
			 	           $groupMembers[]=$rec['user_ID'];
			 	
			                }
			                /* Group chat commented by Padmaja*/
		                    //if (in_array($userId, $groupMembers)){?>
		                     <!-- <span id="groupChat"><li class="select">Group</li></span>-->
		                     <?php //}
		                    
		                    }?>
		                     <?php if($isPublic==1 || $isFBShare==1 || $isTwitterShare==1 || $isPintrestShare==1){?> 
		                     <span id="socialComments" class="f_bold" style="cursor:pointer"><li id="socialComments">Social</li></span>
			
					<div id="wait"></div>
		                     <?php }?>  
		                    </ul>                
		                 </div>              
		             </div>
		             
                  </div>
              <div id="showChat" class="row h_line_gray" style="display:none;">
                 <div class="ping_box">
                  chat
                 </div>
              </div>
              
               <?php if($isPublic==1 || $isFBShare==1 || $isTwitterShare==1 || $isPintrestShare==1){?>
              <div id="showComments" class="row h_line_gray">
               <div style="margin-top:1em" class="span6" >
               
                 <?php if($qcreatorNotes) { ?>
                 <div class="ping_box">
                           <div class="ping_pic">
                           <img src="<?php echo $qCreatorProfileImageThumb;?>" width="60" height="60" alt="" /></div>
                           <div class="ping_green"> 
                            
                            <div class="f_bold_italic"><?php echo $qCreatorDisplayName;?></div>
                            <div style="height:4px"></div>
                           <?php 
                           /* $countString=strlen($qcreatorNotes);
				            if($countString > 40){
				             $qcreatorNotesDesc= substr($qcreatorNotes, 0, 60);
				             $qcreatorNots=$qcreatorNotesDesc.'...';
				                }else{
				            $qcreatorNots=$qcreatorNotes;
				                }*/?>
                            <div class="f_italic" id="qcreatorNots"><?php echo $qcreatorNotes; ?></div></div>
                          </div>
                 <?php } ?>
               
                  <?php if($getSocialComments) { 
                  	foreach($getSocialComments as $row) {
                  	  //$thumb=base_url()."Uploads/ProfilePictures/".$row['thumb'];
                  	  //$thumb=$row['thumb'];
                  		if($row['thumb']!= 'avatar_thumb.png'){
                  			$thumb=$this->_S3Url.$row['thumb'];
                  		}else{
                  			$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
                  		}
                      $displayName=$row['displayName'];
                      $comments=$row['comments'];
                    ?>                      
                      
                      
                          <div class="ping_box">
                           <div class="ping_pic sdf">
                           <img src="<?php echo $thumb;?>" width="60" height="60" alt="" /></div>
                           <div class="ping_green"> 
                           
                            <div class="f_bold_italic" style=""><?php echo $displayName;?></div>
                            <div class="f_italic" style=""><?php echo $comments; ?></div>   </div>
                          </div>                    
                     
                  <?php } }else{ ?> 
                  <div style="margin-top:1em" class="span6" >                       
                                       
                     </div>
                  <?php } ?>   
                    </div> 
                     
                    <div style="margin-top:1em" class="span6" > 
                      <textarea placeholder="Type here to leave a comment" class="txt_chat" name="comment" id="comment" maxlength="100" style="font-style:italic"></textarea>
                      <button class="btn_small_green" id="postComment" onclick="return postComments();">POST</button>
                      
                   </div>
              
              </div>
              
             <?php }?> 

          </div> 
        </div>      
      <?php }else{ //echo "das";  ?>
          	    
        <div class="row" id="viewQtype3">
        <?php 
        $oCount = 0;
	    $getAggregateVotes = NULL;
	    $qId=$this->uri->segment(3);
        foreach($getQOptions as $row) {
        	       $optionId=$row['ID'];	
                   $optionName=$row['optionName'];
					if($optionName){
					$option  =$row['optionName'];	
					}else{
					$option  ='';	
					}	
			        $imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
					if($imgNamethumb){
					$thumb=$this->_S3Url.$imgNamethumb;
					$image=$this->_S3Url.$imgNamePhoto;
					
					}else{
					$thumb=base_url()."Uploads/QImages/default_thumb.png";
					$image=base_url()."Uploads/QImages/default.png";
					
					}
					
					
	                $idName = "PB_".$oCount;
	                if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
					if (!$getAggregateVotes)
					{
						
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$resPerc = $aggResult;	
					}
					else
					{
					  $optionsCount = 4; 
						if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];

					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					$resPerc = $aggResult;
					
					}//end of else
					
                    $getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
                    
					if($getCountQVotesOptions[0]['qCount']>0){
					$isVoted	     = TRUE;	
					}else{
					$isVoted	     = FALSE;
					}
        	
        	?>
           <div class="span3 thumbs_group"> 
                <div style="position:relative">
                   <button <?php if($isVoted==TRUE) {?>class="answer_yes answer_tick_yes"<?php }else{ ?>class="btn_answer2 answer_tick"<?php }?> onclick="return voteAnswer(<?php echo $optionId; ?>);">
                   </button>
                 </div>  
                  <a class="group1" href="<?php echo $image;?>">
                  <img src="<?php echo $thumb;?>" width="290" height="290" alt="" />
                   </a>                   
                   <table class="table_rows" cellpadding="4" style="margin-top:10px;">
                      <tr>
                         <td class="f_bold"><?php echo $option;?></td>                       
                       </tr>
                       
                       <tr>
                         <td> 
                         <?php if($resPerc!=0) {                          
                         ?>
                          <div class="progress_wrap">
                            <div id="<?php echo $idName;?>" class="jquery-ui-like progressBar" onclick="return getVotedPals('<?php echo $optionId;?>','<?php echo $option;?>');"><div></div></div>
                            <div class="progress_yes_cross"></div>
                             &nbsp; &nbsp;
                            <span class="f_bold"><?php //echo $resPerc.'%';?></span> 
                             </div>
                             <?php }else{?>
                             <div class="progress_wrap">
                            <div class=""></div>
                            <div class="progress_yes_cross"></div>
                             &nbsp; &nbsp;
                            <span class="f_bold"><?php echo $resPerc.'%';?></span> 
                             </div>
                             <?php }?>
                         </td>
                       </tr>
               
                      </table>
                    </div>
                    <script type="text/javascript">
		               progressBar(<?php echo $resPerc;?>, $('#<?php echo $idName;?>'));
	                  </script> 
                    
             <?php $oCount++; } ?>
              </div>
              <?php // if($getSocialComments!="" ){?>
             <!--   <div id="note" class="f_bold">Note :</div>-->
                <?php  //  	echo $qcreatorNotes;
		                 //    }
		                     ?>
              
                  <div class="row" style="margin-top:2em; margin-bottom:1em; ">
                 
                  
		             <div class="span12">
		                 <div class="tabs_groups">
		                    <ul>
		                    <?php if($getPrivateGroupMembers) {
		                    	
		                    foreach($getPrivateGroupMembers as $rec){
			 	
			 	           $groupMembers[]=$rec['user_ID'];
			 	
			                }

			                /* Group chat commented by padmaja*/
		                    //	if (in_array($userId, $groupMembers)){
		                    ?>
					
		                    <!-- <span id="groupChat"><li>Group</li></span>-->		                     
		                     <?php //}
		                    
		                    }?>
		                     <?php if($isPublic==1 || $isFBShare==1 || $isTwitterShare==1 || $isPintrestShare==1) {?> 
		                     <span id="socialComments" class="f_bold" style="cursor:pointer"><li >Social</li></span>
		                   
		                     <?php } ?>  
		                    </ul>                
		                 </div>              
		             </div>
		             
                  </div>
                <?php if($getPrivateGroupMembers){
                        foreach($getPrivateGroupMembers as $rec){
			 	
			 	         $groupMembers[]=$rec['user_ID'];
			 	
			           }
                if (in_array($userId, $groupMembers)){?>  
                 <div id="showChat" class="row h_line_gray" style="display:none;">
                 <div class="ping_box">
                  chat
                 </div>
                </div>
                <?php } }?>
                <?php if($isPublic==1 || $isFBShare==1 || $isTwitterShare==1 || $isPintrestShare==1) {?> 
                       <div id="showComments" class="row h_line_gray">
               <div style="margin-top:1em" class="span6" >
                 <?php if($qcreatorNotes) { ?>
                 <div class="ping_box">
                           <div class="ping_pic">
                           <img src="<?php echo $qCreatorProfileImageThumb;?>" width="60" height="60" alt="" /></div>
                           <div class="ping_green"> 
                            <div style="">
                            <div class="f_bold_italic"><?php echo $qCreatorDisplayName;?></div> 
							 <div style="height:4px"></div>
                            <div class="f_italic" style=" -top:20px"><?php echo $qcreatorNotes; ?></div>  </div> </div>
                          </div>
                 <?php } ?>
               
               
                  <?php if($getSocialComments) { 
                  	foreach($getSocialComments as $row) {
                  		// changed by padmaja on 03-07-2014
                  		
                  	 // $thumb=base_url()."Uploads/ProfilePictures/".$row['thumb'];
                  	  $thumb=$this->_S3Url.$row['thumb'];
                      $displayName=$row['displayName'];
                      $comments=$row['comments'];
                    ?>                      
                      
                         <!--  ping_box div modified by padmaja 13-05-2014-->
                      
                          <div class="ping_box">
                          
                           <div class="ping_pic">
                           <img src="<?php echo $thumb;?>" width="60" height="60" alt="" />
                           </div>
                          
                       
                           <div class="ping_green" > 
                           
                            <div class="f_bold_italic"><?php echo $displayName;?></div>
							<div style="height:4px"></div>
                            <div class="f_italic" style="padding-top:15px"><?php echo $comments; ?></div></div>
                                    
                     		</div>
                  <?php } }else{ ?> 
                  <div style="margin-top:1em" class="span6" >                       
                                       
                     </div>
                  <?php } ?>   
                    </div> 
                     
                    <div style="margin-top:1em" class="span6" >
                     
                      <textarea placeholder="Type here to leave a comment" class="txt_chat" name="comment" id="comment" maxlength="100" style="font-style:italic"></textarea>
                      <button class="btn_small_green" id="postComment" onclick="return postComments();">POST</button>
                      
                   </div>
              
              </div>
            <?php } ?>
              
              </div> 
        </div>      
      
      	<!--  
modals -->
<!-- commented by padmaja
<div style="border-radius:0px; border:none; width:500px;height:500px;" id="rcbians" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div  data-dismiss="modal" class="close" style="" >
		<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" /></div>
			
			 <?php $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";?> 
          <div class="flexslider">
          <ul class="slides">
            <li>
  	    	    <img src="<?php echo $thumb; ?>" width="100" height="100"/>
  	    		</li>
  	    		<li>
  	    	     <img src="<?php echo $thumb; ?>" width="100" height="100"/>
  	    		</li>
  	    		<li>
  	    	    <img src="<?php echo $thumb; ?>" width="100" height="100"/>
  	    		</li>
  	    		<li>
  	    	     <img src="<?php echo $thumb; ?>" width="100" height="100"/>
  	    		</li>
          </ul>
        </div>		   
					   
					 
			
					</div> -->
 
 <!--  
modals -->
    <?php   } ?>
    
    
    <!-- login popup -->
    
    
    <div class="container-fluid">
      <div class="row-fluid">
        <div class="">               
					                
					<!-- Modal  popup start-->
					<div id="myModal1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-header">
					    
					   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					   </a>
					    <h5 id="myModalLabel">Log In Details</h5>
					  </div>
					  <div class="modal-body">
					   <div id="result" style="color:red; margin-left: 160px"></div><br/>
                    <table width="100%" cellpadding="5">
					  <tr>
						<td colspan="2">
						 <input type="text" class="span12" name="email" id="email" placeholder="Email"  />
						  </td>
					  </tr>
								
					<tr>
					 <td colspan="2">
					 <input type="password" class="span12" name="password" id="password" placeholder="Password"  onkeypress="submitForm(event)"  /> 
					 </td>
					</tr>
								
					<tr>
					 <td style="vertical-align:top;"></td>
					<td  style="vertical-align:top;" align="right">
					<button style="padding:10px 0; margin-top:0px;" class="butn b_blue" id="signin" onclick="return socialSignIn();">
					 LOG IN</button>
					 </td> 
					</tr>
								
								
					<tr>
					<td style="vertical-align:top;"></td>
					<td  align="right" style="vertical-align:top;"> 
				    <button aria-hidden="true" data-dismiss="modal"  href="#myModal_register1" role="button"  data-toggle="modal" style="margin-top:0px; padding:10px 0; color:#5D5D5D;" class="butn b_yellow">
				    REGISTER NOW</button> 
				    </td>
					</tr>
				 </table>					   
			</div>
			
		</div>


       <div id="myModal_register1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-header" style="background-color: #dedd1f;">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				 <h3 style="margin-top: -10px;">REGISTER NOW</h3>
				  <h5 id="myModalLabel" style="font-size: 15px;">
					 Please provide your email to vote, leave comments, follow this Q <br/>
					 and create your own Q's on Twitter and elsewhere.
				</h5>
			</div>
			
		    <div class="modal-body" > 
		    <div id="result1" style="color:red; margin-left: 160px"></div><br/>
			   <table width="100%" cellpadding="5">
				<tr>
				<td colspan="2">
				<input type="text" class="span12" name="displayName" id="displayName" placeholder="Screen Name (optional)" style="font-size:13px"/>
				
				</td>
				</tr>
								
				<tr>
				 <td colspan="2">
				 <input type="text" class="span12" placeholder="Email" name="userEmail" id="userEmail"  onkeypress="submitForm1(event)" style="font-size:13px" />
				</td>
			 </tr>
			 
			 <tr>
				 <td colspan="2" style="font-size:13px">
				 <div class="clear" style="height:10px">
					<p>Note: Your friends will see your vote only if you use the email address which gave you the link to this page.</p>
				 <div class="clear" style="height:30px">
				 <i>By clicking Register, I accept the Qpals <a href="<?php echo base_url();?>terms" target="_blank" style="text-decoration: underline;">Terms of Use</a> and 
			     <a href="<?php echo base_url();?>privacyPolicy" target="_blank" style="text-decoration: underline;">Privacy Policy.</a></i>
				</td>
			 </tr>
				<tr>
				<td></td>	
				</tr>
				<tr>
				<td></td>	
				</tr>	
				<tr>
				<td></td>	
				</tr>	
				<tr>
				<td></td>	
				</tr>	
				<tr>
				<td></td>	
				</tr>	
				<tr>
				<td></td>	
				</tr>				
			    <tr>
					<td></td>
					<td  align="right" style="vertical-align:top;">
				   <button style="margin-top:0px; padding:10px 0; color:#5d5d5d;" class="butn b_yellow" id="register" onclick="return socialRegistration();">
				   REGISTER</button>
				    </td>
			</tr>
			
			<tr>
					 <td style="vertical-align:top;"></td>
					<td  style="vertical-align:top;" align="right">
					<button style="padding:10px 0; margin-top:0px;" class="butn b_blue" role="button"  data-toggle="modal" href="#myModal1" aria-hidden="true" data-dismiss="modal" >
					 LOG IN</button>
					 </td>
					</tr>
					
					
						
			
			</table>					   
		</div>
	</div>
<!-- Modal-register  popup end-->



       
        </div>      
      </div> 
      
      
      <!-- group members modal -->
      
      
      <div style="border-radius:0px; border:none;" id="groupMembersModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div  data-dismiss="modal" class="close" style="" >
		<img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" /></div>
					  <div style="padding:15px;" class="modalbody">
					     
                   				   
					   
					  </div>
			
					</div> 
      
      
        
<script>
/*$(function() {
  $("#iconRefresh").click(function() {
	alert('sdasdas');
     $('#showComments').load();
	refresh();
  });
function refresh(){
	
		$('#showComments').load().fadeIn('slow');	
		refresh();
	
}
})*/
</script>

	
	</div>
<!--<a href="<?php echo base_url();?>qwall/viewQ/<?php echo $qId;?>"id="refresh">click</a>
-->
      <!-- jquery to delete a q -->
    <style>
   #qcreatorNots{
   width: 300px;
	height: 60px;
   }
    </style>  
     <script>

       function deleteQ(qId){

           var r=confirm("Are you sure you want to delete");

           if(r == true){
    	   var sessionlog="<?php echo $this->session->userdata('userID');?>";
    	   var base_url="<?php echo base_url('qwall/deleteQ');?>";
    	   $.post(base_url,{qId:qId},function(response){                 
    		   window.location = "<?php echo base_url('qwall/qwallView');?>";
                });
           }else{
                return false;
           }
       }
     
     </script> 
    
    <!-- php function for progress bar -->
    
    
    
    <!-- progress bar :http://workshop.rs/2012/12/animated-progress-bar-in-4-lines-of-jquery/ -->
    <!-- voting option start -->
    
       <script>
       
         function voteOption(optionId){
             
             $(document).ready(function(){

            	 var sessionlog="<?php echo $this->session->userdata('userID');?>";
            	 if(sessionlog!=""){//if useris not logged in
            		 var qId=<?php echo $this->uri->segment(3);?>;
                     var base_url="<?php echo base_url('qwall/voteQ');?>";
                     var voteSource=<?php echo $this->uri->segment(4);?> 
                     //alert(voteSource);
                     $.post(base_url,{optionId:optionId,qId:qId,voteSource:voteSource},function(response){                 
                      $('#viewQtype2').html(response);
                       });
            		 
            	 }else{//if user is logged in
            		 $('#myModal_register1').modal('show');
            	 }
            });
         }
       
       </script>
       
       <script>
       
         function voteAnswer(optionId){
             
             $(document).ready(function(){
                 //alert("vote");
            	 var sessionlog="<?php echo $this->session->userdata('userID');?>";
            	 if(sessionlog!=""){
            	 var qId=<?php echo $this->uri->segment(3);?>;
                 var base_url="<?php echo base_url('qwall/voteAnswer');?>";
                 var voteSource=<?php echo $this->uri->segment(4);?>
                 //alert(voteSource); 
                 $.post(base_url,{optionId:optionId,qId:qId,voteSource:voteSource},function(response){  
                    // alert(response);               
                  $('#viewQtype3').html(response);
                   });
            	 }else{//if user is logged in
            		 $('#myModal_register1').modal('show');
            	 }

            });
         }
       
       </script>
    
    
    <!-- voting option end -->
    
    
    <!-- group chat and social sharing start -->
    
      <script>

        $(document).ready(function(){

            $('#groupChat').click(function(){

                 $('#groupChat').html('<li  class="select">Group</li>');
                 $('#showChat').show();
                 $('#showComments').hide();
            });

      });
        
      </script>
    
    
     <script>
     
       $(document).ready(function(){

          $('#socialComments').click(function(){
			//alert("adasd");
        	  $('#groupChat').html('<li>Group</li>');
        	  $('#socialComments').html('<li class="select" >Social</li>');
        	  $('#showChat').hide();
              $('#showComments').show();
		$('#iconRefresh').show();

          });
      });
     
     </script>
    
    <!-- post comments -->
   <script>


       function postComments(){
           
    	   var sessionlog="<?php echo $this->session->userdata('userID');?>";    	  
    	   if(sessionlog!=""){
    	   var comments=$('#comment').val();
           var qId="<?php echo $this->uri->segment(3);?>";
           var userId="<?php echo $userId;?>";
           var base_url="<?php echo base_url('qwall/socialComments');?>";
           if(comments==""){
               alert("please leave a comment");
           }else{
             $.post(base_url,{qId:qId,userId:userId,comments:comments},function(response){

                 $('#showComments').html(response);
             });
           }
    	  }else{
        	  
    		  $('#myModal_register1').modal('show');
    	  }
           
       }
	function refreshComments(){
		window.location.reload();
	 }
   </script> 
   
   <script>

      function viewPal(qCreatorID){
       var sessionlog="<?php echo $this->session->userdata('userID');?>";    	  
   	   if(sessionlog!=""){
   	   	$url="<?php echo base_url()."findPals/viewPals/$qCreatorId";?>";
   		window.location.href = $url;
   	   }else{
   		  $('#myModal_register1').modal('show');
   	   }
      }
   
   </script>
   
   <script type="text/javascript">

     function getVotedPals(optionId,option){
        //alert(option);
        //alert(optionId);
      
         var qId=<?php echo $this->uri->segment(3);?>;
         //alert(qId);
        
         var base_url    ="<?php echo base_url('qwall/getGroupMembersForOption');?>";
        
         $.post(base_url,{optionId:optionId,qId:qId,option:option},function(response){
        	   
       	   $(".modalbody").html(response);       	    
       	  //window.location.reload();
          //alert(response);
          });
         $("#groupMembersModal").modal("show");
        
     }
   
   
   </script>
   
     <!-- group chat and social sharing end -->
     
     <!-- jquery Ajax for login -->
     
     <script type="text/javascript">
      function socialSignIn(){ 
           var email=$('#email').val();
           var password=$('#password').val();
          //alert('dsf');
           $.ajax({            
               type: "POST",
               url: "<?php echo base_url('qwall/login')?>",
               data: ({email: email, password: password }),
             
               success: function(response){
                   if(response==1){
                	   window.location = "<?php echo $this->session->userdata('redirectUrl');?>";
                   }else{
                   $("#result").html(response);
                   }
               }  
           });

      } 
       
     </script>
     
     <!-- jquery ajax for registration -->
     
      <script type="text/javascript">
       
       function socialRegistration(){    
            var userEmail=$('#userEmail').val();           
            var displayName=$('#displayName').val();
           

            $.ajax({
                type: "POST",
                url : "<?php echo base_url('qwall/userRegistration')?>",
                data: ({email:userEmail,displayName:displayName}),

                success: function(responseReg){                 
                //alert(responseReg);
                //$("#result1").html(responseReg);
                 if(responseReg==1){
                window.location = "<?php echo $this->session->userdata('redirectUrl');?>";
                 }else{
                	 $("#result1").html(responseReg);
                 }
                
            }
            });
       }   

         
        
     </script>
     <!-- set Favourites -->
     
     <script>
     
       function setFavourites(qId,userId,Status){
           //alert(Status);

           //var qId=<?php echo $this->uri->segment(3);?>;
           var base_url    ="<?php echo base_url('qwall/setFavourites');?>";

           $.post(base_url,{qId:qId,userId:userId,Status:Status},function(response){
               //alert(response);
         	  $("#showFavouriteStatus").html(response);

            });
       }
     
     </script>
     
     <script>
     
     function submitForm(e)
     {
     	e = e || window.event;
     	   var keycode;
     	   if (window.event){
     	       //this check fails in mozilla/
     	       //so the variable keycode is undefined
     	       keycode = event.which ? window.event.which : window.event.keyCode;
     	   }
     	  if(!keycode){keycode = e.which}
     	   //solves the issue
     	if(e.which==13){
     		socialSignIn();
     		}
     }


     function submitForm1(e)
     {
     	e = e || window.event;
     	   var keycode;
     	   if (window.event){
     	       //this check fails in mozilla/
     	       //so the variable keycode is undefined
     	       keycode = event.which ? window.event.which : window.event.keyCode;
     	   }
     	  if(!keycode){keycode = e.which}
     	   //solves the issue
     	if(e.which==13){
     		socialRegistration();
     		}
     }
     </script>
     
     
     <!-- popup slider -->
     
     <script>
/* commented by Padmaja 14-05-2014*/
    
   /*  $(document).ready(function() {
		   $('.flexslider').flexslider({
		     animation: "slide"
		   });
		 });
	 
       function popupSlider(){
    	   $("#rcbians").modal("show");    	   
    	  
       }*/

       

       
     </script>
     
     
     
    
  <script type="text/javascript">
  $("body").click(function(event) {
    if (event.target.id != "t_wrapper" && event.target.id != "t_wrapper2" && event.target.id != "btn_settings" && event.target.id != "btn_settings2" ) {
		
        $("#t_wrapper").fadeOut();
    }
});



/****************below script for tabs ********************/

 jQuery(document).ready(function() {
  jQuery('#tabs > div').hide(); // hide all child divs
  jQuery('#tabs div:first').show(); // show first child dive
  jQuery('#tabsnav li:first').addClass('tab_active');

  jQuery('.menu-internal').click(function(){
   jQuery('#tabsnav li').removeClass('tab_active');
   var currentTab = jQuery(this).attr('href');
   jQuery('#tabsnav li a[href="'+currentTab+'"]').parent().addClass('tab_active');
   jQuery('#tabs > div').hide();
   jQuery(currentTab).show();
   return false;
  });
  // Create a bookmarkable tab link
  hash = window.location.hash;
  elements = jQuery('a[href="'+hash+'"]'); // look for tabs that match the hash
  if (elements.length === 0) { // if there aren't any, then
   jQuery("ul.tabs li:first").addClass("tab_active").show(); // show the first tab
  } else { elements.click(); } // else, open the tab in the hash
 });
</script>
    
     
 <script type="text/javascript">
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>



    <?php $this->load->view('footerView');?>
