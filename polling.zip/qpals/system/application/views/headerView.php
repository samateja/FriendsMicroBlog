<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>QPals</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="" >

    <!-- Le styles -->
    <link href="<?php echo base_url();?>css/style_inner.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
     <script src="<?php echo base_url();?>js/jquery.js"></script>
    <script src="<?php echo base_url();?>js/jquery.screwdefaultbuttonsV2.js"></script>
	
	<script type="text/javascript">
		$(function(){

			$('input:radio').screwDefaultButtons({
				image: 'url("<?php echo base_url();?>images/radio_2.jpg")',
				width: 30,
				height: 30
			});


		});
	</script>
	
	<style type="text/css">
       
       	.styledRadio, .styledCheckbox {
			display: inline-block;
		}
		
		
		.modal-backdrop {     /*addedv2  internal css*/
         background-color: #ffffff;		 
		}
		
		.close {
      position: relative;
      opacity: 1;
      right: 4px;
      top: -35px;
      float: none;
      left: 96%;		
		}
		
	#logoutBtn:hover{
	color:#DEDD1F;
	}	
	.pull-right:hover	#btn_settings{
	/*color:#DEDD1F;
	background:url(../images/search_qwall.png)
	*/
	}	
	input {
	input {
	text-indent: 80px;
	}
	
	input:focus {
	text-indent:5px;
	 
	}
   </style>
    
    
    <style>    

    /* GLOBAL STYLES
    -------------------------------------------------- */
    /* Padding below the footer and lighter body text */

    body {
      
      color: #5a5a5a;
    }




 
    </style>
       

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../assets/js/html5shiv.js"></script>
    <![endif]-->

 
 
 <script>
 
 
 function get_settings() {	 
	$(".toggle_wrapper").fadeToggle();


}

</script>
  </head>

  <body>



    <!-- --------------------------TOP BAR---------------------------------   -->
    <?php 
    $sessionlog=$this->session->userdata('userID');
    
    ?>
    
    <div class="container-fluid topbar">
      
         <div class="row-fluid">
          
             <div class="container">
            
             <div class="pull-right logout">
              <?php if($active==1) { ?>
             <a href="#myModal" role="button"  data-toggle="modal">Login</a>
             <?php } ?>
             <?php if($active!=1 && $sessionlog!="") { ?>
             <a id="logoutBtn" href="<?php echo base_url('home/logout');?>"> Logout</a>
             <?php } ?> 
             <?php if($sessionlog!="") {?>
             <a  href="#" id="btn_settings"><img  id="btn_settings2" onclick="get_settings()" src="<?php echo base_url();?>images/icon_setting.png" width="24" height="24" alt="" /></a> 
                      <div id="t_wrapper" class="toggle_wrapper">
                        <div id="t_wrapper2" class="toggle_settings">
                            <ul>
                              <li class="active_settings"><a data-toggle="modal" href="#accountPreferences">Account Preferences</a> </li>
                              <li> <a href="<?php echo base_url('home/how');?>"> How QPals Works</a></li>
                              <li> <a href="<?php echo base_url('home/TipsandTracks');?>"> Tips & Tricks</a> </li>
                             <!--  <li> <a href="#"> About </a> </li>-->
                            </ul>                        
                        </div>                     
                      </div>  
                      <?php }?>                    
               </div>
              </div>         
         </div>
       
    </div>
    
    
      <!-- -------------------------- END TOP BAR---------------------------------   -->
      
      
      
       <!-- -------------------------- BEGIN HEADER---------------------------------   -->
    <div class="container-fluid">
      <div class="row-fluid">
         <div class="container header_inner">
          
           <div class="span3"> 
           <a href="<?php echo base_url('qwall/qwallView');?>">
           <img src="<?php echo base_url();?>images/logo_inner.png" class="logo_inner" width="140" height="66" alt="" /></a>
           </div> 
           <div class="span9">
               <div class="navbar navbar-inverse">
          <div class="navbar-inner">
            <!-- Responsive Navbar Part 1: Button for triggering responsive navbar (not covered in tutorial). Include responsive CSS to utilize. -->
            <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            
            <!-- Responsive Navbar Part 2: Place all navbar contents you want collapsed withing .navbar-collapse.collapse. -->
            <div class="nav-collapse collapse">
            <?php if($sessionlog!="") {?>
              <ul class="nav">
                <li class="nav_menu_green"><a <?php if($active==4) {?>class="a_green"<?php }elseif($active=='viewQue'){?>class="a_green"<?php }?> href="<?php echo base_url('qwall/qwallView');?>">QWALL</a></li>
                <li class="nav_menu_red"><a <?php if($active=='createQ') {?>class="a_red"<?php }?> href="<?php echo base_url('qCreate/createQ');?>">CREATE Q </a></li>
                <li class="nav_menu_blue"><a <?php if($active==2) {?>class="a_blue"<?php }elseif($active=='grp'){?> class="a_blue" <?php }elseif($active==3){?>class="a_blue"<?php }elseif($active=='edit'){?> class="a_blue"<?php }?> href="<?php echo base_url('groups/mygroups');?>">GROUPS</a></li>
                <li class="nav_menu_yellow"><a <?php if($active==5) {?>class="a_yellow"<?php } elseif($active=='viewPl') {?>class='a_yellow'<?php }?> href="<?php echo base_url('findPals/findpals');?>">FIND PALS</a></li>
                 <li class="nav_menu_gray"><a <?php if($active=='viewPrfile') {?>class="a_gray"<?php }elseif($active=='editPrfile'){?>class="a_gray"<?php }?>href="<?php echo base_url('profile/viewProfile');?>">PROFILE</a></li>
                	
                 <!--<li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
                  
                  <ul class="dropdown-menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li class="divider"></li>
                    <li class="nav-header">Nav header</li>
                    <li><a href="#">Separated link</a></li>
                    <li><a href="#">One more separated link</a></li>
                   </ul>-->
                </li>
              </ul>
              <?php }?>
            </div><!--/.nav-collapse -->
          </div><!-- /.navbar-inner -->
        </div><!-- /.navbar -->
        
           </div> 
           <?php 
           
           if($active==5){
           ?>
           <div class="row">
             <div class="span6">
                 <div class="tabs_groups">
                    <ul> 
                    <span id="displayMostPopular">                   
                    <!--  <li style="cursor:pointer;" class="select" onclick="return showMostPopular()">Most Popular</li> -->
                    <li style="cursor:pointer;" <?php if($popular == 'poplr'){?> class="select"<?php }?> onclick="return showData(1)" id="popular">Most Popular</li> 
                     </span>
                     <span id="displayMostActive"> 
                     <!-- <li style="cursor:pointer;" onclick="return showMostActive()">Most Active</li>-->
                     <li style="cursor:pointer;"  onclick="return showData(2)" id="active">Most Active</li>
                     </span>
                     <span id="displayNewPals">
                     <!-- <li style="cursor:pointer;" onclick="return showNewPals()">New Pals</li>-->
                     <li style="cursor:pointer;"  onclick="return showData(3)" id="newpals">New Pals</li>
                     </span> 
                    </ul>                
                 </div>              
             </div>
                <style>
		#searchMostPopular {
		text-indent: 160px !important;
		}
		
		#searchMostPopular:focus {
		text-indent: 2px !important;
		}
		
	</style> 	
           <div class="pull-right" id="searchInMostPopular"> 
             <input style="font-style:italic" type="text" name="searchMostPopular" id="searchMostPopular" class="search_findpals" placeholder="Search Most Popular" />
             <img  style="cursor:pointer;" onclick="return searchMostPopularPals();" src="<?php echo base_url();?>/images/search_findpals.png"></img>
            </div>
            
            <div class="pull-right" id="searchInMostActive" style="display:none;"> 
             <input style="font-style:italic" type="text" name="searchMostActive" id="searchMostActive" class="search_findpals" placeholder="Search Most Active" />
             <img  style="cursor:pointer;" onclick="return searchMostActivePals();" src="<?php echo base_url();?>/images/search_findpals.png"></img>
            </div>
            
             <div class="pull-right" id="searchInNewPals" style="display:none;"> 
             <input style="font-style:italic" type="text" name="searchNewPals" id="searchNewPals" class="search_findpals" placeholder="Search New Pals" />
             <img  style="cursor:pointer;" onclick="return searchNewPals();" src="<?php echo base_url();?>/images/search_findpals.png"></img>
            </div>
            
           </div>
           
           
           <?php } ?>
           
           
           
           
           <?php 
           
           if($active==4){
           ?>
           <div class="row">
             <div class="span7">
                 <div class="tabs_groups">
                    <ul>
                    <span id="displayAllQs">
                     <li  onclick="return showAllQs()" style="cursor:pointer;">Private</li>
                     </span> 
                     <!--<li>Private</li>  --> 
                     <span id="displayPublicQs"> 
                     <li class="select" style="cursor:pointer;" onclick="return showPublicQs()">Public</li>
                     </span>
                     <span id="displayICreated"> 
                     <li  onclick="return showICreated()" style="cursor:pointer;">I Created</li>
                     </span>
                     <span id="displayIReplied">
                     <li onclick="return showIReplied()" style="cursor:pointer;">I Replied</li>
                     </span>
                     <span id="displayFavorites">
                     <li onclick="return showFavorites()" style="cursor:pointer;">Favorites</li>
                     </span>
                      <span id="displayFollowed">
                     <li onclick="return showFollowed()" style="cursor:pointer;">Followed</li>
                     </span>     
                    </ul>                
                 </div>
                   <div class="">
                <img src="<?php echo base_url();?>images/icon_refresh.png" width="30" height="27" alt="" style="margin-top: 4px;float:right;cursor:pointer;margin-right:-150px" id="iconRefresh" onclick="return refreshComments();"/>
                </div>&nbsp;
                          
             </div>
              <style>
		.search_input_qwall {
		text-indent: 160px !important;
		}
		
		.search_input_qwall:focus {
		text-indent: 2px !important;
		}
		
	</style> 	
             <div class="pull-right" id="searchInShowAll">
              <input  style="font-style:italic" type="text" name="searchAll" id="searchAll" class="search_input_qwall searchMove" placeholder="Search" />
             
             <img  onclick="return searchAllQs()" style="cursor:pointer;" src="<?php echo base_url();?>/images/search_qwall.png"></img>
            
              </div>
             <div class="pull-right" id="searchInICreated" style="display:none;">
              <input style="font-style:italic" type="text" name="searchCreatedText" id="searchCreatedText" class="search_input_qwall searchMove" placeholder="Search" />
              <img  onclick="return searchICreated()" style="cursor:pointer;" src="<?php echo base_url();?>/images/search_qwall.png"></img>
              
              </div>
               <div class="pull-right" id="searchInIReplied" style="display:none;">
              <input style="text-align: right;font-style:italic" type="text" name="searchRepliedText" id="searchRepliedText" class="search_input_qwall searchMove" placeholder="Search" />
              <img  onclick="return searchIReplied()" style="cursor:pointer;" src="<?php echo base_url();?>/images/search_qwall.png"></img>
              
              </div>
              <div class="pull-right" id="searchInFavorites" style="display:none;">
              <input style="text-align: right;font-style:italic" type="text" name="searchFavoritesText" id="searchFavoritesText" class="search_input_qwall searchMove" placeholder="Search" />
              <img  onclick="return searchFavorites()" style="cursor:pointer;" src="<?php echo base_url();?>/images/search_qwall.png"></img>
               
              </div>
              <div class="pull-right" id="searchInFollowed" style="display:none;">
              <input style="text-align: right;font-style:italic" type="text" name="searchFollowedText" id="searchFollowedText" class="search_input_qwall searchMove" placeholder="Search" />
              <img  onclick="return searchFollowed()" style="cursor:pointer;" src="<?php echo base_url();?>/images/search_qwall.png"></img>
             
             </div>
              
           </div>
           <?php } ?>
           
           <?php if($active==3 && $activeEditGroup=="editGroup"){
           	$groupId= $this->uri->segment(3);?>
          <div class="row">
             <div class="pull-right"> <a  class="f_blue f_italic" href="<?php echo base_url('groups/editGroup/'.$groupId);?>"> Edit  </a> | <a class="f_blue f_italic" onclick="return deleteGroup(<?php echo $groupId;?>)">  Delete Group</a></div>
           </div>
           <?php }?>
           <?php if($active==2) {?>
            <div class="row">
             <div class="span6">
                 <div class="tabs_groups">
                    <ul>
                    <span  id="allGroups">
                     <li class="select" style="cursor:pointer;" onclick="return showAllGroup()">Show All</li>
                    </span>
                     <span id="ICreated">
                     <li  style="cursor:pointer;" onclick="return showIcreated()">I Created</li>
                     </span>
                     <span id="IJoined">
                     <li  style="cursor:pointer;" onclick="return showJoinedGroups()">I Joined</li> 
                     </span>
                    </ul>                
                 </div>              
             </div>
             <style>
             #searchAllGroup{
             text-indent: 160px !important;
             }
             #searchAllGroup:focus {
				text-indent: 2px !important;
				}
			  #searchCreatedGroup{
             text-indent: 160px !important;
             }
             #searchCreatedGroup:focus {
				text-indent: 2px !important;
				}
				 #searchJoinedGroup{
             text-indent: 160px !important;
             }
             #searchJoinedGroup:focus {
				text-indent: 2px !important;
				}
             </style>
             <div class="pull-right" id="showAllSearch"> 
              <form method="POST">
            
            
              <!--<input   type="button" style="background:url(<?php echo base_url();?>/images/search_group.png);border:none;cursor:pointer;" onclick="return searchAllGroups()"/>
              -->
               <img style="cursor:pointer;" onclick="return searchAllGroups()" src="<?php echo base_url();?>/images/search_group.png"></img>
             <a class="c_group" href="<?php echo base_url('groups/createGroup');?>"> + Group </a>
             </form>
              
            </div>
            <div class="pull-right" id="showCreatedSearch" style="display:none;"> 
             <input style="font-style:italic" type="text" id="searchCreatedGroup" class="search_input" placeholder="Search" />
             <img style="cursor:pointer;" onclick="return searchCreatedGroups()" src="<?php echo base_url();?>/images/search_group.png"></img>
             <a class="c_group" href="<?php echo base_url('groups/createGroup');?>"> + Group </a> 
            </div>
           
           <div class="pull-right" id="showIJoinedSearch" style="display:none;"> 
             <input style="font-style:italic" type="text" id="searchJoinedGroup" class="search_input abcc" placeholder="Search" />
             <img style="cursor:pointer;" onclick="return searchJoinedGroups()" src="<?php echo base_url();?>/images/search_group.png"></img>
             <a class="c_group" href="<?php echo base_url('groups/createGroup');?>"> + Group </a> 
            </div>
           
           <?php } ?>      
         </div>      
      </div>
    </div>
    
    
   <!-- Account Preferences start -->
   
  <div style="border-radius:0px; border:none;" id="accountPreferences" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div  data-dismiss="modal" class="close" style="background-color:transparent; box-shadow:none;" > <img src="<?php echo base_url();?>images/icon_popup_close.png" width="25" height="25" alt="" /></div>
		<div style="padding:15px;" class="modal-body">
			<table cellpadding="5">
			<tr>
			 <td colspan="2" style="font-family:roboto-bold; font-size:16px;">
			 Email Notifications
		     <div class="pull-right"> 
		     <?php 
		     $userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
		     $isEmailAlerts	= $userData[0]['isEmailAlerts'];
		     ?>
		     <input type="checkbox"  name="emailAlerts" id="emailAlerts" <?php if($isEmailAlerts==1) {?>checked="checked"<?php }?>onclick="addEmailAlerts();" />
		     </div>
		    </td>
		</tr>
		
		
		<tr>
		 <td colspan="2" style="font-family:roboto-bold;  font-size:16px;">Default Question</td>
		</tr>
		
		<tr>
		 <td> 
		 <input type="radio" name="ex2_a" id="" onclick="return noDefaultQuestion();">
		 </td>
		<td>No Default Question</td>
		</tr>
		
		
		<?php 
		$presetQuestions=$this->getdatamodel->getPresetQuestions();
		if($presetQuestions){
			foreach($presetQuestions as $rec){
				$questionId=$rec['ID'];
				$question  = $rec['questionDesc'];
				$userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$userQuestionId= $userData[0]['defaultQuestion_ID'];
               
			   $userDefaultQuestion=$this->getdatamodel->getQuestionByID($userQuestionId);					
			   $presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];
			   if($presetQuestion_Id==0){
				$userDefaultQsnId = 0;	
				}else{
				$userDefaultQsnId = $userDefaultQuestion[0]['presetQuestion_Id'];	
				}
				
		?>						
		<tr>
		 <td> 
		 <input type="radio" name="ex2_a" id="<?php echo $questionId;?>" <?php if($questionId==$userDefaultQsnId) {?>checked="checked"<?php }?> onclick="return setDefaultQuestion(<?php echo $questionId;?>);">
		 </td>
		<td><?php echo $question;?></td>
		</tr>
		
		<?php } }?>						
		
		<?php 
		   
		  $userAddeddQuestions=$this->getdatamodel->getQuestionsByUserId($sessionlog);
		  if($userAddeddQuestions){
		  	foreach($userAddeddQuestions as $rec){
		  		
		  		$questionId	= $rec['ID'];
				$question	= $rec['name'];
		  	   $userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$userQuestionId= $userData[0]['defaultQuestion_ID'];
               
			   $userDefaultQuestion=$this->getdatamodel->getQuestionByID($userQuestionId);					
			   $presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];
			   if($presetQuestion_Id==0){
				$userDefaultQsnId =$userDefaultQuestion[0]['ID'];	
				}else{
				$userDefaultQsnId = $userDefaultQuestion[0]['presetQuestion_Id'];	
				}
		?>
		
		<tr>
		 <td> 
		 <span id="showAddCustomQues">
		 <input type="radio" name="ex2_a" id="<?php echo $questionId;?>" <?php if($questionId==$userDefaultQsnId) {?> checked="checked"<?php }?> onclick="return setCustomDefaultQuestion(<?php echo $questionId;?>);">
		 
		 </td>
		<td><?php echo $question;?></span></td>
		</tr>
		
		
		<?php } } ?>
								
		<tr>
		<td><input type="radio" name="ex2_a" id="" onclick="return setCustomQuestion();">  
		</td> 
		<td>Custom question: </td>  
		</tr>
		
		
		<tr>		  
           <td colspan="2">          
           <span id="showCustomQuestion" style="display:none;">
           <input class="span3" type="text" placeholder="Type your question here" name="customQuestion" id="customQuestion">
           &nbsp;
           <button onclick="return addCustomQuestion();">
		   Submit</button>
           </span>
           </td>           
        </tr>
        
								
		<tr>
           <td colspan="2" style="font-family:roboto-bold;  font-size:16px;">Default Group</td>								
		</tr>
		
		<tr>
		<td> <input type="radio" name="ex2_a1" id="ex2_a1" onclick="return setNoDefaultGroup();" > </td>
         <td>No Default Group</td>								
		</tr>
		
		
		<?php 
		$userGroups=$this->getdatamodel->getUserGroupsList($sessionlog);
		if($userGroups){
			foreach($userGroups as $group){
				$groupId	= $group['ID'];
				$groupName= $group['name'];
				$userData=$this->getdatamodel->getUserDetailsByUserID($sessionlog);
				$defaultGroup	= $userData[0]['defaultGroup_ID'];
		?>					
		<tr>
		<td> <input type="radio" name="ex2_a1" id="ex2_a1" <?php if($defaultGroup==$groupId) { ?>checked="checked"<?php } ?> onclick="return setDefaultGroup(<?php echo $groupId;?>);"> </td>
         <td><?php echo $groupName;?></td>								
		</tr>								
		<?php } } ?>						
			</table>
           	   
		</div>
			
	 </div> 
   
       <!-- Account Preferences End -->
    
     <!-- -------------------------- END HEADER---------------------------------   -->
     
     <!-- used ajax to login -->
     
     
     <script type="text/javascript">
       $('#signin').click(function(){   
        
           var email=$('#email').val();
           var password=$('#password').val();
          //alert('dsf');
           $.ajax({            
               type: "POST",
               url: "<?php echo base_url('home/login')?>",
               data: ({email: email, password: password }),
             
               success: function(response){ 
                   //alert(response);
                   if(response==1){
                       var groupSession="<?php echo $this->session->userdata('redirectGroupUrl');?>";
                       if(groupSession !=""){
                           
                    	window.location = "<?php echo $this->session->userdata('redirectGroupUrl');?>";   
                       }else{
                           
                	   window.location = "<?php echo base_url('profile/viewProfile')?>";
                       }
                   }else{
                   $("#result").html(response);
                   }
               }  
           }); 
                       
       });
   
     </script>
     
     <script type="text/javascript">
    
        $('#register').click(function(){
            //alert('asd');
            var firstName=$('#firstName').val();
            var lastName =$('#lastName').val();
            var userEmail=$('#userEmail').val();
            var userPassword =$('#userPassword').val();
            var confirmPassword=$('#confirmPassword').val();
            var displayName=$('#displayName').val();
           

            $.ajax({
                type: "POST",
                url : "<?php echo base_url('home/userRegistration')?>",
                data: ({firstName:firstName,lastName:lastName,email:userEmail,password:userPassword,confirmPassword:confirmPassword,displayName:displayName}),

                success: function(responseReg){                 
                
                $("#result1").html(responseReg);
                
            }
            });
           

         });
        
     </script>
     <!-- jquery for account preferences -->
     <script>

     function addEmailAlerts(){
    	var base_url="<?php echo base_url('accountPreferences/setEmailAlerts');?>";
     	var sessionlog="<?php echo $sessionlog;?>";
     	$.post(base_url,{sessionlog:sessionlog},function(response){
                   //alert(response);
          });
      }

     
     function setDefaultQuestion(questionId){
    	$('#showCustomQuestion').hide();
    	var base_url="<?php echo base_url('accountPreferences/presetQuestion');?>";
    	var sessionlog="<?php echo $sessionlog;?>";
    	$.post(base_url,{questionId:questionId,sessionlog:sessionlog},function(response){

         });
        
     }


     function setCustomQuestion(){
    	 
         $('#showCustomQuestion').show();
     }

     
     function addCustomQuestion(){

         var customQuestion=$('#customQuestion').val();
         var sessionlog="<?php echo $sessionlog;?>";
         if(customQuestion==""){
             alert('please enter custom question');
         }else{

             var base_url="<?php echo base_url('accountPreferences/customQuestion');?>";

             $.post(base_url,{customQuestion:customQuestion,sessionlog:sessionlog},function(response){
                 
              });

         }
      }

      function setCustomDefaultQuestion(questionId){

    	$('#showCustomQuestion').hide();
    	//alert(questionId);
      	var base_url="<?php echo base_url('accountPreferences/presetCustomQuestion');?>";
      	var sessionlog="<?php echo $sessionlog;?>";
      	$.post(base_url,{questionId:questionId,sessionlog:sessionlog},function(response){

           });
    	  
      }


      function setDefaultGroup(groupId){
           
    	  var sessionlog="<?php echo $sessionlog;?>"; 
    	  var base_url="<?php echo base_url('accountPreferences/setdefaultGroup');?>";
    	  $.post(base_url,{groupId:groupId,sessionlog:sessionlog},function(response){
                  //alert(response);
          });
      }


      function noDefaultQuestion(){

    	  var sessionlog="<?php echo $sessionlog;?>"; 
    	  var base_url="<?php echo base_url('accountPreferences/noDefaultQuestion');?>";
    	  $.post(base_url,{sessionlog:sessionlog},function(response){
                  //alert(response);
          });
          
      }


      function setNoDefaultGroup(){

    	  var sessionlog="<?php echo $sessionlog;?>"; 
    	  var base_url="<?php echo base_url('accountPreferences/setnoDefaultGroup');?>";
    	  $.post(base_url,{sessionlog:sessionlog},function(response){
                  //alert(response);
          });
      }
     
     /* $(document).keypress(function(e) {
		    if(e.which == 13) {
			   console.log("Kepressed");
			   searchAllGroups();
		    }
		});
      */
 
      
     </script>
     
     
     
     
     
     
     
     
     
     
     
