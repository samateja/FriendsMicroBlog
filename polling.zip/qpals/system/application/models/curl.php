<?php
//
// A very simple PHP example that sends a HTTP POST to a remote site
//
$a="samavteja%40gmail.com";
$b="Codebase";
$c="%3Cb%3EHi%3C%2Fb%3E";

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,"http://59.177.89.249:5280/push_email");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Content-Type: application/x-www-form-urlencoded',
                                            'Connection: Keep-Alive'
                                            ));
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "to=$a&sub=$b&content=$c&key=123456");

// in real life you should use something like:
// curl_setopt($ch, CURLOPT_POSTFIELDS, 
//          http_build_query(array('postvar1' => 'value1')));

// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$server_output = curl_exec ($ch);

var_dump($server_output);

curl_close ($ch);

// further processing ....
if ($server_output == "OK") { 
	echo "Success";
 } else 
 { 
	echo "Failed";
 }

?>