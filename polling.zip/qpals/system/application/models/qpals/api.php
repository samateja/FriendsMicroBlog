<?php
/**
 * Class Api
 *
 * This class is to serve API requests.
 *
 * 
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
require(BASEPATH.'libraries/REST_Controller.php');

class Api extends REST_Controller {
	var $user = "user";
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		//$this->load->library('encrypt');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
	    $this->load->model('messagequeue');
//		include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

		//facebook files
		include(BASEPATH.'application/libraries/facebook.php');
		 
	}
	/**
	 * Converting string into Encrypt or decrypt format
	 * @author Rajesh on 18-09-2013
	 * @param $str
	 */
	function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	/*
	 * To get location name using latitude and longitude
	 * @Asha on 17-3-2014
	 */
	
    function getaddress($lat,$lng)
    {
     $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&sensor=false';
     $json = @file_get_contents($url);
     $data=json_decode($json);
     $status = $data->status;
     if($status=="OK")
         return $data->results[0]->formatted_address;
      else
    return false;
   }
	
	/**
	 * To Sort Array
	 * @author rajesh on 11-11-2013
	 * @param $array
	 * @param $column
	 * @param $dir
	 */
	function array_sort_bycolumn(&$array,$column,$dir = 'desc') {
		/*foreach($array as $a) $sortcol[$a[$column]][] = $a;
		 ksort($sortcol);
		 foreach($sortcol as $col) {
			foreach($col as $row) $newarr[] = $row;
			}

			if($dir=='desc') $array = array_reverse($newarr);
			else $array = $newarr;
			return $array;*/
		$newArr=array();
		$newArray1=array();
		foreach($array as $a){
			if($a['gIsNew']==1){
				$newArr[]=$a;
			}else{
				$newArray1[]=$a;
			}
		}
		//print_r($newArray1);
		$newArr=array_merge($newArr, $newArray1);
		return $newArr;
	}
	/**
	 * Function to check whether umail and password are valid or not
	 * @author rajesh on 17-09-2013
	 */
	function login_post()
	{
		$resArr['result']				= 0;
		$resArr['message']				= "";
		$email							= $this->post('email');
		$password						= $this->post('password');
		$deviceType						= $this->post('deviceType');
		$deviceId						= $this->post('deviceId');
		$pushId							= $this->post('pushId');
		$osVersion						= $this->post('osVersion');
		$appVersion						= $this->post('appVersion');
		
		if(!$email || !$password || !$osVersion || !$appVersion || !$deviceType ){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$email=$this->convert(strtolower($email));
			$isValidEmailAddress= $this->getdatamodel->checkUserByEmail($email);
			$isValidSecEmailAddress=$this->getdatamodel->checkSecondaryEmail($email, 1);
			$isValidPassword 	= $this->getdatamodel->login($email, $password);
			if(($isValidEmailAddress || $isValidSecEmailAddress) && $isValidPassword){
				$res=$this->getdatamodel->login($email, $password);
				if($res){
					$resArr['result']			= 1;
					$userData['userId']			= $res[0]['ID'];
					$userData['firstName']		= $res[0]['firstName'];
					$userData['lastName']		= $res[0]['lastName'];
					$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
					$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
					//$userData['accessToken']	= $res[0]['accessToken'];
					//To get count of group notifications which needs user approval
					$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
						
					//@author Asha on 19-12-2013
					//Added OAuthProvider to generate token
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					 
					
					 
					//fetch access token
					$getUserData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
					$tokenGet=$getUserData[0]['accessToken'];
					
					if($tokenGet !=""){
				   //$userData['accessToken']	= $getUserData[0]['accessToken'];
					$expiry = $this->config->item('tokenExpiry');					
					foreach($getUserData as $toknes){
					$loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
					$thirty_days_ahead =   date('Y-m-d');
					if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						$this->pdo->where('ID',$userData['userId']);
						$tkn = $this->pdo->update($this->user, $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
						
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $userData['userId'],'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
				
			}
						
						
					if($pushId){
						//To reset PUsh ID To all users
						//$this->setdatamodel->resetPushId($pushId);
						$this->setdatamodel->resetPushIdLogin($pushId);
						$updateUserData=array('deviceType_ID'=>$deviceType, 'deviceId'=>$deviceId, 'pushId'=>$pushId,
			'OSVersion'=>$osVersion, 'appVersion'=>$appVersion, 'ID'=> $userData['userId']);
					}else{
						$updateUserData=array('deviceType_ID'=>$deviceType, 'deviceId'=>$deviceId,
			'OSVersion'=>$osVersion, 'appVersion'=>$appVersion, 'ID'=> $userData['userId']);
					}
					$this->setdatamodel->updateUserData($updateUserData);
					$resArr['isFblogin']		= 0;
					$resArr['data']				= $userData;
					$resArr['result']				= 1;
				}else{
					$resArr['message']="Invalid login details";
				}
			}else{
				if(!$isValidEmailAddress){
					$resArr['message']="Sorry, you entered an unregistered email address.";
				}else if(!$isValidPassword){
					$resArr['message']="Sorry, incorrect password.";
				}else if(!$isValidSecEmailAddress){
					$resArr['message']="Sorry, you entered an unregistered email address.";
				}
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Register user into database
	 * @author Rajesh on 17-09-2013
	 */
	function userRegistration_post()
	{
		$resArr['result']	= 0;
		$fullName			= $this->post('name');
		//$displayName		= $this->post('displayName');
		$email				= $this->post('email');
		$encEmail			= $this->convert(strtolower($email));
		//$decEmail=$this->convert($encEmail);
		$password			= $this->post('password');
		$osVersion			= $this->post('osVersion');
		$appVersion			= $this->post('appVersion');
		$deviceType			= $this->post('deviceType');
		$deviceId			= $this->post('deviceId');
		$latitude           = $this->post('latitude');
		$longitude          = $this->post('longitude');
		if(empty($fullName)  || empty($email) || empty($password) || empty($osVersion) || empty($appVersion) || empty($deviceType) ){
			$resArr['message']		= "Please pass all parameters.";

		}else{

			$names=explode(" ",$fullName);
			if(sizeof($names)==1){
				$firstName=$names[0];
				$lastName="";
			}else{
				$firstName=$names[0];
				$lastName=$names[1];
			}
            
			$displayNameExplode=explode("@",$email);
			$displayName=$displayNameExplode[0];
			
			//Check for email duplication
			$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
			$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail,1);
			if($isPrimaryEmailExists || $isSecondaryActivatedEmail){
				//if($isPrimaryEmailExists){
				$userId		= $isPrimaryEmailExists[0]['ID'];
				$isFBUser	= $this->getdatamodel->checkFbUserByUserId($userId);
				if($isFBUser){
					$resArr['message']="Email-address already registered, please login with your Facebook Account";
				}else{
					$resArr['message']="Sorry, the email address you entered is already registered.";
				}
			}else{
				$accessTokenGenerator = str_split(sha1(microtime()),19);
				$accessToken = $accessTokenGenerator[0];
				//$resArr['message']="An Email does not exists.";
				$userInsertData['firstName']		= $firstName;
				$userInsertData['lastName']			= $lastName;
				$userInsertData['displayName']		= $displayName;
				$userInsertData['email']			= $encEmail;
				$userInsertData['password']			= md5($password);
				$userInsertData['thumb']			= "avatar_thumb.png";
				$userInsertData['photo']			= "avatar.png";
				$userInsertData['OSVersion']		= $osVersion;
				$userInsertData['appVersion']		= $appVersion;
				$userInsertData['deviceType_ID']	= $deviceType;
				$userInsertData['deviceId']			= $deviceId;
				$userInsertData['status_ID']  		= 1;
				$userInsertData['latitude']  		= $latitude;
				$userInsertData['longitude']  		= $longitude;
				//$userInsertData['accessToken']		= $accessToken;
				$insertRes = $this->setdatamodel->registerUser($userInsertData);
				if($insertRes){
					$this->setdatamodel->deleteSecondaryEmail($encEmail);
					$nonRegGroupDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($encEmail);
					if($nonRegGroupDetails){
						foreach($nonRegGroupDetails as $rec){
							$groupMemberData=array('user_ID'=>$insertRes, 'group_ID' => $rec['group_ID'], 'status_ID' =>1);
							$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
						}
					}
					$this->setdatamodel->deleteNonRegisteredMemeber($encEmail);
					//Added by Rajesh to Get Non Recieved Q's of user to Map them to Registered account
					//On 28-11-2013
					$nonRecQs=$this->getdatamodel->getNonRecievedQs($encEmail);
					if($nonRecQs){
						foreach($nonRecQs as $rec){
							$recQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
							$this->setdatamodel->insertNonRecievedQ($recQData);
						}
					}
					$this->setdatamodel->deleteNonRecQ($encEmail);
					$from = $this->_supportEmail;

					$mailData['userName'] 	= $firstName;
					$mailData['email'] 		= $email;
					$mailData['password'] 	= $password;

					// getting the mail content
					$mailContet = $this->templatemodel->registerMailTemplate($mailData);
					$subject = "Welcome to QPals";
					// call mailer function to send mail.
					//$status = mailer($from, $email, $subject, $mailContet);

					 $data = new StdClass;
                                         $data->from = $from;
                                         $data->to = $email;
                                         $data->subject = $subject;
                                         $data->body = $mailContet;
                                         $message = json_encode($data);
                                         $this->messagequeue->addMessageToMAILQueue($message);

					$status = true;
						if($status){
						$res=$this->getdatamodel->getUserDetailsByUserID($insertRes);
						//$this->login_post($email,$password,$osVersion,$appVersion,$deviceType);
						$userData['userId']			= $res[0]['ID'];
						//$userData['firstName']		= $res[0]['firstName'];
						$userData['name']		= $res[0]['displayName'];
						$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
						$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
						$userData['accessToken']	= $res[0]['accessToken'];						
						
						//To get count of group notifications which needs user approval
						$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
                        
						$resArr['data']				=$userData;
						$resArr['result']			=1;
						$resArr['message']="Welcome to Qpals.";
						
						
					}
				}else{
					$resArr['message']="Registration failed.";
				}
			}
		}
		echo $this->response($resArr, 200);
	}

	/**
	 * To send password to user
	 * @author Rajesh on 19-09-2013
	 */
	function forgotPassword_post()
	{
		$resArr['result']      = 0;
		$email=$this->post('email');
		if(!$email){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$encEmail=$this->convert($email);
			$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
			if($isPrimaryEmailExists){
					
				$encEmail=$this->convert($email);
				$userId					= $isPrimaryEmailExists[0]['ID'];
				$accessCodeGenerator 		= str_split(sha1(microtime()),7);
				$accessCode				= $accessCodeGenerator[0].$userId;
				$from 					= $this->_supportEmail;
				$mailData['userName'] 	= $isPrimaryEmailExists[0]['firstName'];
				//$mailData['password'] 	= $password;
				$mailData['email'] 		= $email;
				$mailData['accessCode']	= $accessCode;


				//@author Asha on 23-12-2013
				//Added OAuthProvider to generate token
				$oauthProvider                  = new OAuthProvider();
				$authTokengen                   = $oauthProvider->generateToken(64);
				$authToken                      = bin2hex($authTokengen);
				 
				if($authToken){
					$datetime=date('Y-m-d H:i:s');
					$tokenData=array('ID'=> $userId,'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
					$this->setdatamodel->updateAuthToken($tokenData);
				}else{
					$resArr['message']="Invalid Auth Token.";
				}
				 
				//fetch access token
				$getUserData	= $this->getdatamodel->getUserDetailsByUserID($userId);
				if($getUserData){
					$resArr['accessToken']	= $getUserData[0]['accessToken'];
				}
					

				// getting the mail content
				$mailContet 			= $this->templatemodel->forgotPasswordMailTemplate($mailData);
				//echo $mailContet;die;
				$subject 				= "Forgot Password";
				// call mailer function to send mail.
			//	$status 				= mailer($from, $email, $subject, $mailContet);
				 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						$status = true;
				//$status=1;
				if($status){
					$updateUserData			= array('ID'=>$userId, 'changePasswordCode'=>$accessCode);
					$this->setdatamodel->updateUserData($updateUserData);
					$resArr['result']       = 1;
					$resArr['message']		= "Please check your email for a change password link.";
				}
			}else{
				$resArr['message']		= "Invalid Email Address.";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To register FB users
	 * @author Rajesh on 23-09-2013
	 */
	function fbSignin_post()
	{
		$resArr['result']	= 0;
		$fullName			= $this->post('name');
		$displayName		= $this->post('displayName');
		$email				= $this->post('email');
		$FBID				= $this->post('FBID');
		$fbUserAccessToken	= $this->post('fbUserAccessToken');
		$encEmail			= $this->convert(strtolower($email));
		//$decEmail=$this->convert($encEmail);
		//$password			= $this->post('password');
		$osVersion			= $this->post('osVersion');
		$appVersion			= $this->post('appVersion');
		$deviceType			= $this->post('deviceType');
		$deviceId			= $this->post('deviceId');
		$latitude           = $this->post('latitude');
		$longitude          = $this->post('longitude');
		if(!$fullName || !$displayName || !$email || !$osVersion || !$appVersion
		|| !$deviceType ||! $FBID){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$checkUserByFBID=$this->getdatamodel->checkUserByFBID($FBID);
			if($checkUserByFBID){
				$userID=$checkUserByFBID[0]['user_ID'];
				$res=$this->getdatamodel->getUserDetailsByUserID($userID);
				$resArr['result']	= 1;
				$resArr['message']="";
				$userData['userId']			= $res[0]['ID'];
				$userData['firstName']		= $res[0]['firstName'];
				$userData['lastName']		= $res[0]['lastName'];
				$userData['name']		= $res[0]['displayName'];
				$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
				$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
                $userData['isNewFBUser']	= FALSE;
					
				//@author Asha on 23-12-2013
				//Added OAuthProvider to generate token
				$oauthProvider                  = new OAuthProvider();
				$authTokengen                   = $oauthProvider->generateToken(64);
				$authToken                      = bin2hex($authTokengen);
				 
				
				 
				//fetch access token
				$getUserData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
				$tokenGet=$getUserData[0]['accessToken'];
				if($tokenGet !=""){
					//$userData['accessToken']	= $getUserData[0]['accessToken'];
				
				 $expiry = $this->config->item('tokenExpiry');					
				 foreach($getUserData as $toknes){
				 $loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
				 $thirty_days_ahead =   date('Y-m-d');
				 if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						$this->pdo->where('ID',$userData['userId']);
						$tkn = $this->pdo->update($this->user, $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $userData['userId'],'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
				}
				
			}
					

				//$userData['accessToken']	= $res[0]['accessToken'];
				//To get count of group notifications which needs user approval
				$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);

				$resArr['data']				=$userData;
				$resArr['result']			=1;
				$resArr['message']			= "Logged in Successfully";
				$updateUserData=array('deviceType_ID'=>$deviceType, 'deviceId'=>$deviceId,
			'OSVersion'=>$osVersion, 'appVersion'=>$appVersion, 'ID'=> $userID);
				$resArr['isFblogin']		= 1;
				$this->setdatamodel->updateUserData($updateUserData);
			} else {
				$names=explode(" ",$fullName);
				if(sizeof($names)==1){
					$firstName=$names[0];
					$lastName="";
				}else{
					$firstName=$names[0];
					$lastName=$names[1];
				}

				//Check for email duplication
				$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
				$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail, 1);
				if($isPrimaryEmailExists || $isSecondaryActivatedEmail){
					//$resArr['message']="An Email already exists.";
					if($isPrimaryEmailExists){
						$userId=$isPrimaryEmailExists[0]['ID'];
					}else if($isSecondaryActivatedEmail){
						$userId=$isSecondaryActivatedEmail[0]['user_ID'];
					}

					$res=$this->getdatamodel->getUserDetailsByUserID($userId);
					$updateUserData=array('FBID'=>$FBID, 'status_ID'=>1, 'user_ID'=> $userId ,'fbUserAccessToken'=>$fbUserAccessToken);
					$this->setdatamodel->userFBMapping($updateUserData);

					$userData['userId']			= $res[0]['ID'];
					$userData['firstName']		= $res[0]['firstName'];
					$userData['lastName']		= $res[0]['lastName'];
					$userData['name']			= $res[0]['displayName'];
					$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
					$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
					$userData['accessToken']	= $res[0]['accessToken'];
					$userData['isNewFBUser']	= FALSE;
					//$userInsertData['tokenTimeStamp']	= date("Y-m-d H:i:s");
					//To get count of group notifications which needs user approval
					$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
					$resArr['isFblogin']		= 1;
					$resArr['data']				= $userData;
					$resArr['result']			= 1;
					$resArr['message']			= "Registration completed successfully.";
					//}

				}else{
						
					//@author Asha on 23-12-2013
					//Added OAuthProvider to generate token
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					$checkUserByFBID=$this->getdatamodel->checkUserByFBID($FBID);
					$userID=$checkUserByFBID[0]['user_ID'];
					
					//fetch access token
					$getUserData	= $this->getdatamodel->getUserDetailsByUserID($userID);
					$tokenGet=$getUserData[0]['accessToken'];
					
					if($tokenGet !=""){
				   //$userData['accessToken']	= $getUserData[0]['accessToken'];
					$expiry = $this->config->item('tokenExpiry');					
					foreach($getUserData as $toknes){
					$loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
					$thirty_days_ahead =   date('Y-m-d');
					if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						$this->pdo->where('ID',$userData['userId']);
						$tkn = $this->pdo->update($this->user, $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
						
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
				        $checkUserByFBID=$this->getdatamodel->checkUserByFBID($FBID);
					    $userID=$checkUserByFBID[0]['user_ID'];
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $userID,'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userID);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
				
			}
					 
						
					$accessToken =  $authToken;
					$passwordgenerator = str_split(sha1(microtime()),13);
					$password = $passwordgenerator[0];
					$resArr['message']="An Email does not exists.";
					$userInsertData['firstName']		= $firstName;
					$userInsertData['lastName']			= $lastName;
					$userInsertData['displayName']		= $displayName;
					$userInsertData['email']			= $encEmail;
					$userInsertData['password']			= md5($password);
					$userInsertData['thumb']			= "avatar_thumb.png";
					$userInsertData['photo']			= "avatar.png";
					$userInsertData['OSVersion']		= $osVersion;
					$userInsertData['appVersion']		= $appVersion;
					$userInsertData['deviceType_ID']	= $deviceType;
					$userInsertData['deviceId']			= $deviceId;
					$userInsertData['status_ID']  		= 1;
					$userInsertData['accessToken']		= $accessToken;
					$userInsertData['tokenTimeStamp']	= date("Y-m-d H:i:s");
					$userInsertData['latitude']  		= $latitude;
				    $userInsertData['longitude']  		= $longitude;
					$insertRes = $this->setdatamodel->registerUser($userInsertData);
					if($insertRes){
						$this->setdatamodel->deleteSecondaryEmail($encEmail);
						$this->setdatamodel->deleteNonRegisteredFBMemeber($FBID);
						//Added by Rajesh to Get Non Recieved Q's of user to Map them to Registered account
						//On 28-11-2013
						$nonRecFBQs=$this->getdatamodel->getNonRecievedFBQs($FBID);
						if($nonRecFBQs){
							foreach($nonRecQs as $rec){
								$recFBQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
								$this->setdatamodel->insertNonRecievedFbq($recFBQData);
							}
						}
						$this->setdatamodel->deleteNonRecFBQ($FBID);
						$from = $this->_supportEmail;

						$mailData['userName'] 	= $firstName;
						$mailData['email'] 		= $email;
						$mailData['password'] 	= $password;

						// getting the mail content
						$mailContet = $this->templatemodel->fbSigninMailTemplate($mailData);
						$subject = "Welcome to Qpals";
						// call mailer function to send mail.
					//	$status = mailer($from, $email, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						$insertData=array('FBID'=>$FBID, 'status_ID'=>1, 'user_ID'=>$insertRes);
						$insertFbUserMapping=$this->setdatamodel->inserUserFBMapping($insertData);
						if($insertFbUserMapping){
							$res=$this->getdatamodel->getUserDetailsByUserID($insertRes);
							$userData['userId']			= $res[0]['ID'];
							$userData['firstName']		= $res[0]['firstName'];
							$userData['lastName']		= $res[0]['lastName'];
							$userData['name']			= $res[0]['displayName'];
							$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
							$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
							$userData['accessToken']	= $res[0]['accessToken'];
							//To get count of group notifications which needs user approval
							$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
							$userData['isNewFBUser']	= TRUE;
							$resArr['isFblogin']		= 1;
							$resArr['data']				=$userData;
							$resArr['result']			=1;
							$resArr['message']="Registration completed successfully.";
						}
					}else{
						$resArr['message']="Registration failed.";
					}
				}
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * This function to Create a group
	 * @author Rajesh on 23-09-2013
	 */
	function createGroup_post()
	{
		$resArr['result'] 		= 0;
		$userId					= $this->post('userId');
		$groupName				= $this->post('groupName');
		$accessToken			= $this->post('accessToken');
		$osVersion				= $this->post('osVersion');
		$appVersion				= $this->post('appVersion');
		$deviceType				= $this->post('deviceType');
		if(!$userId || !$groupName || !$accessToken ||!$osVersion || !$appVersion || !$deviceType){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$registeredGroupMemberEmails=array();
			$registeredGroupMemberNames=array();

			$nonRegisteredGroupMemberEmails=array();
			$nonRegisteredGroupMemberNames=array();
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$groupInsertRes=0;
				$isDuplicateGroup=$this->getdatamodel->isDuplicateGroup($userId, $groupName);
				//$isDuplicateGroup=false;
				if($isDuplicateGroup){
					//$resArr['message']		= "A group named $groupName already exists.";
					$resArr['message']			= "A Group is already existing with the same name.";
				}else{


					$insertGroupData 	= array('name'=>$groupName, 'thumb'=>'group_thumb.png',
				'photo'=>'group.png', 'status'=>1, 'user_ID'=> $userId, 'osVersion'=>$osVersion, 
				'appVersion'=>$appVersion, 'deviceType_ID'=>$deviceType);
					$groupInsertRes		= $this->setdatamodel->insertGroup($insertGroupData);
					//$groupInsertRes=1;

					$groupCreatorData=$this->getdatamodel->getUserDetailsByUserID($userId);
					if($groupCreatorData){
						$groupCreatorName=$groupCreatorData[0]['firstName'];
					}else{
						$groupCreatorName="";
					}
					if($groupInsertRes) {
						//echo "a";
						$groupMemberData=array('user_ID'=>$userId, 'group_ID' => $groupInsertRes, 'status_ID' =>1, 'isCreator'=>1);
						$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);

						$groupArr['groupId']				= $groupInsertRes;
						$resArr['result'] 		= 1;
						//$resArr['message']		= "$groupName group created successfully.";
						$resArr['message']		= "Congratulations, your group is now live!";
						$resArr['groupId']			= $groupInsertRes;

						//FB members starts
						$fbNames	= $this->post('fbName');
						$fbIds		= $this->post('fbId');
						if($fbNames){
							$fbNamesArr		= explode("|",$fbNames);
							$fbIdsArr		= explode("|",$fbIds);
						}
						if(isset($fbIdsArr)){
							for($i=0;$i<sizeof($fbNamesArr);$i++){
								$FBID=$fbIdsArr[$i];
								$checkUserByFBID=$this->getdatamodel->checkUserByFBID($FBID);
								if($checkUserByFBID){
									$userID=$checkUserByFBID[0]['user_ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								} else {
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								$fbFirstName=$fbNamesArr[$i];

								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);

									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredFBMembers
								else{
									$fbMemberData=array('FBID'=>$FBID,'name'=>$fbFirstName, 'group_ID' => $groupInsertRes, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredFBMember($fbMemberData);									
									
			                        
			                        
								}
							}
						}
						//FB members ends

						//Phone Contacts starts
						$phoneNames		= $this->post('phoneName');
						$phoneEmails	= $this->post('phoneEmail');
						if($phoneEmails){
							$phoneNamesArr		= explode("|",$phoneNames);
							$phoneEmailsArr		= explode("|",$phoneEmails);
						}
						if(isset($phoneEmailsArr)){
							for($i=0;$i<sizeof($phoneNamesArr);$i++){
								$phoneEmail = $this->convert(strtolower($phoneEmailsArr[$i]));
								$phoneName  = $phoneNamesArr[$i];
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($phoneEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);

									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$phoneName, 'email'=>$phoneEmail, 'group_ID' => $groupInsertRes, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$phoneEmail;
									$nonRegisteredGroupMemberNames[]=$phoneName;
								}
							}
						}
						//Phone Contacts ends
						
						//following contacts start
						  $followingNames =$this->post('followingName');
			              $followingEmails=$this->post('followingEmail');

			              if($followingEmails){
			              	$followingNamesArr  =explode("|",$followingNames);
			              	$followingEmailsArr =explode("|",$followingEmails);
			              	
			              }
			              
			              if(isset($followingNamesArr)){
			              	
			              	 for($i=0;$i<sizeof($followingNamesArr);$i++){
			              	 	
			              	 	$followingEmail=$this->convert(strtolower($followingEmailsArr[$i]));
			              	 	$followingName =$followingNamesArr[$i];
			              	 	$checkUserByEmail=$this->getdatamodel->checkUserByEmail($followingEmail);
			              	    if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								
								
			              	 if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);

									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}else{
									$resArr['message']		= "following details not found";
								}
			              	 }
			              	
			              }
						//following contacts end
						
			            //followers contacts start
			             $followersNames =$this->post('followerName');
			             $followersEmails=$this->post('followersEmail');
			             
					     if( $followersEmails){
			              	$followersNamesArr  =explode("|",$followersNames);
			              	$followersEmailsArr =explode("|", $followersEmails);
			              	
			              }
			              
			              if(isset($followersEmailsArr)){
			              	
			              	 for($i=0;$i<sizeof($followersEmailsArr);$i++){
			              	 	
			              	 	$followerEmail=$this->convert(strtolower($followersEmailsArr[$i]));
			              	 	$followerName =$followersNamesArr[$i];
			              	 	$checkUserByEmail=$this->getdatamodel->checkUserByEmail($followerEmail);
			              	    if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								
								
			              	 if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);

									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}else{
									$resArr['message']		= "follower details not found";
								}
			              	 }
			              	
			              }
			             
			            
			            //followers contacts end
			              
			              
						//Custom contacts starts
						$customNames		= $this->post('customName');
						$customEmails		= $this->post('customEmail');
						if($customEmails){
							$customNamesArr		= explode("|",$customNames);
							$customEmailsArr		= explode("|",$customEmails);
						}
						if(isset($customEmailsArr)){
							for($i=0;$i<sizeof($customEmailsArr);$i++){
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));
								$customName  = $customNamesArr[$i];
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$customName, 'email'=>$customEmail, 'group_ID' => $groupInsertRes, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									$nonRegisteredGroupMemberNames[]=$customName;
								}
							}
						}

						//Custom contacts ends
					}

				}

				if($groupInsertRes){
					$emailArr=array();
					$namesArr=array();
					$regUsersData=$this->getdatamodel->getGroupMembersDetails($groupInsertRes,1);
					$nonRegUsersData=$this->getdatamodel->getnonRegGroupMembersDetails($groupInsertRes);
					$nonRegFBUsersData=$this->getdatamodel->getnonRegFBGroupMembersDetails($groupInsertRes);
					//For adding Push to Message Queue
					//@author Rajesh on 13-11-2013
					if($regUsersData){
						foreach($regUsersData as $rec1){
							//@author Asha on 19-12-2013
							//For not showing push alerts for the group creator
							if($userId == $rec1['ID']){
							 //do nothing
							}else{
								if($rec1['isPushAlerts']==1){
									$data = new StdClass;
									$data->deviceToken = $rec1['pushId'];
									$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
									$data->typeID = "2";
					                $data->param = $groupInsertRes;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec1['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec1['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec1['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}
							}
						}
					}


					if($regUsersData){
						foreach($regUsersData as $rec1){
							if($rec1['isEmailAlerts']==1){
								$emailArr[]=$this->convert($rec1['email']);
							}
							$namesArr[]=$rec1['firstName'];
						}
					}
					if($nonRegUsersData){
						foreach($nonRegUsersData as $rec2){
							$emailArr[]=$this->convert($rec2['email']);
							$namesArr[]=$rec2['name'];
						}
					}
					if($nonRegFBUsersData){
						foreach($nonRegFBUsersData as $rec3){
							$namesArr[]=$rec3['name'];
						}
					}
					//echo sizeof($emailArr);
					for($i=0;$i<sizeof($emailArr);$i++){
						$msgStr="";
						$email=	$emailArr[$i];
						$mailData['userName'] 	= $namesArr[$i];
						$namesArr1=$namesArr;
						unset($namesArr1[$i]);
						//print_r($namesArr1);
						$newarr=array();
						foreach($namesArr1 as $name){
							$newarr[]=$name;
						}
						//print_r($newarr);
						for($j=0;$j<sizeof($newarr);$j++){
							if($j==0){
								$msgStr.=$newarr[$j];
							}else if($j<=sizeof($newarr)-2){
								$msgStr.=", ".$newarr[$j];
							}else{
								$msgStr.=" and ".$newarr[$j];
							}
						}
						//echo $msgStr."<br/>";
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['groupId']	=$groupInsertRes;
						$from = $this->_supportEmail;
						//getting the mail content
						$mailContet = $this->templatemodel->nonRegisteredUserGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						// call mailer function to send mail.
					//	$status = mailer($from, $email, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

					}
				}
				
			   $getCountOffollowers=$this->getdatamodel->getCountOffollowers($userId);
				
				if($getCountOffollowers){
					$resArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($userId);
				}else{
					$resArr['countOfFollowers']	=NULL;
				}
				
			$getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($userId);
				
				if($getCountOfFollowing){
				$resArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($userId);
				}else{
				$resArr['countOfFollowing']=NULL;	
				}
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To upload Group Image
	 * @author Rajesh on 24-09-2013
	 */
	function groupImageUpload_post()
	{
		//if(isset($_POST['submit'])){
		//print_r($_FILES);die;
		$resArr['result']		= 0;
		$groupId				= $this->post('groupId');
		if($_FILES['groupImage']['name']){
			$groupImgResponse = $this->setdatamodel->uploadImage($_FILES,'groupImage','GroupImages');
			if($groupImgResponse){
				$groupImgName = $groupImgResponse['imgName'];
				$groupThumbName = $groupImgResponse['thumbName'];
				$groupData = array('ID'=>$groupId, 'thumb'=>$groupThumbName ,'photo'=>$groupImgName);
				$this->setdatamodel->updateGroup($groupData);
				$resArr['result']		= 1;
				$resArr['message']		= "Group image uploaded successfully.";
				$groupImageData['groupImage'] = base_url()."Uploads/GroupImages/".$groupImgName;
				$groupImageData['groupThumb'] = base_url()."Uploads/GroupImages/".$groupThumbName;
				$resArr['data']		  		  =  $groupImageData;
			}else{
				$resArr['message']		= "Group image not uploaded ";
			}
		}
		echo $this->response($resArr, 200);
		//}
	}
	/**
	 * To Get All groups of user
	 * @author Rajesh on 08-10-2013
	 */
	function myGroups_post()
	{
		$resArr['result']		= 0;
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		$searchText 			= $this->post('searchText');
		$groupsType				= $this->post('groupsType');
		$offset					= $this->post('offset');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$groupsCreatedDetails=$this->getdatamodel->getUserCreatedGroups($userId, $searchText, $offset);
				$groupsJoinedDetails=$this->getdatamodel->getUserJoinedGroups($userId, $searchText, $offset);
				$userGroups=$this->getdatamodel->getUserGroups($userId, $searchText, $offset);

				$groupsCreatedCount=$this->getdatamodel->getUserCreatedGroupsCount($userId, $searchText);
				$groupsJoinedCount=$this->getdatamodel->getUserJoinedGroupsCount($userId, $searchText);
				$userGroupsCount=$this->getdatamodel->getUserGroupsCount($userId, $searchText);
				$resArr['groupsCreatedCount']	= $groupsCreatedCount;
				$resArr['groupsJoinedCount']	= $groupsJoinedCount;
				$resArr['userGroupsCount']		= $userGroupsCount;
				
				if($groupsType==1){
				 if($searchText!=""){
				  $resArr['TotalNo']	=$this->getdatamodel->getUserCreatedGroupsTotalNum($userId, $searchText, $offset);	
				 }else{
				  $resArr['TotalNo']	= $groupsCreatedCount;	
				 }
				}else if($groupsType==2){
					
				 if($searchText!=""){
				  $resArr['TotalNo']	=$this->getdatamodel->getUserJoinedGroupsTotalNum($userId, $searchText, $offset);	
				 }else{
				  $resArr['TotalNo']	= $groupsJoinedCount;	
				 }
					
				}else{
					
				if($searchText!=""){
				  $resArr['TotalNo']	=$this->getdatamodel->getUserGroupsTotalNum($userId, $searchText, $offset);	
				 }else{
				  $resArr['TotalNo']	= $userGroupsCount;	
				 }
					
				}
				
				if($groupsType==1){
					$groupsCreated=array();
					//Created Groups Starts
					if($groupsCreatedDetails){
						//echo "asd";die;

						//$resArr['groupsCreatedCount']=sizeof($groupsCreatedDetails);
						foreach($groupsCreatedDetails as $groupCreated){
							//Added by Rajesh on 28-10-2013 to Check is New activity there
							//for group or not
							$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupCreated['user_ID'], $groupCreated['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
							$groupsCreatedArr['gId']			= $groupCreated['ID'];
							$groupsCreatedArr['gName']			= $groupCreated['name'];
							$groupsCreatedArr['thumb']			= base_url()."Uploads/GroupImages/".$groupCreated['thumb'];
							$groupsCreatedArr['photo']			= base_url()."Uploads/GroupImages/".$groupCreated['photo'];
							$groupsCreatedArr['membersCount']	= $this->getdatamodel->getGroupMemnbersCount($groupCreated['ID']);
							$groupsCreatedArr['gIsNew']			= $isNew;
							$groupsCreatedArr['gStatus']		= $groupCreated['status'];
							$groupsCreatedArr['isCreator']		= $this->getdatamodel->checkIsGroupCreator($groupCreated['ID'], $userId);
							$groupsCreated[]			= $groupsCreatedArr;

						}
						$resArr['result']		= 1;
					}else{
						$resArr['message']						= "No groups available.";
					}
					if($groupsCreated){
						$resArr['userGroups']			= $this->array_sort_bycolumn($groupsCreated,'gIsNew','desc');
					}else{
						$resArr['userGroups']		= $groupsCreated;
					}
					//Created Group Ends
				}else if($groupsType==2){
					//Joined Group Details starts

					$groupsJoined=array();
					if($groupsJoinedDetails){
						//$resArr['groupsJoinedCount']=sizeof($groupsJoinedDetails);
						foreach($groupsJoinedDetails as $groupJoined){
							//Added by Rajesh on 28-10-2013 to Check is New activity there
							//for group or not
							$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupJoined['user_ID'], $groupJoined['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
							$groupsJoinedArr['gId']			= $groupJoined['ID'];
							$groupsJoinedArr['gName']			= $groupJoined['name'];
							$groupsJoinedArr['thumb']			= base_url()."Uploads/GroupImages/".$groupJoined['thumb'];
							$groupsJoinedArr['photo']			= base_url()."Uploads/GroupImages/".$groupJoined['photo'];
							$groupsJoinedArr['membersCount']	= $this->getdatamodel->getGroupMemnbersCount($groupJoined['ID']);
							$groupsJoinedArr['gIsNew']			= $isNew;
							$groupsJoinedArr['gStatus']			= $groupJoined['status'];
							$groupsJoinedArr['isCreator']		= $this->getdatamodel->checkIsGroupCreator($groupJoined['ID'], $userId);
							$groupsJoined[]	= $groupsJoinedArr;

						}
						$resArr['result']		= 1;
					}else{
						$resArr['message']		= "No groups available.";
					}
					if($groupsJoined){
						$resArr['userGroups']			=$this->array_sort_bycolumn($groupsJoined,'gIsNew','desc');
					}else{
						$resArr['userGroups']			=	$groupsJoined;
					}
				}
				else{

					$userGroupsdata=array();
					if($userGroups){
						//$resArr['userGroupsCount']=sizeof($userGroups);
						foreach($userGroups as $userGroup){
							//Added by Rajesh on 28-10-2013 to Check is New activity there
							//for group or not
							$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($userGroup['user_ID'], $userGroup['group_ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
							$userGroupsArr['gId']				= $userGroup['group_ID'];
							$userGroupsArr['gName']			= $userGroup['name'];
							$userGroupsArr['thumb']			= base_url()."Uploads/GroupImages/".$userGroup['thumb'];
							$userGroupsArr['photo']			= base_url()."Uploads/GroupImages/".$userGroup['photo'];
							$userGroupsArr['membersCount']	= $this->getdatamodel->getGroupMemnbersCount($userGroup['ID']);
							$userGroupsArr['gIsNew']			= $isNew;
							$userGroupsArr['gStatus']			= $userGroup['status'];
							$userGroupsArr['isCreator']		= $this->getdatamodel->checkIsGroupCreator($userGroup['ID'], $userId);
							$userGroupsdata[]	= $userGroupsArr;

						}
						$resArr['result']		= 1;
					}else{
						if($searchText){
							$resArr['message']				= "Search Field not matching with the existing data.";
						}else{
							$resArr['message']				= "No groups available.";
						}
					}
					if($userGroupsdata){
						$resArr['userGroups']			= $this->array_sort_bycolumn($userGroupsdata,'gIsNew','desc');
					}else{
						$resArr['userGroups']			=	$userGroupsdata;
					}
				}

				//Joined Groups ends
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Display Group Details
	 * @author Rajesh on 10-10-2013
	 */
	function viewGroup_post()
	{
		$resArr['result']		= 0;
		$groupId				= $this->post('groupId');
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken || !$groupId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$groupMemberArr=array();
				$nonRegGroupMemberArr=array();
				$fbRegGroupMembers=array();
				$checkIsUserDeleted=$this->getdatamodel->checkIsGroupMemberDeleted($groupId, $userId);
				if($checkIsUserDeleted){
					$isGroupMember = $checkIsUserDeleted[0]['status_ID'];
					if($isGroupMember==0){
						$resArr['isDeleted']	= 1;
					}else{
						$resArr['isDeleted']	= 0;
					}
				}else{
					$resArr['isDeleted']	= 1;
				}
				//Added by Rajesh on 29-10-2013 to store Update User Group Badges
				$this->setdatamodel->updateUserGroupBadgeByUserId($userId, $groupId, 0);
				$groupData=$this->getdatamodel->getGroupDetailsById($groupId);
				if($groupData){
					$resArr['result']		= 1;
					$resArr['gName']		= $groupData[0]['name'];
					$resArr['thumb']		= base_url()."Uploads/GroupImages/".$groupData[0]['thumb'];
					$resArr['photo']		= base_url()."Uploads/GroupImages/".$groupData[0]['photo'];
					//$resArr['isCreator']	= 1;
					$registeredGroupMemberesData		= $this->getdatamodel->getGroupMembersDetails($groupId);
					//print_r($groupMemberesData);
					if($registeredGroupMemberesData){
						foreach ($registeredGroupMemberesData as $groupMember){
							$groupMemberArr['name'] 	= $groupMember['displayName'];
							$groupMemberArr['memberId']	= $groupMember['ID'];
							$groupMemberArr['thumb']	= base_url()."Uploads/ProfilePictures/".$groupMember['thumb'];
							$groupMemberArr['photo']	= base_url()."Uploads/ProfilePictures/".$groupMember['photo'];
							$groupMemberArr['isCreator']= $groupMember['isCreator'];
							$groupMemberArr['userType']	= 1;
							$groupMembers[]=$groupMemberArr;
						}
						$resArr['registeredGroupMembers']	= $groupMembers;
						$regMembersCount	= sizeof($registeredGroupMemberesData);
					}else{
						$regMembersCount	= 0;
					}
					$nonregisteredGroupMembersData		= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
					//print_r($nonregisteredGroupMemberesData);die;
					if($nonregisteredGroupMembersData){
						foreach ($nonregisteredGroupMembersData as $nonRegGroupMember){
							$nonRegGroupMemberArr['name'] 	= $nonRegGroupMember['name'];
							$nonRegGroupMemberArr['email']		= $this->convert($nonRegGroupMember['email']);
							$nonRegGroupMemberArr['thumb']	= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							$nonRegGroupMemberArr['photo']	= base_url()."Uploads/ProfilePictures/avatar.png";
							$nonRegGroupMemberArr['isCreator']= 0;
							$nonRegGroupMemberArr['userType']	= 2;
							$nonRegGroupMembers[]=$nonRegGroupMemberArr;
							$resArr['nonRegisteredGroupMembers']	= $nonRegGroupMembers;
						}
						$nonRegMembersCount	= sizeof($nonregisteredGroupMembersData);
					}else{
						$nonRegMembersCount	=0;
					}
					$fbGroupMembersData		= $this->getdatamodel->getnonRegFBGroupMembersDetails($groupId);
					//print_r($nonregisteredGroupMemberesData);die;
					if($fbGroupMembersData){
						foreach ($fbGroupMembersData as $fbGroupMemberData){
							$fbGroupMemberArr['name'] 	= $fbGroupMemberData['name'];
							$fbGroupMemberArr['FBID']	= $fbGroupMemberData['FBID'];;
							$fbGroupMemberArr['thumb']	= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
							$fbGroupMemberArr['photo']	= base_url()."Uploads/ProfilePictures/avatar.png";
							$fbGroupMemberArr['isCreator']= 0;
							$fbGroupMemberArr['userType']	= 3;
							$fbRegGroupMembers[]=$fbGroupMemberArr;
							$resArr['fbGroupMembers']	= $fbRegGroupMembers;
						}
						$fbMembersCount	= sizeof($fbGroupMembersData);
					}else{
						$fbMembersCount	=0;
					}
					
					//groups-Qposts
					
					$getQpalQId=$this->getdatamodel->getQPalQID($groupId);
					
					
					if($getQpalQId){//if group Id is prsent in Qpals
						
						foreach($getQpalQId as $getQpalQId){
						   $qId=$getQpalQId['ID'];
						   $qArr['qId']=$qId;
						   
						   $getQdatails=$this->getdatamodel->getQdetails($qId);
					       $qArr['questionDescription']	= $getQdatails[0]['name'];
					       
						   $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $qArr['responseCount']=$result;
						}else{
							$qArr['responseCount']=0;
						}
					       
					       //get Age of Q
					       $qArr['timeStamp']          = $getQdatails[0]['timeStamp'];
					       $quser_ID                   = $getQdatails[0]['user_ID'];
					       
						   
						   $userData      =$this->getdatamodel->getUserDetailsByUserID($quser_ID);
						   $qArr['qCreatorDisplayName'] = $userData[0]['displayName'];
						   
                           $qImageData=$this->getdatamodel->getQImages($qId);

                           if($qImageData){
                           	$imgName=$qImageData[0]['thumb'];
                           if($imgName){
								$qArr['qImagethumb']=base_url()."Uploads/QImages/$imgName";
							}else{
								$qArr['qImagethumb']=base_url()."Uploads/QImages/default_thumb.png";
							}
							
							$resArr['qPosts'][]    =$qArr;
                          }
						else{
							$qArr['qImagethumb']=base_url()."Uploads/QImages/default_thumb.png";
							$resArr['qPosts'][]    =$qArr;
						}
					}
						
					}else{
					$resArr['message']		= "No Qposts available";
					//modified by ganesh @ 20 March 2014 -- =empty array
					$resArr['qPosts']     =array();
					//$resArr['qPosts']     =NULL;	
				  }
				  
					$resArr['membersCount']	=$regMembersCount+$nonRegMembersCount+$fbMembersCount;
				}else{
					$resArr['message']		= "Group data does not exists.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * This function is to Edit Group
	 * @author Rajesh on 24-10-2013
	 */
	function editGroup_post()
	{
        $resArr['result'] 		= 0;
		$userId					= $this->post('userId');
		$groupId				= $this->post('groupId');
		$groupName				= $this->post('groupName');
		$accessToken			= $this->post('accessToken');
		$isDelGroupImage		= $this->post('isDelGroupImage');
		if(!$userId ||  !$accessToken ||!$groupId ){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$registeredGroupMemberEmails=array();
			$registeredGroupMemberNames=array();

			$nonRegisteredGroupMemberEmails=array();
			$nonRegisteredGroupMemberNames=array();
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$isDuplicateGroup=$this->getdatamodel->isUserDuplicateGroup($userId, $groupName, $groupId);
				//$isDuplicateGroup=false;
				if($isDuplicateGroup){
					//$resArr['message']		= "A group named $groupName already exists.";
					$resArr['message']			= "A Group is already existing with the same name.";
				}else{
					if($isDelGroupImage){
						$groupData	= $this->getdatamodel->getGroupDetailsById($groupId);
						if($groupData){
							if($groupData[0]['photo']!="group.png"){
								@unlink(FCPATH."Uploads/GroupImages/".$groupData[0]['photo']);
								@unlink(FCPATH."Uploads/GroupImages/".$groupData[0]['thumb']);
							}
							$updateGroupData=array('photo'=>"group.png", 'thumb'=>"group_thumb.png",'ID'=> $groupId);
							$this->setdatamodel->updateGroup($updateGroupData);

						}
					}
					$insertGroupData 	= array('name'=>$groupName,'ID'=>$groupId );
					$this->setdatamodel->updateGroup($insertGroupData, $groupId);
					$groupCreatorData=$this->getdatamodel->getUserDetailsByUserID($userId);
					if($groupCreatorData){
						$groupCreatorName=$groupCreatorData[0]['firstName'];
					}else{
						$groupCreatorName="";
					}
					$registeredGroupMemberesData1		= $this->getdatamodel->getGroupMembersDetails($groupId,1);
					$nonregisteredGroupMembersData1		= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
					if($registeredGroupMemberesData1){
						$from = $this->_supportEmail;
						foreach ($registeredGroupMemberesData1 as $rec){
							//To Send Push to Newly Added Member
							//@author Rajesh on 13-11-2013
							if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$groupCreatorName has updated the $groupName.";
								$data->typeID = "2";
		     	                                        $data->param = $groupId;
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}
							if($rec['isEmailAlerts']==1){
								$regEmail		= $this->convert($rec['email']);
								$userId=$rec['ID'];
								$this->setdatamodel->updateUserGroupBadgeByUserId($userId, $groupId, 1);
								$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
								$uname			= $userDetails[0]['firstName'];
								$mailData['userName'] 	= $uname;
								$mailData['groupCreator']= $groupCreatorName;
								$mailData['groupName']	= $groupName;
								$mailData['groupId']	= $groupId;
								$mailContet = $this->templatemodel->updateGroupMailTemplate($mailData);
								//$subject = "Group $groupName updated";
								$subject = "QPals Group Updated";
								// call mailer function to send mail.
//								$status = mailer($from, $regEmail, $subject, $mailContet);
								$data = new StdClass;
								$data->from = $from;
								$data->to = $regEmail;
								$data->subject = $subject;
								$data->body = $mailContet;
								$message = json_encode($data);	
								$this->messagequeue->addMessageToMAILQueue($message);
							}
						}
					}

					if($nonregisteredGroupMembersData1){
						$from = $this->_supportEmail;
						foreach ($nonregisteredGroupMembersData1 as $rec){
							$regEmail		= $this->convert($rec['email']);
							$uname			= $rec['name'];
							$mailData['userName'] 	= $uname;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailData['groupId']	= $groupId;
							$mailContet = $this->templatemodel->updateGroupMailTemplate($mailData);
							//$subject = "Group $groupName updated";
							$subject = "QPals Group Updated";
							// call mailer function to send mail.
						//	$status = mailer($from, $regEmail, $subject, $mailContet);
							 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						}
					}
					if($groupId) {

						$resArr['result'] 		= 1;
						//$resArr['message']		= "$groupName group created successfully.";
						$resArr['message']		= "Your updated group is now live.";
						//$resArr['data']			= $groupArr;

						//FB members starts
						$fbNames	= $this->post('fbName');
						$fbIds		= $this->post('fbId');
						if($fbNames){
							$fbNamesArr		= explode("|",$fbNames);
							$fbIdsArr		= explode("|",$fbIds);
						}
						if(isset($fbIdsArr)){
							for($i=0;$i<sizeof($fbNamesArr);$i++){
								$FBID=$fbIdsArr[$i];
								$checkUserByFBID=$this->getdatamodel->checkUserByFBID($FBID);
								if($checkUserByFBID){
									$userID=$checkUserByFBID[0]['user_ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);

								} else {
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								$fbFirstName=$fbNamesArr[$i];

								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 29-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
									//To Send Push to Newly Added Member
									//@author Rajesh on 13-11-2013
									if($res[0]['isPushAlerts']==1){
										$data = new StdClass;
										$data->deviceToken = $res[0]['pushId'];
										$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
										$data->typeID = "2";
					                    $data->param = $groupId;
										//$data->badge = $invitations;
										//$data->sound  = "ping.wav";
										$message = json_encode($data);

										log_message('debug',"hitting message queue $message");			// Check the device type and send push
										if($res[0]['deviceType_ID']== 1){ //Android
											log_message('debug',$message);

											$this->messagequeue->addMessageToC2DMQueue($message);

										}
										elseif($res[0]['deviceType_ID']== 2){ //Ios

											$this->messagequeue->addMessageToAPNSQueue($message);
										}
										elseif($res[0]['deviceType_ID']== 3){ //Windows

											$this->messagequeue->addMessageToWinQueue($message);
										}
									}

								}
								// If user not exists We will insert Group member mapping in nonRegisteredFBMembers
								else{
									$fbMemberData=array('FBID'=>$FBID,'name'=>$fbFirstName, 'group_ID' => $groupId, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredFBMember($fbMemberData);
														//to send notifications to non register group members who are being added in the group
									                      
			                        
			                        

                             
			   
								}
							}
						}
						//FB members ends

						//Phone Contacts starts
						$phoneNames		= $this->post('phoneName');
						$phoneEmails		= $this->post('phoneEmail');
						if($phoneEmails){
							$phoneNamesArr		= explode("|",$phoneNames);
							$phoneEmailsArr		= explode("|",$phoneEmails);
						}
						if(isset($phoneEmailsArr)){
							for($i=0;$i<sizeof($phoneNamesArr);$i++){
								$phoneEmail = $this->convert(strtolower($phoneEmailsArr[$i]));
								$phoneName  = $phoneNamesArr[$i];
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($phoneEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 29-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
									//To Send Push to Newly Added Member
									//@author Rajesh on 13-11-2013
									if($res[0]['isPushAlerts']==1){
										$data = new StdClass;
										$data->deviceToken = $res[0]['pushId'];
										$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
										$data->typeID = "2";
					                    $data->param = $groupId;
										//$data->badge = $invitations;
										//$data->sound  = "ping.wav";
										$message = json_encode($data);

										log_message('debug',"hitting message queue $message");			// Check the device type and send push
										if($res[0]['deviceType_ID']== 1){ //Android
											log_message('debug',$message);

											$this->messagequeue->addMessageToC2DMQueue($message);

										}
										elseif($res[0]['deviceType_ID']== 2){ //Ios

											$this->messagequeue->addMessageToAPNSQueue($message);
										}
										elseif($res[0]['deviceType_ID']== 3){ //Windows

											$this->messagequeue->addMessageToWinQueue($message);
										}
									}
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$phoneName, 'email'=>$phoneEmail, 'group_ID' => $groupId, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$phoneEmail;
									$nonRegisteredGroupMemberNames[]=$phoneName;
								}
							}
						}
						//Phone Contacts ends
						
						//following contacts start
						  $followingNames =$this->post('followingName');
			              $followingEmails=$this->post('followingEmail');

			              if($followingEmails){
			              	$followingNamesArr  =explode("|",$followingNames);
			              	$followingEmailsArr =explode("|",$followingEmails);
			              	
			              }
			              
			              if(isset($followingNamesArr)){
			              	
			              	 for($i=0;$i<sizeof($followingNamesArr);$i++){
			              	 	
			              	 	$followingEmail=$this->convert(strtolower($followingEmailsArr[$i]));
			              	 	$followingName =$followingNamesArr[$i];
			              	 	$checkUserByEmail=$this->getdatamodel->checkUserByEmail($followingEmail);
			              	    if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								
								
			              	 if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];									
			              	         //To Send Push to Newly Added Member									
									if($res[0]['isPushAlerts']==1){
										$data = new StdClass;
										$data->deviceToken = $res[0]['pushId'];
										$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
										$data->typeID = "2";
					                    $data->param = $groupId;
										//$data->badge = $invitations;
										//$data->sound  = "ping.wav";
										$message = json_encode($data);

										log_message('debug',"hitting message queue $message");			// Check the device type and send push
										if($res[0]['deviceType_ID']== 1){ //Android
											log_message('debug',$message);

											$this->messagequeue->addMessageToC2DMQueue($message);

										}
										elseif($res[0]['deviceType_ID']== 2){ //Ios

											$this->messagequeue->addMessageToAPNSQueue($message);
										}
										elseif($res[0]['deviceType_ID']== 3){ //Windows

											$this->messagequeue->addMessageToWinQueue($message);
										}
									}
								}else{
									$resArr['message']		= "following details not found";
								}
			              	 }
			              	
			              }
						//following contacts end
						
			            //followers contacts start
			             $followersNames =$this->post('followerName');
			             $followersEmails=$this->post('followersEmail');
			             
					     if( $followersEmails){
			              	$followersNamesArr  =explode("|",$followersNames);
			              	$followersEmailsArr =explode("|", $followersEmails);
			              	
			              }
			              
			              if(isset($followersEmailsArr)){
			              	
			              	 for($i=0;$i<sizeof($followersEmailsArr);$i++){
			              	 	
			              	 	$followerEmail=$this->convert(strtolower($followersEmailsArr[$i]));
			              	 	$followerName =$followersNamesArr[$i];
			              	 	$checkUserByEmail=$this->getdatamodel->checkUserByEmail($followerEmail);
			              	    if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								
								
			              	 if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
									//push notification
			              	 if($res[0]['isPushAlerts']==1){
										$data = new StdClass;
										$data->deviceToken = $res[0]['pushId'];
										$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
										$data->typeID = "2";
					                    $data->param = $groupId;
										//$data->badge = $invitations;
										//$data->sound  = "ping.wav";
										$message = json_encode($data);

										log_message('debug',"hitting message queue $message");			// Check the device type and send push
										if($res[0]['deviceType_ID']== 1){ //Android
											log_message('debug',$message);

											$this->messagequeue->addMessageToC2DMQueue($message);

										}
										elseif($res[0]['deviceType_ID']== 2){ //Ios

											$this->messagequeue->addMessageToAPNSQueue($message);
										}
										elseif($res[0]['deviceType_ID']== 3){ //Windows

											$this->messagequeue->addMessageToWinQueue($message);
										}
									}
								}else{
									$resArr['message']		= "follower details not found";
								}
			              	 }
			              	
			              }
			             
			            
			            //followers contacts end
						
						
						
						
						
						
						
							
						//Custom contacts starts
						$customNames		= $this->post('customName');
						$customEmails		= $this->post('customEmail');
						if($customEmails){
							$customNamesArr		= explode("|",$customNames);
							$customEmailsArr		= explode("|",$customEmails);
						}
						if(isset($customEmailsArr)){
							for($i=0;$i<sizeof($customEmailsArr);$i++){
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));
								$customName  = $customNamesArr[$i];
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 29-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
									//To Send Push to Newly Added Member
									//@author Rajesh on 13-11-2013
									if($res[0]['isPushAlerts']==1){
										$data = new StdClass;
										$data->deviceToken = $res[0]['pushId'];
										$data->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
										$data->typeID = "2";
					                    $data->param = $groupId;
										//$data->badge = $invitations;
										//$data->sound  = "ping.wav";
										$message = json_encode($data);

										log_message('debug',"hitting message queue $message");			// Check the device type and send push
										if($res[0]['deviceType_ID']== 1){ //Android
											log_message('debug',$message);

											$this->messagequeue->addMessageToC2DMQueue($message);

										}
										elseif($res[0]['deviceType_ID']== 2){ //Ios

											$this->messagequeue->addMessageToAPNSQueue($message);
										}
										elseif($res[0]['deviceType_ID']== 3){ //Windows

											$this->messagequeue->addMessageToWinQueue($message);
										}
									}
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$customName, 'email'=>$customEmail, 'group_ID' => $groupId, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									$nonRegisteredGroupMemberNames[]=$customName;
								}
							}
						}

						//Custom contacts ends
					}

				}
				//To update user Group Badge
				$this->setdatamodel->updateUserGroupBadge($groupId, 1);
				//To send mails to Group Memebers when the group is updated
				$msgStr="";
				$addedMemNames=array_merge($registeredGroupMemberNames,$nonRegisteredGroupMemberNames);
				for($j=0;$j<sizeof($addedMemNames);$j++){
					if($j==0){
						$msgStr.=$addedMemNames[$j];
					}else if($j<=sizeof($addedMemNames)-2){
						$msgStr.=", ".$addedMemNames[$j];
					}else{
						$msgStr.=" and ".$addedMemNames[$j];
					}
				}
				if($registeredGroupMemberesData1){
					$from = $this->_supportEmail;
					foreach ($registeredGroupMemberesData1 as $rec){

						if($rec['isPushAlerts']==1){
							$data = new StdClass;
							$data->deviceToken = $rec['pushId'];
							$data->message = "$groupCreatorName has added $msgStr to $groupName.";
							$data->typeID = "2";
					        $data->param = $groupId;
							//$data->badge = $invitations;
							//$data->sound  = "ping.wav";
							$message = json_encode($data);

							log_message('debug',"hitting message queue $message");			// Check the device type and send push
							if($rec['deviceType_ID']== 1){ //Android
								log_message('debug',$message);

								$this->messagequeue->addMessageToC2DMQueue($message);

							}
							elseif($rec['deviceType_ID']== 2){ //Ios

								$this->messagequeue->addMessageToAPNSQueue($message);
							}
							elseif($rec['deviceType_ID']== 3){ //Windows

								$this->messagequeue->addMessageToWinQueue($message);
							}
						}
						if($rec['isEmailAlerts']==1){
							$regEmail		= $this->convert($rec['email']);
							$userId=$rec['ID'];
							$this->setdatamodel->updateUserGroupBadgeByUserId($userId, $groupId, 1);
							$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
							$uname			= $userDetails[0]['firstName'];
							$mailData['userName'] 	= $uname;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailData['members']	= $msgStr;
							$mailData['groupId']	= $groupId;
							$mailContet = $this->templatemodel->addedGroupMembersMailTemplate($mailData);
							$subject = "News about your group on Qpals";
							// call mailer function to send mail.
						//	$status = mailer($from, $regEmail, $subject, $mailContet);
							 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						}
					}
				}

				if($nonregisteredGroupMembersData1){
					$from = $this->_supportEmail;
					foreach ($nonregisteredGroupMembersData1 as $rec){
						$regEmail		= $this->convert($rec['email']);
						$uname			= isset($rec['name'])?$rec['name']:"User";
						$mailData['userName'] 	= $uname;
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	= $msgStr;
						$mailContet = $this->templatemodel->addedGroupMembersMailTemplate($mailData);
						$subject = "News about your group on Qpals";
						// call mailer function to send mail.
			//			$status = mailer($from, $regEmail, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

					}
				}
				$i=0;
				if($nonRegisteredGroupMemberEmails){
					foreach($nonRegisteredGroupMemberEmails as $userEmail){
						$string="";
						$newArr=$nonRegisteredGroupMemberNames;
						$recEmail=$this->convert($userEmail);
						$uname=$nonRegisteredGroupMemberNames[$i];
						unset($newArr[$i]);
						//print_r($newArr);
						foreach ($newArr as $arr){
							//echo sizeof($newArr)." ".$i;
							$string .=$arr.",";

						}
						$string=substr($string, 0, -1);
						$strArr=explode(",",$string);
						$msgStr="";
						for($j=0;$j<sizeof($strArr);$j++){
							if($j==0){
								$msgStr.=$strArr[$j];
							}else if($j<=sizeof($strArr)-2){
								$msgStr.=", ".$strArr[$j];
							}else{
								$msgStr.=" and ".$strArr[$j];
							}
						}
						$from = $this->_supportEmail;
						$mailData['userName'] 	= $uname;
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['groupId']	=$groupId;
						// getting the mail content
						$mailContet = $this->templatemodel->nonRegisteredUserGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						// call mailer function to send mail.
						//$status = mailer($from, $recEmail, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $recEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						$i++;

					}
				}
				$i=0;
				if($registeredGroupMemberEmails){
					foreach($registeredGroupMemberEmails as $userEmail){
						$string="";
						$newArr=$registeredGroupMemberEmails;
						$recEmail=$this->convert($userEmail);
						$uname=$registeredGroupMemberNames[$i];
						unset($newArr[$i]);
						//print_r($newArr);
						foreach ($newArr as $arr){
							//echo sizeof($newArr)." ".$i;
							$string .=$arr.",";

						}
						$string=substr($string, 0, -1);
						$strArr=explode(",",$string);
						$msgStr="";
						for($j=0;$j<sizeof($strArr);$j++){
							if($j==0){
								$msgStr.=$strArr[$j];
							}else if($j<=sizeof($strArr)-2){
								$msgStr.=", ".$strArr[$j];
							}else{
								$msgStr.=" and ".$strArr[$j];
							}
						}
						$from = $this->_supportEmail;
						$mailData['userName'] 	= $uname;
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['groupId']	=$groupId;
						// getting the mail content
						$mailContet = $this->templatemodel->nonRegisteredUserGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						// call mailer function to send mail.
						//$status = mailer($from, $recEmail, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $recEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						$i++;

					}
				}
				
				
			 $getCountOffollowers=$this->getdatamodel->getCountOffollowers($userId);
				
				if($getCountOffollowers){
					$resArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($userId);
				}else{
					$resArr['countOfFollowers']	=NULL;
				}
				
			$getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($userId);
				
				if($getCountOfFollowing){
				$resArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($userId);
				}else{
				$resArr['countOfFollowing']=NULL;	
				}


			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}


	/**
	 * To Delete Group
	 * @author Rajesh on 23-10-2013
	 */
	function deleteGroup_post()
	{
		$resArr['result']		= 0;
		$groupId				= $this->post('groupId');
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken || !$groupId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result'] 		= 1;
				$groupData=$this->getdatamodel->getGroupDetailsById($groupId);
				if($groupData){
				$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
				$defaultGroupId=$userDetails[0]['defaultGroup_ID'];
				
				if($defaultGroupId==$groupId){
						$userdata=array('defaultGroup_ID'=>0,'ID'=>$userId);
						$this->setdatamodel->updateUserData($userdata);
						
					}
					
					
					$groupName=$groupData[0]['name'];
					$groupCreatorId=$groupData[0]['user_ID'];
					$groupCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($groupCreatorId);
					$groupCreatorName=$groupCreatorDetails[0]['firstName'];
					$registeredGroupMemberesData		= $this->getdatamodel->getGroupMembersDetails($groupId, 1);
					if($registeredGroupMemberesData){
						$from = $this->_supportEmail;
						foreach ($registeredGroupMemberesData as $rec){
							//To Send Push to Newly Added Member
							//@author Rajesh on 13-11-2013
							if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$groupCreatorName has deleted $groupName group.";
								$data->typeID = "3";
					            $data->param = $groupId;
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}

							$regEmail		= $this->convert($rec['email']);
							$userId=$rec['ID'];
							$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
							$uname			= $userDetails[0]['firstName'];
							$mailData['userName'] 	= $uname;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailContet = $this->templatemodel->deleteGroupMailTemplate($mailData);
							$subject = "$groupCreatorName has deleted $groupName on Qpals";
							// call mailer function to send mail.
						//	$status = mailer($from, $regEmail, $subject, $mailContet);
							 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						}
					}
					
					
					
					$this->setdatamodel->deleteGroup($groupId);

					$resArr['message']		= "Group deleted.";
				}else{
					$resArr['message']		= "Group has not been deleted.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Delete Group Memebers
	 * @author Rajesh on 25-10 -2013
	 */
	function deleteGroupMembers_post()
	{
		$resArr['result']		= 0;
		$groupId				= $this->post('groupId');
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken || !$groupId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$from = $this->_supportEmail;
				$resArr['result'] 		= 1;
				$userIDString	= $this->post('userIds');
				$fbIdString		= $this->post('fbIds');
				$emailString	= $this->post('emails');
				$groupData=$this->getdatamodel->getGroupDetailsById($groupId);
				if($groupData){
					$groupName=$groupData[0]['name'];
					$groupCreatorId=$groupData[0]['user_ID'];
					$groupCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($groupCreatorId);
					$groupCreatorName=$groupCreatorDetails[0]['firstName'];
				}
				if($userIDString){
					$userIDArr		= explode("|",$userIDString);
				}
				if(isset($userIDArr)){
					$from = $this->_supportEmail;
					for($i=0;$i<sizeof($userIDArr);$i++){
						$userDetails=$this->getdatamodel->getUserDetailsByUserID($userIDArr[$i]);
						$uname			= $userDetails[0]['firstName'];
						$mailData['userName'] 	= $uname;
						$mailData['groupName']	= $groupName;
						$mailData['groupCreator']=$groupCreatorName;
						$userEmail=$this->convert($userDetails[0]['email']);
						$mailContet = $this->templatemodel->deleteMemberMailTemplate($mailData);
						$subject = "Sorry, you are no longer a member of $groupName";
						// call mailer function to send mail.
						//$status = mailer($from, $userEmail, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $userEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);


						//To Send Push to Newly Added Member
						//@author Rajesh on 13-11-2013
						if($userDetails[0]['isPushAlerts']==1){
							$data = new StdClass;
							$data->deviceToken = $userDetails[0]['pushId'];
							$data->message = "You are no longer a member of $groupName on Qpals.";
							$data->typeID = "2";
					        $data->param = $groupId;
							//$data->badge = $invitations;
							//$data->sound  = "ping.wav";
							$message = json_encode($data);

							log_message('debug',"hitting message queue $message");			// Check the device type and send push
							if($userDetails[0]['deviceType_ID']== 1){ //Android
								log_message('debug',$message);

								$this->messagequeue->addMessageToC2DMQueue($message);

							}
							elseif($userDetails[0]['deviceType_ID']== 2){ //Ios

								$this->messagequeue->addMessageToAPNSQueue($message);
							}
							elseif($userDetails[0]['deviceType_ID']== 3){ //Windows

								$this->messagequeue->addMessageToWinQueue($message);
							}
						}


						$registeredGroupMemberesData		= $this->getdatamodel->getGroupMembersDetails($groupId,1);
						if($registeredGroupMemberesData){
							foreach($registeredGroupMemberesData as $rec){

								//To Send Push to Newly Added Member
								//@author Rajesh on 13-11-2013
								if($rec['isPushAlerts']==1){
									$data = new StdClass;
									$data->deviceToken = $rec['pushId'];
									$data->message = "$uname is no longer a member of $groupName on Qpals.";
									$data->typeID = "2";
					                $data->param = $groupId;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}


								$regUserDetails=$this->getdatamodel->getUserDetailsByUserID($rec['ID']);
								$regUname			= $regUserDetails[0]['firstName'];
								$regUserEmail		= $this->convert($regUserDetails[0]['email']);
								if($regUserEmail!=$userEmail){
									$mailData['userName']	= $regUname;
									$mailData['deletedUser']= $uname;
									$mailData['groupName']	= $groupName;
									$subject = "$uname is no longer a member of $groupName";
									$mailContet=$this->templatemodel->deleteMembersMailTemplate($mailData);
									// call mailer function to send mail.
						//			$status = mailer($from, $regUserEmail, $subject, $mailContet);
									 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regUserEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

								}
							}
						}
						$this->setdatamodel->deleteUserFromGroup($userIDArr[$i], $groupId);
					}
				}
				if($fbIdString){
					$fbIdArr		= explode("|", $fbIdString);
				}
				if(isset($fbIdArr)){
					for($i=0;$i<sizeof($fbIdArr);$i++){
						$this->setdatamodel->deleteFbUserFromGroup($fbIdArr[$i], $groupId);
					}
				}
				if($emailString){
					$emailArr		= explode("|",$emailString);
				}
				if(isset($emailArr)){
					for($i=0;$i<sizeof($emailArr);$i++){
						$encEmail=$this->convert($emailArr[$i]);
						$nonRegUserDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($encEmail);
						$uname=$nonRegUserDetails[0]['name'];
						$registeredGroupMemberesData		= $this->getdatamodel->getGroupMembersDetails($groupId,1);
						if($registeredGroupMemberesData){
							foreach($registeredGroupMemberesData as $rec){
								$regUserDetails=$this->getdatamodel->getUserDetailsByUserID($rec['ID']);
								$regUname			= $regUserDetails[0]['firstName'];
								$regUserEmail		= $this->convert($regUserDetails[0]['email']);
								$mailData['userName']	= $regUname;
								$mailData['deletedUser']= $uname;
								$mailData['groupName']	= $groupName;
								$subject = "$uname is no longer a member of $groupName";
								$mailContet=$this->templatemodel->deleteMembersMailTemplate($mailData);
								// call mailer function to send mail.
								//$status = mailer($from, $regUserEmail, $subject, $mailContet);
								 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $regUserEmail;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

							}
						}
						$this->setdatamodel->deleteNonRegisteredGroupMemebers($encEmail, $groupId);
					}
				}

				//To update user Group Badge
				$this->setdatamodel->updateUserGroupBadge($groupId, 1);
				//$this->setdatamodel->deleteGroup($groupId);
				$resArr['message']		= "Selected group members deleted.";
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To get Group Details For Create Q
	 * @author Rajesh on 29-10-2013
	 */
	function getGroupsFor_post()
	{
		$resArr['result']		= 0;
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['groups']=array();
				$groupsCreatedDetails=$this->getdatamodel->getUserCreatedGroups($userId);
				$groupsJoinedDetails=$this->getdatamodel->getUserJoinedGroups($userId);
				$userGroups=$this->getdatamodel->getUserGroups($userId);
				if($userGroups){
					$resArr['result']		= 1;
					foreach ($userGroups as $rec){
						$groupId=$rec['ID'];
						$totalCount=$this->getdatamodel->getGroupMemnbersCount($groupId);
						if($totalCount>1){
							$groupArr['groupName']=$rec['name'];
							$groupArr['membersCount']=$totalCount;
							$resArr['groups'][]=$groupArr;
						}
					}
				}else{
					$resArr['message']="No groups for user.";
				}

			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To get Group members Details
	 * @author Rajesh on 29-10-2013
	 */
	function getGroupMembers_post()
	{
		$resArr['result']		= 0;
		$userId					= $this->post('userId');
		$groupId				= $this->post('groupId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken || !$groupId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$groupMembersData=$this->getdatamodel->getGroupMembersDetails($groupId);

				if($groupMembersData){
					$resArr['result']		= 1;
					$resArr['firstName']	= $groupMembersData[0]['firstName'];
					$resArr['lastName']		= $groupMembersData[0]['lastName'];
					$resArr['thumb']		=  base_url()."Uploads/ProfilePictures/".$groupMembersData[0]['thumb'];
				}else{
					$resArr['message']="No members in this group.";
				}

			}else{
				$resArr['message']		= "Invalid Access token.";
			}
		}
		echo $this->response($resArr, 200);

	}
	/**
	 * To get all Preset Questions
	 * @author Rajesh on 30-10-2013
	 */
	function presetQuestions_post()
	{
		$resArr['result']		= 0;
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken){
				$presetQuestions=$this->getdatamodel->getPresetQuestions();
				if($presetQuestions){
					$resArr['result']		= 1;
					foreach($presetQuestions as $rec){
						$questionsArr['questionId']	= $rec['ID'];
						$questionsArr['question']	= $rec['name'];
						$resArr['presetQuestions'][]=$questionsArr;
					}
				}else{
					$resArr['message']="No Preset Questions Exists.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * Tp Mapp FBID to user
	 * @author Rajesh on 31-10-2013
	 */
	function userFBMapping_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$fbId				= $this->post('fbId');
		if(!$userId || !$accessToken || !$fbId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$checkFbUser=$this->getdatamodel->checkUserByFBID ($fbId);
				if(!$checkFbUser){
					$updateUserData=array('FBID'=>$fbId, 'status_ID'=>1, 'user_ID'=> $userId);
					$this->setdatamodel->userFBMapping($updateUserData);
					$resArr['result']	= 0;
				}else{
					$resArr['message']		= "Facebook ID already mapped.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To set User follow Un follow mapping
	 * @author Rajesh on 01-11-2013
	 *
	 */

	function followUser_post()
	{
		$resArr['result']		= 0;
		$userId					= $this->post('userId');
		$accessToken			= $this->post('accessToken');
		$followerId				= $this->post('followerId');
		$operation				= $this->post('operation');
		if(!$userId || !$accessToken || !$followerId || !$operation){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']		= 1;
				if($operation==1){
					$resArr['message']		= "Following Successfully.";
				}else if($operation==2){
					$resArr['message']		= "Unfollowing Successfully.";
				}
				$this->setdatamodel->followUser($userId,$followerId, $operation);
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 *To Delete User himself From Group
	 *@author Rajesh on 04-11-2013
	 */
	function deleteMyself_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$groupId			= $this->post('groupId');
		$operation				= $this->post('operation');
		if(!$userId || !$accessToken || !$groupId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
				$uname=$userData[0]['firstName'];
				$defaultGroupId=$userData[0]['defaultGroup_ID'];			
				
				if($defaultGroupId==$groupId){
						$userdata=array('defaultGroup_ID'=>0,'ID'=>$userId);
						$this->setdatamodel->updateUserData($userdata);
						
					}
				$groupDetails=$this->getdatamodel->getGroupDetailsById($groupId);
				$groupName=$groupDetails[0]['name'];
				$res=$this->setdatamodel->deleteUserFromGroup($userId, $groupId);
				$from = $this->_supportEmail;
				if($res){
					$resArr['result']       = 1;
					$registeredGroupMembersData		= $this->getdatamodel->getGroupMembersDetails($groupId, 0);
					//var_dump($registeredGroupMembersData);die;
					if($registeredGroupMembersData){
						foreach ($registeredGroupMembersData as $rec){
							//To Send Push to Newly Added Member
							//@author Rajesh on 13-11-2013
							if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$uname is no longer a member of $groupName on Qpals.";
								$data->typeID = "0";
					            $data->param = "0";
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}

							$mailData['userName']	= $rec['firstName'];
							$mailData['deletedUser']= $uname;
							$mailData['groupName']	= $groupName;
							$regEmail				= $rec['email'];
							$email=$this->convert($regEmail);
							$subject = "$uname is no longer a member of $groupName";
							$mailContet=$this->templatemodel->deleteMembersMailTemplate($mailData);
							// call mailer function to send mail.
							//$status = mailer($from, $email, $subject, $mailContet);
							 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);


						}
					}
					$resArr['message']		= "Group deleted.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To get User Profile Details
	 * @author Rajesh 06-11-2013
	 */
	function userProfile_post()
	{
		//echo "daasdasdasd";die;
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
				if($userData){
					$resArr['result']		= 1;
					$resArr['firstName']	= $userData[0]['firstName'];
					$resArr['lastName']		= $userData[0]['lastName'];
					$resArr['displayName']	= $userData[0]['displayName'];
					$resArr['biography']	= $userData[0]['biography'];
					$resArr['email']		= $this->convert($userData[0]['email']);
					$location				= $userData[0]['locationName'];
					$latitude				= $userData[0]['latitude'];
					$longitude				= $userData[0]['longitude'];
					if($location){
						$resArr['location']		= $location;
					}else if(!$location && $latitude && $longitude){
						$resArr['location']		= $this->getaddress($latitude,$longitude);
					}else{
						$resArr['location']		='';
					}

					$gender					= $userData[0]['gender'];
					if($gender){
						$resArr['gender']		= $gender;
					}else{
						$resArr['gender']		= 0;
					}
					$resArr['photo']		= base_url()."Uploads/ProfilePictures/".$userData[0]['photo'];
					$resArr['thumb']		= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
					$secEmailData=$this->getdatamodel->getSecondaryEmails($userId);
					if($secEmailData){
						foreach ($secEmailData as $rec){
							$secArr['email']=$this->convert($rec['email']);
							$secArr['status']	= $rec['status_ID'];
							$secEmailArr[]=$secArr;
						}
						$resArr['secEmails'] =$secEmailArr;
					}	else{
						$resArr['secEmails']=array();
					}
				$resArr['iCreated']=$this->getdatamodel->getTotCountOfMyQs($userId);
				$resArr['iRecieved']=$this->getdatamodel->getTotCountOfRecievedQs($userId);
				$getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($userId);
				
				if($getCountOfFollowing){
				$resArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($userId);
				}else{
				$resArr['countOfFollowing']=0;	
				}
				
				$getCountOffollowers=$this->getdatamodel->getCountOffollowers($userId);
				
				if($getCountOffollowers){
					$resArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($userId);
				}else{
					$resArr['countOfFollowers']	=0;
				}
				
				}else{
					$resArr['message']		= "Unable to retrieve user data.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User Profile
	 * @author Rajesh on 06-11-2013
	 */
	function updateProfile_post()
	{
		$resArr['result']	= 0;
		$primaryEmailError=0;
		$secondaryEmailError=0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$from = $this->_supportEmail;
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$firstName		= $this->post('firstName');
				$lastName		= $this->post('lastName');
				$displayName	= $this->post('displayName');
				$biography		= $this->post('biography');
				$location		= $this->post('location');
				$gender			= $this->post('gender');
				$isChangePwd 	= $this->post('isChangePassword');
				$secondaryEmail	= $this->post('secondaryEmail');
				$isDelProfilePic= $this->post('isDelProfilePic');
				$secEmailArr=array();
				if($secondaryEmail){
					$secEmailArr=explode("|",$secondaryEmail);
				}

				if($secEmailArr){
					for($i=0;$i<sizeof($secEmailArr);$i++){
						$encEmail=$this->convert($secEmailArr[$i]);
						$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
						if($isPrimaryEmailExists){
							$primaryEmailError= 1;
						}
						$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail, 1);
						//var_dump($isSecondaryActivatedEmail);
						if($isSecondaryActivatedEmail){
							$secondaryEmailError=1;
						}
					}
				}
				//var_dump($emailError);
				if($primaryEmailError){
					$resArr['message']= "Email already registered.";
				}if($secondaryEmailError){
					$resArr['message']= "Email already registered.";
				}
				//print_r($resArr);
				//die;
				$error			= 0;
				if($isChangePwd){
					$currentPwd	= $this->post('currentPassword');
					$newPwd		= $this->post('newPassword');
					$userData	= $this->getdatamodel->getUserDetailsByUserID($userId);
					$userPassword= $userData[0]['password'];
					$email		= $this->convert($userData[0]['email']);
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					 
					if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $userId,'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userId);
						$resArr['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
					if(md5($currentPwd)==$userPassword){
						$updateData['password']	= md5($newPwd);
					}else{
						$error 	= 1;
						$resArr['message']		= "Incorrect current password.";
					}
				}
				if($isDelProfilePic){
					$userData	= $this->getdatamodel->getUserDetailsByUserID($userId);
					if($userData){
						$resArr['result']	= 1;
						if($userData[0]['photo']!="avatar.png"){
							@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['photo']);
							@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['thumb']);
						}
						$updateUserData=array('photo'=>"avatar.png", 'thumb'=>"avatar_thumb.png",'ID'=> $userId);
						$this->setdatamodel->updateUserData($updateUserData);
							
					}
				}
				if(!$error && !$primaryEmailError && !$secondaryEmailError){
					$resArr['result']	= 1;
					$updateData['firstName']	= $firstName;
					$updateData['lastName']		= $lastName;
					$updateData['displayName']	= $displayName;
					$updateData['biography']	= $biography;
					$updateData['locationName']	= $location;
					$updateData['gender']		= $gender;
					$updateData['ID']			= $userId;
					//$res=0;
					$res=$this->setdatamodel->updateUserData($updateData);
					if($res && $isChangePwd){
						$mailData['userName']	= $firstName;
						$mailData['email']		= $email;
						$mailData['password']	= $newPwd;
						$subject = "Request to change password on Qpals";
						$mailContet=$this->templatemodel->changePasswordMailTemplate($mailData);
						// call mailer function to send mail.
						//$status = mailer($from, $email, $subject, $mailContet);
						 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

					}
					if($secEmailArr){
						for($i=0;$i<sizeof($secEmailArr);$i++){
							$encEmail=$this->convert($secEmailArr[$i]);
							$activationCodeGenerator 	= str_split(sha1(microtime()),7);
							$activationCode				= $activationCodeGenerator[0].$userId;
							$email = $secEmailArr[$i];
							$userNameArr=explode("@",$secEmailArr[$i]);
							$userName=$userNameArr[0];
							$mailData['userName']=$firstName;
							$mailData['email']=$email;
							$mailData['activationCode']=$activationCode;
							$insertData=array('email'=>$encEmail,'activationCode'=>$activationCode,'user_ID'=>$userId);
							$res=$this->setdatamodel->insertSecondaryEmail($insertData);
							//die;
							$subject	= "Secondary Email Activation";
							$mailContent=$this->templatemodel->secondaryEmailActivationMailTemplate($mailData);
							//$status = mailer($from, $email, $subject, $mailContent);
							 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContent;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);


						}

						$resArr['message']		= "Profile updated.";
					}
					$resArr['message']		= "Profile updated.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			//print_r($resArr);die;
			echo $this->response($resArr, 200);

		}
	}
	/**
	 * To upload Profile Image
	 * @author Rajesh on 06-11-2013
	 */
	function profileImageUpload_post()
	{
		//if(isset($_POST['submit'])){
		//print_r($_FILES);die;
		$resArr['result']		= 0;
		$userId				= $this->post('userId');
		if($_FILES['profileImage']['name']){
			$profileImgResponse = $this->setdatamodel->uploadImage($_FILES,'profileImage','ProfilePictures');
			if($profileImgResponse){
				$profileImgName = $profileImgResponse['imgName'];
				$profileThumbName = $profileImgResponse['thumbName'];
				$userData = array('ID'=>$userId, 'thumb'=>$profileThumbName ,'photo'=>$profileImgName);
				$this->setdatamodel->updateUserData($userData);
				$resArr['result']		= 1;
				$resArr['message']		= "Profile image uploaded successfully.";
				$profileImageData['profileImage'] = base_url()."Uploads/ProfilePictures/".$profileImgName;
				$profileImageData['profileThumb'] = base_url()."Uploads/ProfilePictures/".$profileThumbName;
				$resArr['data']		  		  =  $profileImageData;
			}else{
				$resArr['message']		= "Profile image not uploaded ";
			}
		}
		echo $this->response($resArr, 200);
		//}
	}
	/**
	 * Function to get user settings
	 * @author Rajesh on 07-11-2013
	 */
	function userSettings_post()
	{
		$resArr['result']	= 0;
		$userId			= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$presetQuestions=$this->getdatamodel->getPresetQuestions();
				$userGroups=$this->getdatamodel->getUserGroupsList($userId);
				if($userGroups){
					foreach($userGroups as $group){
						$groupsArr['groupId']	= $group['ID'];
						$groupsArr['groupName']	= $group['name'];
						$resArr['groups'][]=$groupsArr;
					}
				}

				if($presetQuestions){
					foreach($presetQuestions as $rec){
						$questionsArr['questionId']	= $rec['ID'];
						//$questionsArr['question']	= $rec['name'];
						$questionId=$rec['ID'];
						/*$getIsDefaultQuestion=$this->getdatamodel->getIsDefaultQuestion($questionId,$userId);
						if($getIsDefaultQuestion){
						$questionsArr['isDefault']	= TRUE;	
						}else{
						$questionsArr['isDefault']	= FALSE;	
						}*/
						
					    $questionsArr['question']	= $rec['questionDesc'];						
						$resArr['presetQuestions'][]=$questionsArr;
					}
				}
				$userAddeddQuestions=$this->getdatamodel->getQuestionsByUserId($userId);
				if($userAddeddQuestions){
					foreach($userAddeddQuestions as $rec){
						$questionsArr['questionId']	= $rec['ID'];
						$questionsArr['question']	= $rec['name'];
						//$questionsArr['isDefault']	= TRUE;
						$resArr['presetQuestions'][]=$questionsArr;
					}
				}
				$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
				if($userData){
					$resArr['result']			= 1;
					$resArr['isEmailAlerts']	= $userData[0]['isEmailAlerts'];
					$resArr['isPushAlerts']		= $userData[0]['isPushAlerts'];
					$resArr['defaultGroup']		= $userData[0]['defaultGroup_ID'];				
					
					$questionId					= $userData[0]['defaultQuestion_ID'];
					//$resArr['defaultQuestion']	= $questionId;
					if($questionId){
						$userDefaultQuestion=$this->getdatamodel->getQuestionByID($questionId);					
						$presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];
						if($presetQuestion_Id==0){
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['ID'];	
						}else{
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['presetQuestion_Id'];	
						}
						
						$resArr['userDefaultQsn'] = $userDefaultQuestion[0]['name'];
					}else{
						$resArr['userDefaultQsnId'] = 0;
						$resArr['userDefaultQsn'] = NULL;
					}
				}else{
					$resArr['message']		= "Unable to retrieve user data.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User Push alert settings
	 * @author Rajesh on 07-11-2013
	 */
	function updatePushAlerts_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$isPushAlerts 	= $this->post('isPushAlerts');
				$userData=array('ID'=>$userId, 'isPushAlerts'=>$isPushAlerts);
				$res=$this->setdatamodel->updateUserData($userData);
				if($res){
					$resArr['result']	= 1;
					$resArr['isPushAlerts']	= $isPushAlerts;
					$resArr['message']	= "Push notification settings updated successfully.";
				}else{
					$resArr['message']	= "Push notification settings not updated.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User Default Group settings
	 * @author Rajesh on 07-11-2013
	 */
	function updateDefaultGroup_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$defaultGroup 	= $this->post('defaultGroup');
				$userData=array('ID'=>$userId, 'defaultGroup_ID'=>$defaultGroup);
				$res=$this->setdatamodel->updateUserData($userData);
				if($res){
					$resArr['result']	= 1;
					$resArr['defaultGroup']	= $defaultGroup;
					$resArr['message']	= "Default Group updated successfully.";
				}else{
					$resArr['message']	= "Default Group not updated.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User Email alert settings
	 * @author Rajesh on 07-11-2013
	 */
	function updateEmailAlerts_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$isEmailAlerts 	= $this->post('isEmailAlerts');
				$userData=array('ID'=>$userId, 'isEmailAlerts'=>$isEmailAlerts);
				$res=$this->setdatamodel->updateUserData($userData);
				if($res){
					$resArr['result']	= 1;
					$resArr['isEmailAlerts']	= $isEmailAlerts;
					$resArr['message']	= "Email notification settings updated successfully.";
				}else{
					$resArr['message']	= "Email notification settings not updated.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User Default Question settings
	 * @author Rajesh on 07-11-2013
	 */
	function updateDefaultQuestion_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				
				$defaultQuestionId=$this->post('defaultQuestionId');
				$defaultQuestionName=$this->post('defaultQuestionName');
				$customQuestionName=$this->post('customQuestionName');
				/*if($defaultQuestion){
					$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$defaultQuestion);
					$res=$this->setdatamodel->updateUserData($userData);
				}else{
					if($defaultQuestionName){
						$insertData=array("name"=>$defaultQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
						$defaultQuestion=$insertedId;
						$resArr['defaultQuestion']	= $defaultQuestion;
						$res=$this->setdatamodel->updateUserData($userData);
					}
				}*/
				
			if($defaultQuestionName){				        
				        //$getUserQuestion=$this->pdo->getdatamodel->getUserQuestion($userId);
						$insertData=array("name"=>$defaultQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$defaultQuestionId);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
						$defaultQuestion=$insertedId;
						$resArr['defaultQuestion']	= $defaultQuestion;
						$res=$this->setdatamodel->updateUserData($userData);
					}
					
			if($customQuestionName){
				$insertData=array("name"=>$customQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$defaultQuestionId);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
						$defaultQuestion=$insertedId;
						$resArr['defaultQuestion']	= $defaultQuestion;
						$res=$this->setdatamodel->updateUserData($userData);
				
			}
				

				if($res){
					$resArr['result']	= 1;
					//$resArr['defaultQuestion']	= $insertedId;
					$resArr['message']	= "Default Question updated successfully.";
					$presetQuestions=$this->getdatamodel->getPresetQuestions();
					if($presetQuestions){
						foreach($presetQuestions as $rec){
							$questionsArr['questionId']	= $rec['ID'];
							$questionsArr['question']	= $rec['questionDesc'];
							$resArr['presetQuestions'][]=$questionsArr;
						}
					}
					$userAddeddQuestions=$this->getdatamodel->getQuestionsByUserId($userId);
					if($userAddeddQuestions){
						foreach($userAddeddQuestions as $rec){
							$questionsArr['questionId']	= $rec['ID'];
							$questionsArr['question']	= $rec['name'];
							$resArr['presetQuestions'][]=$questionsArr;
						}
					}
					if($defaultQuestion){
						$userDefaultQuestion=$this->getdatamodel->getQUestionByID($defaultQuestion);
						//$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['ID'];
						$presetQuestion_Id          = $userDefaultQuestion[0]['presetQuestion_Id'];
					    if($presetQuestion_Id==0){
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['ID'];	
						}else{
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['presetQuestion_Id'];	
						}
						$resArr['userDefaultQsn'] = $userDefaultQuestion[0]['name'];
					}
				}else{
					$resArr['message']	= "Default Question not updated.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Delete User Profile picture
	 * @author Rajesh on 13-11-2013
	 * 	 */
	function deleteProfilePicture_get()
	{
		$resArr['result']	= 0;
		$userId				= $this->get('userId');
		$accessToken		= $this->get('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
				if($userData){
					$resArr['result']	= 1;
					unlink(BASEPATH."Uploads/ProfilePictures/".$userData[0]['photo']);
					unlink(BASEPATH."Uploads/ProfilePictures/".$userData[0]['thumb']);
					$updateUserData=array('photo'=>"avatar.png", 'thumb'=>"avatar_thumb.png",'ID'=> $userId);
					$this->setdatamodel->updateUserData($updateUserData);
					$resArr['photo']		= base_url()."Uploads/ProfilePictures/avatar.png";
					$resArr['thumb']		= base_url()."Uploads/ProfilePictures/avatar_thumb.png";

				}else{
					$resArr['message']		= "Unable to retrieve user data.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		//print_r($userArr);
		echo $this->response($resArr, 200);
	}
	/**
	 * To Delete User Secondary Email
	 * @author Rajesh on 14-11-2013
	 */
	function deleteSecEmail_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$email				= $this->post('email');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$email=$this->convert($email);
				$this->setdatamodel->deleteSecondaryEmailByUserID($email, $userId);
				$resArr['result']	= 1;
				$resArr['message']		= "Secondary email deleted.";
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		//print_r($userArr);
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update User settings for Windows phone Only
	 * @author Rajesh on 14-11-2013
	 */
	function updateSettingsForWindows_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$isPushAlerts 	= $this->post('isPushAlerts');
				$isEmailAlerts 	= $this->post('isEmailAlerts');
				$defaultGroup 	= $this->post('defaultGroup');
				$userData=array('ID'=>$userId, 'isPushAlerts'=>$isPushAlerts,
				'isEmailAlerts'=>$isEmailAlerts,'defaultGroup_ID'=>$defaultGroup);
				$res=$this->setdatamodel->updateUserData($userData);
				//$defaultQuestion 	= $this->post('defaultQuestion');
				//$defaultQuestionName= $this->post('defaultQuestionName');
				$defaultQuestionId=$this->post('defaultQuestionId');
				$defaultQuestionName=$this->post('defaultQuestionName');
				$customQuestionName=$this->post('customQuestionName');
			if($defaultQuestionName){				        
				        //$getUserQuestion=$this->pdo->getdatamodel->getUserQuestion($userId);
						$insertData=array("name"=>$defaultQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$defaultQuestionId);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
						$defaultQuestion=$insertedId;
						$resArr['defaultQuestion']	= $defaultQuestion;
						$res=$this->setdatamodel->updateUserData($userData);
					}
					
			if($customQuestionName){
				$insertData=array("name"=>$customQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$defaultQuestionId);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
						$defaultQuestion=$insertedId;
						$resArr['defaultQuestion']	= $defaultQuestion;
						$res=$this->setdatamodel->updateUserData($userData);
				
			}
				$resArr['result']	= 1;
				$resArr['message']	= "Settings updated successfully.";
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Get All Parameters needed for Create Q
	 * @author Rajesh on 26-11-2013
	 **/
	function getCreateQUserParams_post()
	{
		$resArr['result']	= 0;
		$userId			= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$presetQuestions=$this->getdatamodel->getPresetQuestions();
				$userGroups=$this->getdatamodel->getUserGroupsList($userId, "");
				if($userGroups){
					foreach($userGroups as $group){
						$groupsArr['groupId']	= $group['ID'];
						$groupsArr['groupName']	= $group['name'];
						$groupsArr['membersCount']=$this->getdatamodel->getGroupMemnbersCount($group['ID']);
						$resArr['groups'][]=$groupsArr;
					}
				}

				if($presetQuestions){
					foreach($presetQuestions as $rec){
						$questionsArr['questionId']	= $rec['ID'];
						$questionsArr['question']	= $rec['questionDesc'];
						$getIconImage               = $rec['icon'];
						$getImage                   = $rec['image'];
						if($getIconImage){
						$questionsArr['icon']	=base_url()."Uploads/predefinedIcons/".$getIconImage;
						$questionsArr['isDefaultImage']	=0;
						}else{
						$questionsArr['icon']	=base_url()."Uploads/predefinedIcons/default-icon.png";
						$questionsArr['isDefaultImage']	=1;	
						}
						
						if($getImage){
						$questionsArr['image']	=base_url()."Uploads/predefinedIcons/".$getImage;
						$questionsArr['isDefaultImage']	=0;	
						}else{
						$questionsArr['image']	=base_url()."Uploads/predefinedIcons/default-icon.png";	
						$questionsArr['isDefaultImage']	=1;
						}
						
						$opt1                   =$rec['opt1'];
						$opt2                   =$rec['opt2'];
						
						if($opt1){
							$questionsArr['opt1']	=$opt1;	
						}else{
							$questionsArr['opt1']	=NULL;
						}
						
					if($opt2){
							$questionsArr['opt2']	=$opt2;	
						}else{
							$questionsArr['opt2']	=NULL;
						}
						
						
						$resArr['presetQuestions'][]=$questionsArr;
					}
				}
				$userAddeddQuestions=$this->getdatamodel->getQuestionsByUserId($userId);
				if($userAddeddQuestions){
					foreach($userAddeddQuestions as $rec){
						$questionsArr['questionId']	= $rec['ID'];
						$questionsArr['question']	= $rec['name'];
						$questionsArr['icon']	    =base_url()."Uploads/predefinedIcons/default-icon.png";	
						$questionsArr['image']	    =base_url()."Uploads/predefinedIcons/default-icon.png";
						$questionsArr['isDefaultImage']=1;	
						$resArr['presetQuestions'][]=$questionsArr;
					}
				}
				$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
				if($userData){
					$resArr['result']			= 1;
					//$resArr['isEmailAlerts']	= $userData[0]['isEmailAlerts'];
					//$resArr['isPushAlerts']		= $userData[0]['isPushAlerts'];
					$resArr['defaultGroup']		= $userData[0]['defaultGroup_ID'];
					$questionId					= $userData[0]['defaultQuestion_ID'];
					//$resArr['defaultQuestion']	= $questionId;
					if($questionId){
						$userDefaultQuestion=$this->getdatamodel->getQuestionByID($questionId);						
						$presetQuestion_Id= $userDefaultQuestion[0]['presetQuestion_Id'];						
					if($presetQuestion_Id==0){
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['ID'];	
						}else{
						$resArr['userDefaultQsnId'] = $userDefaultQuestion[0]['presetQuestion_Id'];	
						}
						$resArr['userDefaultQsn'] = $userDefaultQuestion[0]['name'];
					}else{
					   $resArr['userDefaultQsnId'] = 0;
					   $resArr['userDefaultQsn'] = NULL;	
					}
				}else{
					$resArr['message']		= "Unable to retrieve user data.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		//print_r($resArr);
		echo $this->response($resArr, 200);
	}
	/**
	 * This function is to Create Q
	 * @author Rajesh on 22-10-2013
	 */
	function createQ_post()
	{
		$resArr['result'] 		= 0;
		$userId					= $this->post('userId');
		$groupId				= $this->post('groupId');
		$accessToken			= $this->post('accessToken');
		$questionId				= $this->post('questionId');
		$questionName			= $this->post('questionName');
		$option1				= $this->post('option1');
		$option2				= $this->post('option2');
		$option3				= $this->post('option3');
		$option4				= $this->post('option4');
		$isNoImg				= $this->post('isNoImg');
		$isNoAns				= $this->post('isNoAns');
		$note					= $this->post('note');
		$isPublic				= $this->post('isPublic');
		$isFbShare				= $this->post('isFbShare');
		$isTwitterShare			= $this->post('isTwitterShare');
		$isPinterestShare		= $this->post('isPinterestShare');
		$latitude				= $this->post('latitude');
		$longitude				= $this->post('longitude');
		$locationName			= $this->post('locationName');
		$accessType				= $this->post('accessType');
		$fbId				    = $this->post('fbId');
		$fbUserAccessToken	    = $this->post('fbUserAccessToken');
		$twitterOAuthToken       = $this->post('twitterOAuthToken');
		$twitterOAuthTokenSecret =$this->post('twitterOAuthTokenSecret');
		//parameters for Qimages
		$isImg1				= $this->post('isImg1');
		$isImg2				= $this->post('isImg2');
		$isImg3				= $this->post('isImg3');
		$isImg4				= $this->post('isImg4');
		$imgCount			= $this->post('imgCount');
		$from = $this->_supportEmail;
		if(!$userId || !isset($groupId) || !$accessToken ||  !isset($questionName)
		|| !isset($isNoImg) || !isset($isNoAns) || !isset($note) || !isset($isFbShare)
		|| !isset($isTwitterShare) || !isset($isPinterestShare) || !isset($latitude) || !isset($longitude)
		|| !isset($locationName) ||  !isset($accessType)){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){

				
				/*if($questionId==0){
					if($questionName){
						$insertData=array("name"=>$questionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>0);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$qsnId=$insertedId;
					}else{
						$qsnId="";
					}
				}else{
					$qsnId=$questionId;
				}*/
				
			if($questionName){
						$insertData=array("name"=>$questionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>0);
						$insertedId=$this->setdatamodel->insertQuestion($insertData);
						$qsnId=$insertedId;
					}
				
				$insertQData=array('user_ID'=>$userId, 'publishType'=>1,'accessType'=>$accessType,'isNoImg'=>$isNoImg,
				'isNoAns'=>$isNoAns,'note'=>$note,'isPublic'=>$accessType,'latitude'=>$latitude,'longitude'=>$longitude,'locationName'=>$locationName,
				'status'=>1,'question_ID'=>$qsnId,'qPalQGroup_ID'=>$groupId);
				$insertedQId=$this->setdatamodel->insertQdata($insertQData);
				//var_dump($insertedQId);die;
				if($insertedQId){
					$resArr['qId']=$insertedQId;
					$resArr['result'] 		= 1;
					$resArr['message']="Q created successfully.";
					if($option1){
						$insertOptionData=array("optionName"=>$option1,"qPalQ_ID"=>$insertedQId);
						$res=$this->setdatamodel->insertOptions($insertOptionData);
						//var_dump($res);
					}
					if($option2){
						$insertOptionData=array("optionName"=>$option2,"qPalQ_ID"=>$insertedQId);
						$this->setdatamodel->insertOptions($insertOptionData);
					}
					if($option3){
						$insertOptionData=array("optionName"=>$option3,"qPalQ_ID"=>$insertedQId);
						$this->setdatamodel->insertOptions($insertOptionData);
					}
					if($option4){
						$insertOptionData=array("optionName"=>$option4,"qPalQ_ID"=>$insertedQId);
						$this->setdatamodel->insertOptions($insertOptionData);
					}
					
					//changes done by Asha on 3-1-2014 to use the qImages webservice in Create Q webservice
					
					$qId=$resArr['qId'];
					$res=$this->getdatamodel->getQOptions($qId);
				for ($i = 1; $i<=$imgCount; $i++){

			switch ($i){
				case 1:
					if($isImg1){
						if($_FILES['qImage1']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage1','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = NULL;
						$qThumbName = NULL;
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 2:
					if($isImg2){
						if($_FILES['qImage2']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage2','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[1]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = NULL;
						$qThumbName = NULL;
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[1]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 3:
					if($isImg3){
						if($_FILES['qImage3']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage3','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[2]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = NULL;
						$qThumbName = NULL;
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[2]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 4:
					if($isImg4){
						if($_FILES['qImage4']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage4','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[3]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = NULL;
						$qThumbName = NULL;
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[3]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
			}
		}
					
					$groupMembersData=$this->getdatamodel->getGroupMembersDetails($groupId,0);
					$nonRegGroupMembersData=$this->getdatamodel->getnonRegGroupMembersDetails($groupId);
					$nonRegFbMembers=$this->getdatamodel->getnonRegFBGroupMembersDetails($groupId);
					if($groupMembersData){
						foreach($groupMembersData as $rec){
							//karthik - 12/12/2013 - changed by karthik to fix a  BUG .
								
							// BUG -  the Q is  being added  to the RECEIVED Q table of the  sender which is wrong

							if ($userId == $rec['ID'])
							{
								//do nothing bcoz the sender of the Q should not be notified or entry added to RECIEVED Q
									
							}
							else
							{
								$recievedQData=array("user_ID"=>$rec['ID'],"qPalQ_ID"=>$insertedQId);
								$this->setdatamodel->insertRecievedQ($recievedQData);
                                
								//insert user Q Badges 
								//@Author Asha on 3-2-2014 
								$userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$insertedQId,'isNew'=>1);
                                $this->setdatamodel->insertQBadges($userQBagesData);
								//To Send Push to Group Member
								//@author Rajesh on 27-11-2013
								if($rec['isPushAlerts']==1){
									$data = new StdClass;
									$data->deviceToken = $rec['pushId'];
									$data->message = "You have a new Q";
									$data->typeID = "1";
					                $data->param = $insertedQId;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}


							}
						}
					}
					if($nonRegGroupMembersData){

						foreach($nonRegGroupMembersData as $rec2){
							$email=$rec2['email'];
							$insertData=array("qPalQ_ID"=>$insertedQId,'email'=>$email);
							$this->setdatamodel->insertNonRecievedQ($insertData);

						}
					}
					if($nonRegFbMembers){
						foreach($nonRegFbMembers as $rec3){
							$fbId=$rec3['FBID'];
							$insertData=array("FBID"=>$fbId,"qPalQ_ID"=>$insertedQId);
							$this->setdatamodel->insertNonRecievedFbq($insertData);
						}
					}
					
					//create room for chating 
					//@Author Asha on 21-2-2014
					$fetchPrivateGroupId=$this->getdatamodel->fetchPrivateGroupId($qId);
					$privateGropId=$fetchPrivateGroupId[0]['qPalQGroup_ID'];
					
					if($privateGropId!=0){
						
						$createRoomName="qPalQ_".$qId;
						$this->setdatamodel->updateQRoomName($qId,$createRoomName);
						
					}
					
					//to send emails if there is a group
					
					if($groupId){
						//echo $privateGropId;die;
					$emailArr=array();
					$namesArr=array();
					$groupData=$this->getdatamodel->getGroupDetailsById($privateGropId);
					$groupName=$groupData[0]['name'];
					$regUsersData=$this->getdatamodel->getGroupMembersDetails($privateGropId,1);
					$nonRegUsersData=$this->getdatamodel->getnonRegGroupMembersDetails($privateGropId);
					$nonRegFBUsersData=$this->getdatamodel->getnonRegFBGroupMembersDetails($privateGropId);
					$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
			        $qcreatorUserId= $getQCreatorId[0]['user_ID'];
			        $getMemberData= $this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
				    $qCreatorName=$getMemberData[0]['displayName'];
			 
					if($regUsersData){
						foreach($regUsersData as $rec1){
							if($rec1['isEmailAlerts']==1){
								$emailArr[]=$this->convert($rec1['email']);
							}
							$namesArr[]=$rec1['firstName'];
						}
					}
					if($nonRegUsersData){
						foreach($nonRegUsersData as $rec2){
							$emailArr[]=$this->convert($rec2['email']);
							$namesArr[]=$rec2['name'];
						}
					}
					if($nonRegFBUsersData){
						foreach($nonRegFBUsersData as $rec3){
							$namesArr[]=$rec3['name'];
						}
					}
                    //echo sizeof($emailArr);
					for($i=0;$i<sizeof($emailArr);$i++){
						$msgStr="";
						$email=	$emailArr[$i];
						$mailData['userName'] 	= $namesArr[$i];
						$namesArr1=$namesArr;
						unset($namesArr1[$i]);
						//print_r($namesArr1);
						$newarr=array();
						foreach($namesArr1 as $name){
							$newarr[]=$name;
						}
						//print_r($newarr);
						for($j=0;$j<sizeof($newarr);$j++){
							if($j==0){
								$msgStr.=$newarr[$j];
							}else if($j<=sizeof($newarr)-2){
								$msgStr.=", ".$newarr[$j];
							}else{
								$msgStr.=" and ".$newarr[$j];
							}
						}
						//echo $msgStr."<br/>";
						$mailData['qCreatorName']= $qCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['questionName']=$questionName;
						$mailData['option1']=$option1;
						$mailData['qId']=$qId;
						$qImageData=$this->getdatamodel->getQImages($qId);
						if($qImageData){
						$imgName=$qImageData[0]['thumb'];
						if($imgName){
								$mailData['thumb']=base_url()."Uploads/QImages/$imgName";
							}else{
								$mailData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							}
						}
						$from = $this->_supportEmail;
						//getting the mail content
						$mailContet = $this->templatemodel->createQTemplate($mailData);
						$subject = "Q Alert";
						// call mailer function to send mail.
					
						 $data = new StdClass;
                                         $data->from = $from;
                                         $data->to = $email;
                                         $data->subject = $subject;
                                         $data->body = $mailContet;
                                         $message = json_encode($data);
                                         $this->messagequeue->addMessageToMAILQueue($message);

					$status = true;

					}
						
				}
					
					
					
					//end of creting room for chating
					
					
					//composite image for twitter share and facebook share
					//@Author Asha on 29-1-2014
					
					if($isFbShare==1 || $isTwitterShare==1 || $isPinterestShare==1){
						
					$countOfImages=$this->getdatamodel->countOfImages($qId);
			
			        if($countOfImages==0 || $countOfImages==1){//only one image or if no image
				    $numberOfImages = 1;
				     $x = 200;
                     $y = 200;
                     $background = imagecreatetruecolor($x, $y);
                     $color = imagecolorallocate($background, 255, 255, 255);//add background color
                     $outputImage = $background;
                     // fill entire image
                    imagefill($background, 0, 0, $color);
				    $getNotNullImages=$this->getdatamodel->getNotNullImages($qId);
				
			        if($getNotNullImages){
                      $getimage=$getNotNullImages[0]['thumb'];
                      $imageUrl=base_url()."Uploads/QImages/$getimage";
                      $image=imagecreatefromjpeg($imageUrl);	
                   }else{
                      $imageUrl=base_url()."Uploads/QImages/default_thumb.jpg";
                      $image=imagecreatefromjpeg($imageUrl);	
                }
                
                $qImageData=$this->getdatamodel->getQImages($qId);
                $i=1;
                
			    foreach($qImageData as $qImageData){
                $optionName[$i]=$qImageData['optionName'];	
                $font = 6;
                $font_width = ImageFontWidth($font);
                $font_height = ImageFontHeight($font);
                $text_width = $font_width * strlen($optionName[$i]);
                $position_center = ceil(($x - $text_width));
                $text_height = $font_height;
                $position_middle = ceil(($y - $text_height));
             
                if($i==1){		   
		        $text_color = imagecolorallocate($image, 255, 255, 255);
                imagestring($image, $font, 0, 0, $optionName[$i], $text_color);
		       }elseif($i==2){
		     	$text_color1 = imagecolorallocate($image, 255, 255, 255);
                imagestring($image,$font, $position_center, 0, $optionName[$i], $text_color1);
		       }elseif($i==3){		   
		     	$text_color2 = imagecolorallocate($image, 255, 255, 255);
                imagestring($image, $font, $position_center,$position_middle,  $optionName[$i], $text_color2);
		       }elseif($i==4){		   	
		     	$text_color3 = imagecolorallocate($image, 255, 255, 255);
               imagestring($image, $font,0, $position_middle, $optionName[$i], $text_color3);
		      }
             
             $i++;
             }
             imagecopymerge($outputImage,$image,0,0,0,0, $x, $y,100);   
			}else{
			$numberOfImages = 4;
            $x = 200;
            $y = 200;
            $background = imagecreatetruecolor($x*2, $y*2);
            $color = imagecolorallocate($background, 255, 255, 255);
            // fill entire image
            imagefill($background, 0, 0, $color);
            $qImageData=$this->getdatamodel->getQImages($qId);
            $i=1;
            foreach($qImageData as $qImageData){
            	
            $imgName[$i]=$qImageData['thumb'];
            $optionName[$i]=$qImageData['optionName'];
            if($imgName[$i]){
			$Url[$i]=base_url()."Uploads/QImages/$imgName[$i]";
			$image[$i] = imagecreatefromjpeg($Url[$i]);
			}else{
			$Url[$i]=base_url()."Uploads/QImages/default.png";
			$image[$i] = imagecreatefrompng($Url[$i]);			
		   }
		   $outputImage = $background;
		   
		   if($i==1){
		   
		   $text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   imagestring($image[1], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   imagecopymerge($outputImage,$image[$i],0,0,0,0, $x, $y,100);
		   }elseif($i==2){
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);		   
		   	imagestring($image[$i], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,0,0,0, $x, $y,100);
		   }elseif($i==3){		   
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],0,$y,0,0, $x, $y,100);
		   }elseif($i==4){		   	
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,$y,0,0, $x, $y,100);
		   }
		   
            $i++;           
            }
			}
						
			$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];		
		    $upldFileName = $newFileName;
           //$ourFileName ="/home/workstation/Qpals/qpals/Uploads/compositeImages/$upldFileName.jpeg";
            $ourFileName   =FCPATH."Uploads/compositeImages/$upldFileName.jpeg";
            imagejpeg($outputImage, $ourFileName );			
						
	}
					
			    //Social media sharing		
				//check fb share is true
					if($isFbShare==1){
						
					 $facebookConfig=array('appId'=>$this->config->item('appId'),'secret'=>$this->config->item('secret'));
			         $fb = new Facebook($facebookConfig);
			         
			         //To get the question name
			         $getFbShare=$this->getdatamodel->getFbShare($userId,$resArr['qId']);
			         $note=$getFbShare[0]['note'];
					foreach($getFbShare as $question){
                      $quesId=$question['question_ID'];
                    }
                    
				     //question name to share
                     $getQQuestion=$this->getdatamodel->getQQuestion($quesId);
                      foreach($getQQuestion as $queName){            	
            	         $questionName=$queName['name'];
            	      }
            	      
            	      
            	    //to fetch a Qimage			
			          $qImageData=$this->getdatamodel->getQImages($resArr['qId']);
			          if($qImageData){
			          $ourFileName1 =base_url()."Uploads/compositeImages/$upldFileName.jpeg";
			          $imgName=$ourFileName1;
			             if($imgName){
				        $picture=$imgName;
				      }else{
				      $picture=base_url()."Uploads/QImages/default_thumb.png";
				     }
			   }else{
				$picture=base_url()."Uploads/QImages/default_thumb.png";
			 }	
			 $link=base_url()."qwall/viewQ/".$resArr['qId']."/3";//3 is for facebook source type
			 $params = array(
             "access_token" => $fbUserAccessToken, 
             "message" => $questionName,
             "link" => $link,
             "picture" =>$picture,
             "name" => "",
             "caption" => "",
             "description" => $note);
			//var_dump($params);die; 
			 
				try {
			 	//post a feed to facebook
			 	$ret = $fb->api('/'.$fbId.'/feed', 'POST', $params);
			 	
			 	if (array_key_exists("id",$ret))
			 	{
			 		//sucessfully posted to Wall
			 		$this->setdatamodel->updateFBShare($resArr['qId'],$isFBShare=1);
			 		$resArr['result']	= 1;			 		
			 		$resArr['message']	= "Sucessfully posted to facebook";
			 	}
			 	else
			 	{
			 		//do nothing
			 		$this->setdatamodel->updateFBShare($resArr['qId'],$isFBShare=0);
			 	}
			 	
			 } catch(Exception $e) {
			  	
			 	$resArr['message']=$e->getMessage();
			 }
						
		}//fbshare ending
					

		if($isTwitterShare==1){	          
			$_SESSION['usertoken']=$this->post('twitterOAuthToken');
            $_SESSION['usertokensecret']=$this->post('twitterOAuthTokenSecret');
		    include(BASEPATH.'application/libraries/tmhOAuthExample.php');
		    $tmhOAuth = new tmhOAuthExample();
		    
		    $getTwitterShare=$this->getdatamodel->getTwitterShare($userId,$resArr['qId']);
		    $note=$getTwitterShare[0]['note'];
		    //to fetch Question id
            foreach($getTwitterShare as $question){
            $quesId=$question['question_ID'];
            }
            
            //question name to share
            $getQQuestion=$this->getdatamodel->getQQuestion($quesId);
            
            foreach($getQQuestion as $queName){
            	
            	$questionName=$queName['name'];
            	
            }
            
            //to fetch a Qimage	
			$pathQImage=$this->config->item('qImageUploadPath');
			//echo $pathQImage;		
			$qImageData=$this->getdatamodel->getQImages($resArr['qId']);
			$link=base_url()."qwall/viewQ/".$resArr['qId']."/4";//social sharing using twitter
			
			if($qImageData){				
			 $imgName=$qImageData[0]['thumb'];
			
			
				 if($imgName){
				 	
						$image=$ourFileName;
					}else{
						
						$image=$pathQImage."default_thumb.png";
					}
			  }else{			  
				$image=$pathQImage."default_thumb.png";
			  }	
			  
			 $name  = basename($image);
           $status = $questionName;
          // $twitter_content = $questionName.' '.base_url().'qwall/viewQ/'.$resArr['qId'].'/4';
           //$tweet = preg_replace("/([w]+://[w-?&;#~=./@]+[w/])/", "<a target="" href="$link">$link</a>", $twitter_content); 
           $code = $tmhOAuth->user_request(array(           
           'method' => 'POST',
           'url' => $tmhOAuth->url('1.1/statuses/update_with_media'),
           'params' => array(
            
            'media[]'  => "@{$image};filename={$name}",
            
            'status'   => $status.'-'.$link,
             ),
            'multipart' => true,
             
            ));
           //var_dump($code);die;
			$this->setdatamodel->updateTwitterShare($resArr['qId'],$isTwitterShare=1);
		}//ending of twitter share
		
		if($isPinterestShare==1){
			$this->setdatamodel->updatePinterestShare($resArr['qId'],$isPinterestShare=1);
			$resArr['pinterestUrl']=base_url()."qwall/viewQ/".$resArr['qId']."/5";
			$resArr['questionName']=$questionName;
			 $qImageData=$this->getdatamodel->getQImages($resArr['qId']);
			          if($qImageData){
			          $ourFileName1 =base_url()."Uploads/compositeImages/$upldFileName.jpeg";
			          $imgName=$ourFileName1;
			             if($imgName){
				        $picture=$imgName;
				      }else{
				      $picture=base_url()."Uploads/QImages/default_thumb.png";
				     }
			   }else{
				$picture=base_url()."Uploads/QImages/default_thumb.png";
			 }	
			 
			 $resArr['compositeImage']=$picture;

		}//end of pintrest
	}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	/**
	 * To Update Q images in Options table
	 *@author Rajesh on 27-11-2013
	 */
	function uploadQImages_post()
	{
		$resArr['result']		= 1;
		$qId				= $this->post('qId');
		$isImg1				= $this->post('isImg1');
		$isImg2				= $this->post('isImg2');
		$isImg3				= $this->post('isImg3');
		$isImg4				= $this->post('isImg4');
		$imgCount			= $this->post('imgCount');
		//var_dump($res);
		$res=$this->getdatamodel->getQOptions($qId);
		//print_r($res);die;
		for ($i = 1; $i<=$imgCount; $i++){

			switch ($i){
				case 1:
					if($isImg1){
						if($_FILES['qImage1']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage1','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = "default.png";
						$qThumbName = "default_thumb.png";
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 2:
					if($isImg2){
						if($_FILES['qImage2']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage2','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[1]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = "default.png";
						$qThumbName = "default_thumb.png";
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[1]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 3:
					if($isImg3){
						if($_FILES['qImage3']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage3','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[2]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = "default.png";
						$qThumbName = "default_thumb.png";
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[2]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
				case 4:
					if($isImg4){
						if($_FILES['qImage4']['name']){
							$qImgResponse = $this->setdatamodel->uploadImage($_FILES,'qImage4','QImages');
							if($qImgResponse){
								$qImgName = $qImgResponse['imgName'];
								$qThumbName = $qImgResponse['thumbName'];
								$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[3]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
								if($res){
									$this->setdatamodel->updateOption($optionData);
								}else{
									$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
									$this->setdatamodel->insertOptions($insertOptionData);
								}

							}
						}
					}else{
						$qImgName = "default.png";
						$qThumbName = "default_thumb.png";
						$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[3]['ID'], 'thumb'=>$qThumbName ,'photo'=>$qImgName);
						if($res){
							$this->setdatamodel->updateOption($optionData);
						}else{
							$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$qThumbName,'photo'=>$qImgName);
							$this->setdatamodel->insertOptions($insertOptionData);
						}
					}
					break;
			}
		}
		//print_r($resArr);die;
		echo $this->response($resArr, 200);
	}
	/**
	 * To get User Q's
	 * @author Rajesh on 28-11-2013
	 */
	function myQs_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$qType				= $this->post('qType');
		$offset				= $this->post('offset');
		$searchText 		= $this->post('searchText');
		
	 $getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$user_Id=$row['ID'];//Qpals login user Id to check valid access token or not
		}
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				if($qType==0){//private Qs
					
					$res=$this->getdatamodel->getPrivateQs($userId,$searchText,$offset);
					//$resArr['totCount']=$this->getdatamodel->getTotCountOfQs($userId);
				}else if($qType==1){//I created
					
					$res=$this->getdatamodel->getMyQs($userId,$searchText,$offset);
					//$resArr['totCount']=$this->getdatamodel->getTotCountOfMyQs($userId);
				}else if($qType==2){//received Q
					
					$res=$this->getdatamodel->getrecievedQs($userId,$offset);
					//$resArr['totCount']=$this->getdatamodel->getTotCountOfRecievedQs($userId);
				}else if($qType==3){//I replied
					
					$res=$this->getdatamodel->getrepliedQs($userId,$searchText,$offset);
					//$resArr['totCount']=$this->getdatamodel->getTotCountOfRecievedQs($userId);
				}elseif($qType==4){
					$res=$this->getdatamodel->getPublicQs($searchText);
				}elseif($qType==5){//liked Qs
					$res=$this->getdatamodel->getFavorites($userId,$searchText,$offset);
				}elseif($qType==6){
				   $res=$this->getdatamodel->getMyQFollowed($userId,$searchText,$offset);
				}
				
				$resArr['totCount']=$this->getdatamodel->getCountOfPrivateQs($userId);
				$resArr['iCreated']=$this->getdatamodel->getTotCountOfMyQs($userId);
				$resArr['iRecieved']=$this->getdatamodel->getTotCountOfRecievedQs($userId);
				$resArr['iReplied']=$this->getdatamodel->getTotCountOfRepliedQs($userId);
				$resArr['publicQCount']=$this->getdatamodel->countOfPublicQs();
				$resArr['favouritesCount']=$this->getdatamodel->getCountOfFavourites($userId);
				$resArr['followedCount']=$this->getdatamodel->getCountOfMyQFollowed($userId);
				
				if($qType==0){//private Qs
				 if($searchText!=""){
				 $resArr['totalNO']=$this->getdatamodel->getCountOfPrivateQsNum($userId,$searchText,$offset);
				 }else{
				 $resArr['totalNO']=$this->getdatamodel->getCountOfPrivateQs($userId);	
				 }	
				}else if($qType==1){//I created
				 if($searchText!=""){
			     $resArr['totalNO']=$this->getdatamodel->getCountOfMyQsNum($userId,$searchText,$offset);
				 }else{
				 $resArr['totalNO']=$this->getdatamodel->getTotCountOfMyQs($userId);	
				 }
				}else if($qType==2){//received Q
				  //do nothing
				}else if($qType==3){//I replied
				  if($searchText!=""){
				  $resArr['totalNO']=$this->getdatamodel->getCountOfRepliedQsNum($userId,$searchText,$offset);
				  }else{
				  $resArr['totalNO']=$this->getdatamodel->getTotCountOfRepliedQs($userId);	
				  }
				}elseif($qType==4){
				  $resArr['totalNO']=$this->getdatamodel->countOfPublicQs();
				}elseif($qType==5){//liked Qs
				  if($searchText!=""){
				  $resArr['totalNO']=$this->getdatamodel->getCountofFavoritesNum($userId,$searchText,$offset);
				  }else{
				  $resArr['totalNO']=$this->getdatamodel->getCountOfFavourites($userId);	
				  }
				}elseif($qType==6){
				  if($searchText!=""){
				  $resArr['totalNO']=$this->getdatamodel->getCountofMyQFollowedNum($userId,$searchText,$offset);
				  }else{
				  $resArr['totalNO']=$this->getdatamodel->getCountOfMyQFollowed($userId);	
				  }
				}
				
				if($res){
					$resArr['result']	= 1;
					foreach($res as $rec){
						
						$qId=$rec['ID'];
						$qArr['qId']=$qId;
						$qArr['qsn']=$rec['name'];
						//$qArr['responseCount']=0;
						$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $qArr['responseCount']=$result;
						}else{
							$qArr['responseCount']=0;
						}
						
						$time1 = $rec['timeStamp'];
						//$time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					    //$time2 = date('Y-m-d H:i:s');
					    //echo $time1;die;
					    //$qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					    $qArr['timestamp']= $time1;
						$userId=$rec['user_ID'];
						
						//get user Q badges
						//@Author Asha on 3-2-2014
						
						$getUserQBadges=$this->getdatamodel->getUserQBadge($user_Id,$qId);
						if($getUserQBadges){
						
						$qArr['isNew']		=$getUserQBadges[0]['isNew'];
						}else{
						
						$qArr['isNew']		=0;
						}
						
						$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$qArr['uname']=$qCreatorDetails[0]['firstName'];
						}else{
							$qArr['uname']="";
						}
						$qImageData=$this->getdatamodel->getQImages($qId);
						$qArr['qImages']="";
						if($qImageData){
							//$imgName=$qImageData[0]['thumb'];
							/*if($imgName){
								$qArr['thumb']=base_url()."Uploads/QImages/$imgName";
							}else{
								$qArr['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							}*/
																				 
							foreach($qImageData as $rows){								
								$imgName=$rows['thumb'];
								if($imgName){							
								$optionData['thumb']=base_url()."Uploads/QImages/".$rows['thumb'];
								$optionData['isDefaultImage']=FALSE;
								}else{
								$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
								$optionData['isDefaultImage']=TRUE;	
								}
								
								$qArr['qImages'][]    =$optionData;
							}
							
						}else{
							$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							$optionData['isDefaultImage']=TRUE;
							$qArr['qImages'][]    =$optionData;
						}
						
						
						$resArr['qs'][]=$qArr;
						
					}
					
					
		//			    foreach ($resArr['qs'] as $key => $row) {
		//                 $isNew[$key]  	= $row['isNew'];
		 //                $timeStamp[$key] = $row['timestamp'];
	          //          }
	                   
	            //        @array_multisort($isNew, SORT_DESC,$timeStamp,SORT_DESC,$resArr['qs']);
	                   
	                   // print_r($resArr['qs']);die;
					

				}else{
					$resArr['message']="No Q's available.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	function qPalImages_post()
	{
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		if(!$userId || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$res=$this->getdatamodel->getQpalImages();
				//var_dump($res);
				if($res){
					$resArr['result']	= 1;
					foreach($res as $rec){
						$thumb=$rec['thumb'];
						$photo=$rec['photo'];
						$imgArr['thumb']=base_url()."Uploads/QpalImages/$thumb";
						$imgArr['photo']=base_url()."Uploads/QpalImages/$photo";
						$resArr['images'][]=$imgArr;
					}
				}else{
					$resArr['result']	= 0;
					$resArr['message']	= "No Qpal Images exists.";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		echo $this->response($resArr, 200);
	}
	function mailTest_get()
	{
		$from="testcyt@cytrion.com";
		$email="rajesh.rudraraju@cytrion.com";
		$subject="Test mail";
		$mailContet="This is test mail";
		//$status = mailer($from, $email, $subject, $mailContet);
		try{
			//$status = mail($email,$subject, $mailContet, "From:".$from);
//			$status = mailer($from, $email, $subject, $mailContet);
			 $data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

			$status = true;
			if($status){
				echo "Mail sent Successfully to : $email";
			}else{
				echo "Mail sending failed.";
			}
		}
		catch(Exception $e)
		{
			echo $e->getMessage();
		}

	}
	function getEmail_get()
	{
		$userId=$this->get('userId');
		$userDetails=$this->getdatamodel->getSecondaryEmails($userId);
		echo $email=$this->convert($userDetails[0]['email']);
	}
	function checkMailTemplate_get()
	{
		$mailData['userName']=trim("Rajesh");
		$mailData['email']="rajesh.rudraraju@cytrion.com";
		$mailData['accessCode']="141sfsadfs4234";
		$res=$this->templatemodel->forgotPasswordMailTemplate($mailData);
		echo $res;
	}
	function userLogin_get()
	{
		$email=$this->convert("rajesh.rudraraju+sec1@cytrion.com");
		$password="qwerty";
		$res=$this->getdatamodel->login($email,$password);
		var_dump($res);
	}



	//checking for valid token test
	function checktoken_post(){
		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
		if($isValidAccessToken==1){
			$resArr['message']	= "access token expired";
		}elseif($isValidAccessToken==2){
			$resArr['message']	= "is valid token";
		}else{
			$resArr['message']	= "invalid token";
		}
		echo $this->response($resArr, 200);
	}



	/**
	 * This function is to update Facebook Access Token
	 * @author Asha on 19-12-2013
	 */

	function updateFbAccessToken_post(){

		$resArr['result']	= 0;
		$userId				= $this->post('userId');
		$accessToken		= $this->post('accessToken');
		$fbId				= $this->post('fbId');
		$fbUserAccessToken	= $this->post('fbUserAccessToken');
		if(!$fbId || !$fbUserAccessToken || !$accessToken || !$userId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$checkFbUser=$this->getdatamodel->checkUserByFBID ($fbId);
				if($checkFbUser){
					$updateUserData=array('FBID'=>$fbId,'fbUserAccessToken'=>$fbUserAccessToken);
					$this->setdatamodel->updateUserFbMapping($updateUserData);
					$resArr['result']	= 1;
					$resArr['message']	= "updated Suceesfully";
				}else{
					$resArr['message']	= "invalid facebook Id";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
				
		}
		echo $this->response($resArr, 200);

	}
	
	
	/**
	 * This function is to divide the Qtype 
	 * @Author Asha on 06-01-2014
	 */

	
	function getQtype_post(){
		
		$resArr['result']	= 0;
		$qId=$this->post('qId');
		
		$getQOptions=$this->getdatamodel->getQOptions($qId);
		
		if(!empty($getQOptions)){
		$getOptionCount=$this->getdatamodel->qpalsCountOptions($qId);
		$getImgCount=$this->getdatamodel->qpalsCountImages($qId);
		
		
	    foreach($getOptionCount as $row){			
		 $optionCountGet=$row['optionName'];//count of options				 
	    }
	    foreach($getImgCount as $row){			
		$imgCountGet=$row['thumb'];//count of options				 
	    }
	   $imgCount=$imgCountGet;
	   $optionCount=$optionCountGet;
	   //echo $optionCount;die;
	  //categorise  Qtype 1
	  if(!$imgCount==0 && $optionCount==0){
	  	$resArr['qType']=1;
	   }elseif($imgCount==1 && $optionCount==0){
	  	$resArr['qType']=1;
	   }elseif($imgCount==2 && $optionCount==0){
	  	$resArr['qType']=1;
	   }elseif($imgCount==3 && $optionCount==0){
	  	$resArr['qType']=1;
	   }elseif($imgCount==4 && $optionCount==0){
	  	$resArr['qType']=1;
	   }elseif($imgCount==0 && $optionCount==2){//categorise Qtype 2
	  	$resArr['qType']=2;
	   }elseif($imgCount==0 && $optionCount==3){
	   	$resArr['qType']=2;
	   }elseif($imgCount==0 && $optionCount==4){
	   	$resArr['qType']=2;
	   }elseif($imgCount==1 && $optionCount==2){
	   	$resArr['qType']=2;
	   }elseif($imgCount==1 && $optionCount==3){
	   	$resArr['qType']=2;
	   }elseif($imgCount==1 && $optionCount==4){
	   	$resArr['qType']=2;
	   }elseif($imgCount==2 && $optionCount==2){//categorize Qtype 3
	   	$resArr['qType']=3;
	   }elseif($imgCount==2 && $optionCount==3){
	   	$resArr['qType']=3;
	   }elseif($imgCount==2 && $optionCount==4){
	   	$resArr['qType']=3;
	   }elseif($imgCount==3 && $optionCount==3){//categorize Qtype 4
	   	$resArr['qType']=4;
	   }elseif($imgCount==3 && $optionCount==4){
	   	$resArr['qType']=4;
	   }elseif($imgCount==4 && $optionCount==4){//categorize Qtype 5
	   	$resArr['qType']=5;
	   }
	}else{
		$resArr['qType']=1;
	}
	    	
	  echo $this->response($resArr, 200);	
	}
	
	
	/*
	 * This function is to fetch Q data
	 * @Author Asha on 6-1-2014
	 */
	
	function fetchQData_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$accessToken		=$this->post('accessToken');
		
		//get UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		}else{
			$userId='';
		}
		
		if(!$qId  || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
			 $resArr['result']	= 1;
			 $getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
			 $qcreatorUserId= $getQCreatorId[0]['user_ID'];
			 $qcreatorRoomName=$getQCreatorId[0]['roomName'];
			 $notes=$getQCreatorId[0]['note'];
			 $isPublic=$getQCreatorId[0]['isPublic'];
			 $isFBShare=$getQCreatorId[0]['isFBShare'];
			 $isTwitterShare=$getQCreatorId[0]['isTwitterShare'];
			 $isPintrestShare=$getQCreatorId[0]['isPintrestShare'];
			 //to display room name only for private group users
			  
			  $getPrivateGroupMembers=$this->getdatamodel->getPrivateGroupMembers($qId);
			 
			  if($getPrivateGroupMembers){
			  foreach($getPrivateGroupMembers as $rec){
			 	
			 	$groupMembers[]=$rec['user_ID'];
			 	
			 }
		
			 
			 if (in_array($userId, $groupMembers)){
			 	//show room name
			 	$chatData['host']=$this->config->item('XMPP_SERVER_HOST');
			    $chatData['port']=$this->config->item('XMPP_SERVER_PORT');
			    $chatData['conferenceHost']=$this->config->item('XMPP_CONFERENCE_HOST');
			 	$chatData['roomName']=$qcreatorRoomName;
			 	$userDataForChat  =$this->getdatamodel->getUserDetailsByUserID($userId);
			 	
			    $chatData['jabberdUserName']=$userId;
			   if($userDataForChat){
			   	$chatData['jabberdPassword']=$userDataForChat[0]['password'];			   	
			   	$chatData['NickName']=$userDataForChat[0]['displayName'];	
			   } 

			   if($getPrivateGroupMembers){
			   	foreach($getPrivateGroupMembers as $rec){
			   	  $groupMemberData =$this->getdatamodel->getUserDetailsByUserID($rec['user_ID']);
			   	  $memberData['memberId']=$rec['user_ID'];
			   	  $memberData['memberThumb']= base_url()."Uploads/ProfilePictures/".$groupMemberData[0]['thumb'];
			   	  $chatData['groupMembers'][]    = $memberData;	
			   	}
			  }
			  
			   $resData['chat'][]    = $chatData;
			 }
			 
			 if (in_array($userId, $groupMembers)){
			 	$resData['isPrivateTouser']=TRUE;
			 }else{
			 	$resData['isPrivateTouser']=FALSE;
			 }
			 
			 
			 
			 
		}else{
			 //	$resData['chat'][]=NULL;
				$resData['chat'] =NULL;
                $resData['isPrivateTouser']=FALSE;
			 }
			 
			  
			
			if($isPublic==1 || $isFBShare==1 || $isTwitterShare==1 || $isPintrestShare==1){
			 	$resData['isSocialComments']=TRUE;
			 }else{
			 	$resData['isSocialComments']=FALSE;
			 }
			 
			 
			 
			 $getFavouriteStatus=$this->getdatamodel->getFavouriteStatus($qId,$userId);
			 if($getFavouriteStatus){
			 $resData['likeStatus']	                = 1;	
			 }else{
			 $resData['likeStatus']	                = 0;	
			 }
			 
			 if($notes){
			 $resData['notes']	                = $notes;		
			 }else{
			  $resData['notes']	                = '';	
			 }
			 
			 
			 $updateUserQBadges=$this->setdatamodel->updateUserQBadges($qId,$userId);
			 $userData      =$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);	 
			 
               if($userData){
					$resArr['result']		        = 1;
					$resData['qId']	                = $qId;					
					$resData['qCreatorDisplayName'] = $userData[0]['displayName'];
					$resData['qCreatorProfileImageThumb']= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
					//get Qdetails
					$getQdatails=$this->getdatamodel->getQdetails($qId);
					$resData['questionDescription']	= $getQdatails[0]['name'];
					//get Age of Q
					$resData['timeStamp']          = $getQdatails[0]['timeStamp'];
					//$time2                          = date('Y-m-d H:i:s');
					//$qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					//$resData['qAge']	            = $qAge;
					$resData['qCreatorId']	        = $qcreatorUserId;
					
					
										
					//get Q type
			       $getQOptions=$this->getdatamodel->getQOptions($qId);//check where Qid is present or not
		           $getOptionCount=$this->getdatamodel->qpalsCountOptions($qId);
		           $getImgCount=$this->getdatamodel->qpalsCountImages($qId);
		           if(!$getQOptions){
		           	//do nothing
		           	$resArr['message']		= "There are no options for the Q.";
		           	//$optionData['optionId']		= NULL;
		           	$resData['options']    =NULL;
		           }else{
	               $oCount = 0;
	               $getAggregateVotes = NULL;
			       foreach($getQOptions as $row){//qOptions
				    
			 	    $optionData['optionId']=$row['ID'];			
					$optionName=$row['optionName'];
					if($optionName){
					$optionData['option']  =$row['optionName'];	
					}else{
					$optionData['option']  ='';	
					}	
			        $imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
					if($imgNamethumb){
					$optionData['thumb']=base_url()."Uploads/QImages/$imgNamethumb";
					$optionData['image']=base_url()."Uploads/QImages/$imgNamePhoto";
					$optionData['isDefaultImage']=FALSE;
					}else{
					$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
					$optionData['image']=base_url()."Uploads/QImages/default.png";
					$optionData['isDefaultImage']=TRUE;	
					}
					
					$getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					if($getCountQVotesOptions[0]['qCount']>0){
					$optionData['isVoted']	     = TRUE;	
					}else{
					$optionData['isVoted']	     = FALSE;
					}
					
					if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					if (!$getAggregateVotes)
					{
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$optionData['resPerc'] = $aggResult;	
					}
					else
					{
					//now get the individual options sum
					$optionsCount = 4; //default number of options to a Q 
					if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}	
					
					// Calculate the result in % for the option
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					
					
					$optionData['resPerc'] = $aggResult;
					
					
					}	
					
					
					$resData['options'][]    =$optionData;
					$oCount++;
			 	  }//end of foreach
		       }
			 	   
			 	  
	        //var_dump($resData);
					
		    }else{
					$resArr['message']		= "Unable to retrieve user data.";
		}
				
					
			
			$resArr['data'][]				 =$resData;
		}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
		 }
				
	}
		
		 echo $this->response($resArr, 200);
	}
	
	
	/*
	 * to get vote results for windows mobile
	 */
	
	function getVoteDetails_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$accessToken		=$this->post('accessToken');
		
		//get UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		}else{
			$userId='';
		}
		
		if(!$qId  || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				
			$resArr['result']	= 1;
			 $getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
			 $qcreatorUserId= $getQCreatorId[0]['user_ID'];
			 $qcreatorRoomName=$getQCreatorId[0]['roomName'];
			 $notes=$getQCreatorId[0]['note'];
			 $isPublic=$getQCreatorId[0]['isPublic'];
			 $isFBShare=$getQCreatorId[0]['isFBShare'];
			 $isTwitterShare=$getQCreatorId[0]['isTwitterShare'];
			 $isPintrestShare=$getQCreatorId[0]['isPintrestShare'];
			 //to display room name only for private group users
			  
			  $getPrivateGroupMembers=$this->getdatamodel->getPrivateGroupMembers($qId);	 
			 
			
			 
			
			 
			 
			 $updateUserQBadges=$this->setdatamodel->updateUserQBadges($qId,$userId);
			 $userData      =$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);	 
			 
               if($userData){
					$resArr['result']		        = 1;
					
					
					
										
					//get Q type
			       $getQOptions=$this->getdatamodel->getQOptions($qId);//check where Qid is present or not
		           $getOptionCount=$this->getdatamodel->qpalsCountOptions($qId);
		           $getImgCount=$this->getdatamodel->qpalsCountImages($qId);
		           if(!$getQOptions){
		           	//do nothing
		           	$resArr['message']		= "There are no options for the Q.";
		           	//$optionData['optionId']		= NULL;
		           	$resData['options']    =NULL;
		           }else{
	               $oCount = 0;
	               $getAggregateVotes = NULL;
			       foreach($getQOptions as $row){//qOptions
				    
			 	    $optionData['optionId']=$row['ID'];			
					$optionName=$row['optionName'];
					if($optionName){
					$optionData['option']  =$row['optionName'];	
					}else{
					$optionData['option']  ='';	
					}	
			        $imgNamethumb=$row['thumb'];
					$imgNamePhoto=$row['photo'];
					
					
					$getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					
					
					if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					if (!$getAggregateVotes)
					{
					//$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$optionData['resPerc'] = $aggResult;	
					}
					else
					{
					//now get the individual options sum
					$optionsCount = 4; //default number of options to a Q 
					if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}	
					
					// Calculate the result in % for the option
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes,2); 
					}
					
					
					
					$optionData['resPerc'] = $aggResult;
					
					
					}	
					
					
					$resData['options'][]    =$optionData;
					$oCount++;
			 	  }//end of foreach
		       }
			 	   
			 	  
	        //var_dump($resData);
					
		    }else{
					$resArr['message']		= "Unable to retrieve user data.";
		}
				
					
			
			$resArr['data'][]				 =$resData;
				
				
				
				
				
		   	 
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
		    }
			
		}
		
		 echo $this->response($resArr, 200);
		
	}
	
	
	
	/*
	 * This function is to Vote Q 
	 * @Author Asha on 7-1-2014
	 */
	
	function voteQ_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$accessToken		=$this->post('accessToken');
		$voteFor            =$this->post('voteFor');//option Id which has been voted for
		$voteSourceType     =$this->post('voteSourceType');//1-private,2-QpalsPublic,3-Facebook,4-Twitter,5-Pinterest
		
	   //get UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		
		if(!$qId  || !$accessToken || !$voteFor){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){	
				
				//changes done for new badges after voting
				
				//$userQBagesData=array('user_ID'=>$userId,'qPalQ_ID'=>$qId,'isNew'=>1);
                //$this->setdatamodel->insertQBadges($userQBagesData);
                
				 $getGroupId =$this->getdatamodel->getUserIdFromQId($qId);
				 $groupIdForQ=$getGroupId[0]['qPalQGroup_ID'];
		         if($groupIdForQ){
				 $groupMembersData=$this->getdatamodel->getGroupMembersDetails($groupIdForQ,0);
				 $getGroupName=$this->getdatamodel->getGroupDetailsById($groupIdForQ);
				 $groupNameDisp=$getGroupName[0]['name'];
		         	if($groupMembersData){
						foreach($groupMembersData as $rec){
							
							if ($userId == $rec['ID'])
							{
								//do nothing bcoz the sender of the Q should not be notified or entry added to RECIEVED Q
									
							}
							else
							{
								$recievedQData=array("user_ID"=>$rec['ID'],"qPalQ_ID"=>$qId);
								$this->setdatamodel->insertRecievedQ($recievedQData);
                                
								//insert user Q Badges 
								//@Author Asha on 14-5-2014

								$getUserQBadges=$this->getdatamodel->getUserQBadge($rec['ID'],$qId);
								$getUserDeatails=$this->getdatamodel->getUserDetailsByUserID($userId);
								$repliedMemberName=$getUserDeatails[0]['displayName'];
								//print_r($getUserQBadges);die;
								if($getUserQBadges){
									//echo "dsf";die;
								//$userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$qId,'isNew'=>1);
								$this->setdatamodel->updateUserQBadgesForVote($rec['ID'],$qId);	
								}else{
								$userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$qId,'isNew'=>1);
                                $this->setdatamodel->insertQBadges($userQBagesData);
								}
								//To Send Push to Group Member
								//@author Rajesh on 27-11-2013
								if($rec['isPushAlerts']==1){
									$data = new StdClass;
									$data->deviceToken = $rec['pushId'];
									$data->message = "$repliedMemberName from the $groupNameDisp replied to your Q. Check it now.";
									$data->typeID = "1";
					                $data->param = $qId;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}


							}
						}
					}
		         }
				 
				
				$getCountQVotes=$this->getdatamodel->getCountQVotes($qId,$userId);
				
				$voteQdata=array('qID'=>$qId,'userID'=>$userId,'votedOption'=>$voteFor,'voteSourceType'=>$voteSourceType);
				
				if($getCountQVotes[0]['qCount']==0){
										
				$insertQVotes=$this->setdatamodel->insertQVotes($voteQdata);
				$resArr['result']	= 1;
				$resArr['message']	= "Vote inserted Successfully";
				}else{
					$updateQVotes=$this->setdatamodel->updateQVotes($voteQdata);
					$resArr['result']	= 1;
					$resArr['message']	= "Vote updated Successfully";//if user changes his votes
				}
               
				$getQOptions=$this->getdatamodel->getQOptions($qId);//check where Qid is present or not
				$oCount = 0;
	            $getAggregateVotes = NULL;
	            foreach($getQOptions as $row){//qOptions
	            	
	                $optionData['optionId']=$row['ID'];			
					$optionName=$row['optionName'];
					if($optionName){
					$optionData['option']  =$row['optionName'];	
					}else{
					$optionData['option']  ='';	
					}
					
	            $getCountQVotesOptions=$this->getdatamodel->getCountQVotesOptions($row['qPalQ_ID'],$userId,$row['ID']);
					if($getCountQVotesOptions[0]['qCount']>0){
					$optionData['isVoted']	     = TRUE;	
					}else{
					$optionData['isVoted']	     = FALSE;
					}
					
	            if ($getAggregateVotes == NULL)
					{
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					}
					
	            if (!$getAggregateVotes)
					{
					$resArr['message']		= "Aggregate votes not found";
					$aggResult=0;
					$optionData['resPerc'] = $aggResult;	
					}else
					{
					//now get the individual options sum
					$optionsCount = 4; //default number of options to a Q 
					if ($getAggregateVotes[0]['opt1'] == NULL)
					{
						$optionsCount = 0;
						
					} else 	if ($getAggregateVotes[0]['opt2'] == NULL)
					{
						$optionsCount = 1;
					} else if  ($getAggregateVotes[0]['opt3'] == NULL)
					{
						$optionsCount = 2;
					} else if ($getAggregateVotes[0]['opt4'] == NULL)
					{
						$optionsCount = 3;
					}	
					
					// Calculate the result in % for the option
					
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					
					if ($opt3 == NULL)
					{
						$opt3 = 0;
					}
					
					if ($opt4 == NULL)
					{
						$opt4 = 0;
					}
					$tempRes = 0;
					if ($oCount == 0)
					{
						//first option result 
						
						$tmpRes = ($opt1)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes); 
					}
					if ($oCount == 1)
					{
						//first option result 
						
						$tmpRes = ($opt2)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes); 
					}
					if ($oCount == 2)
					{
						//first option result 
						
						$tmpRes = ($opt3)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes); 
					}
					if ($oCount == 3)
					{
						//first option result 
						
						$tmpRes = ($opt4)/($opt1+$opt2+$opt3+$opt4) * 100;
						$aggResult=round($tmpRes); 
					}
					
					
					
					$optionData['resPerc'] = $aggResult;
					
					
					}

					$resData['options'][]    =$optionData;
					$oCount++;
					
	            }//end of foreach
				
				$resArr['data'][]		    =$resData;
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		 echo $this->response($resArr, 200);
		
	}
	
/*
    * This functionis to find Pals
    * @Author Asha on 20-1-2014
    */
	
	function findPals_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$searchText 		= $this->post('searchText');
		$filterType         =$this->post('filterType');//1-MostPopular,2-Most Active,3-New Pals
		$offset             =$this->post('offset');
	   //get UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		if(!$accessToken || !$filterType){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				
				if($filterType==1){//Most Popular-Max number of followers					
					
					$res=$this->getdatamodel->getMostPopular($userId,$searchText,$offset);
				}
				elseif($filterType==2){//Most Active-Created max of Q's					
				 $res=$this->getdatamodel->getMostActiveUsers($userId,$searchText,$offset);//created max of Q's-MostActive-2
				}elseif($filterType==3){//New Pals
				 $res=$this->getdatamodel->getNewPals($userId,$searchText,$offset);//recently registered order-New Pals-3
				}
				$resArr['countMaxFollowers']=$this->getdatamodel->getCountOfMostPopular($userId);
				$resArr['countMostActive']	=$this->getdatamodel->getCountOfMostActiveUsers($userId);
				$resArr['countNewPals']	    =$this->getdatamodel->getCountOFNewPals($userId);
				
				if($filterType==1){
				
					 if($searchText!=""){
					 	$resArr['TotalNo']=$this->getdatamodel->getMostPopularTotalNum($userId,$searchText,$offset);
					 }else{
					 	$resArr['TotalNo']=$this->getdatamodel->getCountOfMostPopular($userId);
					 }
				}else if($filterType==2){
					
					if($searchText!=""){
					$resArr['TotalNo']=$this->getdatamodel->getMostActiveUsersTotalNum($userId,$searchText,$offset);		
					}else{
					$resArr['TotalNo']=$this->getdatamodel->getCountOfMostActiveUsers($userId);	
					}
					
				}else if($filterType==3){
					
					if($searchText!=""){
					$resArr['TotalNo']=$this->getdatamodel->getNewPalsTotalNum($userId,$searchText,$offset);	
					}else{
					$resArr['TotalNo']=$this->getdatamodel->getNewPalsTotalNum($userId);	
					}
					
				}
				
				if($res){
				  $resArr['result']	= 1;	
				  foreach($res as $res){
				  	if($filterType==1){
				  	$usrArr['userID']=$res['followers_ID'];	
				  	}
				  	elseif($filterType==2){				  	
				  	$usrArr['userID']=$res['user_ID'];
				  	}elseif($filterType==3){
				  	$usrArr['userID']=$res['ID'];	
				  	}
                    //count of Q's created by user
                   /* $countOfQCreated=$this->getdatamodel->getTotCountOfMyQs($usrArr['userID']);
				  	
				  	if($countOfQCreated==0){
				  	$usrArr['countOfQCreated']	=NULL;	
				  	}else{
				  	$usrArr['countOfQCreated']	=$this->getdatamodel->getTotCountOfMyQs($usrArr['userID']);
				  	}*/
				  	
				  //public Q Count
				
				//check the Q's which are public
				$getIsPublic=$this->getdatamodel->getCountOFPublicQ($usrArr['userID']);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($usrArr['userID'],$userId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($usrArr['userID']);
					
					if($getCountOFPublicQ){
					$usrArr['countOfQCreated']=$getCountOFPublicQ;	
					}else{
					$usrArr['countOfQCreated']=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($usrArr['userID'],$userId);					
					if($getCountOfReceivedQ){
					$usrArr['countOfQCreated']=$getCountOfReceivedQ;
					}else{
					$usrArr['countOfQCreated']=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($usrArr['userID'],$userId);
				   if($getCountOfPublicReceived){
				   $usrArr['countOfQCreated']=$getCountOfPublicReceived;
				   }else{
				   $usrArr['countOfQCreated']=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$usrArr['countOfQCreated']	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($usrArr['userID']);
				    if($countOfFollowers){
				  	$usrArr['countOfFollowers']	=$this->getdatamodel->getTotCountOfFollowers($usrArr['userID']);
				    }else{
				    $usrArr['countOfFollowers']	=0;	
				    }
				  	
				  	
				  	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($usrArr['userID']);
				  	if($getUserDetails){				  	  
				  	  $usrArr['displayName']=$getUserDetails[0]['displayName'];
				  	  $usrArr['UserThumbImage']=base_url()."Uploads/ProfilePictures/".$getUserDetails[0]['thumb'];	
				  	}else{
				  	  $usrArr['displayName']   =NULL;
				  	  $usrArr['UserThumbImage']=NULL;
				  	}
				  	
				  	$resArr['userDetails'][]    =$usrArr;
				  }
					
				}else{
					$resArr['result']	    = 0;
					$resArr['userDetails']  =NULL;
					$resArr['message']		= "Result not found";
					
				}
				
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
		    }else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		
		 echo $this->response($resArr, 200);
	}
  
	
	/*
	 * This function is to set the followers
	 * @Author Asha 0n 20-1-2014
	 */
    
	function setFollowStatus_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$user_ID            =$this->post('user_ID');//following UserId
		$friend_ID          =$this->post('friend_ID');//followers Id
		$followStatus       =$this->post('followStatus');//1-follow,0-unfollow
		
	    //get Qpals UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		
		if(!$user_ID  || !$accessToken || !$friend_ID){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				//following		
						
				$resArr['result']		= 1;
				$setFollow=$this->setdatamodel->insertFollowers($user_ID,$friend_ID,$followStatus);
			if($setFollow){
			if($followStatus==1){
					$resArr['message']		= "Following Successfully.";
				}else if($followStatus==0){
					$resArr['message']		= "Unfollowing Successfully.";
				}
			}else{
				$resArr['result']	= 0;
				$resArr['message']	= "Already following";//already following
			}	

				//following count
			     $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($friend_ID);				
				if($getCountOfFollowing){
				$dataArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($friend_ID);
				}else{
				$dataArr['countOfFollowing']=0;	
				}
				
				//followers count
			   $getCountOffollowers=$this->getdatamodel->getCountOffollowers($friend_ID);				
				if($getCountOffollowers){
					$dataArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($friend_ID);
				}else{
					$dataArr['countOfFollowers']	=0;
				}
			
			 $resArr['data'][]=$dataArr;
				 
			  }elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
		
		
	 echo $this->response($resArr, 200);	
	}
	
	
	function viewPals_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$user_ID            =$this->post('user_ID');
		$friend_ID          =$this->post('friend_ID');
	   //get Qpals UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];//Qpals lodin user Id to check valid access token or not
		}
		
		if(!$user_ID || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$getFollowStatus=$this->getdatamodel->getFollowStatus($user_ID,$friend_ID);
				if($getFollowStatus){
				$resArr['followStatus']	=1;	
				}else{
				$resArr['followStatus']	=0;	
				}
				
				//following count
			   $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($friend_ID);				
				if($getCountOfFollowing){
				$resArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($friend_ID);
				}else{
				$resArr['countOfFollowing']=0;	
				}
				
				//followers count
			   $getCountOffollowers=$this->getdatamodel->getCountOffollowers($friend_ID);				
				if($getCountOffollowers){
					$resArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($friend_ID);
				}else{
					$resArr['countOfFollowers']	=0;
				}
				
				//public Q Count
				
				//check the Q's which are public
				$getIsPublic=$this->getdatamodel->getCountOFPublicQ($friend_ID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($friend_ID,$user_ID);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($friend_ID);
					
					if($getCountOFPublicQ){
					$resArr['countOfPalsQ']=$getCountOFPublicQ;	
					}else{
					$resArr['countOfPalsQ']=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($friend_ID,$user_ID);					
					if($getCountOfReceivedQ){
					$resArr['countOfPalsQ']=$getCountOfReceivedQ;
					}else{
					$resArr['countOfPalsQ']=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($friend_ID,$user_ID);
				   if($getCountOfPublicReceived){
				   	$resArr['countOfPalsQ']=$getCountOfPublicReceived;
				   }else{
				   	$resArr['countOfPalsQ']=0;
				   }
			  }
			  
			 if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					
					$resArr['countOfPalsQ']		= 0;
				}
				
				
				$userData=$this->getdatamodel->getUserDetailsByUserID($friend_ID);
				if($userData){
					$resArr['result']		= 1;					
					$resArr['displayName']	= $userData[0]['displayName'];
					$resArr['biography']	= $userData[0]['biography'];
					$resArr['thumb']		= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				}
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		
		 echo $this->response($resArr, 200);
		
	}
	
	function palsQCreated_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$friend_ID          =$this->post('friend_ID');//pal userId
		$offset             =$this->post('offset');
	//get Qpals UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];//Qpals login user Id to check valid access token or not
		}
		
		if(!$friend_ID || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']	= 1;
				
				//check the Q's which are public
				$getIsPublicCount=$this->getdatamodel->getCountOFPublicQ($friend_ID);
				
				//check the Q in received Q's
				$getReceivedQCount=$this->getdatamodel->countOfReceivedQForPal($friend_ID,$userId);
				
				//check the Q's which are public
				$getIsPublic=$this->getdatamodel->getPublicQ($friend_ID,$offset);
				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->getReceivedQForPal($friend_ID,$userId,$offset);
				
				if($getIsPublicCount && !$getReceivedQCount){
				//public Q's
				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($friend_ID);
					
					if($getCountOFPublicQ){
					$resArr['countOfPalsQ']=$getCountOFPublicQ;	
					}else{
					$resArr['countOfPalsQ']=0;	
					}
				
					foreach($getIsPublic as $getIsPublic){
						
						$qArr['qId']      =$getIsPublic['ID'];
						$time1            =$getIsPublic['timeStamp'];
						$qArr['timestamp']= $time1;
						$qArr['qsn']      =$getIsPublic['name'];
						//$qArr['responseCount']=0;
					    $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qArr['qId']);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $qArr['responseCount']=$result;
						}else{
							$qArr['responseCount']=0;
						}
						$quserId           =$getIsPublic['user_ID'];
						$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
						
					   if($qCreatorDetails){
						
							$qArr['uname']=$qCreatorDetails[0]['firstName'];
						}else{
							$qArr['uname']=NULL;
						}
						
						$qImageData=$this->getdatamodel->getQImages($qArr['qId']);
						$qArr['qImages']="";
						if($qImageData){
						foreach($qImageData as $rows){								
								$imgName=$rows['thumb'];
								if($imgName){							
								$optionData['thumb']=base_url()."Uploads/QImages/".$rows['thumb'];
								$optionData['isDefaultImage']=FALSE;
								}else{
								$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
								$optionData['isDefaultImage']=TRUE;	
								}
								
								$qArr['qImages'][]    =$optionData;
							}
						}else{
							$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							$optionData['isDefaultImage']=TRUE;
							$qArr['qImages'][]    =$optionData;
						}
						
						
					 $resArr['qs'][]=$qArr;		
					}
				}
				
				if(!$getIsPublicCount && $getReceivedQCount){
					//not public but received Q's
					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($friend_ID,$userId);
					
					if($getCountOfReceivedQ){
					$resArr['countOfPalsQ']=$getCountOfReceivedQ;
					}else{
					$resArr['countOfPalsQ']=NULL;	
					}
					
					foreach($getReceivedQ as $getReceivedQ){
						$qArr['qId']      =$getReceivedQ['QpalId'];
						$time1            =$getReceivedQ['timeStamp'];
						$qArr['timestamp']= $time1;
						$qArr['qsn']      =$getReceivedQ['quename'];
						//$qArr['responseCount']=0;
					 $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qArr['qId']);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $qArr['responseCount']=$result;
						}else{
							$qArr['responseCount']=0;
						}
						$quserId          =$getReceivedQ['QpalUserId'];
						$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
					   if($qCreatorDetails){
						
							$qArr['uname']=$qCreatorDetails[0]['firstName'];
						}else{
							$qArr['uname']=NULL;
						}
						
						$qImageData=$this->getdatamodel->getQImages($qArr['qId']);
						$qArr['qImages']="";
						if($qImageData){
						foreach($qImageData as $rows){								
								$imgName=$rows['thumb'];
								if($imgName){							
								$optionData['thumb']=base_url()."Uploads/QImages/".$rows['thumb'];
								$optionData['isDefaultImage']=FALSE;
								}else{
								$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
								$optionData['isDefaultImage']=TRUE;	
								}
								
								$qArr['qImages'][]    =$optionData;
							}
						}else{
							$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							$optionData['isDefaultImage']=TRUE;
							$qArr['qImages'][]    =$optionData;
						}
						
					 $resArr['qs'][]=$qArr;	
						
					}
					
					
				}
				
			if($getIsPublicCount && $getReceivedQCount){				
				
					//public and received Q's
				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($friend_ID,$userId);
				   if($getCountOfPublicReceived){
				   	$resArr['countOfPalsQ']=$getCountOfPublicReceived;
				   }else{
				   	$resArr['countOfPalsQ']=NULL;
				   }
				
				
					$getPublicReceived=$this->getdatamodel->getPublicReceived($friend_ID,$userId,$offset);
					foreach($getPublicReceived as $getPublicReceived){
						$qArr['qId']      =$getPublicReceived['QpalId'];
						$time1            =$getPublicReceived['timeStamp'];
						$qArr['timestamp']= $time1;
						$qArr['qsn']      =$getPublicReceived['quename'];
						//$qArr['responseCount']=0;
					 $getAggregateVotes=$this->getdatamodel->getAggregateVotes($qArr['qId']);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $qArr['responseCount']=$result;
						}else{
							$qArr['responseCount']=0;
						}
						$quserId          =$getPublicReceived['QpalUserId'];
						
					$qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($quserId);
					   if($qCreatorDetails){
						
							$qArr['uname']=$qCreatorDetails[0]['firstName'];
						}else{
							$qArr['uname']=NULL;
						}
						
						$qImageData=$this->getdatamodel->getQImages($qArr['qId']);
						$qArr['qImages']="";
						if($qImageData){
						foreach($qImageData as $rows){								
								$imgName=$rows['thumb'];
								if($imgName){							
								$optionData['thumb']=base_url()."Uploads/QImages/".$rows['thumb'];
								$optionData['isDefaultImage']=FALSE;
								}else{
								$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
								$optionData['isDefaultImage']=TRUE;	
								}
								
								$qArr['qImages'][]    =$optionData;
							}
						}else{
							$optionData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							$optionData['isDefaultImage']=TRUE;
							$qArr['qImages'][]    =$optionData;
						}
						
						
					 $resArr['qs'][]=$qArr;	
					}
					
					
					}
				
				if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$resArr['result']	= 0;
					$resArr['message']		= "No Q's Available";
				}
				
				
				
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		 echo $this->response($resArr, 200);
	}
	
	
   function palsFollowers_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$friend_ID          =$this->post('friend_ID');//pal userId
		$offset             =$this->post('offset');
	   //get Qpals UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];//Qpals login user Id to check valid access token or not
		}
		
		if(!$friend_ID || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']=1;
				
				$getCountOffollowers=$this->getdatamodel->getCountOffollowers($friend_ID);
				
				if($getCountOffollowers){
					$resArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($friend_ID);
				}else{
					$resArr['countOfFollowers']	=0;
				}
				
				if($offset!=''){					
				$getPalFollowers=$this->getdatamodel->followersOfPal($friend_ID,$offset);
				}else{					
				$getPalFollowers=$this->getdatamodel->followersOfPals($friend_ID);	
				}
				if($getPalFollowers){
					
					foreach($getPalFollowers as $getPalFollowers){						
						$usrArr['fUserId']=$getPalFollowers['user_ID'];
						$userData            =$this->getdatamodel->getUserDetailsByUserID($usrArr['fUserId']);
						$usrArr['thumb']	 =base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
						$usrArr['displayName']=$userData[0]['displayName'];
						$usrArr['email']	  =$this->convert($userData[0]['email']);
						$resArr['followers'][] =$usrArr;
					}
					
				}else{
					$resArr['result']	= 0;
					$resArr['message']	= "No followers for the pal";
				}
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		
		 echo $this->response($resArr, 200);
	}
	
	
  function followingPals_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$friend_ID           =$this->post('friend_ID');//pal userId
		$offset             =$this->post('offset');
	   //get Qpals UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];//Qpals login user Id to check valid access token or not
		}
		
		if(!$friend_ID || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']	= 1;
				$getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($friend_ID);
				
				if($getCountOfFollowing){
				$resArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($friend_ID);
				}else{
				$resArr['countOfFollowing']=0;	
				}

				if($offset!=''){
				$getFollowingPals=$this->getdatamodel->followingPals($friend_ID,$offset);
				}else{
				$getFollowingPals=$this->getdatamodel->followingPal($friend_ID);	
				}				
				if($getFollowingPals){
					
					foreach($getFollowingPals as $getFollowingPals){
						$usrArr['fUserId']     =$getFollowingPals['followers_ID'];
						$userData              =$this->getdatamodel->getUserDetailsByUserID($usrArr['fUserId']);
						$usrArr['thumb']	   = base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
						$usrArr['displayName'] = $userData[0]['displayName'];
						$usrArr['email']	   =$this->convert($userData[0]['email']);
						$resArr['following'][] =$usrArr;
					}
					
				}else{
					$resArr['result']	= 0;
					$resArr['message']		= "No following";
				}
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		 echo $this->response($resArr, 200);
	}
	
	/*
	*this functin is to get count of followers and following
	*@Author Asha on 31-1-2014
	*/
	
	function getFollowingFollowersCount_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$friend_ID           =$this->post('friend_ID');//pal userId
		
	    $getUserId=$this->getdatamodel->getUserId($accessToken);
		foreach($getUserId as $row){			
			$userId=$row['ID'];//Qpals login user Id to check valid access token or not
		}
		
		if(!$friend_ID || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				
			    $resArr['result']	= 1;
				$getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($friend_ID);				
				if($getCountOfFollowing){
				$dataArr['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($friend_ID);
				}else{
				$dataArr['countOfFollowing']=0;	
				}
				
			    $getCountOffollowers=$this->getdatamodel->getCountOffollowers($friend_ID);				
				if($getCountOffollowers){
					$dataArr['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($friend_ID);
				}else{
					$dataArr['countOfFollowers']	=0;
				}
				
				$resArr['data'][]=$dataArr;
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";				
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		echo $this->response($resArr, 200);
		
	}
	
	/*
	 * To get likes of Q
	 * @Author Asha on 3-2-2014
	 */
	
	function setFavourites_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
		$qId                =$this->post('qId');
		$user_ID            =$this->post('user_ID');
		$favouriteStatus    =$this->post('favouriteStatus');//1-like,0-unlike
		
	    $getUserId=$this->getdatamodel->getUserId($accessToken);
	    if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
	    }else{
	    	$userId='';
	    }
		
		if(!$user_ID  || !$accessToken || !$qId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				//do something			
				
				$resArr['result']	= 1;
				
				$insertFavourites=$this->setdatamodel->insertFavourites($qId,$user_ID,$favouriteStatus);
				
				if($insertFavourites){
				  if($favouriteStatus==1){
					$resArr['message']		= "like";
				  }else if($favouriteStatus==0){
					$resArr['message']		= "unlike";
				}
			}else{
				$resArr['message']	= "Already liked";//already following
			}
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}			
			
		}
		
		echo $this->response($resArr, 200);
	}
	
	/*
	 * About
	 * @Asha on 5-2-2014
	 */
	
	function about_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
	    $getUserId=$this->getdatamodel->getUserId($accessToken);
	    if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
	    }else{
	    	$userId='';
	    }
	    
	    if(!$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']	= 1;
				$resArr['url']='https://www.google.co.in/';
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		
		echo $this->response($resArr, 200);
	}
	
	function getProfilePic_post(){
		
		$resArr['result']	= 0;
		$accessToken		=$this->post('accessToken');
	    $friendId           =$this->post('friendId');
	    $getUserId=$this->getdatamodel->getUserId($accessToken);
	    if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
	    }else{
	    	$userId='';
	    }
	    
	 if(!$accessToken || !$friendId){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']	= 1;
				$userData=$this->getdatamodel->getUserDetailsByUserID($friendId);
				if($userData){
				$resData['thumb']		    = base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				}
				$resArr['data'][]				 =$resData;
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
			
		}
		echo $this->response($resArr, 200);
	}
	
	//test function to share on twitter
	
	function tcompositeimage_post(){
		
		$istwitterShare=$this->post('istwitterShare');
		$userId		= $this->post('userId');
		$qId		= $this->post('qID');
		
		$countOfImages=$this->getdatamodel->countOfImages($qId);
		

		if($istwitterShare==1){	

			if($countOfImages==0 || $countOfImages==1){
				
			$numberOfImages = 1;
			$x = 200;
            $y = 200;
            $background = imagecreatetruecolor($x, $y);
            $color = imagecolorallocate($background, 255, 255, 255);
            $outputImage = $background;
            // fill entire image
            imagefill($background, 0, 0, $color);
            $getNotNullImages=$this->getdatamodel->getNotNullImages($qId);
            
            if($getNotNullImages){
            $getimage=$getNotNullImages[0]['thumb'];
            $imageUrl=base_url()."Uploads/QImages/$getimage";
            $image=imagecreatefromjpeg($imageUrl);	
            }else{
            $imageUrl=base_url()."Uploads/QImages/default_thumb.jpg";
            $image=imagecreatefromjpeg($imageUrl);	
            }
            
             $qImageData=$this->getdatamodel->getQImages($qId);
             $i=1;
             
             foreach($qImageData as $qImageData){
             $optionName[$i]=$qImageData['optionName'];	
             $font = 3;
             $font_width = ImageFontWidth($font);
             $font_height = ImageFontHeight($font);
             $text_width = $font_width * strlen($optionName[$i]);
             $position_center = ceil(($x - $text_width));
             $text_height = $font_height;
             $position_middle = ceil(($y - $text_height));
             
             if($i==1){		   
		    $text_color = imagecolorallocate($image, 255, 255, 255);
            imagestring($image, $font, 0, 0, $optionName[$i], $text_color);
		   }elseif($i==2){
		   	$text_color1 = imagecolorallocate($image, 255, 255, 255);
            imagestring($image,$font, $position_center, 0, $optionName[$i], $text_color1);
		   }elseif($i==3){		   
		   	$text_color2 = imagecolorallocate($image, 255, 255, 255);
            imagestring($image, $font, $position_center,$position_middle,  $optionName[$i], $text_color2);
		   }elseif($i==4){		   	
		   	$text_color3 = imagecolorallocate($image, 255, 255, 255);
            imagestring($image, $font,0, $position_middle, $optionName[$i], $text_color3);
		   }
             
             $i++;
             }
            imagecopymerge($outputImage,$image,0,0,0,0, $x, $y,100);
				
			}else{
				
			$numberOfImages = 4;
            $x = 200;
            $y = 200;
            $background = imagecreatetruecolor($x*2, $y*2);
            $color = imagecolorallocate($background, 255, 255, 255);
            // fill entire image
            imagefill($background, 0, 0, $color);
            $qImageData=$this->getdatamodel->getQImages($qId);
            $i=1;
            foreach($qImageData as $qImageData){
            	
            $imgName[$i]=$qImageData['thumb'];
            $optionName[$i]=$qImageData['optionName'];
            if($imgName[$i]){
			$Url[$i]=base_url()."Uploads/QImages/$imgName[$i]";
			$image[$i] = imagecreatefromjpeg($Url[$i]);
			}else{
			$Url[$i]=base_url()."Uploads/QImages/default.png";
			$image[$i] = imagecreatefrompng($Url[$i]);			
		   }
		   $outputImage = $background;
		   
		   if($i==1){
		   
		   $text_color[$i] = imagecolorallocate($image[$i], 233, 14, 91);
		   imagestring($image[1], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   imagecopymerge($outputImage,$image[$i],0,0,0,0, $x, $y,100);
		   }elseif($i==2){
		   	$text_color[$i] = imagecolorallocate($image[$i], 233, 14, 91);		   
		   	imagestring($image[$i], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,0,0,0, $x, $y,100);
		   }elseif($i==3){		   
		   	$text_color[$i] = imagecolorallocate($image[$i], 233, 14, 91);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],0,$y,0,0, $x, $y,100);
		   }elseif($i==4){		   	
		   	$text_color[$i] = imagecolorallocate($image[$i], 233, 14, 91);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,$y,0,0, $x, $y,100);
		   }
		   
            $i++;           
            }
            
            
			}  
		
            
            //$firstUrl = base_url()."Uploads/images/1.jpg";
           // $secondUrl =base_url()."Uploads/images/2.jpg";
            //$thirdUrl = base_url()."Uploads/images/3.jpg";
            //$fourthUrl =base_url()."Uploads/images/4.jpeg";
            //$outputImage = $background;
            //$first = imagecreatefromjpeg($Url[1]);
            //$second = imagecreatefromjpeg($Url[2]);
            //$third = imagecreatefromjpeg($Url[3]);
            //$fourth = imagecreatefromjpeg($Url[4]);
            //$text_color = imagecolorallocate($image[1], 233, 14, 91);
            //imagestring($image[1], 5, 10, 180,  'A Simple Text String', $text_color);
            //$text_color1 = imagecolorallocate($image[2], 233, 14, 91);
            //imagestring($image[2], 5, 10, 180,  'A Simple Text String', $text_color1);
            //$text_color2 = imagecolorallocate($image[3], 233, 14, 91);
            //imagestring($image[3], 5, 10, 180,  'A Simple Text String', $text_color2);
            //$text_color3 = imagecolorallocate($image[4], 233, 14, 91);
            //imagestring($image[4], 5, 10, 180,  'A Simple Text String', $text_color3);
            //imagecopymerge($outputImage,$image[1],0,0,0,0, $x, $y,100);
            //imagecopymerge($outputImage,$image[2],0,$y,0,0, $x, $y,100);
            //imagecopymerge($outputImage,$image[3],$x,0,0,0, $x, $y,100);
            //imagecopymerge($outputImage,$image[4],$x,$y,0,0, $x, $y,100);
            $currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];		
		    $upldFileName = $newFileName;
            $ourFileName =$_SERVER['DOCUMENT_ROOT']."/Qpals/Uploads/compositeImages/$upldFileName.jpeg";
            imagejpeg($outputImage, $ourFileName );
            //imagedestroy ( $outputImage );
            //echo $upldFileName;die;
            
            //twitter share
            $_SESSION['usertoken']='2264221561-spbMiRbd3GRbK5ED1vmwy7nkuPwQOSnY2bifghV';
            $_SESSION['usertokensecret']='5HftA5MRnBeKwnIuzXpdR6z47vmxX0CGOmYAIZXi5S7Lm';
		    include(BASEPATH.'application/libraries/tmhOAuthExample.php');
		    $tmhOAuth = new tmhOAuthExample();
		    
		    $getTwitterShare=$this->getdatamodel->getTwitterShare($userId,$qId);
		    
		    //to fetch Question id
            foreach($getTwitterShare as $question){
            $quesId=$question['question_ID'];
            }
            
            //question name to share
            $getQQuestion=$this->getdatamodel->getQQuestion($quesId);
            
            foreach($getQQuestion as $queName){
            	
            	$questionName=$queName['name'];
            	
            }
            
            //to fetch a Qimage	
			$pathQImage='/home/workstation/Qpals/Uploads/compositeImages/';
			//echo $pathQImage;		
			$qImageData=$this->getdatamodel->getQImages($qId);
			if($qImageData){				
			 $imgName=$ourFileName;
			
			
				 if($imgName){				 	
						$image=$ourFileName;						
						
					}else{
						
						$image=$pathQImage."default_thumb.png";
					}
			  }else{			  
				$image=$pathQImage."default_thumb.png";
			  }	
			  
			 $name  = basename($image);
            $status = $questionName;

           $code = $tmhOAuth->user_request(array(
           'method' => 'POST',
           'url' => $tmhOAuth->url('1.1/statuses/update_with_media'),
           'params' => array(
            'media[]'  => "@{$image};filename={$name}",
            'status'   => $status,
             ),
            'multipart' => true,
            ));
            
			$this->setdatamodel->updateTwitterShare($qId,$isTwitterShare=1);
            
            

          
		}
		
	}
	
	public function unregister_post(){
		
	//ejabberd code 
	$userId		= $this->post('userId');					
						$param = array("user"=>$userId,"host"=>"chat.staging.qpals.com");
						$request = xmlrpc_encode_request('unregister', $param, (array('encoding' => 'utf-8')));
						$context = stream_context_create(array('http' => array(
	                                                     'method' => "POST",
	                                                     'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
				                                         "Content-Type: text/xml\r\n" .
				                                         "Content-Length: ".strlen($request),
	                                                     'content' => $request
                                                          )));
                                                          
                    $path=$this->config->item('XMPP_RPC_SERVER_HOST');                                     
					$file = file_get_contents($path.'/RPC2', false, $context);
                    $response = xmlrpc_decode($file); 

                   if (xmlrpc_is_fault($response)) {
	                   trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
                   } else {
	               print_r($response);
                 }
                 
                 
                 
                 
	$param = array("user"=>$userId,"host"=>"chat.staging.qpals.com","password"=>"textoxalic");
						$request = xmlrpc_encode_request('register', $param, (array('encoding' => 'utf-8')));
						$context = stream_context_create(array('http' => array(
	                                                     'method' => "POST",
	                                                     'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
				                                         "Content-Type: text/xml\r\n" .
				                                         "Content-Length: ".strlen($request),
	                                                     'content' => $request
                                                          )));
                                                          
                    $path=$this->config->item('XMPP_RPC_SERVER_HOST');                                     
					$file = file_get_contents($path.'/RPC2', false, $context);
                    $response = xmlrpc_decode($file); 

                   if (xmlrpc_is_fault($response)) {
	                   trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
                   } else {
	               print_r($response);
                 }
	}

       /*function sendChatToUser_post(){

        $senderId           =$this->post('senderId');
		$message            =$this->post('message');
		$roomId             =$this->post('roomId');
		$onlineUsers        =$this->post('onlineUsers');
		
	   
		if(!$senderId || !$message || !$roomId || !$onlineUsers){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			  //$str = "RoomName_226@chat.staging.qpals.com";
              //$res_str = strtok($str,'@');
              //print_r($res_str);
			  $qId=explode("_",$roomId);
			  $qId=$qId[1];
			  
			 $getPrivateGroupMembers=$this->getdatamodel->getPrivateGroupMembers($qId);
			 
			  if($getPrivateGroupMembers){
			  foreach($getPrivateGroupMembers as $rec){
			 	
			 	$groupMembers[]=$rec['user_ID'];
			 	
			 }
			 
			$groupMembersArr= $groupMembers; 
			$onlineusersArr=explode(",",$onlineUsers);
			$offlineMembers = array_diff($groupMembersArr, $onlineusersArr);
			//echo sizeof($offlineMembers);
			for($i=1;$i<=sizeof($offlineMembers);$i++){
              
				$userId=$offlineMembers[$i];
				$getMemberData= $this->getdatamodel->getUserDetailsByUserID($userId);
				$Notifications['name']=$getMemberData[0]['displayName'];
				$Notifications['message']=$message;
				$offlineMembersNotifications['offlineData'][]=$Notifications;
				
			}
			
			$resArr['offlineMem']=$offlineMembersNotifications;
			
         }
             
		
      echo $this->response($resArr, 200);
	}	
}*/
		
	function sendChatToUser_post(){
		
		$senderId           =$this->post('senderId');
		$message            =$this->post('message');
		$roomId             =$this->post('roomID');
		$onlineUsers        =$this->post('onlineUsers');
		
		
		
		
		$req_dump = print_r($_REQUEST, TRUE);
	        $fp = fopen('/var/www/logs/request.log', 'a+');
		fwrite($fp, $req_dump);
		//fclose($fp);
	   
		
		
		if(!$senderId || !$message || !$roomId || !$onlineUsers){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			  
			  $roomName = strtok($roomId,'@');
   		          $qId=explode("_",$roomName);
			  $qId=$qId[1];
			  
		      $getPrivateGroupMembers=$this->getdatamodel->getPrivateGroupMembers($qId);
		      $groupId=$getPrivateGroupMembers[0]['group_ID'];
		      $groupData=$this->getdatamodel->getGroupDetailsById($groupId);
		      $getUserData= $this->getdatamodel->getUserDetailsByUserID($senderId);
		      $groupName=$groupData[0]['name'];
		      $displayName=$getUserData[0]['displayName'];
		      
		      $pushMessage=$displayName.' @ "'.$groupName.'":'.$message;
			//echo $pushMessage;
		       
			  if($getPrivateGroupMembers){
			  foreach($getPrivateGroupMembers as $rec){
			 	
			 	$groupMembers[]=$rec['user_ID'];
			 	
			 }
			 $groupMembersArr= $groupMembers;
			 
			 $onlineusersArr=explode(",",$onlineUsers);
			 $newOnlineUserArr = array();
			  foreach ($onlineusersArr as $e)
              {
                $tempString = str_replace("\"","",$e);
                $tempString = str_replace("<<","",$tempString);
                $tempString = str_replace(">>","",$tempString);
                $tempString = str_replace("[","",$tempString);
                $tempString = str_replace("]","",$tempString);
                $newOnlineUserArr[] = $tempString;
		fwrite($fp,$tempString);
              } 
              
              $OnlineUserArray=$newOnlineUserArr;
              
              $offlineMembers = array_diff($groupMembersArr, $OnlineUserArray);
              $offlineMembers = array_values($offlineMembers);
		 // $req_dump = print_r($offlineMembers,TRUE);
	//	fwrite($fp, $req_dump);
//		fwrite($fp,"\n\n");
		$req_dump = print_r($offlineMembers,TRUE); 
//		fwrite($fp,sizeof($offlineMembers));
			  for($k=0;$k<sizeof($offlineMembers);$k++)
				{//offline members              
				$userId=$offlineMembers[$k];
				$getMemberData= $this->getdatamodel->getUserDetailsByUserID($userId);
				$Notifications['UserId']=$userId;
				$name=$getMemberData[0]['displayName'];
				$isPushAlerts=$getMemberData[0]['isPushAlerts'];
				//$req_dump = print_r($getMemberData,TRUE);
				//fwrite($fp,$req_dump);
				$pushId=$getMemberData[0]['pushId'];
				//fwrite($fp,"before push");				
				if($isPushAlerts==1){
					$devType = $getMemberData[0]['deviceType_ID'];
					fwrite($fp,print_r($pushId,TRUE));
					$data = new StdClass;
					$data->deviceToken =$pushId;
					$data->message = $pushMessage;
					$data->typeID = "1";
					$data->param = $qId;
					$mess = json_encode($data);
					log_message('debug',"hitting message queue $mess");
					
				    if($devType== 1){ //Android
					  log_message('debug',$mess);
		                	      $this->messagequeue->addMessageToC2DMQueue($mess);
					    }elseif($devType== 2){ //Ios
			                        
						 $this->messagequeue->addMessageToAPNSQueue($mess);
						}elseif($devType== 3){ //Windows
		                         $this->messagequeue->addMessageToWinQueue($mess);
					}
				}//end of push alerts
			}//end of for loop
		}
	 }
   }//end of function
	
   /*
    * function to get Q comments
    * @Author Asha on 13-3-2014
    */
   function setQComments_post(){
   	
    	$resArr['result']	= 0;
		$accessToken    =$this->post('accessToken');
	    $qId            =$this->post('qId');
	    $comments       =$this->post('comments');
	    $getUserId=$this->getdatamodel->getUserId($accessToken);
	    if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
	    }else{
	    	$userId='';
	    }
	    
	 if(!$accessToken || !$qId || !$comments){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				$resArr['result']	= 1;
				$postComments=array('qId'=>$qId,'userId'=>$userId,'comments'=>$comments);
		        $commentsId=$this->setdatamodel->setSocialComments($postComments);
				$resArr['message']		= "Successfully posted.";
				
				
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
			}
		}
   	echo $this->response($resArr, 200);
   }//end of setQ comments
   
   /*
    * function to get Q comments
    */
   
   	function getQcomments_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$accessToken		=$this->post('accessToken');
		$offset             =$this->post('offset');
		//get UserId
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		}else{
			$userId='';
		}
		
		if(!$qId  || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
			 $resArr['result']	= 1;		
			 
			 
			 $commentsCount      =$this->getdatamodel->countOfSocialComments($qId);	 
			 $resData['contOfComments']	= $commentsCount;	
					
			$getQComments=$this->getdatamodel->getSocialQComments($qId,$offset);
		           
		           if(!$getQComments){		           	
		           	$resArr['message']		= "There are no Comments for the Q.";		           	
		           	$resData['Comments']    =array();
		           }else{
	               
			       foreach($getQComments as $row){   
			 	    $commentsData['qId']         = $row['qId'];
					$commentsData['comments']    = $row['comments'];
					$thumb                       =base_url()."Uploads/ProfilePictures/".$row['thumb'];
					$commentsData['thumb']       =$thumb;
					$commentsData['displayName'] =$row['displayName'];
					$userId                      =$row['userId'];
					$commentsData['userId']      =$row['userId'];
					$getVoteSource=$this->getdatamodel->getVoteSourceType($row['qId'],$userId);
					$commentsData['voteSourceType']=$getVoteSource[0]['voteSourceType'];//1-private,2-qpalsPublic,3-Facebook,4-Twitter,6-Pininterest
					$resData['Comments'][]    =$commentsData;
					
			 	  }//end of foreach
		       }   
			 	  
	        $resArr['data'][]				 =$resData;
		}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
		 }
				
	}
		
		 echo $this->response($resArr, 200);
	}
	
   
   
   
   /*
    * function to delete a Q
    * Asha on 07-04-2014
    */
   
	function deleteQ_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$accessToken		=$this->post('accessToken');
		
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		}else{
			$userId='';
		}
		
		if(!$qId  || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
			 
             
			 $getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
			 $qcreatorUserId= $getQCreatorId[0]['user_ID'];
			 
			 if($qcreatorUserId==$userId){
			 $resArr['result']	= 1;
			 $this->setdatamodel->deleteQ($qId);
			 $resArr['message']	= "Q deleted successfully.";			 
			 }else{
			 $resArr['message']	= "Not an owner of the Q.";	
			 }
			 
			
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
		      }
	     }
		 echo $this->response($resArr, 200);
		
	}//end of delete Q function
   
   
   /*
    * function to get voted Pals
    * @Author Asha on 9-4-2014
    */
   
	
	function getVotedPals_post(){
		
		$resArr['result']	= 0;
		$qId                =$this->post('qId');
		$optionId           =$this->post('optionId');
		$accessToken		=$this->post('accessToken');
		
		$getUserId=$this->getdatamodel->getUserId($accessToken);
		if($getUserId){
		foreach($getUserId as $row){			
			$userId=$row['ID'];
		}
		}else{
			$userId='';
		}
		
		if(!$qId  || !$accessToken){
			$resArr['message']		= "Please pass all parameters.";
		}else{
			$isValidAccessToken=$this->getdatamodel->isValidToken($accessToken, $userId);
			if($isValidAccessToken==2){
				
			$getUserIdList=$this->getdatamodel->getVotedPalsForQ($qId,$optionId);
			
			if(!$getUserIdList){
			 $resData['userDetails']    =array();	
			}else{
				$resArr['result']	= 1;
				
				foreach($getUserIdList as $row){
				
				$usrArr['userID']      =$row['userID'];
				$userData              =$this->getdatamodel->getUserDetailsByUserID($usrArr['userID']);
				$usrArr['thumb']	   =base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$usrArr['displayName'] =$userData[0]['displayName'];
					
				$resData['userDetails'][]=$usrArr;	
				}
			}
			$resArr['data'][]				 =$resData;
				
			}elseif($isValidAccessToken==3){
				$resArr['message']		= "Invalid Access token.";
			}else{
				$resArr['message']		= "Access token expired";
		      }
			
		}
		
		echo $this->response($resArr, 200);
	}
   
   

}
