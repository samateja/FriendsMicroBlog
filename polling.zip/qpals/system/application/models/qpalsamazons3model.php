<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Qpalsamazons3model
 *
 * This class is to set the data in database.
 *
 *
 * @package     Qpals
 * @subpackage  Models
 * @category    Authentication
 * @author      Padmaja
 * @copyright   Copyright (c) 2014
 * @license
 * @link
 * @version 	0.1
 */

class Qpalsamazons3model extends CI_Model
{
	//Database tables Added by Rajesh
	var $user						= "user";
	var $groupMembers				= "groupMembers";
	var $secondaryEmails			= "secondaryEmails";
	var $userFacebook				= "userFacebook";
	var $groups						= "groups";
	var $nonRegisteredFBMembers 	= "nonRegisteredFBMembers";
	var $nonRegisteredGroupMembers 	= "nonRegisteredGroupMembers";
	var $userGroupBadges			= "userGroupBadges";	
	var $followers					= "followers";
	var $question					= "question";
	var $qPalQ						= "qPalQ";
	var $options					= "options";
	var $recievedQ					= "recievedQ";
	var $nonReceivedQ				= "nonReceivedQ";
	var $nonReceivedFBQ				= "nonReceivedFBQ";
	var $qVotes                     = "qVotes";
	var $userQBadges                = "userQBadges";
	var $favourites                 = "favourites";
	var $socialQComments            = "socialQComments";
	
	/** initialises the class inheriting the methods of the class Model
	*
	* @return Usermodel
	*/
 	public function __construct()
    {
        parent::__construct();
  
		$this->load->model('getdatamodel');
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
	//die;
	}
	
	function getExtension($str) 
		{
         $i = strrpos($str,".");
         if (!$i) { return ""; } 

         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
		}


	/*
	function uploadImage($FILES, $fieldName)
	{
		
		$imgName = "";
		$imageThumbName = "";
		 
		$fileName = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$msg='';
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
		$imgName = "";
		$imageThumbName = "";
		 
		echo$name = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$size = $_FILES[$fieldName]['size'];
		//$name = $_FILES['file']['name'];
		//$size = $_FILES['file']['size'];
		$tmp = $_FILES[$fieldName]['tmp_name'];
		$ext = $this->getExtension($name);
		echo $ext;
		if(strlen($name) > 0)
		{
		//echo "sdfdsf";die;
		if(in_array($ext,$valid_formats))
		{
		 
		if($size<(1024*1024))
		{
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$path = $this->config->item('path');
		//die;
		$s3 = new S3($awsAccessKey, $awsSecretKey);
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
		echo$actual_image_name = time().".".$ext;
		if($s3->putObjectFile($tmp, $bucket , $actual_image_name, S3::ACL_PUBLIC_READ) )
		{
		//echo "hellooo";
		echo$msg = "S3 Upload Successful.";	
		echo$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$actual_image_name;
		//echo $s3file=$path.$actual_image_name;?>
		<?php echo "<img src='$s3file' style='max-width:400px'/><br/>";
		 
		//echo '<b>S3 File URL:</b>'.$s3file;
		
	//	echo "<br>";
		}
		else
		$msg = "S3 Upload Fail.";
		
		
		}
		else
		$msg = "Image size Max 1 MB";
		
		}
		else
		$msg = "Invalid file, please upload image file.";
		
		}
		else
		$msg = "Please select image file.";

		}
		$thumbName='';
		echo$returnData['thumbName'] = $s3file;
		echo$returnData['imgName'] = $s3file;
		$returnData['msg'] = $msg;
		//$returnData['imgName'] = $s3file;
		return $returnData;
	}
	*/
 	function uploadImage($FILES, $fieldName, $uploadFolder)
	 {
		//print_r($_FILES);die;
	 	$imgName = "";
	 	$imageThumbName = "";
	 	
		$fileName = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$extension = end(explode('.',$fileName));
		$tmp = $_FILES[$fieldName]['tmp_name'];
		$currEncTimestamp = str_split(sha1(microtime()),10);
		$newFileName = $currEncTimestamp[0];
		
		$upldFileName = $newFileName.'.'.$extension;
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
		$ext = $this->getExtension($fileName);
		$s3 = new S3($awsAccessKey, $awsSecretKey);
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
		$actual_image_name = time().".".$ext;
		//echo FCPATH.'Uploads/'.$uploadFolder;die;
		$imgConfig['upload_path']		= FCPATH.'Uploads/'.$uploadFolder;
		//$imgConfig['allowed_types']		= 'jpeg|jpg|png';
		$imgConfig['allowed_types']		=0;
		$imgConfig['file_name']     	= $upldFileName;
		

		$this->load->library('upload',$imgConfig);
		$this->upload->initialize($imgConfig);
		
		$fileType = $FILES[$fieldName]['type'];
		// uploading the image
		$isImgUploaded = $this->upload->do_upload($fieldName);
		if(!$isImgUploaded){
		 $this->upload->display_errors();
		}
		
		if($s3->putObjectFile($tmp, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{	
		   		$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$upldFileName;
				if($isImgUploaded)  {
					
					$uploadedData = $this->upload->data();
					
					$imgName 	= $uploadedData['file_name'];
					$thumbName = str_replace(".","_thumb2x.","$imgName");
					$rebnameThumb=str_replace(".","_thumb2x_thumb.",$imgName);
					$config1['image_library'] 	= 'gd2';
					$config1['source_image']  	= FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName;
					$config1['create_thumb']  	= TRUE;
					$config1['new_image'] 		= $thumbName;
					$config1['maintain_ratio'] 	= FALSE;
					
					$config1['width'] 			= 400;
					$config1['height'] 			= 400;
					
					$this->load->library('image_lib', $config1);
					$this->image_lib->initialize($config1);
					//$this->image_lib->clear($config1);
					//var_dump($this->image_lib->resize());
					
					if($this->image_lib->resize())
					{
						rename(FCPATH.'Uploads/'.$uploadFolder.'/'.$rebnameThumb, FCPATH.'Uploads/'.$uploadFolder.'/'.$thumbName);
					}else{
						//print_r($this->image_lib->display_errors());
					}
					 unlink(FCPATH.'Uploads/'.$uploadFolder.'/'.$thumbName);
					$this->image_lib->clear();
					
					$thumbName = str_replace(".","_thumb.","$imgName");
					$config2['image_library'] 	= 'gd2';
					$config2['source_image']  	= FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName;
					$config2['create_thumb']  	= TRUE;
					$config1['new_image'] 		= $thumbName;
					$config2['maintain_ratio'] 	= FALSE;
					
					$config2['width'] 			= 200;
					$config2['height'] 			= 200;
		
					$this->load->library('image_lib', $config2);
					$this->image_lib->initialize($config2);
					
					if($this->image_lib->resize())
					{
						$imageThumbName = str_replace(".","_thumb.","$imgName");
					}else{
						//print_r($this->image_lib->display_errors());
					}
					if($s3->putObjectFile($tmp, $bucket , $imageThumbName, S3::ACL_PUBLIC_READ) )
					{
						$s3thumbFile='http://'.$bucket.'.s3.amazonaws.com/'.$imageThumbName;
					}
					
				} else {
					//print_r($this->upload->display_errors());
				}
		   	}
		  	unlink(FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName);
     		unlink(FCPATH.'Uploads/'.$uploadFolder.'/'.$imageThumbName);
     	 //unlink(FCPATH.'Uploads/GroupImages/'.$thumbName);die;
		$returnData['imgName'] = $imgName;
		$returnData['thumbName'] = $imageThumbName;
		
		return $returnData;
 	}
	
}