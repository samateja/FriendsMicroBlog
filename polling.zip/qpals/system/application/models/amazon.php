<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Qpalsamazons3model
 *
 * This class is to set the data in database.
 *
 *
 * @package     Qpals
 * @subpackage  Models
 * @category    Authentication
 * @author      Padmaja
 * @copyright   Copyright (c) 2014
 * @license
 * @link
 * @version 	0.1
 */

class Qpalsamazons3model extends CI_Model
{
	//Database tables Added by Rajesh
	var $user						= "user";
	var $groupMembers				= "groupMembers";
	var $secondaryEmails			= "secondaryEmails";
	var $userFacebook				= "userFacebook";
	var $groups						= "groups";
	var $nonRegisteredFBMembers 	= "nonRegisteredFBMembers";
	var $nonRegisteredGroupMembers 	= "nonRegisteredGroupMembers";
	var $userGroupBadges			= "userGroupBadges";	
	var $followers					= "followers";
	var $question					= "question";
	var $qPalQ						= "qPalQ";
	var $options					= "options";
	var $recievedQ					= "recievedQ";
	var $nonReceivedQ				= "nonReceivedQ";
	var $nonReceivedFBQ				= "nonReceivedFBQ";
	var $qVotes                     = "qVotes";
	var $userQBadges                = "userQBadges";
	var $favourites                 = "favourites";
	var $socialQComments            = "socialQComments";
	
	/** initialises the class inheriting the methods of the class Model
	*
	* @return Usermodel
	*/
 	public function __construct()
    {
        parent::__construct();
  
		$this->load->model('getdatamodel');
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
	//die;
	}
	
	function getExtension($str) 
		{
         $i = strrpos($str,".");
         if (!$i) { return ""; } 

         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
		}


	
	function uploadImage($FILES, $fieldName)
	{
		
		$imgName = "";
		$imageThumbName = "";
		 
		$fileName = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$msg='';
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
		$imgName = "";
		$imageThumbName = "";
		 
		$name = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$size = $_FILES[$fieldName]['size'];
		//$name = $_FILES['file']['name'];
		//$size = $_FILES['file']['size'];
		$tmp = $_FILES[$fieldName]['tmp_name'];
		$ext = $this->getExtension($name);
	
		if(strlen($name) > 0)
		{
		//echo "sdfdsf";die;
		if(in_array($ext,$valid_formats))
		{
		 
		if($size<(1024*1024))
		{
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$path = $this->config->item('path');
		//die;
		$s3 = new S3($awsAccessKey, $awsSecretKey);
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
		$actual_image_name = time().".".$ext;
		if($s3->putObjectFile($tmp, $bucket , $actual_image_name, S3::ACL_PUBLIC_READ) )
		{
		//echo "hellooo";
		$msg = "S3 Upload Successful.";	
		echo$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$actual_image_name;
		$content = file_get_contents($s3file);
		//print_r($content);die;
		$dir = FCPATH.'Uploads/s3Images/';
		$imageName=time().".jpg";
		$Ofile=file_put_contents($dir.$imageName, $content);
		echo$UplodFile = $imageName;
		if($UplodFile)  {
			
			//$uploadedData = $this->upload->data();
			//$imgName 	= $uploadedData['file_name'];
			//echo$thumbName = str_replace(".","_thumb2x.","$UplodFile");
			//echo$rebnameThumb=str_replace(".","_thumb2x_thumb.",$UplodFile);
			$config1['image_library'] 	= 'gd2';
			$config1['source_image']  	= FCPATH.'Uploads/s3Images/'.$UplodFile; 
			$config1['create_thumb']  	= TRUE;
			$config1['new_image'] 		= $actual_image_name;
			$config1['maintain_ratio'] 	= FALSE;
			
			$config1['width'] 			= 400;
			$config1['height'] 			= 400;
			echo "<pre>";
			print_r($config1);
			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			//$this->image_lib->clear($config1);
			//var_dump($this->image_lib->resize());
		
			if($this->image_lib->resize())
			{
				$imageThumbName = str_replace(".","_thumb.","$UplodFile");
			}else{
				print_r($this->image_lib->display_errors());
			}
			$this->image_lib->clear();
			
			echo$thumbName = str_replace(".","_thumb.","$UplodFile");
			$config2['image_library'] 	= 'gd2';
			$config2['source_image']  	= FCPATH.'Uploads/s3Images/'.$UplodFile; 
			$config2['create_thumb']  	= TRUE;
			$config1['new_image'] 		= $thumbName;
			$config2['maintain_ratio'] 	= FALSE;
			
			$config2['width'] 			= 200;
			$config2['height'] 			= 200;

			$this->load->library('image_lib', $config2);
			$this->image_lib->initialize($config2);
			
			if($this->image_lib->resize())
			{
				echo$imageThumbName = str_replace(".","_thumb.","$UplodFile");
			}else{
				//print_r($this->image_lib->display_errors());
			}
			
		} else {
			//print_r($this->upload->display_errors());
		}
		//echo $s3file=$path.$actual_image_name;
		echo "<img src='$s3file' style='max-width:400px'/><br/>";
		echo '<b>S3 File URL:</b>'.$s3file;
		//die;
		echo "<br>";
		}
		else
		$msg = "S3 Upload Fail.";
		
		
		}
		else
		$msg = "Image size Max 1 MB";
		
		}
		else
		$msg = "Invalid file, please upload image file.";
		
		}
		else
		$msg = "Please select image file.";

		}
		$thumbName='';
		$returnData['thumbName'] = $imageThumbName;
		$returnData['imgName'] = $UplodFile;
		$returnData['msg'] = $msg;
		//$returnData['imgName'] = $s3file;
		return $returnData;
	}
	
}