<?php
/**
 * Class Getdatamodel
 *
 * This class for the get the data from the database.
 *
 *
 * @package     Qpals
 * @subpackage  Models
 * @category    Authentication
 * @author      Rajesh on 17-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */

class Getdatamodel extends CI_Model
{
	//Database tables Added by Rajesh
	var $user					= "user";
	var $groupMembers			= "groupMembers";
	var $secondaryEmails		= "secondaryEmails";
	var $userFacebook			= "userFacebook";
	var $groups					= "groups";
	var $nonRegGroupMembers 	= "nonRegisteredGroupMembers";
	var $nonRegFBMembers		= "nonRegisteredFBMembers";
	var $userGroupBadges		= "userGroupBadges";
	var $question				= "question";
	var $qPalQ					= "qPalQ";
	var $options				= "options";
	var $recievedQ				= "recievedQ";
	var $nonReceivedQ			= "nonReceivedQ";
	var $nonReceivedFBQ			= "nonReceivedFBQ";
	var $qPalImages				= "qPalImages";
	var $qVotes				    = "qVotes";
    var $userQBadges            = "userQBadges";
    var $predefinedQuestions    = "predefinedQuestions";
    
	function __construct()
	{
		parent::__construct();
	}

	/**
	 * To check whether email and password exists in database or not
	 * @author Rajesh on 17-09-2013
	 * @param $email
	 * @param $password
	 */
	function login($email="", $password="")
	{
		$this->pdo->where('email',$email);
		$this->pdo->where('password',md5($password));
		$query=$this->pdo->get($this->user);
		//echo $this->pdo->last_query();
		$this->pdo->where('email',$email);
		$this->pdo->where('status_ID',1);
		$query1=$this->pdo->get($this->secondaryEmails);
		if($query->num_rows()>0){
			return $query->result_array();
		}else if($query1->num_rows()>0){
			$res=$query1->result_array();
			$userId=$res[0]['user_ID'];
			$this->pdo->where('ID',$userId);
			$this->pdo->where('password',md5($password));
			$query2=$this->pdo->get($this->user);
			if($query2->num_rows()>0){
				return $query2->result_array();
			}else{
				return false;
			}
		}else{
			return false;
		}

	}
	/**
	 * To get Group notifications count for user
	 * @author Rajesh on 17-09-2013
	 */
	function getGroupNotificationCount($userId)
	{
		$this->pdo->where('user_ID', $userId);
		$this->pdo->where('status_ID',2);
		$query=$this->pdo->get($this->groupMembers);
		return $query->num_rows();
	}
	/**
	 * To check Whether primary email exists or not
	 * @author Rajesh on 18-09-2013
	 * @param $encEmail
	 */
	function checkPrimaryEmail($encEmail)
	{
		$this->pdo->where('email',$encEmail);
		$query=$this->pdo->get($this->user);
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	/**
	 * To check Whether email exists in Secondary emails table or not
	 * @author Rajesh on 18-09-2013
	 * @param  $encEmail
	 */
	function checkSecondaryEmail($encEmail, $status)
	{
		$this->pdo->where('email',$encEmail);
		$this->pdo->where('status_ID',$status);
		$query=$this->pdo->get($this->secondaryEmails);
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	/**
	 * To get User details by User id
	 * @author Rajesh on 19-09-2013
	 */
	function getUserDetailsByUserID($userID)
	{
		$this->pdo->where('ID',$userID);
		$query=$this->pdo->get($this->user);
		//echo $this->pdo->last_query();die;
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	/**
	 * TO check ehether user exists or not by Facebook Id
	 * @author Rajesh on 23-09-2013
	 * @param $FBID
	 */
	function checkUserByFBID($FBID)
	{
		$this->pdo->where('FBID',$FBID);
		$query=$this->pdo->get($this->userFacebook);
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}

	}
	/**
	 * To check Whether a Group already exists or not
	 * @author Rajesh on 23-09-2013
	 * @param $userId
	 * @param $groupName
	 */
	function isDuplicateGroup($userId, $groupName)
	{
		$this->pdo->where('name', $groupName);
		$this->pdo->where('user_ID', $userId);
		$query=$this->pdo->get($this->groups);
		if($query->num_rows()>0){
			return true;
		}else {
			return false;
		}
	}
	/**
	 * To check whether User Access Token is Valid or not
	 * @author Rajesh on 24-09-2013
	 * @param $accessToken
	 * @param $userId
	 */
	function isValidToken($accessToken, $userId)
	{
	$this->pdo->where('ID',$userId);
		$this->pdo->where('accessToken',$accessToken);
		$query=$this->pdo->get($this->user);		
		if($query->num_rows()>0){
			foreach($query->result_array() as $toknes){
			$expiry = $this->config->item('tokenExpiry');
			$loggedInDate = date("Y-m-d", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";			
			$todayDate =   date('Y-m-d');
			if(strtotime($loggedInDate) < strtotime($todayDate)){
			return 1;//access token expired	
			}else{
			return 2;//valid token	
			}
		}
		
	}else {
			return 3;//invalid token
		}
	}
	/**
	 * To check whether user exists or not with Email
	 * @author Rajesh on 24-09-2013
	 * @param string $email
	 */
	function checkUserByEmail($email)
	{
		$this->pdo->where('email',$email);
		$query=$this->pdo->get($this->user);
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	/**
	 * To Get User Created Group Details
	 * @author Rajesh on 08-10-2013
	 * @param $userId
	 */
	function getUserCreatedGroupsCount($userId, $searcText="", $offset=0)
	{
		if($searcText){
			$this->pdo->like('g.name', $searcText);
		}
		$this->pdo->select("g.name,g.thumb,g.photo,g.ID,g.status,g.user_ID, ugb.isNew");
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=g.user_ID",'LEFT');
		$this->pdo->where('g.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		$query = $this->pdo->get("$this->groups g");
		return $query->num_rows();

	}
	/**
	 * To Get User Created Group Details
	 * @author Rajesh on 08-10-2013
	 * @param $userId
	 */
	function getUserCreatedGroups($userId, $searcText="", $offset=0)
	{
		if($searcText){
			$this->pdo->like('g.name', $searcText);
		}
		$this->pdo->select("g.name,g.thumb,g.photo,g.ID,g.status,g.user_ID, ugb.isNew");
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=g.user_ID",'LEFT');
		$this->pdo->where('g.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
		if(isset($offset)){
			$query = $this->pdo->get("$this->groups g", 20,$offset);
		}else{
			$query = $this->pdo->get("$this->groups g");
		}
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	
function getUserCreatedGroupsTotalNum($userId, $searcText="", $offset=0)
	{
		if($searcText){
			$this->pdo->like('g.name', $searcText);
		}
		$this->pdo->select("g.name,g.thumb,g.photo,g.ID,g.status,g.user_ID, ugb.isNew");
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=g.user_ID",'LEFT');
		$this->pdo->where('g.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
		if(isset($offset)){
			$query = $this->pdo->get("$this->groups g", 20,$offset);
		}else{
			$query = $this->pdo->get("$this->groups g");
		}
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->num_rows();
		}else {
			return 0;
		}
	}
	
	
	
	
	
/**
	 * To Get User Created Group Details on Web
	 * @author Asha on 03-03-2014
	 * @param $userId
	 */
	function getUserCreatedGroupsOnWeb($userId, $searcText="")
	{
		if($searcText){
			$this->pdo->like('g.name', $searcText);
		}
		$this->pdo->select("g.name,g.thumb,g.photo,g.ID,g.status,g.user_ID, ugb.isNew");
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=g.user_ID",'LEFT');
		$this->pdo->where('g.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
		
			$query = $this->pdo->get("$this->groups g");
		
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	
	
	
	/**
	 * To get Members count of a Group
	 * @author Rajesh on 09-10-2013
	 * @param integer $groupId
	 */
	function getGroupMemnbersCount($groupId)
	{
		$registeredMembers			= $this->pdo->query("SELECT ID FROM $this->groupMembers where group_ID=$groupId and status_ID=1");
		$nonRegisteredMembers 		= $this->pdo->query("SELECT ID FROM $this->nonRegGroupMembers where group_ID=$groupId");
		$nonRegFBMembers			= $this->pdo->query("SELECT ID FROM $this->nonRegFBMembers where group_ID=$groupId");
		$registeredMembersCount		= $registeredMembers->num_rows();
		$nonRegisteredMembersCount 	= $nonRegisteredMembers->num_rows();
		$nonRegFBMembersCount		= $nonRegFBMembers->num_rows();
		$totalCount= $registeredMembersCount+$nonRegisteredMembersCount+$nonRegFBMembersCount;

		return $totalCount;
	}
	/**
	 * To check whether user is Group Creator or not
	 * @author Rajesh on 09-10-2013
	 * @param integer $groupId
	 * @param integer $userId
	 */
	function checkIsGroupCreator($groupId, $userId)
	{
		$this->pdo->where('group_ID', $groupId);
		$this->pdo->where('user_ID', $userId);
		$query=$this->pdo->get($this->groupMembers);
		if($query->num_rows>0){
			$res=$query->result_array();
			return $res[0]['isCreator'];
		}else{
			return 0;
		}

	}
	/**
	 * To Get User joined Groups
	 * @author Rajesh on 09-10-2013
	 * @param $userId
	 */
	function getUserJoinedGroupsCount($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select('g.ID,g.name,g.thumb,g.photo,g.status,gm.user_ID, ugb.isNew');
		$this->pdo->join("$this->groups g", 'g.ID =gm.group_ID ', 'left');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.isCreator', 0);
		$this->pdo->where('g.status', 1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		$query = $this->pdo->get("$this->groupMembers gm");
		return $query->num_rows();
	}
	/**
	 * To Get User joined Groups
	 * @author Rajesh on 09-10-2013
	 * @param $userId
	 */
	function getUserJoinedGroups($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select('g.ID,g.name,g.thumb,g.photo,g.status,gm.user_ID, ugb.isNew');
		$this->pdo->join("$this->groups g", 'g.ID =gm.group_ID ', 'left');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.isCreator', 0);
		$this->pdo->where('g.status', 1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->groupMembers gm",20,$offset);
		}else{
			$query = $this->pdo->get("$this->groupMembers gm");
		}
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}

	}
	
	
function getUserJoinedGroupsTotalNum($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select('g.ID,g.name,g.thumb,g.photo,g.status,gm.user_ID, ugb.isNew');
		$this->pdo->join("$this->groups g", 'g.ID =gm.group_ID ', 'left');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.isCreator', 0);
		$this->pdo->where('g.status', 1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->groupMembers gm",20,$offset);
		}else{
			$query = $this->pdo->get("$this->groupMembers gm");
		}
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}

	}
	
	
/**
	 * To Get User joined Groups on Web
	 * @author Asha on 03-03-2014
	 * @param $userId
	 */
	function getUserJoinedGroupsOnWeb($userId, $searchText="")
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select('g.ID,g.name,g.thumb,g.photo,g.status,gm.user_ID, ugb.isNew');
		$this->pdo->join("$this->groups g", 'g.ID =gm.group_ID ', 'left');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.isCreator', 0);
		$this->pdo->where('g.status', 1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
			$query = $this->pdo->get("$this->groupMembers gm");
		
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}

	}
	
	
	/**
	 * To Get Group Details by Group ID
	 * @author Rajesh on 10-10-2013
	 * @param $groupId
	 */
	function getGroupDetailsById($groupId)
	{
		$this->pdo->where('ID', $groupId);
		$query=$this->pdo->get($this->groups);
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Get Group Members Details by Group ID
	 * @author Rajesh on 10-10-2013
	 * @param $groupId
	 */
	function getGroupMembersDetails($groupId, $isCreator=0)
	{
		$this->pdo->select('u.*, gm.isCreator');
		$this->pdo->join("$this->user u", 'u.ID = gm.user_ID');
		if($isCreator){
			$this->pdo->where('gm.isCreator', 0);
		}
		$this->pdo->where('gm.group_ID', $groupId);
		$this->pdo->where('gm.status_ID',1);
		$this->pdo->group_by('u.ID');

		$query = $this->pdo->get("$this->groupMembers gm");
	//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
			//print_r($vg);die;
		}else{
			return false;
		}
	}
	
	/**
	 * To Get Group Membernames  Details by $emailROw
	 * @author padmaja on 1-07-2014
	 * @param $emailROw
	 */
	function getName($emailROw){
		$query = $this->pdo->query("select firstName from user where email='$emailROw'");
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
/**
	 * To Get Group Membernames  Details by $emailROw
	 * @author padmaja on 9-07-2014
	 * @param $emailROw
	 */
	function getRegDetails($emailROw){
		$query = $this->pdo->query("select * from user where email='$emailROw'");
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
/**
	 * To Get Group Membernames  Details by $emailROw
	 * @author padmaja on 9-07-2014
	 * @param $emailROw
	 */
	function getNonRegDetails($rowID){
		$query = $this->pdo->query("select * from nonRegisteredGroupMembers where ID=$rowID");
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
/**
	 * To Get Group Membernames  Details by $emailROw
	 * @author padmaja on 1-07-2014
	 * @param $emailROw
	 */
	function getNonRegName($emailROw){
		$query = $this->pdo->query("select * from nonRegisteredGroupMembers where email='$emailROw'");
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
/** 
 * To Get Group Member email Id by Id
 * @author Teja 
 * @param $rowID
 */
 
 function getNonRegEmailId($rowID){
		$query = $this->pdo->query("select email,group_id from nonRegisteredGroupMembers where ID='$rowID'");
		//echo $this->pdo->last_query();
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
 
 
	/**
	 * To get Non Regestered Group members details
	 * @author Rajesh on 24-10-2013
	 * @param $groupId
	 */
	 
	function checkunregistereduser($Id)
	{
		$query = $this->pdo->query("select ID from nonRegisteredGroupMembers where ID='$Id'");
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	
	function fetchunregistereduser($Id)
	{
		$query = $this->pdo->query("select ID,name,email,timeStamp,group_ID from nonRegisteredGroupMembers where ID='$Id'");
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
	function inserttousersdata($ID,$name,$email,$groupID,$timestamp,$password,$statusID,$thumb,$photo,$isEmailAlerts,$isPushAlerts,$defaultGroup_ID,$defaultQuestion_ID) 
	{
		
		$query = $this->pdo->query("INSERT INTO user values ('$ID','$name','','$name','','$email','$password','$thumb','$photo',
		 '','','','','','','','','$timestamp','$timestamp','','','','$statusID','$isEmailAlerts','$isPushAlerts','$defaultGroup_ID','','$defaultQuestion_ID') ");
		
		//$query = $this->pdo->query("DELETE from nonRegisteredGroupMembers WHERE ID = '$ID'");
		
		return true;
			
	}
	
	function getId($userName)
	{
		$query = $this->pdo->query("select ID,group_ID from nonRegisteredGroupMembers where name='$userName'");
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
	function getnonRegGroupMembersDetails($groupId)
	{
		$this->pdo->where('group_ID', $groupId);
		$query=$this->pdo->get($this->nonRegGroupMembers);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get NON regiostered FB Group Member details
	 * @author Rajesh on 24-10-2013
	 * @param $groupId
	 */
	function getnonRegFBGroupMembersDetails($groupId)
	{
		$this->pdo->where('group_ID', $groupId);
		$query=$this->pdo->get($this->nonRegFBMembers);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	
	/**
	 * To Get count groups related to user
	 * @author Rajesh on 24-10-2013
	 * @param $groupId
	 */
	function getUserGroupsCount($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select("gm.user_ID,g.name,g.thumb,g.photo,g.ID,g.status,gm.group_ID, ugb.isNew");
		$this->pdo->join("$this->groups g", 'g.ID = gm.group_ID');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->where('g.status',1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		$query = $this->pdo->get("$this->groupMembers gm");
		return $query->num_rows();

	}
	/**
	 * To Get All groups related to user
	 * @author Rajesh on 24-10-2013
	 * @param $groupId
	 */
	function getUserGroups($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select("gm.user_ID,g.name,g.thumb,g.photo,g.ID,g.status,gm.group_ID, ugb.isNew");
		$this->pdo->join("$this->groups g", 'g.ID = gm.group_ID');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->groupMembers gm", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->groupMembers gm");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
function getUserGroupsTotalNum($userId, $searchText="", $offset=0)
	{
		if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		$this->pdo->select("gm.user_ID,g.name,g.thumb,g.photo,g.ID,g.status,gm.group_ID, ugb.isNew");
		$this->pdo->join("$this->groups g", 'g.ID = gm.group_ID');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->groupMembers gm", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->groupMembers gm");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}
	}
	
	
/**
	 * To Get All groups related to user on website
	 * @author Asha on 3-03-2014
	 * @param $groupId
	 */
	function getUserGroupsOnWeb($userId,$searchText)
	{
	    if($searchText){
			$this->pdo->like('g.name', $searchText);
		}
		
		$this->pdo->select("gm.user_ID,g.name,g.thumb,g.photo,g.ID,g.status,gm.group_ID, ugb.isNew");
		$this->pdo->join("$this->groups g", 'g.ID = gm.group_ID');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
		$query = $this->pdo->get("$this->groupMembers gm");
		
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	

	
/**
	 * To Get All groups related to user
	 * @author Asha on 7-2-2014
	 * @param $groupId
	 */
	function getUserGroupsList($userId)
	{
		
		$this->pdo->select("gm.user_ID,g.name,g.thumb,g.photo,g.ID,g.status,gm.group_ID, ugb.isNew");
		$this->pdo->join("$this->groups g", 'g.ID = gm.group_ID');
		$this->pdo->join("$this->userGroupBadges ugb","ugb.user_ID=gm.user_ID",'LEFT');
		$this->pdo->where('gm.user_ID', $userId);
		$this->pdo->where('g.status',1);
		$this->pdo->where('gm.status_ID', 1);
		$this->pdo->order_by('ugb.isNew','DESC');
		$this->pdo->order_by('g.timeStamp','DESC');
		$this->pdo->group_by('g.ID');
		
		$query = $this->pdo->get("$this->groupMembers gm");
		
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
	/**
	 * To Check Duplicate group for user
	 * @author Rajesh on 25-10-2013
	 * @param $userId
	 * @param $groupName
	 * @param $groupId
	 */
	function isUserDuplicateGroup($userId, $groupName, $groupId)
	{
		$this->pdo->where('name', $groupName);
		$this->pdo->where('user_ID', $userId);
		$this->pdo->where_not_in('ID',$groupId);
		$query=$this->pdo->get($this->groups);
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return true;
		}else {
			return false;
		}
	}
	/**
	 * To Get Whether there is a new activity exists or not for Group with user
	 * @author Rajesh on 28-10-2013
	 * @param $userID
	 * @param $groupgID
	 */
	function getUserGroupBadge($userID, $groupID)
	{
		$this->pdo->where('user_ID', $userID);
		$this->pdo->where('group_ID',$groupID);
		$query=$this->pdo->get($this->userGroupBadges);
		//echo $this->pdo->last_query();
		if($query->num_rows()>0){
			return $query->result_array();
		}else {
			return false;
		}
	}
	/**
	 * To get All Preset Questions of Qpals
	 * @author Rajesh on 30-10-2013
	 */
	function getPresetQuestions()
	{
		//$this->pdo->where('qType',1);
		//$query=$this->pdo->get($this->question);
		$query=$this->pdo->get($this->predefinedQuestions);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get Non Regestered Group member details by Email
	 * @author Rajesh on 01-11-2013
	 * @param $email
	 */
	function getnonRegGroupMemberByEmail($email)
	{
		$this->pdo->where('email', $email);
		$query=$this->pdo->get($this->nonRegGroupMembers);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To check whether Group member is deleted or not
	 * @author Rajesh on 05-11-2013
	 * @param $groupId
	 * @param $userId
	 */
	function checkIsGroupMemberDeleted($groupId, $userId)
	{
		$this->pdo->where('user_ID',$userId);
		$this->pdo->where('group_ID',$groupId);
		$query = $this->pdo->get($this->groupMembers);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Check whther user is Mapped with FB id or not
	 * @author Rajesh on 06-11-2013
	 * @param $userId
	 */
	function checkFbUserByUserId($userId)
	{
		$this->pdo->where('user_ID',$userId);
		$query = $this->pdo->get($this->userFacebook);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Get Question Details by ID
	 * @author Rajesh on 07-11-2013
	 * @param $questionId
	 */
	function getQuestionByID($questionId)
	{
		$this->pdo->where('ID',$questionId);
		$query = $this->pdo->get($this->question);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get Secondary Emails with User ID and Activation code
	 * @param $userId
	 * @param $activationCode
	 */
	function getSecondaryEmail($userId, $activationCode)
	{
		$this->pdo->where('user_ID',$userId);
		$this->pdo->where('activationCode',$activationCode);
		$query=$this->pdo->get($this->secondaryEmails);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Get Secondary Email of user
	 * @author Rajesh on 14-11-2013
	 * @param $userId
	 */
	function getSecondaryEmails($userId)
	{
		$this->pdo->where('user_ID',$userId);
		$query=$this->pdo->get($this->secondaryEmails);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Get User Added Questions
	 * @param $userId
	 */
	function getQuestionsByUserId($userId)
	{
		$this->pdo->where('user_ID',$userId);
		$this->pdo->where('isSettingsQuestion',1);
		$this->pdo->where('presetQuestion_Id',0);
		$query = $this->pdo->get($this->question);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 *To get Q options
	 *@author Rajesh on 27-11-2013
	 * @param $qId
	 */
	function getQOptions($qId)
	{
		$this->pdo->where("qPalQ_ID",$qId);
		$query=$this->pdo->get($this->options);
		//echo $this->pdo->last_query();
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get User Created Q's
	 * @author Rajesh on 28-11-2013
	 * @param $userId
	 */
	function getMyQs($userId,$searchText="",$offset=0)
	{   
	    if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID');
		$this->pdo->where('q.user_ID', $userId);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('q.timeStamp','DESC');
		$this->pdo->group_by('q.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->qPalQ q", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->qPalQ q");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
function getCountOfMyQsNum($userId,$searchText="",$offset=0)
	{   
	    if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID');
		$this->pdo->where('q.user_ID', $userId);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('q.timeStamp','DESC');
		$this->pdo->group_by('q.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->qPalQ q", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->qPalQ q");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}
	}
	
	
	
	
	
	
 function getMyQsOnQwall($userId,$searchText="")
	{   
	    if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID');
		$this->pdo->where('q.user_ID', $userId);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('q.timeStamp','DESC');
		$this->pdo->group_by('q.ID');
		$query = $this->pdo->get("$this->qPalQ q");
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
/**
	 * To get User Created Q's in website
	 * @author Asha on 19-02-2014
	 * @param $userId
	 */
	function getMyQsCreated($userId)
	{   
	    
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID');
		$this->pdo->where('q.user_ID', $userId);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('q.timeStamp','DESC');
		$this->pdo->group_by('q.ID');
		
		$query = $this->pdo->get("$this->qPalQ q");
		
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get User Recieved Q's
	 * @author Rajesh on 28-11-2013
	 * @param $userId
	 */
	function getrecievedQs($userId,$offset=0)
	{   $this->pdo->distinct();
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('rq.user_ID', $userId);
		$this->pdo->where('rq.status',1);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('rq.timeStamp','DESC');
		$this->pdo->group_by('rq.ID');
		if(isset($offset)){
			$query = $this->pdo->get("$this->recievedQ rq", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->recievedQ rq");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
/**
	 * To get User Recieved Q's on website
	 * @author Asha on 28-11-2013
	 * @param $userId
	 */
	function getUserRecievedQs($userId)
	{
		
		$this->pdo->distinct();// Added by padmaja on 18-06-2014
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('rq.user_ID', $userId);
		$this->pdo->where('rq.status',1);
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('rq.timeStamp','DESC');
		$this->pdo->group_by('rq.ID');
		
			$query = $this->pdo->get("$this->recievedQ rq");
		
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
/**
	 * To get User Replied Q's
	 * @author Asha on 16-1-2014
	 * @param $userId
	 */
	function getrepliedQs($userId,$searchText="",$offset=0)
	{
	   if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}	
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->qPalQ q", 'qv.qID = q.ID');
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('qv.userID', $userId);
		$this->pdo->where('q.user_ID != userID');
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('qv.timeStamp','DESC');
		
		
		
		if(isset($offset)){
			$query = $this->pdo->get("$this->qVotes qv", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->qVotes qv");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
function getCountOfRepliedQsNum($userId,$searchText="",$offset=0)
	{
	   if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}	
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->qPalQ q", 'qv.qID = q.ID');
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('qv.userID', $userId);
		$this->pdo->where('q.user_ID != userID');
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('qv.timeStamp','DESC');
		
		
		
		if(isset($offset)){
			$query = $this->pdo->get("$this->qVotes qv", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->qVotes qv");
		}
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}
	}
	
	
	
	
	
	
	
	
	
	
  function getrepliedQsOnQwall($userId,$searchText="",$offset=0)
	{
	   if($searchText){
			$this->pdo->like('qsn.name', $searchText);
		}	
		
		$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->join("$this->qPalQ q", 'qv.qID = q.ID');
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('qv.userID', $userId);
		$this->pdo->where('q.user_ID != userID');
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('qv.timeStamp','DESC');
		
		
		
		
			$query = $this->pdo->get("$this->qVotes qv");
		
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	/**
	 * To Get Q images
	 * @author Rajesh on 28-11-2013
	 * @param $qId
	 */
	function getQImages($qId)
	{
		$this->pdo->distinct();
		$this->pdo->where("qPalQ_ID",$qId);
		$query=$this->pdo->get($this->options);
		//echo $this->pdo->last_query();die;
		if($query->num_rows > 0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get Non Recieved Q's
	 * @author Rajesh on 28-11-2013
	 * @param $encEmail
	 */
	function getNonRecievedQs($encEmail)
	{
		$this->pdo->where("email",$encEmail);
		$query=$this->pdo->get($this->nonReceivedQ);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To get non Recieved FBQ's
	 * @author Rajesh on 28-11-2013
	 * @param $FBID
	 */
	function getNonRecievedFBQs($FBID)
	{
		$this->pdo->where("FBID",$FBID);
		$query=$this->pdo->get($this->nonReceivedFBQ);
		if($query->num_rows>0){
			return $query->result_array();
		}else{
			return false;
		}
	}
	/**
	 * To Get Total count of MY Q's
	 * @author Rajesh on 28-11-2013
	 * @param $userId
	 */
	function getTotCountOfMyQs($userId)
	{
		$this->pdo->where("user_ID",$userId);
		$this->pdo->where('status',1);
		$query=$this->pdo->get($this->qPalQ);
		//echo $this->pdo->last_query();die;
		return $query->num_rows();
	}
	/**
	 * To Get Total count of Recieved Q's
	 * @author Rajesh on 28-11-2013
	 * @param $userId
	 */
	function getTotCountOfRecievedQs($userId)
	{
		
		$this->pdo->group_by('qPalQ_ID');// Added by Padmaja on 18-06-2014
		$this->pdo->where("user_ID",$userId);
		$query=$this->pdo->get($this->recievedQ);
		return $query->num_rows();
	}
	
/**
	 * To Get Total count of Replied Q's
	 * @author Rajesh on 16-1-2014
	 * @param $userId
	 */
	function getTotCountOfRepliedQs($userId)
	{
	   $this->pdo->select("q.ID");
		$this->pdo->join("$this->qPalQ q", 'qv.qID = q.ID');
	#	$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		$this->pdo->where('qv.userID', $userId);
		$this->pdo->where('q.user_ID != userID');
		$this->pdo->where('q.status',1);
		$this->pdo->order_by('qv.timeStamp','DESC');
		
		
		
		if(isset($offset)){
			$query = $this->pdo->get("$this->qVotes qv", 20, $offset);
		}else{
			$query = $this->pdo->get("$this->qVotes qv");
		}
		
		return $query->num_rows();
	}
	
	/**
	 * To Get Total count of Q's related to user
	 * @author Rajesh on 29-11-2013
	 * @param $userId
	 */
	function getTotCountOfQs($userId)
	{
		$count1=$this->getTotCountOfMyQs($userId);
		$count2=$this->getTotCountOfRecievedQs($userId);
		$totCount=$count1+$count2;
		return $totCount;
	}
	/**
	 * To Get All Q's Related to user
	 * @author rajesh on 29-11-2013
	 * @param $userId
	 * @param $offset
	 */
	function getTotalQs($userId,$searchText="",$offset=0)
	{
		 /*$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		 $this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		 $this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		 $this->pdo->or_where('rq.user_ID', $userId);
		 $this->pdo->or_where('q.user_ID', $userId);
		 $this->pdo->where('rq.status',1);
		 $this->pdo->order_by('rq.timeStamp','DESC');
		 $this->pdo->group_by('rq.ID');
		 if(isset($offset)){
			$query = $this->pdo->get("$this->recievedQ rq", 20, $offset);
			}else{
			$query = $this->pdo->get("$this->recievedQ rq");
			}
			echo $this->pdo->last_query();*/
		
	  if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}
		
		if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		$query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE (rq.user_ID=$userId OR q.user_ID=$userId)  $search group by ID order by q.timeStamp desc $limit");
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	/*
	 * To get private Qs of user
	 * @Author Asha on 18-3-2014
	 */
	
/**
	 * To Get All Q's Related to user
	 * @author rajesh on 29-11-2013
	 * @param $userId
	 * @param $offset
	 */
	function getPrivateQs($userId,$searchText="",$offset=0)
	{
		 /*$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		 $this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		 $this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		 $this->pdo->or_where('rq.user_ID', $userId);
		 $this->pdo->or_where('q.user_ID', $userId);
		 $this->pdo->where('rq.status',1);
		 $this->pdo->order_by('rq.timeStamp','DESC');
		 $this->pdo->group_by('rq.ID');
		 if(isset($offset)){
			$query = $this->pdo->get("$this->recievedQ rq", 20, $offset);
			}else{
			$query = $this->pdo->get("$this->recievedQ rq");
			}
			echo $this->pdo->last_query();*/
		
	  if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}
		
		if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
	$query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE (rq.user_ID=$userId OR q.user_ID=$userId) AND qPalQGroup_ID!=0 AND q.status=1 $search group by ID order by q.timeStamp desc $limit");
		//echo $this->pdo->last_query();die;


/*	 $query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE rq.user_ID=$userId  AND qPalQGroup_ID!=0 AND q.status=1 $search group by ID order by q.timeStamp desc $limit");*/

		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
	
function getCountOfPrivateQs($userId)
	{
		 /*$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		 $this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		 $this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		 $this->pdo->or_where('rq.user_ID', $userId);
		 $this->pdo->or_where('q.user_ID', $userId);
		 $this->pdo->where('rq.status',1);
		 $this->pdo->order_by('rq.timeStamp','DESC');
		 $this->pdo->group_by('rq.ID');
		 if(isset($offset)){
			$query = $this->pdo->get("$this->recievedQ rq", 20, $offset);
			}else{
			$query = $this->pdo->get("$this->recievedQ rq");
			}
			echo $this->pdo->last_query();*/
		
	 
/*		$query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE rq.user_ID=$userId  AND qPalQGroup_ID!=0 AND q.status=1  group by ID order by q.timeStamp desc");
*/

 $query=$this->pdo->query("SELECT  q.ID FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID WHERE (rq.user_ID=$userId  OR q.user_ID=$userId )  AND q.qPalQGroup_ID!=0 AND q.status=1 group by q.ID  ");


		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}
	}
	
	
	
	function getCountOfPrivateQsNum($userId,$searchText="",$offset=0)
	{
		 /*$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		 $this->pdo->join("$this->qPalQ q", 'rq.qPalQ_ID = q.ID');
		 $this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID' );
		 $this->pdo->or_where('rq.user_ID', $userId);
		 $this->pdo->or_where('q.user_ID', $userId);
		 $this->pdo->where('rq.status',1);
		 $this->pdo->order_by('rq.timeStamp','DESC');
		 $this->pdo->group_by('rq.ID');
		 if(isset($offset)){
			$query = $this->pdo->get("$this->recievedQ rq", 20, $offset);
			}else{
			$query = $this->pdo->get("$this->recievedQ rq");
			}
			echo $this->pdo->last_query();*/
		
	  if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}
		
		if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		$query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE (rq.user_ID=$userId OR q.user_ID=$userId) AND qPalQGroup_ID!=0 AND q.status=1 $search group by ID order by q.timeStamp desc $limit");
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->num_rows();
		}else{
			return 0;
		}
	}
	
	
	
	
	
	
/**
	 * To Get All Q's Related to user on website
	 * @author Asha 
	 * @param $userId
	 * @param $offset
	 */
	function getTotalQsOnQwall($userId,$searchText="")
	{
		
	  if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}
		
/*		$query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE (rq.user_ID=$userId OR q.user_ID=$userId) AND qPalQGroup_ID!=0 AND q.status=1 $search group by ID order by q.timeStamp desc");
*/

  $query=$this->pdo->query("SELECT  qsn.name,q.ID, q.user_ID, q.timeStamp,rq.user_ID as rqUserId
FROM qPalQ q LEFT JOIN recievedQ rq ON q.ID=rq.qPalQ_ID
LEFT JOIN question qsn ON q.question_ID=qsn.ID
WHERE (rq.user_ID=$userId OR q.user_ID=$userId)  AND qPalQGroup_ID!=0 AND q.status=1 $search group by ID order by q.timeStamp desc");

		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	
	
	/**
	 * To Get All Qpals Images
	 * @author Rajesh on 30-11-2013
	 */
	function getQpalImages()
	{
		$query=$this->pdo->get($this->qPalImages);
		if($query->num_rows>0){

			return $query->result_array();
		}else{
			return false;
		}
	}
	
	/*
	 * To get FbShare for Qpals User
	 * @author Asha on 25-12-2013
	 */
	 
	function getFbShare($userId,$qId){
		
		$this->pdo->where("user_ID",$userId);
		$this->pdo->where("ID",$qId);		
		$query=$this->pdo->get($this->qPalQ);
		
		if($query->num_rows>0){
			
			return $query->result_array();
			
		}else{
			
			return false;
		}
		
	}
	
	
/*
	 * To get Qpals Question to share on FB
	 * @author Asha on 25-12-2013
	 */
	 
	function getQQuestion($quesId){
		
		$this->pdo->where("ID",$quesId);		
		$query=$this->pdo->get($this->question);
		
		if($query->num_rows>0){
			
			return $query->result_array();
			
		}else{
			
			return false;
		}
		
	}
	
	
/*
	 * To get Qpals Question to share on FB
	 * @author Asha on 26-12-2013
	 */
	 
     function getTwitterShare($userId,$qId){
		
		$this->pdo->where("user_ID",$userId);
		$this->pdo->where("ID",$qId);		
		$query=$this->pdo->get($this->qPalQ);
		//echo $this->pdo->last_query();die;
		if($query->num_rows>0){
			
			return $query->result_array();
			
		}else{
			
			return false;
		}
		
	}
	
	
	/*
	 * To get count of  options for Q
	 * @Author Asha on 6-1-2014
	 */
	
	function qpalsCountOptions($qId){
		
	  $query=$this->pdo->query("SELECT COUNT( optionName ) as optionName FROM options WHERE  `qPalQ_ID`=$qId and optionName!=''");
	  $res=$query->result_array();
	 	
	
		
	 if($query->num_rows>0){
			return  $res;
			
		}else{
			
		return false;	
	 }
		
 }
 
/*
	 * To get count of  options for Q
	 * @Author Asha on 6-1-2014
	 */
	
	function qpalsCountImages($qId){
		
	  $query=$this->pdo->query("SELECT COUNT( thumb ) as thumb FROM options WHERE  `qPalQ_ID`=$qId and thumb!=''");
	  $res=$query->result_array();
	 	
	 
		
	 if($query->num_rows>0){
			return  $res;
			
		}else{
			
		return false;	
	 }
		
 }
 
  /*
   * To fetch user Id from access token
   * @Author Asha on 6-1-2014
   */
   function getUserId($accessToken){
   	
   	 $this->pdo->where('accessToken',$accessToken);
   	 $query=$this->pdo->get($this->user);
   	 
   	  if($query->num_rows > 0){
   	  	return $query->result_array();
   	  }else{
   	  	return false;
   	  }
   }
   
   /*
    * To get the details of Q
    * @Author Asha on 6-1-2014
    */
   
    function getQdetails($qId){
    	$this->pdo->select("qsn.name,q.ID,q.user_ID,q.timeStamp");
		$this->pdo->from("$this->qPalQ q");
		$this->pdo->join("$this->question qsn", 'q.question_ID = qsn.ID','rq.qPalQ_ID = $qId' );
		$this->pdo->where('q.ID', $qId);		
		$query = $this->pdo->get();
		//echo $this->pdo->last_query();die;
        if($query->num_rows > 0){
   	  	 return $query->result_array();
   	    }else{
   	  	return false;
   	   }
		
    }
    
    /*
     * To get options datails of Q
     * @Author Asha on 6-1-2014
     */
    
    function getQOption($qId){
    	
    	$this->pdo->where("qPalQ_ID",$qId);
    	$query=$this->pdo->get($this->options);
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		return false;
    	}
    }
    
    /*
     * To get Age of a Q
     * @Author Asha on 7-1-2014
     */
    
 function getQAge($time1, $time2, $precision = 6){
    // If not numeric then convert texts to unix timestamps
if (!is_int($time1)) {
$time1 = strtotime($time1);
}
if (!is_int($time2)) {
$time2 = strtotime($time2);
}

// If time1 is bigger than time2
// Then swap time1 and time2
if ($time1 > $time2) {
$ttime = $time1;
$time1 = $time2;
$time2 = $ttime;
}

// Set up intervals and diffs arrays
// added week in the array for getting the weeks by harika on 22-12-2011
$intervals = array('year','month','week','day','hour','minute');
$diffs = array();

// Loop thru all intervals
foreach ($intervals as $interval) {
// Set default diff to 0
$diffs[$interval] = 0;

// Create temp time from time1 and interval
$ttime = strtotime("+1 " . $interval, $time1);
// Loop until temp time is smaller than time2
while ($time2 >= $ttime) {
$time1 = $ttime;
$diffs[$interval]++;
// Create new temp time from time1 and interval
$ttime = strtotime("+1 " . $interval, $time1);
}
}
$count = 0;
$times = array();
// Loop thru all diffs
foreach ($diffs as $interval => $value) {
// Break if we have needed precission
if ($count >= $precision) {
break;
}
// Add value and interval
// if value is bigger than 0
if ($value > 0) {
// Add s if value is not 1
if ($value != 1) {
$interval .= "";
}
// Add value and interval to times array
$times[] = $value . " " . $interval;
$count++;
}
}

//this condition is to return the time with out seconds--- added by--- ganesh on 29-11-2011
$sz = sizeof($times);
if($sz == 0) {
$tm="Just now";
}
else
{
$tm=$times[0];
//$tm = implode(", ", $times);
$tm = str_replace("hour","hour ago",$tm);
$tm = str_replace("minute","minute ago",$tm);
// replace short cuts .. added by harika on 22-12-2011 ...
$tm = str_replace("week","week ago",$tm);
$tm = str_replace("month","month ago",$tm);
$tm = str_replace("day","day ago",$tm);
$tm = str_replace("year","year ago",$tm);
}
//print_r($tm);die;
// Return string with times
return $tm;
    
    
    
    	
    }
    
    
    /*
     * To get user Id based on QId
     * @Author Asha on 8-1-2014
     */
    
    
    function getUserIdFromQId($qId){
    	
        $this->pdo->where("ID",$qId);
    	$query=$this->pdo->get($this->qPalQ);
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		return false;
    	}
    	
    }
    
  /*
     * To get option type for vote
     * @Author Asha on 10-1-2014
     */
    
    
    function getOptionType($qId){
    	
        $this->pdo->where("qPalQ_ID",$qId);
    	$query=$this->pdo->get($this->options);
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		return false;
    	}
    	
    }
    
    function getCountQOptions($qId){
    	$query=$this->pdo->query("select * from options where qPalQ_ID=$qId");
    	$res=$query->num_rows();
    	
    	if($query->num_rows > 0){
    		
    		return $res;
    		
    	}
    	
    }
    
    /*
     * To get vote count from qvotes
     * @Author Asha on 15-1-2014
     */
    
    function getCountQVotes($qId,$userId){
    	
    	$query=$this->pdo->query("select count(*) as qCount from qVotes where qID=$qId and userID=$userId");
    	
    	//var_dump($res);die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		//var_dump($query->result_array);die;
    		
    	}else{
    		return false;
    	}
    	
    }
    

    
/*
     * To get vote count from qvotes
     * @Author Asha on 15-1-2014
     */
    
    function getCountQVotesOptions($qId,$userId,$votedOption){
    	
    	$query=$this->pdo->query("select count(*) as qCount from qVotes where qID=$qId and userID=$userId and votedOption=$votedOption");
    	//echo $this->pdo->last_query();die;
    	//var_dump($res);die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		//var_dump($query->result_array);die;
    		
    	}else{
    		return false;
    	}
    	
    }
    
    
    function getAggregateVotes($qId){
    	
    	$query=$this->pdo->query("select * from aggregateVotes where q_ID=$qId");
    	//echo $this->pdo->last_query();
    	if($query->num_rows > 0){
    	   
    		return $query->result_array();
    		
    	}else{
    		return false;
    	}
    	
    }
    
    
    /*
     * To get Qid using the groupId
     * @Author Asha on 17-1-2014
     */
    
    function getQPalQID($groupId){
    	
    	$query=$this->pdo->query("select ID from qPalQ where qPalQGroup_ID=$groupId");
    	
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		return false;
    	}
    	
    	
    }
    
    
 /*
     * To get Most Popular Users(Max no of followers)
     * @Author Asha on 21-1-2014
     */
    
    function getMostPopular($userId, $searchText="" ,$offset=0){
    	
    if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}	
        
		
    	//$query=$this->pdo->query("SELECT  `followers_ID` FROM  `followers` WHERE  `followers_ID`!=$userId GROUP BY  `followers_ID` ORDER BY COUNT( * ) DESC $limit");
    	$query=$this->pdo->query("SELECT f.followers_ID FROM followers f LEFT JOIN user u ON f.followers_ID = u.ID
                                 WHERE  `followers_ID` !=$userId $search GROUP BY  `followers_ID` 
                                 ORDER BY COUNT( * ) DESC $limit");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		
    		return false;
    	}
    }
    
    
  function getMostPopularTotalNum($userId, $searchText="" ,$offset=0){
    	
    if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}	
        
		
    	//$query=$this->pdo->query("SELECT  `followers_ID` FROM  `followers` WHERE  `followers_ID`!=$userId GROUP BY  `followers_ID` ORDER BY COUNT( * ) DESC $limit");
    	$query=$this->pdo->query("SELECT f.followers_ID FROM followers f LEFT JOIN user u ON f.followers_ID = u.ID
                                 WHERE  `followers_ID` !=$userId $search GROUP BY  `followers_ID` 
                                 ORDER BY COUNT( * ) DESC $limit");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    	}else{
    		
    		return 0;
    	}
    }
    
    
    
    
    
    
    
    
  function getMostPopularOnWeb($userId, $searchText=""){
    	
  if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}	
        
		
    	//$query=$this->pdo->query("SELECT  `followers_ID` FROM  `followers` WHERE  `followers_ID`!=$userId GROUP BY  `followers_ID` ORDER BY COUNT( * ) DESC $limit");
    	$query=$this->pdo->query("SELECT f.followers_ID FROM followers f LEFT JOIN user u ON f.followers_ID = u.ID
                                 WHERE  `followers_ID` !=$userId $search GROUP BY  `followers_ID` 
                                 ORDER BY COUNT( * ) DESC");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		
    		return false;
    	}
    }
    
    
    
    
    
    
/*
     * To get count of Most Popular(count of max number of followers)
     * @Author Asha on 20-1-2014
     */
    
    function getCountOfMostPopular($userId){
    	
    	$query=$this->pdo->query("SELECT  `followers_ID` FROM  `followers` WHERE  `followers_ID`!=$userId GROUP BY  `followers_ID` ORDER BY COUNT( * ) DESC");
    	
    	if($query->num_rows > 0){
    		
    		return $query->num_rows;
    	}else{
    		
    		return 0;
    	}
    }
    
    /*
     * To get Most Active Users(created max no of Q's)
     * @Author Asha on 20-1-2014
     */
    
    function getMostActiveUsers($userId, $searchText="" ,$offset=0){

    if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}    	
    	
    if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
    	
    	//$query=$this->pdo->query("SELECT  `user_ID` FROM qPalQ where user_ID!=$userId  GROUP BY user_ID ORDER BY COUNT( * ) DESC $limit" );
    	  $query=$this->pdo->query("SELECT q.user_ID FROM qPalQ q LEFT JOIN user u ON q.user_ID = u.ID 
    	                            WHERE q.user_ID !=1 $search GROUP BY q.user_ID
                                    ORDER BY COUNT( * ) DESC $limit");
    	  //echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		
    		return false;
    	}
    }
    
    
    function getMostActiveUsersTotalNum($userId, $searchText="" ,$offset=0){

    if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}    	
    	
    if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
    	
    	//$query=$this->pdo->query("SELECT  `user_ID` FROM qPalQ where user_ID!=$userId  GROUP BY user_ID ORDER BY COUNT( * ) DESC $limit" );
    	  $query=$this->pdo->query("SELECT q.user_ID FROM qPalQ q LEFT JOIN user u ON q.user_ID = u.ID 
    	                            WHERE q.user_ID !=1 $search GROUP BY q.user_ID
                                    ORDER BY COUNT( * ) DESC $limit");
    	  //echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    	}else{
    		
    		return 0;
    	}
    }
    
    
    
    
    
    
 function getMostActiveUsersOnWeb($userId, $searchText=""){

    if($searchText){		
        	$search="AND u.displayName LIKE '%$searchText%'";
		}else{
			$search='';
		}    	
    	
    
    	//$query=$this->pdo->query("SELECT  `user_ID` FROM qPalQ where user_ID!=$userId  GROUP BY user_ID ORDER BY COUNT( * ) DESC $limit" );
    	  $query=$this->pdo->query("SELECT q.user_ID FROM qPalQ q LEFT JOIN user u ON q.user_ID = u.ID 
    	                            WHERE q.user_ID !=1 $search GROUP BY q.user_ID
                                    ORDER BY COUNT( * ) DESC");
    	  //echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    	}else{
    		
    		return false;
    	}
    }
    
    
    
    
/*
     * To get count of Most Active Users(created max no of Q's)
     * @Author Asha on 20-1-2014
     */
    
    function getCountOfMostActiveUsers($userId){
    	
    	$query=$this->pdo->query("SELECT  `user_ID` FROM qPalQ where user_ID!=$userId GROUP BY user_ID ORDER BY COUNT( * ) DESC" );
    	
    	if($query->num_rows > 0){
    		
    		return $query->num_rows;
    	}else{
    		
    		return 0;
    	}
    }
    
    /*
     * To get new pals
     * @Author Asha on 20-1-2014
     */
    
    
    function getNewPals($userId, $searchText="" ,$offset=0){
    	
    if($searchText){		
        	$search="AND displayName LIKE '%$searchText%'";
		}else{
			$search='';
		} 
    	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
    	$query=$this->pdo->query("SELECT ID FROM  `user` where ID!=$userId $search ORDER BY  `ID` DESC $limit");
    	
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
    }
    
    
function getNewPalsTotalNum($userId, $searchText="" ,$offset=0){
    	
    if($searchText){		
        	$search="AND displayName LIKE '%$searchText%'";
		}else{
			$search='';
		} 
    	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
    	$query=$this->pdo->query("SELECT ID FROM  `user` where ID!=$userId $search ORDER BY  `ID` DESC $limit");
    	
    	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return 0;
    	}
    }
    
    
    
    
function getNewPalsOnWeb($userId, $searchText=""){
    	
    if($searchText){		
        	$search="AND displayName LIKE '%$searchText%'";
		}else{
			$search='';
		} 
    	
    
		
    	$query=$this->pdo->query("SELECT ID FROM  `user` where ID!=$userId $search ORDER BY  `ID` DESC");
    	
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
    }
    
/*
     * To get count of new pals
     * @Author Asha on 20-1-2014
     */
    
    
    function getCountOFNewPals($userId){
    	
    	$query=$this->pdo->query("SELECT ID FROM  `user` where ID!=$userId ORDER BY  `ID` DESC");
    	
    	if($query->num_rows > 0){
    		
    		return $query->num_rows;
    		
    	}else{
    		
    		return 0;
    	}
    }
    
    /*
     * TO get count of followers
     * @Author Asha on 21-1-2014
     */
    
    function getTotCountOfFollowers($userId){
    	
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `followers_ID` =$userId");
        if($query->num_rows > 0){
    		
    		return $query->num_rows;
    		
    	}else{
    		
    		return NULL;
    	}
    	
    }
    
    /*
     * To get followers of the user
     * @Author Asha on 22-1-2014
     */
    
     function followersOfPal($friend_ID,$offset=0){
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
     
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `followers_ID` =$friend_ID  $limit");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
/*
     * To get followers of the user
     * @Author Asha on 22-1-2014
     */
    
     function followersOfPals($friend_ID){
     	
     
     
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `followers_ID` =$friend_ID");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
 /*
     * To get count of followers of the user
     * @Author Asha on 22-1-2014
     */
    
     function getCountOffollowers($friend_ID){
     	
     
     
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `followers_ID` =$friend_ID");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     
 /*
     * To get following result
     * @Author Asha on 22-1-2014
     */
    
     function followingPals($friend_ID,$offset=0){
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
     
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `user_ID`=$friend_ID  $limit");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     /*
     * To get following result
     * @Author Asha on 22-1-2014
     */
    
     function followingPal($friend_ID,$offset=0){
     	
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `user_ID`=$friend_ID");
    	//echo "jk";
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     
/*
     * To get count of following result
     * @Author Asha on 22-1-2014
     */
    
     function countOFfollowingPals($friend_ID){
     	
     
     
    	$query=$this->pdo->query("SELECT * FROM  `followers` WHERE  `user_ID`=$friend_ID");
    	//echo $this->pdo->last_query();die;
    	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
    /*
     * To get public Q
     * @Author Asha on 22-1-2014
     */
    
     function getPublicQ($friend_ID,$offset=0){
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
     	
      $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp FROM qPalQ q LEFT JOIN question qsn ON q.question_ID = qsn.ID
                                WHERE q.isPublic =1 and q.user_ID=$friend_ID AND q.status=1 ORDER BY q.timeStamp DESC $limit");
      
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
function getPublicQOnWebsite($friend_ID){
     	
     
     	
      $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp FROM qPalQ q LEFT JOIN question qsn ON q.question_ID = qsn.ID
                                WHERE q.isPublic =1 and q.user_ID=$friend_ID AND q.status=1 ORDER BY q.timeStamp DESC");
      
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     
     /*
     * To get count of  public Q
     * @Author Asha on 22-1-2014
     */
    
     function getCountOFPublicQ($friend_ID){
     	
      $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp FROM qPalQ q LEFT JOIN question qsn ON q.question_ID = qsn.ID
                                WHERE q.isPublic =1 and q.user_ID=$friend_ID AND q.status=1 ORDER BY q.timeStamp DESC");
      
      if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
/*
     * To get recived Q for Pal
     * @Author Asha on 22-1-2014
     */
    
     function getReceivedQForPal($friend_ID,$userId,$offset=0){
     	
      	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                               FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID LEFT JOIN question qsn ON q.question_ID = qsn.ID
                               WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 ORDER BY q.timeStamp DESC $limit");
      
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     
function getReceivedQForPalOnWeb($friend_ID,$userId){
     	
      	
     
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                               FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID LEFT JOIN question qsn ON q.question_ID = qsn.ID
                               WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 ORDER BY q.timeStamp DESC");
      
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
    
     
/*
     * To get count of recived Q for Pal
     * @Author Asha on 22-1-2014
     */
    
     function countOfReceivedQForPal($friend_ID,$userId){
     	
      	
     
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                               FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID LEFT JOIN question qsn ON q.question_ID = qsn.ID
                               WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 ORDER BY q.timeStamp DESC");
      
      if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
          
    /*
     * To get recived Q and Public Q for Pal
     * @Author Asha on 22-1-2014
     */
    
     function getPublicReceived($friend_ID,$userId,$offset=0){
     	
      	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                                FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID OR q.isPublic =1
                                LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 GROUP BY q.ID
                                ORDER BY q.timeStamp DESC $limit");
      //echo $this->pdo->last_query();die;
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
 function getPublicReceivedOnWeb($friend_ID,$userId){
     	
      	
     
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                                FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID OR q.isPublic =1
                                LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 GROUP BY q.ID
                                ORDER BY q.timeStamp DESC");
      //echo $this->pdo->last_query();die;
      if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
      /*
     * To get Count of recived Q and Public Q for Pal
     * @Author Asha on 22-1-2014
     */
    
     function getCountOfPublicReceived($friend_ID,$userId){
     	
      $query=$this->pdo->query("SELECT qsn.name AS quename, q.ID AS QpalId, q.user_ID QpalUserId, q.timeStamp, rq.user_ID AS rqUserId
                                FROM qPalQ q RIGHT JOIN recievedQ rq ON q.ID = rq.qPalQ_ID OR q.isPublic =1
                                LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE (rq.user_ID =$userId and q.user_ID=$friend_ID) AND q.status=1 GROUP BY q.ID
                                ORDER BY q.timeStamp DESC");
      //echo $this->pdo->last_query();die;
      if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     /*
      * To get the follow status of the pal
      * @Author on 24-1-2014
      */
    
     function getFollowStatus($user_ID,$friend_ID){
     	
     	$query=$this->pdo->query("select * from followers where user_ID=$user_ID and followers_ID=$friend_ID");
     //echo $this->pdo->last_query();die;
     	
     	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     function countOfImages($qId){//count of Images if there is a null or not
     	
     $query=$this->pdo->query("SELECT *  FROM  `options` WHERE  `qPalQ_ID` =$qId AND  `thumb` IS NOT NULL");
     	if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
 function getNotNullImages($qId){//count of Images if there is a null or not
     	
     $query=$this->pdo->query("SELECT * FROM  `options` WHERE  `qPalQ_ID` =$qId AND  `thumb` IS NOT NULL");
     	if($query->num_rows > 0){
    		
    		return $query->result_array();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     
     /*
      * To get public Q's
      * @Author Asha on 31-1-2014
      */
     
     function getPublicQs($searchText=""){
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}
     	$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp
                                  FROM qPalQ q LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE q.isPublic =1 AND q.status=1 $search GROUP BY q.ID
                                  ORDER BY RAND( ) LIMIT 20");
     	
     	if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     }
     
     function countOfPublicQs(){
     //return 20;	
     $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp
                                  FROM qPalQ q LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE q.isPublic =1 AND q.status=1 GROUP BY q.ID
                                  ORDER BY RAND( ) LIMIT 20");
     	
     	if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return 0;
     	}
     	
     }
     
     /*
      * Get Q badges
      * @Author Asha on 3-1-2014
      */
     
     function getUserQBadge($userId,$qId){
     	
     	$this->pdo->where('user_ID',$userId);
     	$this->pdo->where('qPalQ_ID',$qId);
     	$query=$this->pdo->get($this->userQBadges);
     	//echo $this->pdo->last_query();die;
     	if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     
     /*
      * to get favourite status
      * @Author Asha 0n 4-2-2014
      */
     
     function getFavouriteStatus($qId,$userId){
     	
     	$query=$this->pdo->query("select * from favourites where qPalQ_ID=$qId and user_ID=$userId");
        if($query->num_rows > 0){
    		
    		return $query->num_rows();
    		
    	}else{
    		
    		return false;
    	}
     	
     }
     
     /*
      *get Favorites of user
      *@Author asha on 4-2-2014
      */
     
     function getFavorites($userId,$searchText="",$offset=0){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     	
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.user_ID AS fuserId
                                  FROM favourites f LEFT JOIN qPalQ q ON q.ID = f.qPalQ_ID LEFT JOIN 
                                  question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId AND q.status=1 $search ORDER BY
                                   q.timeStamp DESC $limit");
		
     if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
		
		
     	
     }
     
     
function getCountofFavoritesNum($userId,$searchText="",$offset=0){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     	
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.user_ID AS fuserId
                                  FROM favourites f LEFT JOIN qPalQ q ON q.ID = f.qPalQ_ID LEFT JOIN 
                                  question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId AND q.status=1 $search ORDER BY
                                   q.timeStamp DESC $limit");
		
     if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return 0;
     	}
		
		
     	
     }
     
     
     
     
     
  function getFavoritesOnQwall($userId,$searchText=""){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     	
     	
    
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.user_ID AS fuserId
                                  FROM favourites f LEFT JOIN qPalQ q ON q.ID = f.qPalQ_ID LEFT JOIN 
                                  question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId AND q.status=1 $search ORDER BY
                                   q.timeStamp DESC");
		
     if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
		
		
     	
     }
     
     /*
      * get favourites count
      * @Author Asha on 4-2-2014
      */
     
     function getCountOfFavourites($userId){
     	
     $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.user_ID AS fuserId
                                  FROM favourites f LEFT JOIN qPalQ q ON q.ID = f.qPalQ_ID LEFT JOIN 
                                  question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId AND q.status=1 ORDER BY
                                   q.timeStamp DESC");
		
     if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return 0;
     	}
     	
     }
     
     /*
      * to get default preset question
      * @Authoe Asha on 5-2-2014
      */
     
     function getIsDefaultQuestion($questionId,$userId){
     	
     	$query=$this->pdo->query("select * from question where presetQuestion_Id=$questionId and user_ID=$userId");
     	
       if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return false;
     	}
     }
     
     /*
      * To get followed in myQs
      * @Author Asha on 7-2-2014
      */
     
     function getMyQFollowed($userId,$searchText="",$offset=0){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     	
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.followers_ID AS fuId
                                  FROM followers f LEFT JOIN qPalQ q ON f.followers_ID = q.`user_ID` 
                                  LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId
                                  AND q.`isPublic` =1 AND q.status=1 $search $limit");
		
     if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     
     
     
     
 function getCountofMyQFollowedNum($userId,$searchText="",$offset=0){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	
     	
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,20";
		}else{
			$limit="";
		}
		
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.followers_ID AS fuId
                                  FROM followers f LEFT JOIN qPalQ q ON f.followers_ID = q.`user_ID` 
                                  LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId
                                  AND q.`isPublic` =1 AND q.status=1 $search $limit");
		
     if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return 0;
     	}
     	
     }
     
     
     
     
     
     
     
     
     
     
     
     
 function getMyQFollowedOnQwall($userId,$searchText=""){
     	
     if($searchText){		
        	$search="AND qsn.name LIKE '%$searchText%'";
		}else{
			$search='';
		}	 	
     	
     
		
		$query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.followers_ID AS fuId
                                  FROM followers f LEFT JOIN qPalQ q ON f.followers_ID = q.`user_ID` 
                                  LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId
                                  AND q.`isPublic` =1 AND q.status=1 $search");
		
     if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     
     
     
     
   function getCountOfMyQFollowed($userId){
     	
     $query=$this->pdo->query("SELECT qsn.name, q.ID, q.user_ID, q.timeStamp, f.followers_ID AS fuId
                                  FROM followers f LEFT JOIN qPalQ q ON f.followers_ID = q.`user_ID` 
                                  LEFT JOIN question qsn ON q.question_ID = qsn.ID WHERE f.user_ID =$userId
                                  AND q.`isPublic` =1 AND q.status=1");
		
     if($query->num_rows > 0){
     		
     		return $query->num_rows();
     		
     	}else{
     		return 0;
     	}
     	
     }
    
    /*
     * To create room for chat using QId
     * @Author Asha on 21-2-2014
     */
     
     function fetchPrivateGroupId($qId){
     	
     	$query=$this->pdo->query("select qPalQGroup_ID from qPalQ where ID=$qId");
     	
        if($query->num_rows > 0){
     		
     	   return $query->result_array();
     		
     	}else{
     	   return false;
     	}
     	
     }
     
     /*
      * display Room Name for Private group members only
      * @Author Asha 0n 21-2-2014
      */
     
     function getPrivateGroupMembers($qId){
     	
     	$query=$this->pdo->query("SELECT gm.user_ID,gm.group_ID FROM qPalQ q JOIN groupMembers gm 
     	                          ON q.qPalQGroup_ID = gm.group_ID WHERE q.ID =$qId");
     	//echo $this->pdo->last_query();die;
     	
      if($query->num_rows > 0){
     		
     	   return $query->result_array();
     		
     	}else{
     	   return false;
     	}
     	
     	
     }
	
     /*
      * @Author Asha 0m 26-2-2014
      * search a friend
      */
     
     function searchFriend($searchText, $sesUserId,$email){
     	
     	$query=$this->pdo->query("SELECT u.thumb, u.displayName, f.`followers_ID` FROM followers f
                                 JOIN user u ON f.`followers_ID` = u.ID WHERE f.`user_ID` = $sesUserId
                                 AND (u.displayName LIKE  '%$searchText%' OR u.firstName LIKE  '%$searchText%' or u.email LIKE '%$email%')");
       //echo $this->pdo->last_query();die;
      if($query->num_rows > 0){
     		
     	   return $query->result_array();
     		
     	}else{
     	   return false;
     	}
     	
     	
     	
     }
     
     
 /*
      * @Author Asha 0m 26-2-2014
      * search a friend
      */
     
     function searchFriendInFollower($searchText, $sesUserId,$email){
     	
     	$query=$this->pdo->query("SELECT u.thumb, u.displayName, f.`user_ID` FROM followers f
                                 JOIN user u ON f.`user_ID` = u.ID WHERE f.`followers_ID` = $sesUserId
                                 AND (u.displayName LIKE  '%$searchText%' OR u.firstName LIKE  '%$searchText%' or u.email LIKE '%$email%')");
       //echo $this->pdo->last_query();die;
      if($query->num_rows > 0){
     		
     	   return $query->result_array();
     		
     	}else{
     	   return false;
     	}
     	
     	
     	
     }
	
     /*
      * @Author Asha on 12-3-2014
      * function to get social comments
      * 
      */
     
     function getSocialComments($qId,$userId){
     	
     	$query=$this->pdo->query("SELECT u.thumb, u.displayName, c.comments FROM socialQComments c
                                 JOIN user u ON u.ID = c.userId WHERE c.qId =$qId 
                                 ");
     	
        if($query->num_rows > 0){
     		
     	   return $query->result_array();
     		
     	}else{
     	   return false;
     	}
     	
     }
     
     function countOfSocialComments($qId){
     	
     	$query=$this->pdo->query("SELECT * from socialQComments where qId=$qId");
     	
       if($query->num_rows > 0){
     		
     	   return $query->num_rows();
     		
     	}else{
     	   return 0;
     	}
     	
    }
    
 function getSocialQComments($qId,$offset=0){     	
     	
     if(isset($offset)){
			//$limit="LIMIT 0,20";
			$limit="LIMIT $offset,100";
		}else{
			$limit="";
		}
		
		$query=$this->pdo->query("SELECT u.thumb, u.displayName, c.comments,c.qId,c.userId FROM socialQComments c
                                 JOIN user u ON u.ID = c.userId WHERE c.qId =$qId 
                                 $limit");
		//echo $this->pdo->last_query();die;
     if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     
     function getVoteSourceType($qId,$userId){
     	$query=$this->pdo->query("select * from qVotes where qId=$qId and userId=$userId");
        if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     
     /*
      * function to get members voted for the Q
      * @Author Asha on 9-4-2014
      */
     function getVotedPalsForQ($qId,$optionId){

     	$query=$this->pdo->query("select userID from qVotes where qID=$qId and votedOption=$optionId");
     	if($query->num_rows > 0){
     		return $query->result_array();
     	}else{
     		return false;
     	}
     }
     
     function getQuestionName($questionId){
          
     	$query=$this->pdo->query("select * from predefinedQuestions where ID=$questionId");
     	
     	if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
     	
     }
     /*getting checked following data
      * @author :Padmaja
      */
     function getCheckedFData($groupMemberData){
     	$this->pdo->where('user_ID',$groupMemberData['user_ID']);
     	$this->pdo->where('group_ID',$groupMemberData['group_ID']);
 		$query=$this->pdo->get($this->groupMembers);
    	 if($query->num_rows > 0){
     		
     		return $query->result_array();
     		
     	}else{
     		return false;
     	}
 		
     }
     

     
     
	//--------------------------------------------------------------
}
