<?php //if(!defined ('BASEPATH') exit('No direct script access allowed');

class Messagequeue extends CI_Model {


//////



function __Construct()
{
	parent::__Construct();
	log_message('debug',"Initializing MessageQueue");

	// $this->memcache_apns = memcache_connect($this->config->item('apnsQueue'));
	// $this->memcache_gcm = memcache_connect($this->config->item('gcmQueue'));
	// $this->memcache_wpns = memcache_connect($this->config->item('winQueue'));
	// $this->memcache_mail = memcache_connect($this->config->item('emailQueue'));
	

}

public function addMessageToAPNSQueue($message)
{

	log_message('debug',"In apns QUEUE - $message");

	$key_prefix = "apns-queue";
	$total_sleep = 100000;
	while ($total_sleep >0)
	{
	 $lock_key = $this->memcache_apns->increment("$key_prefix-lock");

	if (empty($lock_key))
	{
		#echo "not defined in lock";
		$this->memcache_apns->set("$key_prefix-lock",$lock_key=1);
		$this->memcache_apns->set("$key_prefix-curr",0);
		break;
	}
	elseif ($lock_key==1)
	{
		break;
	}

	$total_sleep -= 1000;
	usleep(1000);
	}        
          
	if ($total_sleep <=0)
        {
	//indefinite lock
	log_message("The queue is locked.Exiting .....");
	}   
    
	$next_key = $this->memcache_apns->increment("$key_prefix-curr");
	if (empty($next_key))
	{   
	#echo "not defined in key"; 
	$this->memcache_apns->set("$key_prefix-curr",1);
	}
	$key = sprintf("$key_prefix-key-%d",$next_key);

	$this->memcache_apns->set($key,$message);
	$this->memcache_apns->set("$key_prefix-lock",0);

}
public function ejabberdlogout(){

$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL,"http://54.173.184.199:5280/unregister_device");
					curl_setopt($ch, CURLOPT_POST, 1);
					
					curl_setopt($ch, CURLOPT_HTTPHEADER, array(
																'Content-Type: application/x-www-form-urlencoded',
																'Connection: Keep-Alive'
																));
											
					curl_setopt($ch, CURLOPT_POSTFIELDS,
								"token=$pushId&type=$deviceType&server=$server&key=$key");

					//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

					$server_output = curl_exec ($ch);
					
						
					curl_close ($ch);

}
public function registerDeviceToEjabberd($data){

//$data 				= json_decode($data,true);
$username 			= str_replace(' ', '', $data[0]);
$name				= strtolower($username);
$password			= $data[1];
$pushId				= $data[2];
$deviceType			= $data[3];
$server 			= 'chat.qpals.com';
$key 				= 123456;

//$string = str_replace(' ', '', $fullName);	
$req_dump = $name;
$a = $password;
$b = $pushId;
$c = $pushId;
$d = $deviceType;

 // $fp = fopen('/var/www/logs/android.log', 'a+');
	// fwrite($fp, $req_dump);
	// fwrite($fp, $a);
	// fwrite($fp, $b);
	// fwrite($fp, $c);
	// fwrite($fp, $d);
		// //fclose($fp);
$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL,"http://54.173.184.199:5280/register");
					curl_setopt($ch, CURLOPT_POST, 1);
					
					curl_setopt($ch, CURLOPT_HTTPHEADER, array(
																'Content-Type: application/x-www-form-urlencoded',
																'Connection: Keep-Alive'
																));
											
					curl_setopt($ch, CURLOPT_POSTFIELDS,
								"user=$name&pswd=$password&server=$server&token=$pushId&type=$deviceType&key=$key");

					//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

					$server_output = curl_exec ($ch);
					 curl_close($ch);
				 
}
public function addMessageToC2DMQueue($message)

{

$json 		= json_decode($message,true);
$sender 	= $json['sender'];
$to			= $json['to'];
$server 	= 'chat.qpals.com';
$mess		= $json['message'];
$param		= $json['qId'];
$typeId		= $json['typeID'];
$key		= 123456;
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL,"http://54.173.184.199:5280/push_device");
	curl_setopt($ch, CURLOPT_POST, 1);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
												'Content-Type: application/x-www-form-urlencoded',
												'Connection: Keep-Alive'
												));
							
	curl_setopt($ch, CURLOPT_POSTFIELDS,
				"sender=$sender&to=$to&server=$server&msg=$mess&param=$param&type_id=$typeId&key=$key");

	//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$server_output = curl_exec ($ch);

	curl_close ($ch);

/*

log_message('debug',"In gcm QUEUE                  - $message");

$key_prefix = "gcm-queue";
$total_sleep = 100000;
	while ($total_sleep >0)
	{
		 $lock_key = $this->memcache_gcm->increment("$key_prefix-lock");
		if (empty($lock_key))
		{
			#echo "not defined in lock";
			$this->memcache_gcm->set("$key_prefix-lock",$lock_key=1);
			$this->memcache_gcm->set("$key_prefix-curr",0);
			break;
		}
		elseif ($lock_key==1)
		{
			break;
		}
		$total_sleep -= 1000;
		 usleep(1000);
	}

	if ($total_sleep <=0)

	{
	//indefinite lock
	#echo "The queue is locked.Exiting .....";
	}

	 $next_key = $this->memcache_gcm->increment("$key_prefix-curr");
	log_message('debug' ,"gcm ------ $next_key");

	if (empty($next_key))
	{
		#echo "not defined in key"; 
		$this->memcache_gcm->set("$key_prefix-curr",1);
	}
	$key = sprintf("$key_prefix-key-%d",$next_key);
	$this->memcache_gcm->set($key,$message);
	$this->memcache_gcm->set("$key_prefix-lock",0);
	*/
}




public function addMessageToWinQueue($message)

{
log_message('debug',"In wpns QUEUE                  - $message");

$key_prefix = "wpns-queue";
$total_sleep = 100000;
while ($total_sleep >0)
{
 $lock_key = $this->memcache_wpns->increment("$key_prefix-lock");

if (empty($lock_key))
{
#echo "not defined in lock";
$this->memcache_wpns->set("$key_prefix-lock",$lock_key=1);
$this->memcache_wpns->set("$key_prefix-curr",0);
break;

}
elseif ($lock_key==1){
break;

}

$total_sleep -= 1000;
 usleep(1000);
}

if ($total_sleep <=0)

{

//indefinite lock
#echo "The queue is locked.Exiting .....";

}

 $next_key = $this->memcache_wpns->increment("$key_prefix-curr");
if (empty($next_key))
{
#echo "not defined in key"; 
$this->memcache_wpns->set("$key_prefix-curr",1);

}
$key = sprintf("$key_prefix-key-%d",$next_key);

$this->memcache_wpns->set($key,$message);
$this->memcache_wpns->set("$key_prefix-lock",0);


}


public function addMessageToMAILQueue($message)

{

	log_message('debug',"In mail  QUEUE- $message");

	$key_prefix = "mail-queue";
	$total_sleep = 100000;
        while ($total_sleep >0)
        {
                 $lock_key = $this->memcache_mail->increment("$key_prefix-lock");
                if (empty($lock_key))
                {
                        #echo "not defined in lock";
                        $this->memcache_mail->set("$key_prefix-lock",$lock_key=1);
                        $this->memcache_mail->set("$key_prefix-curr",0);
                        break;
                }
                elseif ($lock_key==1)
                {
                        break;
                }
                $total_sleep -= 1000;
                 usleep(1000);
        }

        if ($total_sleep <=0)

        {
        //indefinite lock
        #echo "The queue is locked.Exiting .....";
        }

         $next_key = $this->memcache_mail->increment("$key_prefix-curr");
        log_message('debug' ,"gcm ------ $next_key");

        if (empty($next_key))
        {
                #echo "not defined in key"; 
                $this->memcache_mail->set("$key_prefix-curr",1);

        }
        $key = sprintf("$key_prefix-key-%d",$next_key);
        $this->memcache_mail->set($key,$message);
        $this->memcache_mail->set("$key_prefix-lock",0);
}




}
