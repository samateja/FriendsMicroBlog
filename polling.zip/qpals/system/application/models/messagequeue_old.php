<?php //if(!defined ('BASEPATH') exit('No direct script access allowed');


class Messagequeue extends CI_Model {


//////



function __Construct()
{
	parent::__Construct();
	log_message('debug',"Initializing MessageQueue");

	//$this->memcache_apns = memcache_connect($this->config->item('apnsQueue'));
	//$this->memcache_gcm = memcache_connect($this->config->item('gcmQueue'));
	//$this->memcache_wpns = memcache_connect($this->config->item('winQueue'));
	//$this->memcache_mail = memcache_connect($this->config->item('emailQueue'));

}

public function addMessageToAPNSQueue($message)
{

	log_message('debug',"In apns QUEUE - $message");

	$key_prefix = "apns-queue";
	$total_sleep = 100000;
	while ($total_sleep >0)
	{
	 $lock_key = $this->memcache_apns->increment("$key_prefix-lock");

	if (empty($lock_key))
	{
		#echo "not defined in lock";
		$this->memcache_apns->set("$key_prefix-lock",$lock_key=1);
		$this->memcache_apns->set("$key_prefix-curr",0);
		break;
	}
	elseif ($lock_key==1)
	{
		break;
	}

	$total_sleep -= 1000;
	usleep(1000);
	}        
          
	if ($total_sleep <=0)
        {
	//indefinite lock
	log_message("The queue is locked.Exiting .....");
	}   
    
	$next_key = $this->memcache_apns->increment("$key_prefix-curr");
	if (empty($next_key))
	{   
	#echo "not defined in key"; 
	$this->memcache_apns->set("$key_prefix-curr",1);
	}
	$key = sprintf("$key_prefix-key-%d",$next_key);

	$this->memcache_apns->set($key,$message);
	$this->memcache_apns->set("$key_prefix-lock",0);

}

public function addMessageToC2DMQueue($message)

{

log_message('debug',"In gcm QUEUE                  - $message");

$key_prefix = "gcm-queue";
$total_sleep = 100000;
	while ($total_sleep >0)
	{
		 $lock_key = $this->memcache_gcm->increment("$key_prefix-lock");
		if (empty($lock_key))
		{
			#echo "not defined in lock";
			$this->memcache_gcm->set("$key_prefix-lock",$lock_key=1);
			$this->memcache_gcm->set("$key_prefix-curr",0);
			break;
		}
		elseif ($lock_key==1)
		{
			break;
		}
		$total_sleep -= 1000;
		 usleep(1000);
	}

	if ($total_sleep <=0)

	{
	//indefinite lock
	#echo "The queue is locked.Exiting .....";
	}

	 $next_key = $this->memcache_gcm->increment("$key_prefix-curr");
	log_message('debug' ,"gcm ------ $next_key");

	if (empty($next_key))
	{
		#echo "not defined in key"; 
		$this->memcache_gcm->set("$key_prefix-curr",1);
	}
	$key = sprintf("$key_prefix-key-%d",$next_key);
	$this->memcache_gcm->set($key,$message);
	$this->memcache_gcm->set("$key_prefix-lock",0);
}




public function addMessageToWinQueue($message)

{
log_message('debug',"In wpns QUEUE                  - $message");

$key_prefix = "wpns-queue";
$total_sleep = 100000;
while ($total_sleep >0)
{
 $lock_key = $this->memcache_wpns->increment("$key_prefix-lock");

if (empty($lock_key))
{
#echo "not defined in lock";
$this->memcache_wpns->set("$key_prefix-lock",$lock_key=1);
$this->memcache_wpns->set("$key_prefix-curr",0);
break;

}
elseif ($lock_key==1){
break;

}

$total_sleep -= 1000;
 usleep(1000);
}

if ($total_sleep <=0)

{

//indefinite lock
#echo "The queue is locked.Exiting .....";

}

 $next_key = $this->memcache_wpns->increment("$key_prefix-curr");
if (empty($next_key))
{
#echo "not defined in key"; 
$this->memcache_wpns->set("$key_prefix-curr",1);

}
$key = sprintf("$key_prefix-key-%d",$next_key);

$this->memcache_wpns->set($key,$message);
$this->memcache_wpns->set("$key_prefix-lock",0);


}


public function addMessageToMAILQueue($message)
{
	
	$json = json_decode($message, true);
	$isHtml = true;
	$to = urlencode($json['to']);
	$subject = urlencode($json['subject']);
	$content = urlencode($json['body']);

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL,"http://59.177.89.249:5280/push_email");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
												'Content-Type: application/x-www-form-urlencoded',
												'Connection: Keep-Alive'
												));
	curl_setopt($ch, CURLOPT_POSTFIELDS,
				"to=$to&sub=$subject&content=$content&key=123456");

	// in real life you should use something like:
	// curl_setopt($ch, CURLOPT_POSTFIELDS, 
	//          http_build_query(array('postvar1' => 'value1')));

	// receive server response ...
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$server_output = curl_exec ($ch);

	//var_dump($server_output);

	curl_close ($ch);

	/* further processing ....
	if ($server_output == "OK") { 
		echo "Success";
	 } else 
	 { 
		echo "Failed";
	 }
*/
	//var_dump($head);
/*
	if ( mail ( $to, $json['subject'], $json['body']) ) {
		//echo "Mail sent successfully!<br>\n";
	} else {
		echo "Mail sending failed :(<br>\n";
	}
	*/
/*
	$key_prefix = "mail-queue";
	$total_sleep = 100000;
        while ($total_sleep >0)
        {
                 $lock_key = $this->memcache_mail->increment("$key_prefix-lock");
                if (empty($lock_key))
                {
                        #echo "not defined in lock";
                        $this->memcache_mail->set("$key_prefix-lock",$lock_key=1);
                        $this->memcache_mail->set("$key_prefix-curr",0);
                        break;
                }
                elseif ($lock_key==1)
                {
                        break;
                }
                $total_sleep -= 1000;
                 usleep(1000);
        }

        if ($total_sleep <=0)

        {
        //indefinite lock
        #echo "The queue is locked.Exiting .....";
        }

         $next_key = $this->memcache_mail->increment("$key_prefix-curr");
        log_message('debug' ,"gcm ------ $next_key");

        if (empty($next_key))
        {
                #echo "not defined in key"; 
                $this->memcache_mail->set("$key_prefix-curr",1);

        }
        $key = sprintf("$key_prefix-key-%d",$next_key);
        $this->memcache_mail->set($key,$message);
        $this->memcache_mail->set("$key_prefix-lock",0);
    */
}




}
