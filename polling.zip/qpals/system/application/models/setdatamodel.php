<?php
/**
 * Class Setdatamodel
 *
 * This class is to set the data in database.
 *
 *
 * @package     Qpals
 * @subpackage  Models
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */

class Setdatamodel extends CI_Model
{
	//Database tables Added by Rajesh
	var $user						= "user";
	var $groupMembers				= "groupMembers";
	var $secondaryEmails			= "secondaryEmails";
	var $userFacebook				= "userFacebook";
	var $groups						= "groups";
	var $nonRegisteredFBMembers 	= "nonRegisteredFBMembers";
	var $nonRegisteredGroupMembers 	= "nonRegisteredGroupMembers";
	var $userGroupBadges			= "userGroupBadges";	
	var $followers					= "followers";
	var $question					= "question";
	var $qPalQ						= "qPalQ";
	var $options					= "options";
	var $recievedQ					= "recievedQ";
	var $nonReceivedQ				= "nonReceivedQ";
	var $nonReceivedFBQ				= "nonReceivedFBQ";
	var $qVotes                     = "qVotes";
	var $userQBadges                = "userQBadges";
	var $favourites                 = "favourites";
	var $socialQComments            = "socialQComments";
	
	/** initialises the class inheriting the methods of the class Model
	*
	* @return Usermodel
	*/
	function __construct()
	{
		parent::__construct();
		$this->load->model('getdatamodel');
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$this->_S3Url = $this->config->item('S3Url');
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
	}
	/**
	 * To store user details into user table
	 * @param arrat type $userInsertData
	 */
	function registerUser($userInsertData)
	{
		//print_r($userInsertData);
		
		$this->pdo->insert($this->user, $userInsertData);
		//echo $this->pdo->last_query();die;
		$userId=$this->pdo->insert_id();
		
		return $userId;
		//ejabberd code added by Asha on 20-3-2014
		
						$chatHost = $this->config->item('XMPP_SERVER_HOST');	
						$param = array("user"=>$userId,"host"=>$chatHost,"password"=>$userInsertData['password']);
						$request = xmlrpc_encode_request('register', $param, (array('encoding' => 'utf-8')));
						$context = stream_context_create(array('http' => array(
	                                                     'method' => "POST",
	                                                     'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
				                                         "Content-Type: text/xml\r\n" .
				                                         "Content-Length: ".strlen($request),
	                                                     'content' => $request
                                                          )));
                                                          
                    $path=$this->config->item('XMPP_RPC_SERVER_HOST');                                     
					$file = file_get_contents($path.'/RPC2', false, $context);
                    $response = xmlrpc_decode($file); 

                   if (xmlrpc_is_fault($response)) {
	                   trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
                   } 
		return $this->pdo->insert_id();
	}
	
	
	/**
	 * To update new password to user
	 * @author Rajesh on 19-09-2013
	 * @param $password
	 */
	function updateUserData($userdata)
	{
	//	var_dump($userdata);die;
		$this->pdo->where('ID',$userdata['ID']);
		$this->pdo->update($this->user,$userdata);
		//echo $this->pdo->last_query();
		if (isset($userdata['password']))
	       {	
		 //ejabberd code added by karthik on 16-6-2014 - to update password for user in ejabberd server
                                             /*   $chatHost = $this->config->item('XMPP_SERVER_HOST');
                                                $param = array("user"=>$userdata['ID'],"host"=>$chatHost,"newpass"=>$userdata['password']);
                                                $request = xmlrpc_encode_request('change_password', $param, (array('encoding' => 'utf-8')));
                                                $context = stream_context_create(array('http' => array(
                                                             'method' => "POST",
                                                             'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
                                                                         "Content-Type: text/xml\r\n" .
                                                                         "Content-Length: ".strlen($request),
                                                             'content' => $request
                                                          )));

                    $path=$this->config->item('XMPP_RPC_SERVER_HOST');
                                        $file = file_get_contents($path.'/RPC2', false, $context);
                    $response = xmlrpc_decode($file);

                   if (xmlrpc_is_fault($response)) {
                           trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
                   }
*/

 $chatHost = $this->config->item('XMPP_DB_HOST');
 $con= mysqli_connect($chatHost,"admin", "Oxalic_336","ejabberd") or die(mysql_error());
 $password = $userdata['password']; 
 $userID = $userdata['ID'];
$query = "UPDATE users SET password='$password'  WHERE username='$userID'";  
$con->query($query);
 mysqli_close($con);
}

		return true;
	}
	
    /**
	 * To update Qpals auth token to user
	 * @author Asha on 19-12-2013
	 * @param $password
	 */
	function updateAuthToken($tokenData)
	{
		$this->pdo->where('ID',$tokenData['ID']);		
		$this->pdo->update($this->user,$tokenData);		
		return true;
	}
	
	
	/**
	 * To insert FB user mapping
	 * @author Rajesh on 23-09-2013
	 * @param $insertData
	 */
	function inserUserFBMapping($insertData)
	{
		$this->pdo->insert($this->userFacebook, $insertData);
		//echo $this->pdo->last_query();die;
		return $this->pdo->insert_id();
	}
	
	/**
	 * To update FbAccess Token
	 * @author Asha on 19-09-2013
	 * @param $updateData
	 */
	
	function updateUserFbMapping($updateData)
	{
		$this->pdo->where('FBID',$updateData['FBID']);
		$this->pdo->update($this->userFacebook,$updateData);
		return true;
	}	
	/**
	 * This function is to upload image
	 * @author Rajesh on 23-09-2013
	 * @param $FILES (an array of the uploaded file details) , $fieldName (varchar) 
	 * @return $returnData (an array contains the image name and image thumb name)
	 */
	// This function is modified by Padmaja for implementing s3 amazon functionality
	
	
	function uploadImage($FILES, $fieldName, $uploadFolder)
	 {
		//print_r($_FILES);die;
	 	$imgName = "";
	 	$imageThumbName = "";
	 	
		$fileName = $FILES[$fieldName]['name'];
		$fileType = $FILES[$fieldName]['type'];
		$extension = end(explode('.',$fileName));
		
		$currEncTimestamp = str_split(sha1(microtime()),10);
		$newFileName = $currEncTimestamp[0];
		
		$upldFileName = $newFileName.'.'.$extension;
		//echo FCPATH.'Uploads/'.$uploadFolder;die;
		/*
		 * Added by Padmaja
		 */
		$bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
		$ext = $this->getExtension($fileName);
		$s3 = new S3($awsAccessKey, $awsSecretKey);
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
		$actual_image_name = time().".".$ext;
		
		$imgConfig['upload_path']		= FCPATH.'Uploads/'.$uploadFolder;
		//$imgConfig['allowed_types']		= 'jpeg|jpg|png';
		$imgConfig['allowed_types']		=0;
		$imgConfig['file_name']     	= $upldFileName;
		

		$this->load->library('upload',$imgConfig);
		$this->upload->initialize($imgConfig);
		
		$fileType = $FILES[$fieldName]['type'];
		// uploading the image
		$isImgUploaded = $this->upload->do_upload($fieldName);
		if(!$isImgUploaded){
		echo $this->upload->display_errors();
		}	
		if($isImgUploaded)  {
			
			$uploadedData = $this->upload->data();
			$imgName 	= $uploadedData['file_name'];
			$thumbName = str_replace(".","_thumb2x.","$imgName");
			$rebnameThumb=str_replace(".","_thumb2x_thumb.",$imgName);
			$config1['image_library'] 	= 'gd2';
			$config1['source_image']  	= FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName;
			$config1['create_thumb']  	= TRUE;
			$config1['new_image'] 		= $thumbName;
			$config1['maintain_ratio'] 	= FALSE;
			
			$config1['width'] 			= 400;
			$config1['height'] 			= 400;
			
			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			//$this->image_lib->clear($config1);
			//var_dump($this->image_lib->resize());
			if($this->image_lib->resize())
			{
				rename(FCPATH.'Uploads/'.$uploadFolder.'/'.$rebnameThumb, FCPATH.'Uploads/'.$uploadFolder.'/'.$thumbName);
			}else{
				//print_r($this->image_lib->display_errors());
			}
			//echo $imgName;
			$filePath = FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName;
			if($s3->putObjectFile($filePath, $bucket , $imgName, S3::ACL_PUBLIC_READ) )
		   	{	
		   		$s3file=$this->_S3Url.$imgName;
		   	}
			$this->image_lib->clear();
			
			$thumbName = str_replace(".","_thumb.","$imgName");
			$config2['image_library'] 	= 'gd2';
			$config2['source_image']  	= FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName;
			$config2['create_thumb']  	= TRUE;
			$config1['new_image'] 		= $thumbName;
			$config2['maintain_ratio'] 	= FALSE;
			
			$config2['width'] 			= 200;
			$config2['height'] 			= 200;

			$this->load->library('image_lib', $config2);
			$this->image_lib->initialize($config2);
			
			if($this->image_lib->resize())
			{
				$imageThumbName = str_replace(".","_thumb.","$imgName");
			}else{
				//print_r($this->image_lib->display_errors());
			}
			$filePath1 = FCPATH.'Uploads/'.$uploadFolder.'/'.$imageThumbName;
			if($s3->putObjectFile($filePath1, $bucket , $imageThumbName, S3::ACL_PUBLIC_READ) )
		   	{	
		   		$s3file=$this->_S3Url.$imageThumbName;
		   	}
			
		} else {
			//print_r($this->upload->display_errors());
		}
		//die;
		unlink(FCPATH.'Uploads/'.$uploadFolder.'/'.$imgName);
		unlink(FCPATH.'Uploads/'.$uploadFolder.'/'.$imageThumbName);
		$returnData['imgName'] = $imgName;
		$returnData['thumbName'] = $imageThumbName;
		
		return $returnData;
 	}
	

 	
 	/*	For s3amazon images extension 
 	 * @author Padmaja on 04-07-2014
 	 */
	function getExtension($str) 
		{
         $i = strrpos($str,".");
         if (!$i) { return ""; } 

         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
		}
 	/**
 	 * To store Group into database 
 	 * @author Rajesh on 23-09-2013
 	 * @param $insertGroupData
 	 */
 	function insertGroup($insertGroupData)
 	{
 		$this->pdo->insert($this->groups, $insertGroupData);
		return $this->pdo->insert_id();
 	}
 	/**
 	 * To store Registered Group member data in Database
 	 * @author Rajesh on 24-09-2013
 	 * @param $groupMemberData
 	 */
 	function insertRegisteredGroupMemberMapping($groupMemberData)
 	{
 		$this->pdo->where('user_ID',$groupMemberData['user_ID']);
 		$this->pdo->where('group_ID',$groupMemberData['group_ID']);
 		$query=$this->pdo->get($this->groupMembers);
 		if($query->num_rows()==0){
 		$this->pdo->insert($this->groupMembers, $groupMemberData);
 		//echo $this->pdo->last_query();
		return $this->pdo->insert_id();
 		}else{
 			$updateMemberData=array('status_ID'=>1);
 			$this->pdo->update($this->groupMembers, $updateMemberData);
 			//echo $this->pdo->last_query();
 		}
 	}
 	/**
 	 * To store NonRegistered Fb member group mapping
 	 * @author Rajesh on 24-09-2013
 	 * @param $fbMemberData
 	 */
 	function insertNonRegisteredFBMember($fbMemberData)
 	{
 		$this->pdo->where('FBID',$fbMemberData['FBID']);
 		$this->pdo->where('group_ID',$fbMemberData['group_ID']);
 		$query=$this->pdo->get($this->nonRegisteredFBMembers);
 		if($query->num_rows()==0){
 		$this->pdo->insert($this->nonRegisteredFBMembers, $fbMemberData);
		return $this->pdo->insert_id();
 		}
 	}
 	/**
 	 * To store Non Registered Group members in database
 	 * @author Rajesh on 24-09-2013
 	 * @param $groupMemberData
 	 */
 	function insertNonRegisteredGroupMember($groupMemberData)
 	{
 		$this->pdo->where('email',$groupMemberData['email']);
 		$this->pdo->where('group_ID',$groupMemberData['group_ID']);
 		$query=$this->pdo->get($this->nonRegisteredGroupMembers);
 		if($query->num_rows()==0){
 		$this->pdo->insert($this->nonRegisteredGroupMembers, $groupMemberData);
		return $this->pdo->insert_id();
 		}
 	}
 	/**
 	 * To update Group data in Group table
 	 * @author Rajesh on 25-09-2013
 	 * @param array $groupData
 	 */
 	function updateGroup($groupData)
 	{
 		$this->pdo->where('ID',$groupData['ID']);
		$this->pdo->update($this->groups,$groupData);
		return true;
 	}
	/**
 	 * To mapp User facebook id to user
 	 * @author Rajesh on 22-09-2013
 	 * @param $userData
 	 */
 	function userFBMapping($userData)
 	{
 		$fbId	= $userData['FBID'];
 		$userId = $userData['user_ID'];
 		//$this->pdo->where('FBID',$groupMemberData['email']);
 		$this->pdo->where('user_ID',$userId);
 		$query=$this->pdo->get($this->userFacebook);
 		if($query->num_rows()==0){
 		$this->pdo->insert($this->userFacebook, $userData);
		//return $this->pdo->insert_id();
 		}else{
 		$this->pdo->where('user_ID',$userId);
		$this->pdo->update($this->userFacebook,$userData);
 		}
 	}
	/**
 	 * To Delete Group
 	 * @author Rajesh on 23-10-2103 
 	 * @param $groupId
 	 */
 	function deleteGroup($groupId)
 	{
 		$groupData=array('status'=>0);
 		$this->pdo->where('ID',$groupId);
		$this->pdo->update($this->groups,$groupData);
		//echo $this->pdo->last_query();die;
		return true;
 	}
	/**
	 * To Delete Non registered Member
	 * @author Rajesh on 25-10-2013
	 * @param $encEmail
	 */
	function deleteNonRegisteredMemeber($encEmail)
	{
		$this->pdo->where('email',$encEmail);
		$query=$this->pdo->get($this->nonRegisteredGroupMembers);
		if($query->num_rows()>0){
			$this->pdo->where('email',$encEmail);
			$this->pdo->delete($this->nonRegisteredGroupMembers);
		}
	}
	/**
	 * To Delete Non registered FB Member
	 * @author Rajesh on 25-10-2013
	 * @param $FBID
	 */
	function deleteNonRegisteredFBMemeber($FBID)
	{
		$this->pdo->where('FBID',$FBID);
		$query=$this->pdo->get($this->nonRegisteredFBMembers);
		if($query->num_rows()>0){
			$this->pdo->where('FBID',$FBID);
			$this->pdo->delete($this->nonRegisteredFBMembers);
		}
	}
	/**
	 * To Delete user from Group
	 * @author Rajesh on 25-10-2013
	 * @param $userId
	 * @param $groupId
	 */
	function deleteUserFromGroup($userId, $groupId)
	{
		$groupData=array('status_ID'=>0);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->where('user_ID',$userId);
		$this->pdo->update($this->groupMembers,$groupData);
		return true;
	}
	/**
	 * To Delete FB user form Group
	 * @author Rajesh on 25-10-2013
	 * @param $fbId
	 * @param $groupId
	 */
	function deleteFbUserFromGroup($fbId, $groupId)
	{
		$groupData=array('status_ID'=>0);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->where('FBID',$fbId);
		$this->pdo->delete($this->nonRegisteredFBMembers);
		return true;
	}
	/**
	 * To delete Non registered user from Group
	 * @author Rajesh on 25-10-2013
	 * @param unknown_type $email
	 * @param unknown_type $groupId
	 */
	function deleteNonRegisteredGroupMemebers($email, $groupId)
	{
		$groupData=array('status_ID'=>0);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->where('email',$email);
		$this->pdo->delete($this->nonRegisteredGroupMembers);
		return true;
	}
	
/**
	 * To delete Non registered user from Group
	 * @author Rajesh on 25-10-2013
	 * @param unknown_type $email
	 * @param unknown_type $groupId
	 */
	function deleteNonRegisteredGroupMemebersOnWeb($Id, $groupId)
	{
		$groupData=array('status_ID'=>0);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->where('ID',$Id);
		$this->pdo->delete($this->nonRegisteredGroupMembers);
		return true;
	}
	
	/**
	 * To insert User Group badge data
	 * @author Rajesh on 28-10-2013
	 * @param $groupBadgesData
	 */
	function insertUserGroupBadges($groupBadgesData)
	{
		$this->pdo->where('user_ID',$groupBadgesData['user_ID']);
		$this->pdo->where('group_ID',$groupBadgesData['group_ID']);
		$query=$this->pdo->get($this->userGroupBadges);
		if($query->num_rows()==0){
			$this->pdo->insert($this->userGroupBadges, $groupBadgesData);
			return $this->pdo->insert_id();
		}
	}
	/**
	 * To Update User Group Badge by Group ID
	 * @author Rajesh on 29-10-2013
	 * @param $groupId
	 */
	function updateUserGroupBadge($groupId, $isNew)
	{
		$updateData=array('isNew'=>$isNew);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->update($this->userGroupBadges,$updateData);
	}
	/**
	 * To Update User Group Badge by User ID and Group ID
	 * @author Rajesh on 29-10-2013
	 * @param $userId
	 * @param $groupId
	 * @param $isNew
	 */
	function updateUserGroupBadgeByUserId($userId, $groupId, $isNew)
	{
		$updateData=array('isNew'=>$isNew);
		$this->pdo->where('group_ID',$groupId);
		$this->pdo->where('user_ID',$userId);
		$this->pdo->update($this->userGroupBadges,$updateData);
	}
	/**
	 * 
	 * @param $userID
	 * @param $followerId
	 * @param $operation
	 */
	function followUser($userID,$followerId, $operation)
	{
		$this->pdo->where('user_ID',$userID);
		$this->pdo->where('follower_ID',$followerId);
		if($operation==1){
		$query=$this->pdo->get($this->followers);
		if($query->num_rows==0){
			$insertData=array('user_ID'=>$userID, 'follower_ID'=>$followerId);
			$this->pdo->insert($this->followers, $insertData);
		}
		}else if($operation==2){
		$this->pdo->where('user_ID',$userID);
		$this->pdo->where('follower_ID',$followerId);	
		$this->pdo->delete($this->followers);
		}
	}
	/**
	 * To insert Secondary Email ID into database
	 * @aurhor Rajesh on 08-11-2013
	 * @param $insertData
	 */
	function insertSecondaryEmail($insertData)
	{
		$this->pdo->where('email',$insertData['email']);
		$this->pdo->where('status_ID',0);
		$query=$this->pdo->get($this->secondaryEmails);
		if($query->num_rows>0){
		$this->pdo->where('email',$insertData['email']);
		$this->pdo->where('status_ID',0);
		$query1=$this->pdo->delete($this->secondaryEmails);	
		}
		$this->pdo->insert($this->secondaryEmails, $insertData);
		//echo $this->pdo->last_query();
	}
	/**
	 * 
	 * @param $userId
	 * @param $activationCode
	 */
	function updateSecondaryEmailStatus($userId, $activationCode)
	{
		$this->pdo->where('user_ID',$userId);
		$this->pdo->where('activationCode',$activationCode);
		$updateData=array('status_ID'=>1);
		$this->pdo->update($this->secondaryEmails,$updateData);
	}
	/**
	 * To Delete Secondary Email
	 * @author Rajesh on 11-11-2013
	 * @param $encEmail
	 */
	function deleteSecondaryEmail($encEmail)
	{
		$this->pdo->where('email',$encEmail);
		$this->pdo->where('status_ID',0);
		$query=$this->pdo->get($this->secondaryEmails);
		if($query->num_rows>0){
		$this->pdo->where('email',$encEmail);
		$this->pdo->where('status_ID',0);
		$query1=$this->pdo->delete($this->secondaryEmails);	
		}
	}
	/**
	 * To Insert Custom Question By user
	 * @author Rajesh on 12-11-2013
	 * @param $insertData
	 */
	function insertQuestion($insertData)
	{
		$this->pdo->insert($this->question, $insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To Delete User Secondary Email
	 * @author Rajesh on 14-11-2013
	 * @param $email
	 * @param $userId
	 */
	function deleteSecondaryEmailByUserID($email, $userId)
	{
		$this->pdo->where('email',$email);
		$this->pdo->where('user_ID',$userId);
		$this->pdo->delete($this->secondaryEmails);
		return true;
	}
	
/**
	 * To Delete User Secondary Email
	 * @author Rajesh on 14-11-2013
	 * @param $email
	 * @param $userId
	 */
	function deleteSecondaryEmailById($Id)
	{
		$this->pdo->where('ID',$Id);		
		$this->pdo->delete($this->secondaryEmails);
		//echo $this->pdo->last_query();die;
		return true;
	}
	
	/**
	 * To reset Push ID to users
	 * @author Rajesh on 21-11-2013
	 * @param $pushId
	 */
	function resetPushId($pushId)
	{
		$this->pdo->where('pushId',$pushId);
		$updateData=array("pushId"=>$pushId);
		$this->pdo->update("$this->user",$updateData);
		return true;
	}
	
	/*
	 * to reset push Id to zero
	 * @Author Asha on 27-3-2014
	 */
	
function resetPushIdLogin($pushId)
	{
		$this->pdo->where('pushId',$pushId);
		$updateData=array("pushId"=>0);
		$this->pdo->update("$this->user",$updateData);
		return true;
	}
	
	
	/**
	 * To insert Q data
	 * @author Rajesh on 27-11-2013
	 * @param $insertData
	 */
	function insertQdata($insertData)
	{
		$this->pdo->insert($this->qPalQ,$insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To insert Options data
	 * @author Rajesh on 27-11-2013
	 * @param $insertData
	 */
	function insertOptions($insertData)
	{
		$this->pdo->insert($this->options,$insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To insert Recieved Q Data
	 * @author Rajesh on 27-11-2013
	 * @param $insertData
	 */
	function insertRecievedQ($insertData)
	{
		$this->pdo->insert($this->recievedQ,$insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To insert Non-Recieved Q Data
	 * @author Rajesh on 27-11-2013
	 * @param $insertData
	 */
	function insertNonRecievedQ($insertData)
	{
		$this->pdo->insert($this->nonReceivedQ,$insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To insert Non-Recieved FB Q Data
	 * @author Rajesh on 27-11-2013
	 * @param $insertData
	 */
	function insertNonRecievedFbq($insertData)
	{
		$this->pdo->insert($this->nonReceivedFBQ,$insertData);
		return $this->pdo->insert_id();
	}
	/**
	 * To Update Option data
	 * @author Rajesh on 27-11-2013
	 * @param  $updateData
	 */
	function updateOption($updateData)
	{
		$this->pdo->where("ID",$updateData['ID']);
		$this->pdo->update($this->options,$updateData);
	}
	/**
	 * To Delete Non Recived Q's of User
	 * @author Rajesh on 28-11-2013
	 * @param $encEmail
	 */
	function deleteNonRecQ($encEmail)
	{
		$this->pdo->where("email",$encEmail);
		$this->pdo->delete($this->nonReceivedQ);
	}
	/**
	 * To delete Non Recieved FB Q's
	 * @author Rajesh on 28-11-2013
	 * @param $FBID
	 */
	function deleteNonRecFBQ($FBID)
	{
		$this->pdo->where("FBID",$FBID);
		$this->pdo->delete($this->nonReceivedFBQ);
	}
	
	
	/**
	 * To update FBShare in database
	 * @author Rajesh on 2-1-2014
	 * @param $FBID
	 */
	function updateFBShare($qID,$isFBShare)
	{
		$this->pdo->where("ID",$qID);
		$updateData=array("isFBShare"=>$isFBShare);
		$this->pdo->update($this->qPalQ,$updateData);
	}
	
/**
	 * To update twitterShare in database
	 * @author Rajesh on 2-1-2014
	 * @param $FBID
	 */
	function updateTwitterShare($qID,$isTwitterShare)
	{
		$this->pdo->where("ID",$qID);
		$updateData=array("isTwitterShare"=>$isTwitterShare);
		$this->pdo->update($this->qPalQ,$updateData);
	}
	
	function updatePinterestShare($qID,$isPintrestShare){
		$this->pdo->where("ID",$qID);
		$updateData=array("isPintrestShare"=>$isPintrestShare);
		$this->pdo->update($this->qPalQ,$updateData);
		
	}
	
	
	
	
	/**
	 * To insert Qvotes in database
	 * @author Asha on 9-1-2014
	 */
	
	function insertQVotes($voteQdata){
		
		$this->pdo->insert($this->qVotes,$voteQdata);
		//echo $this->pdo->last_query();die;
		return $this->pdo->insert_id();
		
	}
	
/**
	 * To update Qvotes in database
	 * @author Asha on 15-1-2014
	 */
	
	function updateQVotes($voteQdata){
		
		$this->pdo->where("qID",$voteQdata['qID']);
		$this->pdo->where("userID",$voteQdata['userID']);
		$this->pdo->update($this->qVotes,$voteQdata);
		//echo $this->pdo->last_query();die;
		return $this->pdo->insert_id();
		
	}
	
	
/**
	 * To insert followers
	 * @Author Asha on 21-1-2014
	 * @param $userID
	 * @param $followerId
	 * @param $operation
	 */
	function insertFollowers($userID,$friend_ID, $followStatus)
	{
		$this->pdo->where('user_ID',$userID);
		$this->pdo->where('followers_ID',$friend_ID);
		if($followStatus==1){
		$query=$this->pdo->get($this->followers);
		if($query->num_rows==0){
			$insertData=array('user_ID'=>$userID, 'followers_ID'=>$friend_ID);
			$this->pdo->insert($this->followers, $insertData);
			return true;
		}
		}else if($followStatus==0){
		$this->pdo->where('user_ID',$userID);
		$this->pdo->where('followers_ID',$friend_ID);	
		$this->pdo->delete($this->followers);
		return true;
		}
		
		//echo $this->pdo->last_query();
	}
	
	/*
	 * insert Q badges
	 * @Author Asha on 3-2-2014
	 */
	
	function insertQBadges($userQBagesData){
		
		$query=$this->pdo->insert($this->userQBadges,$userQBagesData);
		return $this->pdo->insert_id();
		
	}
	
	function updateUserQBadges($qId,$userId){
		//echo "asa";die;
		$updateData=array('isNew'=>0);
		$this->pdo->where('qPalQ_ID',$qId);
		$this->pdo->where('user_ID',$userId);		
		$this->pdo->update($this->userQBadges,$updateData);
		//echo $this->pdo->last_query();die;
		
	}
	
   function updateUserQBadgesForVote($userId,$qId){
		//echo "asa";die;
		$updateData=array('isNew'=>1);
		$this->pdo->where('qPalQ_ID',$qId);
		$this->pdo->where('user_ID',$userId);		
		$this->pdo->update($this->userQBadges,$updateData);
		//echo $this->pdo->last_query();die;
		
	}
	
	/*
	 * to insert likes for Q
	 * @Author on 4-2-2014
	 */
	
	function insertFavourites($qId,$user_ID,$favouriteStatus){
		
		$this->pdo->where('qPalQ_ID',$qId);
		$this->pdo->where('user_ID',$user_ID);
		if($favouriteStatus==1){
			$query=$this->pdo->get($this->favourites);
			if($query->num_rows==0){
			  $insertData=array('qPalQ_ID'=>$qId,'user_ID'=>$user_ID);
			  $this->pdo->insert($this->favourites,$insertData);
			  return true;	
			}
		}else if($favouriteStatus==0){
			
			$this->pdo->where('qPalQ_ID',$qId);
		    $this->pdo->where('user_ID',$user_ID);
		    $this->pdo->delete($this->favourites);
			return true;
		}
	}
	
	
	
	/*
	 * To update Room Name in QpalQ for chatting
	 * @Author Asha on 21-2-2014
	 */
	
	
	function updateQRoomName($qId,$roomName){
		
		$this->pdo->where('ID',$qId);
		$updateData=array('roomName'=>$roomName);
		$this->pdo->update($this->qPalQ,$updateData);
		
	}
	
	
	/*
	 *@Author Asha on 12-3-2014 
	 * posting social comments
	 */
	
	function setSocialComments($postComments){
		$this->pdo->insert($this->socialQComments,$postComments);
		return $this->pdo->insert_id();
	}
	
	
	/*
	 * function to delete a Q
	 * Asha on 07-04-2014
	 */
	
	
	function deleteQ($qId){
		
		$this->pdo->where('ID',$qId);
		$updateData=array('status'=>0);
		$this->pdo->update($this->qPalQ,$updateData);
		//echo $this->pdo->last_query();
		
	}
	
	function updatePassword($email,$password,$userID){
		
		$this->pdo->where('email',$email);
		$updateData=array('password'=>$password);
		$this->pdo->update($this->user,$updateData);

		 //ejabberd code added by karthik on 16-6-2014 - to update password for user in ejabberd server
                                          /*      $chatHost = $this->config->item('XMPP_SERVER_HOST');
                                                $param = array("user"=>$userID,"host"=>$chatHost,"newpass"=>$password);
                                                $request = xmlrpc_encode_request('change_password', $param, (array('encoding' => 'utf-8')));
                                                $context = stream_context_create(array('http' => array(
                                                             'method' => "POST",
                                                             'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
                                                                         "Content-Type: text/xml\r\n" .
                                                                         "Content-Length: ".strlen($request),
                                                             'content' => $request
                                                          )));

                    $path=$this->config->item('XMPP_RPC_SERVER_HOST');
                                        $file = file_get_contents($path.'/RPC2', false, $context);
                    $response = xmlrpc_decode($file);

                   if (xmlrpc_is_fault($response)) {
                           trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
                   }

		
	*/	

  $chatHost = $this->config->item('XMPP_DB_HOST');
 $con= mysqli_connect($chatHost,"admin", "Oxalic_336","ejabberd") or die(mysqli_error());
 $query ="UPDATE users SET password='$password'  WHERE username='$userID'";  
 $con->query($query);
 mysqli_close($con);
	}
	/*
	 * @author:padmaja
	 */
	function updateunRegisterdData($userdata)
	{
	//	var_dump($userdata);die;
		$this->pdo->where('ID',$userdata['ID']);
		$this->pdo->update($this->nonRegisteredGroupMembers,$userdata);
		//echo $this->pdo->last_query();
		return true;
	}
	
}
	
	
	
