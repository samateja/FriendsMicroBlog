<?php
/**
 * Class Templatemodel
 * handles to form the mail contents in the application
 *
 *
 * @package     Qpals
 * @subpackage  Models
 * @category    Authentication
 * @author      Rajesh on 15-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class Templatemodel extends CI_Model
{
	/**
	 * initialises the class inheriting the methods of the class Model
	 *
	 * @return Usermodel
	 */
	function __construct()
	{
		parent::__construct();
		$this->_signature = "See you on QPals.";
	}
	
	
	/*
	 * for rest pasword url
	 */
	
    function decrypt_blowfish($data,$key){
    $iv=pack("H*" , substr($data,0,16));
    $x =pack("H*" , substr($data,16));
    $res = mcrypt_decrypt(MCRYPT_BLOWFISH, $key, $x , MCRYPT_MODE_CBC, $iv);
    return $res;
    }

    function encrypt_blowfish($data,$key){
    $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $crypttext = mcrypt_encrypt(MCRYPT_BLOWFISH, $key, $data, MCRYPT_MODE_CBC, $iv);
    return bin2hex($iv . $crypttext);
    }
	
	
	
	
	
	
	/**
	 * This function is to form the mail content
	 * for the registration process
	 * @author Rajesh -- on 18/09/2013
	 * @param $mailData (an array contains the required data)
	 */
	function registerMailTemplate($mailData)
	{
		//print_r($mailData);
		$userName 	= $mailData['userName'];
		$email 		= $mailData['email'];
		$password 	= $mailData['password'];
		$password	= $this->hiddenPassword($password);
		//$activationUrl = base_url()."home/activation/$tempUserId/$activationCode";
		
		// Added by Padmaja for unsubscribe
		 $encEmail =$mailData['encEmail'];
		 $getId=$this->getdatamodel->getRegDetails($encEmail);
		 $rowID= $getId[0]['ID'];
		 $unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
         $url=base_url()."images/user_reg.jpg";
		
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .= "QPals is easy and fun to use.<br/><br/>";
		$message .= "<img src='$url' style='width:100%;'/><br/><br/>";
		$message .= "Download a QPals app (links below) or use our website (<a target='_blank' href='https://www.qpals.com/'>www.QPals.com</a>) to login.<br/><br/>";
		$message .= "To use instant chat and voting with your friends, please enable push notifications and ask your friends to keep their notifications also enabled.  We won't send you any annoying ads using push notifications and you can always adjust your notification settings under the Settings menu.<br/><br/>";
	    $message .= "Email: $email<br/>";
		$message .= "Password: $password <br/><br/>";		
		$message .= "If you did not register for QPals, please <a target='_blank' href='mailto:ideas@qpals.com'>let us know</a> immediately.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
        
		ob_start();
		$this->load->view('emailTemplate', $data);
		
		$message = ob_get_contents();
		ob_end_clean();
		//print_r ($message);
		return $message;
	}
	
	/*
	 * @Author Asha on 12-3-2014
	 * socail sharing register
	 */
	
  function socialSharingregisterMailTemplate($mailData)
	{
		$userName 	= $mailData['userName'];
		$email 		= $mailData['email'];
		$password 	= $mailData['password'];
		// Added by Padmaja for unsubscribe
		$encEmail =$mailData['encEmail'];
		$getId=$this->getdatamodel->getRegDetails($encEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		//$activationUrl = base_url()."home/activation/$tempUserId/$activationCode";


		//form the email template body content
		$url=base_url()."images/user_reg.jpg";
		$message  ="Dear $userName,<br/><br/>";
		$message  .=" QPals is easy and fun to use.<br/><br/>";
		$message .= "<img src='$url' style='width:100%;'/><br/><br/>";
		$message .= "Download a QPals app (links below) or use our website (<a target='_blank' href='https://www.qpals.com/'>www.QPals.com</a>) to login.<br/><br/>";
		$message .= " To use instant chat and voting with your friends, please enable push notifications and ask your friends to keep their notifications also enabled. We won't sent you any annoying ads using push notifications and you can always adjust your notification settings under the Settings menu.<br/><br/>";
		//$message .= "Great to have you on QPals. You are receiving this mail for registering with QPals. Thanks for registration.<br/>";
		//$message .= "Below are the details of your account to access the QPals:<br/><br/>";
		$message .= "Email: $email<br/>";
		$message .= "Password: $password<br/><br/>";
		$message .= " If you did not register for QPals, please let us know immediately.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
        
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();

		return $message;
	}
	
	
	function socialSharingunregisterMailTemplate($mailData)
	{
		$userName 	= $mailData['userName'];
		$email 		= $mailData['email'];
		$password 	= $mailData['password'];
		$emailpassword = $mailData['emailpassword'];
		 $encEmail =$email;
		 $getId=$this->getdatamodel->getRegDetails($encEmail);
		 $rowID= $getId[0]['ID'];
		 
		 $unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
         $url=base_url()."images/user_reg.jpg";
		//form the email template body content
		$url=base_url()."images/user_reg.jpg";
		$message  ="Dear $userName,<br/><br/>";
		$message  .=" QPals is easy and fun to use.<br/><br/>";
		$message .= "<img src='$url' style='width:100%;'/><br/><br/>";
		$message .= "Download a QPals app (links below) or use our website (<a target='_blank' href='https://www.qpals.com/'>www.QPals.com</a>) to login.<br/><br/>";
		$message .= " To use instant chat and voting with your friends, please enable push notifications and ask your friends to keep their notifications also enabled. We won't sent you any annoying ads using push notifications and you can always adjust your notification settings under the Settings menu.<br/><br/>";
		//$message .= "Great to have you on QPals. You are receiving this mail for registering with QPals. Thanks for registration.<br/>";
		//$message .= "Below are the details of your account to access the QPals:<br/><br/>";
		$message .= "Email: $emailpassword<br/>";
		$message .= "Password: $password<br/><br/>";
		$message .= " If you did not register for QPals, please let us know immediately.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
        
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();

		return $message;
	}
	
	/**
	 *This function is to form the mail content
	 * for the forgot password process
	 * @author Rajesh -- on 19/09/2013
	 * @param $mailData
	 */
	function forgotPasswordMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		//$password = $mailData['password'];
		$email	  = $mailData['email'];
		$accessCode= $mailData['accessCode'];
		
		// Added by Padmaja for unsubscribe
		$encEmail =$mailData['encEmail'];
		$getId=$this->getdatamodel->getRegDetails($encEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		$keyBlow   = md5("QPals");
		$encMail   =$this->encrypt_blowfish($email,$keyBlow);
		//print_r($mailData);die;
		$url= base_url()."resetPassword/reset/$encMail";
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";		
		$message .= "We received a request to <a target='_blank' href='$url'>reset</a> your QPals password.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();

		return $message;
	}
	/**
	 *This function is to form the mail content
	 * for the Facebook Signup process
	 * @author Rajesh -- on 23/09/2013
	 * @param $mailData
	 */
	function fbSigninMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		//$password = $mailData['password'];
		$email	  = $mailData['email'];
		$password = $mailData['password'];
		$url=base_url()."images/user_reg.jpg";
			
			// Added by Padmaja for unsubscribe
		$encEmail =$mailData['encEmail'];
		$getId=$this->getdatamodel->getRegDetails($encEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		 
		//@Author Asha --on 19/12/2013
		//commented the hidden password to show the actual password in email
		//$password	= $this->hiddenPassword($password);
		
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .= "Thanks for signing up for QPals through Facebook.  QPals is easy and fun to use.<br/><br/>";
		$message .= "<img src='$url' style='width:100%'/><br/><br/>";
		$message .= 'Download the free QPals mobile app (links below), create your own private groups (e.g. "My college buddies", "Family", "Basketball buddies") and send a "Q" to a private group or post it on Facebook, Twitter and Pinterest and get lots of replies straightaway.<br/><br/>';
		
		$message .= "Login using Facebook signon or your email $email and temporary password $password.  If you already have a QPals account using another email, please associate your Facebook account with it to avoid setting up multiple accounts.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 *This function is to form the mail content
	 * for the Nonregistered member group creation process
	 * @author Rajesh -- on 07/10/2013
	 * @param $mailDa+ta
	 */
	function nonRegisteredUserGroupMailTemplate($mailData)
	{
		
		//$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		//$members	= $mailData['members'];
		$groupId    = $mailData['groupId'];
		$Rfname      =$mailData['firstName'];
		$registerdGrpsemails = $mailData['regUsersData'];
		//$mailData['firstName']=$uname;
		$userName = $mailData['userName'];
		$members =$mailData['members'];
		//$reg=$mailData['fNme'] ;
		
		//print_r($mailData);echo  "<br>";
		//updateGroupMailTemplateprint_r($mailData);die;
		if($members){
			$msgStr = "Other members are $members";
		}else{
			$msgStr = "";
		}
		
		
		$url=base_url()."groups/viewGroup/$groupId/show";
		//form the email template body content
		
			
		$message  = "Dear $Rfname,<br/><br/>";
		$message .= " You're popular. <b>$groupCreator</b> has added you to 
		<b>$groupName</b> on QPals. $msgStr<br/><br/>";
		$message .= "<a target='_blank' href='$url'>Check out</a>your new group on QPals.<br/><br/>";
		
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		
		//print_r($message);
		
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 *This function is to form the mail content
	 * for the unregistered member group creation process
	 * @author padmaja -- on 25/06/2014
	 * @param $mailData
	 */
	function unRegisteredGroupMailTemplate($mailData)
	{
		//echo "hjil";die;
		
		$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		$members =$mailData['members'];
		$groupId    = $mailData['groupId'];
		$Nfname      =$mailData['firstName'];
		//$NonReg=$mailData['fNme'] ;
		
		//$email     = $mailData['email'];
		//print_r($mailData);die;
		$notregisterdGrpsemails = $mailData['nonRegUsersData'];
		
		if($members){
			$msgStr = "Other members are $members";
		}else{
			$msgStr = "";
		}
		
		 $url=base_url()."images/user_reg.jpg";
		
		//form the email template body content
		
		$message  = "Dear $userName,<br/><br/>";
		$message .= "<a href='$registrationmail'> Registered email</a><br/><br/>";
		$message .= "You're popular. <b>$groupCreator</b> has added you to 
		<b>$groupName</b> on QPals. $msgStr.QPals is fun and easy to use.<br/><br/>";
		$message .= "<img src='$url' style='width:100%'/><br/><br/>";
		$message .="To join your group, we suggest you complete your registration at <a target='_blank' href='https://www.qpals.com/'>www.QPals.com</a> and download the QPals app (links below). If you are already a member of QPals, then add $notregisterdGrpsemails as a secondary email to your account.<br/><br/>";
		//$message .="To use instant chat and voting, please enable push notifications and ask your friends to keep their notifications enabled. We won't send you any annoying ads using push notifications. Plus, at any time, you may adjust your notifications status under the Settings menu.<br/><br/>";
		
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		//print_r($message);
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/*
	 * This function is send email after the Qis created
	 * @Author Asha on 9-4-2014
	 */
	
	
	
	function createQTemplate($mailData)
	{
		//echo "hello";die;
		$userName = $mailData['userName'];
		$qCreatorName = $mailData['qCreatorName'];
		$groupName	= $mailData['groupName'];
		$members	= $mailData['members'];
	    $questionName= $mailData['questionName'];
	    $option1     = $mailData['option1'];
	   $encrEmail = $mailData['encrEmail'];
	    $thumb=$mailData['thumb'];
		if($members){
			$msgStr = "(which includes $members.)";
		}else{
			$msgStr = "";
		}
		$qId= $mailData['qId'];
		$UID = $this->getdatamodel-> getId($userName);
		if ($UID == Null)
		{
			$qlink=base_url()."qwall/viewQ/".$qId."/3/";
		}
		else {	
		$u = $UID[0]['ID'];
		$qlink=base_url()."qwall/viewQ/".$qId."/3/".$u;
		}
		$getId=$this->getdatamodel->getRegDetails($encrEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		
		$url=base_url()."home";
		//form the email template body content
		$message   ='<div id="mail-text" style="float:left; width:100%;">
                     <div style="padding-top:15px; padding-bottom:15px;">';
		$message  .='<div style="padding-left:20px; padding-right:20px; ">Dear '.$userName.',<br/><br/>';
		$message .= "<p><b>$qCreatorName</b> from <b>$groupName</b> $msgStr has sent you a Q.</p>
		             <br></div>";
		$message .= ' <div style="border-top:2px solid #dedd1f; color:#606060; width:100%; min-height:auto; overflow:hidden; padding-top:40px; padding-bottom:40px; border-bottom:2px solid #dedd1f;;">
                      <div style="font-size:20px; padding-left:20px; padding-right:20px; ">'.$questionName.'</div>
                       
                      <div style="padding-left:20px; padding-right:20px;">
                      <div style="margin-right:15px; float:left; margin-top:25px;">
                      <img src="'.$thumb.'" width="125" height="125" alt="" /> <br> 
                      <div style="margin-top:10px; font-weight:bold;">'.$option1.'</div>                       
                     </div>
                    
                  </div>
                    <div style="padding-left:20px; padding-right:20px;"> <div style="margin-top:25px; background-color:#dedd1f; width:101px; color:#ffffff; font-size:16px; font-weight:bold; float:left; padding:8px 12px; cursor:pointer;">
                    <a href="'.$qlink.'" target="_blank" style="decoration:none;">CLICK HERE</a></div>
                   <div style="font-weight:bold; margin-left:10px; margin-top:25px; float:left; padding-top:10px;">To answer this Q</div> </div>
                </div>';
		$message .= "<div style='padding-left:20px; padding-right:20px; margin-top:35px; margin-bottom:35px;'><a target='_blank' href='$url'>Click here</a> to delete yourself from $groupName.</div><br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		//print_r($message);die;
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	
	
	
	/**
	 *This function is to form the mail content
	 * for the registered member group creation process
	 * @author Rajesh -- on 07/10/2013
	 * @param $mailData
	 */
	function registeredUserGroupMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		$members	= $mailData['members'];
		$groupId    = $mailData['groupId'];
		
		if($members){
			$msgStr = "Other members are $members.";
		}else{
			$msgStr = "";
		}
		$url=base_url()."groups/viewGroup/$groupId/show";
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .= "You're popular. <b>$groupCreator</b> has added you to 
		<b>$groupName</b> on Qpals. $msgStr<br/><br/>";
		$message .= "<a target='_blank' href='$url'>Check out</a> your new group on Qpals.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To form the mail content for Update group
	 * @author Rajesh on 28-10-2013
	 * @param $mailData
	 */
	function updateGroupMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		$groupId	= $mailData['groupId'];
		$members	= $mailData['members'];
		//print_r($mailData);
		$url=base_url()."groups/viewGroup/$groupId/show";
		if($members){
			$msgStr = "Other members are $members.";
		}else{
			$msgStr = "";
		}
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .=" You're popular. <b>$groupCreator</b> has added you to 
		<b>$groupName</b> on QPals.$msgStr<br/><br/>";
		$message .="<a target='_blank' href='$url'>Check out</a> the changes on QPals.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
/**
	 * To form the mail content for non registered Update group
	 * @author Padmaja on 28-10-2013
	 * @param $mailData
	 */
	function NonRegisteredupdateGroupMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		$groupId	= $mailData['groupId'];
		$members	= $mailData['members'];
		//print_r($mailData);die;
		//$url=base_url()."groups/viewGroup/$groupId/show";
		//form the email template body content
		//$url=base_url()."groups/viewGroup/$groupId/show";
		//form the email template body content
		 $url=base_url()."images/user_reg.jpg";
		if($members){
			$msgStr = "Other members are $members.";
		}else{
			$msgStr = "";
		}
		 $message  = "Dear $userName,<br/><br/>";
		$message .= "You're popular. <b>$groupCreator</b> has added you to 
		<b>$groupName</b> on Qpals.$msgStr QPals is fun and easy to use <br/><br/>";
		$message .= "<img src='$url' style='width:100%'/><br/><br/>";
		$message .= "To join your group, we suggest you complete your registration at Qpals.com and download the QPals app (links below). If you are already a member of QPals, then add  as a secondary email to your account. <br/><br/>";
		//$message .= "<a target='_blank' href='$url'>Check out</a> your new group on Qpals.<br/><br/>";
		$message .= "To use instant chat and voting, please enable push notifications and ask your friends to keep their notifications enabled. We won't send you any annoying ads using push notifications. Plus, at any time, you may adjust your notifications status under the Settings menu.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
/**
	 * To form mail content for Delete group.
	 * @author Rajesh on 28-10-2013
	 * @param $mailData
	 */
	function deleteGroupMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$groupCreator = $mailData['groupCreator'];
		$groupName	= $mailData['groupName'];
		$encrEmail =$mailData['encrEmail']  ;
		$url=base_url()."groups/viewGroup/createGroup/create";
		
		$getId=$this->getdatamodel->getRegDetails($encrEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .="Just wanted to let you know that $groupCreator has deleted $groupName on Qpals.<br/><br/>";
		$message .="Maybe it's time to <a target='_blank' href='$url'>create</a> your own new groups.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To form Mail content for Delete member group
	 * @author Rajesh on 28-10-2013
	 * @param $mailData
	 */
	function deleteMemberMailTemplate($mailData)
	{
		$userName = $mailData['uname'];
		$groupCreator = $mailData['uname'];
		$groupName	= $mailData['groupName'];
		$deldName = $mailData['deldName'];
		//echo $userName;echo $groupCreator;die;
		$url=base_url()."groups/viewGroup/createGroup/create";
		//form the email template body content
		$message  = "Dear $deldName,<br/><br/>";
		$message .="We're sorry. $groupCreator has deleted you from $groupName.<br/><br/>";
		$message .="Maybe it's time to <a target='_blank' href='$url'>create</a> your own new groups.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		//print_r($message);die;
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	
	/**
	 * To form Mail content for Delete NonRegistered member group
	 * @author Padmaja on 28-06-2014
	 * @param $mailData
	 */
	function deleteNonRegisterdMemberMailTemplate($mailData)
	{
				
		$groupName     =   $mailData['gName'];
		$deldName      =   $mailData['dNname'];
		$groupCreator  =   $mailData['groupCreator'];
		$url=base_url()."groups/viewGroup/createGroup/create";
		//form the email template body content
		$message  = "Dear $deldName,<br/><br/>";
		$message .="We're sorry. $groupCreator has deleted you from $groupName.<br/><br/>";
		$message .="Maybe it's time to <a target='_blank' href='$url'>create</a> your own new groups.<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		//print_r($message);die;
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To form Mail content for Delete member group to send to other members
	 * @author Rajesh on 28-10-2013
	 * @param $mailData
	 */
	function deleteMembersMailTemplate($mailData)
	{
		$userName = $mailData['uname'];
		$groupName	= $mailData['groupName'];
		$deletedUser = $mailData['uname'];
		 $regEmail  =$mailData['regEmail'];
		 
		 $getId=$this->getdatamodel->getRegDetails($regEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		$url=base_url()."groups/viewGroup/createGroup/create";
		//form the email template body content
		$message  = "Dear ".$userName.",<br/><br/>";
		$message .="Just wanted to let you know that ".$deletedUser." is no longer a member of  $groupName.<br/><br/>";
		//$message .="Maybe it's time to <a target='_blank' href='$url'>create</a> your own new groups.<br/><br/>";
		$message .= $this->_signature;
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To form Change Password Mail template
	 * @author Rajesh on 07-11-2013
	 * @param $mailData
	 */
	function changePasswordMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$email	  = $mailData['email'];
		$password = $mailData['password'];
		
		
			// Added by Padmaja for unsubscribe
		$dbmail = $mailData['dbMail'];
		$getId=$this->getdatamodel->getRegDetails($dbmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .= "We just received a request to change your password for QPals.  If this was not you, then please change your password again.<br/><br/>";
		$message .= "Account Email:$email<br/>Password:$password<br/><br/>";
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;
		//print_r($message);die;
		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To form Secondary Email Activation Template
	 * @author Rajesh on 08-11-2013
	 * @param $mailData
	 */
	function secondaryEmailActivationMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$email	  = $mailData['email'];
		$activationCode = $mailData['activationCode'];
		$url	  = base_url()."home/secondaryEmailActivation/$activationCode";
		
		$encEmail =$mailData['encEmail'];
		$getId=$this->getdatamodel->getRegDetails($encEmail);
		$rowID= $getId[0]['ID'];
		$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		//form the email template body content
		$message  = "Dear $userName,<br/><br/>";
		$message .="Thanks for adding a new secondary email $email to your QPals account.
		 The more secondary email addresses you add to your profile, the easier it will be for you to manage your friends and Qs on QPals.<br/><br/>";
		$message .= "Please activate the new secondary email by clicking on (or copying and pasting into a new browser window) the following link:<br/><br/>";
		
		$message .= "<a target='_blank' href='$url'>$url</a><br/><br/>";
		
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='$unsubscribeLink'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * 
	 * @param $maildata
	 */
	function addedGroupMembersMailTemplate($mailData)
	{
		$userName = $mailData['userName'];
		$groupCreatorName=$mailData['groupCreator'];
		$groupName=$mailData['groupName'];
		$members	= $mailData['members'];
		$groupId	= $mailData['groupId'];
		if($members){
			$msgStr = " $members";
		}else{
			$msgStr = "";
		}
		
		$url=base_url()."groups/viewGroup/$groupId/show";
		$message  = "Dear $userName,<br/><br/>";
		$message .="Just wanted to let you know that $groupCreatorName  added $msgStr to $groupName.<br/><br/>";
		$message .="<a target='_blank' href='$url'>Check out</a> your new group on Qpals.<br/><br/>";		
		$message .= $this->_signature;
		$message .="<br><br>If you don't want to receive invitation emails from QPals, please click <a target='_blank' href='mailto:unsubscribe@qpals.com'>unsubscribe.</a><br>";
		$message .="Auro ADT TS PVT LTD. Attention: Everest Law Group, APC, 6303 Owensmouth Avenue, 10th Floor, Woodland Hills, CA 91302.";
		$data['message'] = $message;

		ob_start();
		$this->load->view('emailTemplate', $data);
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}
	/**
	 * To Convert Password into Asterisk
	 * @author Rajesh on 28-11-2013
	 * @param $password
	 */
	function hiddenPassword($password)
	{
		$arr=str_split($password);
		$reqStr="";
		for($i=0;$i<sizeof($arr);$i++){
			if($i>1){
				$reqStr .=preg_replace("|.|","*",$arr[$i]);
			}else{
				$reqStr .=$arr[$i];
			}
		}
		return $reqStr;
		//echo $hidden_password = preg_replace("|.|","*",$real_password);
	}
	//----------------------------------------------------------------------------------------------------
}
