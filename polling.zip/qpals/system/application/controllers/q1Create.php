<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// To avoid back button after logout
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0", false);
//header("Cache-Control: post-check=0, pre-check=0", false);
// HTTP/1.0
header("Pragma: no-cache");
// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Asha on 13-02-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class qCreate extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
		$this->load->library('form_validation');	
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->library('pagination');
		$sessionlog=$this->session->userdata('userID');
		//print_r($sessionlog);die;
	    $sourceType=$this->uri->segment(4);
		$this->load->model('messagequeue');
		$this->_S3Url = $this->config->item('S3Url');
			// Added by padmaja on 02-07-2014
		$this->load->model('qpalsamazons3model');
		$this->load->library('s3upload/S3.php');
		if(!$sessionlog && $sourceType!=""){
			 $link = $_SERVER['REDIRECT_URL'];
              $this->session->set_userdata(array('redirectUrl'=> $link));
			redirect('socialSharing');
		}
		
	    if(!$sessionlog){
	    	//echo $sessionlog;
			redirect('home');
		}
		
		
       
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
   function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	function decrypt_blowfish($data,$key){
    $iv=pack("H*" , substr($data,0,16));
    $x =pack("H*" , substr($data,16));
    $res = @mcrypt_decrypt(MCRYPT_BLOWFISH, $key, $x , MCRYPT_MODE_CBC, $iv);
    return $res;
    }
  
	public function createQ(){
		
		$data['active']='createQ';
		$sesUserId=$this->session->userdata('userID');
		$keyBlow   = md5("QPals");
		$getGroupUriId=$this->uri->segment(4);
		$data['uriGroupId']=$this->decrypt_blowfish($getGroupUriId,$keyBlow);
        //echo $getGroupUriId;die;
		$data['presetQuestions']=$this->getdatamodel->getPresetQuestions();
		$data['userAddeddQuestions']=$this->getdatamodel->getQuestionsByUserId($sesUserId);
		
		$this->load->view('createQ',$data);
     }
	
	/*
	 * Ajax function for Images and options
	 */
     
     
     public function qOptions(){
     	$questionId=$this->input->post('questionId');
     	echo $questionId;
     }
     
     public function fetchPredefinedOptions(){
     	
     	$questionId=$this->input->post('questionId');
     	
     	$res=$this->getdatamodel->getQuestionName($questionId);
     	$response='';
     	if($res){
     		
     		$response.=$res[0]['opt1'].'/'.$res[0]['opt2'];     		
     		
     	}
     	
     	echo $response;
     }
     
     public function fetchPredefinedIcons(){
     	$questionId=$this->input->post('questionId');
     	
     	$res=$this->getdatamodel->getQuestionName($questionId);
     	$response='';
     	if($res[0]['image']!=""){
     		
     		$response.=base_url()."Uploads/predefinedIcons/".$res[0]['image'];     		
     		
     	}else{
     		$response.='';
     	}
     	
     	echo $response;
     	
     }
	
     
     /*
      * fetch group memebers
      */
     
     function getGroupMembers(){
     	
     	$groupId=$this->input->post('val');
     	$registeredGroupMemberesData=$this->getdatamodel->getGroupMembersDetails($groupId);
     	$nonregisteredGroupMembersData=$this->getdatamodel->getnonRegGroupMembersDetails($groupId); 	
     	$groupData  =$this->getdatamodel->getGroupDetailsById($groupId); 	
     	$gName		= $groupData[0]['name']; 
     	$totalCount=$this->getdatamodel->getGroupMemnbersCount($groupId);
        if($totalCount>1){
         $membersCount=$totalCount;
		}	
     	$groupData='<table width="100%" cellpadding="5">
                     <tr>
                     <td><span class="f_bold">'.$gName.'</span> </span>
                     <span class="f_italic">'.$membersCount.' Pals  </span></td>
                   </tr>
                    <tr>
				    <td> 
					<div style="height:320px; overflow:auto;">

					<table width="100%" class="view_group_pals"><tr>';
     	if($registeredGroupMemberesData){
     	$i=1; 
     	$bucket = $this->config->item("bucket");
     	foreach ($registeredGroupMemberesData as $groupMember){
     	 		$name = $groupMember['firstName'];
				$memberId= $groupMember['ID'];
				if($groupMember['thumb'] == 'avatar_thumb.png'){
					$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
				}else{
					$thumb=$this->_S3Url.$groupMember['thumb'];
				}
				//$thumb='http://'.$bucket.'.s3.amazonaws.com/'.$groupMember['thumb'];
				$photo= $this->_S3Url.$groupMember['photo'];
				$isCreator=$groupMember['isCreator'];
				$userType= 1;
     	
     	$groupData.='
               <td>
               <img src="'.$thumb.'" width="80" height="80" alt="" />
                <br>
                <div>'.$name.'</div></td>              
               ';
     	if($i%5==0){$groupData.='<td><tr>';}                      
     	 		$i++;} }
          $j=1;
     	 if($nonregisteredGroupMembersData) {
     	 		foreach ($nonregisteredGroupMembersData as $nonRegGroupMember){
     	 			
     	 			$name= $nonRegGroupMember['name'];							   
				    $thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
					$photo= base_url()."Uploads/ProfilePictures/avatar.png";
			        $userType= 2;
			        
			        
			        $groupData.='
               <td>
               <img src="'.$thumb.'" width="80" height="80" alt="" />  <br>
                <div>'.$name.'</div> </td>
              ';
			if($j%5==0){$groupData.='<td><tr>';}         
     	 			
     	 	$i++;}		
     	 }
                               
          $groupData.=' </tr></table>	
                       </div> 							
					   </td>
				       </tr>
					</table>';
     	 
          echo $groupData;
     }
     
	function getExtension($str) 
		{
         $i = strrpos($str,".");
         if (!$i) { return ""; } 

         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
		}
     
	/*
	 * function to createQ
	 */
     
     function insertQ(){     	
     	//echo "kjhoo";die;
     	/* For loading qpalsamazons3model file and including s3 file from library
     	 * @author:Padmaja on 02-07-2014
     	 */
     	$this->load->model('qpalsamazons3model');
		$this->load->library('s3upload/S3.php');
     	$questionName			= $this->input->post('questionName');
     	$userId                 = $this->input->post('userId');
     	$accessType             = $this->input->post('accessType');
     	$isNoImg                = $this->input->post('isNoImg');
     	$isNoAns                = $this->input->post('isNoAns');
     	$note                   = $this->input->post('notes');
     	$groupId                = $this->input->post('groupId');
     	$option1                = $this->input->post('opt1');
     	$option2                = $this->input->post('opt2');
     	$option3                = $this->input->post('opt3');
     	$option4                = $this->input->post('opt4');
     	$img1                   = $this->input->post('img1');
     	$img2                   = $this->input->post('img2');
     	$img3                   = $this->input->post('img3');
     	$img4                   = $this->input->post('img4');
     	$groupId                = $this->input->post('groupId');
     	$isFbShare              = $this->input->post('isFbShare');
     	$isTwitterShare         = $this->input->post('isTwitterShare');
     	$isPinterestShare       = $this->input->post('isPinterestShare');
     	$fbId                   = $this->input->post('fbId');
     	$accessToken            = $this->session->userdata('twittAcessToken');//twitter user acess token
     	$accessTokenSecret      = $this->session->userdata('twittAcessTokenSecret');//twitter user acess token
		/*
		 * Image extensions
		 * @author:Padmaja on 02-07-2014
		 */ 
        $valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
    if($questionName){
			$insertData=array("name"=>$questionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>0);
			$insertedId=$this->setdatamodel->insertQuestion($insertData);
			$qsnId=$insertedId;
		}
		
		
	 $insertQData=array('user_ID'=>$userId, 'publishType'=>1,'accessType'=>$accessType,'isNoImg'=>$isNoImg,
				        'isNoAns'=>$isNoAns,'note'=>$note,'isPublic'=>$accessType,
				        'status'=>1,'question_ID'=>$qsnId,'qPalQGroup_ID'=>$groupId);
	 $insertedQId=$this->setdatamodel->insertQdata($insertQData);
	 
	
		
  if($insertedQId){
	 if($option1){
		$insertOptionData=array("optionName"=>$option1,"qPalQ_ID"=>$insertedQId);
		$res=$this->setdatamodel->insertOptions($insertOptionData);
		}
	 if($option2){
		$insertOptionData=array("optionName"=>$option2,"qPalQ_ID"=>$insertedQId);
		$this->setdatamodel->insertOptions($insertOptionData);
		}
	 if($option3){
		$insertOptionData=array("optionName"=>$option3,"qPalQ_ID"=>$insertedQId);
		$this->setdatamodel->insertOptions($insertOptionData);
		}
	if($option4){
		$insertOptionData=array("optionName"=>$option4,"qPalQ_ID"=>$insertedQId);
		$this->setdatamodel->insertOptions($insertOptionData);
		}
		$qId=$insertedQId;
	 }

	 
      	//code for createQ Images
      	
	 	 //Added by Padmaja on 2-07-2014
		   
	 $bucket = $this->config->item("bucket");
	 $awsAccessKey = $this->config->item('awsAccessKey');
	 $awsSecretKey = $this->config->item('awsSecretKey');
	 $path          =$this->config->item('image');
		
     	if($img1){
     	
     	$res=$this->getdatamodel->getQOptions($qId);
     	$imgIden=explode(":",$img1);
     	if($imgIden[0]=="data"){ //canvas url cropped image 400 * 400
     		
     		$parts   = explode(',', $img1);
     		$data    = $parts[1];
     		$data    = base64_decode($data); 
     		$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];
		   	$upldFileName = $newFileName.'.'.'jpeg';
		 	//$tmp = $_FILES[$newFileName]['tmp_name'];///////
		 	
		 	/*For adding s3 amazon images to image1
		 	 *@author: Added by Padmaja on 02-07-2014
		 	 */ 
		 	
		   	$ext = $this->getExtension($upldFileName);
		 	$s3 = new S3($awsAccessKey, $awsSecretKey);
			$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
			$actual_image_name = time().".".$ext;
			//echo $file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		
			$file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		$success = file_put_contents($file, $data);
		 	if($s3->putObjectFile($file, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
		 	$s3file=$this->_S3Url.$upldFileName;
		   	}
		 	
		    $success = file_put_contents($file, $data);
     		
     		if($success){//create a thum image 200 * 200
     			
     	  	$config1['image_library'] = 'gd2';
			$config1['source_image'] = $file;
			$config1['create_thumb'] = TRUE;
			$arr = explode(".",$upldFileName);

			$config1['maintain_ratio'] = FALSE;
			$config1['width'] = 200;
			$config1['height'] =200;

			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			

			if($this->image_lib->resize())
			{
				$thumbimg = $arr[0]."_thumb.".$arr[1];
			}else {
				$thumbimg="";
			}	
			//print_r($thumbimg);
			$file1    = FCPATH.'Uploads/QImages/'.$thumbimg;
			if($s3->putObjectFile($file1, $bucket , $thumbimg, S3::ACL_PUBLIC_READ) )
			{
			$s3thumbFile=$this->_S3Url.$thumbimg;
			}
			
     	} 
     	//die;
     	if(!empty($res[0]['ID'])){
     		
     		// $optionData changed by Padmaja on 03-07-2014
     		
     		$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$thumbimg ,'photo'=>$upldFileName);
			//print_r($optionData);echo "<br>";////////
     		$this->setdatamodel->updateOption($optionData);
     		
		}else{
		
			// $insertOptionData changed by Padmaja on 03-07-2014
			
			$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$thumbimg,'photo'=>$upldFileName);
			$this->setdatamodel->insertOptions($insertOptionData);
			//print_r($insertOptionData);
//			die;
		}
     	unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     	unlink(FCPATH.'Uploads/QImages/'.$thumbimg);
		
     }else{ //selected question image
     		//
     	    $image = imagecreatefromjpeg($img1);
     	    $currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];
		    $upldFileName = $newFileName.'.'.'jpeg';
     	    imagejpeg($image,FCPATH.'Uploads/QImages/'.$upldFileName,100);
     	 
     	 	/*For adding s3 amazon images 
		 	 *@author: Added by Padmaja on 02-07-2014
		 	 */ 
     	    	
		   	$ext = $this->getExtension($upldFileName);
		 	$s3 = new S3($awsAccessKey, $awsSecretKey);
			$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
			$actual_image_name = time().".".$ext;
     		//echo $upldFileName;
		 	
		    $file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		//$success = file_put_contents($file, $data);
		    if($s3->putObjectFile($file, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
		   		$s3file=$this->_S3Url.$upldFileName;
		   	}
     		
		  				
			$config1['image_library'] = 'gd2';
			$config1['source_image'] = $file;
			$config1['create_thumb'] = TRUE;
			$arr = explode(".",$upldFileName);

			$config1['maintain_ratio'] = FALSE;
			$config1['width'] = 200;
			$config1['height'] =200;

			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			

			if($this->image_lib->resize())
			{
				$thumbimg = $arr[0]."_thumb.".$arr[1];
			}else {
				$thumbimg="";
			}	
			//print_r($thumbimg);
		   	
		   	
		   	
			$file1    = FCPATH.'Uploads/QImages/'.$thumbimg;
    		 if($s3->putObjectFile($file1, $bucket ,$thumbimg, S3::ACL_PUBLIC_READ) )
			{
			$s3thumbFile=$this->_S3Url.$thumbimg;
			}
		
     	if(!empty($res[0]['ID'])){
     		
     		// $optionData changes done by padmaja on 3-07-2014
     		$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[0]['ID'], 'thumb'=>$thumbimg ,'photo'=>$upldFileName);
			//print_r($optionData);
     		$this->setdatamodel->updateOption($optionData);
		}else{
		
			// $insertOptionData changes done by padmaja on 3-07-2014
			$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$thumbimg,'photo'=>$upldFileName);
			$this->setdatamodel->insertOptions($insertOptionData);
			
		}
     		unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     		unlink(FCPATH.'Uploads/QImages/'.$thumbimg);
     	}
     	//ended s3
     //	unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     	//unlink(FCPATH.'Uploads/QImages/'.$thumbName);
    }//end of image 1	
    
   
    if($img2){
    		
    		$res=$this->getdatamodel->getQOptions($qId);    	
            $parts   = explode(',', $img2);
     		$data    = $parts[1];
     		$data    = base64_decode($data); 
     		$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];
			$upldFileName = $newFileName.'.'.'jpeg';
		    
		   // $tmp = $_FILES[$upldFileName]['tmp_name'];
		    
		    /*For adding s3 amazon images to image2
		     *@author: Added by Padmaja on 02-07-2014
		     */
		 	
		   	$ext = $this->getExtension($upldFileName);
		 	$s3 = new S3($awsAccessKey, $awsSecretKey);
			$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
			$actual_image_name = time().".".$ext;
			$file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		$success = file_put_contents($file, $data);
     		if($s3->putObjectFile($file, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
		 		$s3file=$this->_S3Url.$upldFileName;
		   	}
     		$success = file_put_contents($file, $data);
     		
     		if($success){//create a thum image 200 * 200
     		
     		$config1['image_library'] = 'gd2';
			$config1['source_image'] = $file;
			$config1['create_thumb'] = TRUE;
			$arr = explode(".",$upldFileName);

			$config1['maintain_ratio'] = FALSE;
			$config1['width'] = 200;
			$config1['height'] =200;

			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			

			if($this->image_lib->resize())
			{
				$thumbimg = $arr[0]."_thumb.".$arr[1];
			}else {
				$thumbimg="";
			}	
			//print_r($thumbimg);
		   	
		   	
		   	
			$file1    = FCPATH.'Uploads/QImages/'.$thumbimg;
    		if($s3->putObjectFile($file1, $bucket ,$thumbimg, S3::ACL_PUBLIC_READ) )
			{
				$s3thumbFile=$this->_S3Url.$thumbimg;
			}
		
     	}
     	
     
     	if(!empty($res[1]['ID'])){
     		// $optionData changes done by padmaja on 3-07-2014
     		$optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[1]['ID'], 'thumb'=>$thumbimg ,'photo'=>$upldFileName);
			
     		//print_r($optionData);die;
     		
     		$this->setdatamodel->updateOption($optionData);
		}else{
		   // $insertOptionData changes done by padmaja on 3-07-2014
			$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$thumbimg,'photo'=>$upldFileName);
			//print_r($optionData);die;
			$this->setdatamodel->insertOptions($insertOptionData);
		}
		
		  //ended s3
		   
		unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     	unlink(FCPATH.'Uploads/QImages/'.$thumbimg);
    	
    }//end of image2
    
    
       if($img3){
       	$res=$this->getdatamodel->getQOptions($qId);    	
            $parts   = explode(',', $img3);
     		$data    = $parts[1];
     		$data    = base64_decode($data); 
     		$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];
		    $upldFileName = $newFileName.'.'.'jpeg';
		   //  $tmp = $_FILES[$upldFileName]['tmp_name'];
		     
		      	/*For adding s3 amazon images to image3
		     	*@author: Added by Padmaja on 02-07-2014
		     	*/
		   	$ext = $this->getExtension($upldFileName);
		 	$s3 = new S3($awsAccessKey, $awsSecretKey);
			$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
			$actual_image_name = time().".".$ext;
			$file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		$success = file_put_contents($file, $data);
		 	if($s3->putObjectFile($file, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
		   
		   		$s3file=$this->_S3Url.$upldFileName;
		 	
		   	 }
     		$success = file_put_contents($file, $data);
     		
     		if($success){	//create a thum image 200 * 200
     		
     		$config1['image_library'] = 'gd2';
			$config1['source_image'] = $file;
			$config1['create_thumb'] = TRUE;
			$arr = explode(".",$upldFileName);

			$config1['maintain_ratio'] = FALSE;
			$config1['width'] = 200;
			$config1['height'] =200;

			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			

			if($this->image_lib->resize())
			{
				$thumbimg = $arr[0]."_thumb.".$arr[1];
			}else {
				$thumbimg="";
			}	
			//print_r($thumbimg);
		   	
		   	
		   	
			$file1    = FCPATH.'Uploads/QImages/'.$thumbimg;
    		if($s3->putObjectFile($file1, $bucket ,$thumbimg, S3::ACL_PUBLIC_READ) )
			{
				$s3thumbFile=$this->_S3Url.$thumbimg;
			}
     	}
     	//echo $imageThumbName;
       
     	if(!empty($res[2]['ID'])){
     		 $optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[2]['ID'], 'thumb'=>$thumbimg ,'photo'=>$upldFileName);
			//print_r($optionData);die;
     		 $this->setdatamodel->updateOption($optionData);
	   }else{
			$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$thumbimg,'photo'=>$upldFileName);
			$this->setdatamodel->insertOptions($insertOptionData);
		}
		  // ended s3
		unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     	unlink(FCPATH.'Uploads/QImages/'.$thumbimg);
    }//end of image 3
    
    
    
       if($img4){
       		$res=$this->getdatamodel->getQOptions($qId);    	
            $parts   = explode(',', $img4);
     		$data    = $parts[1];
     		$data    = base64_decode($data); 
     		$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];
		    $upldFileName = $newFileName.'.'.'jpeg';
		   //  $tmp = $_FILES[$upldFileName]['tmp_name'];
		   
		    
		   		/*For adding s3 amazon images to image4
		     	*@author: Added by Padmaja on 02-07-2014
		     	*/
		   	$ext = $this->getExtension($upldFileName);
		 	$s3 = new S3($awsAccessKey, $awsSecretKey);
			$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);
			$actual_image_name = time().".".$ext;
			$file    = FCPATH.'Uploads/QImages/'.$upldFileName;
     		$success = file_put_contents($file, $data);
		 	if($s3->putObjectFile($file, $bucket , $upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
			 
		   		$s3file=$this->_S3Url.$upldFileName;
		 
		   	}
     		$success = file_put_contents($file, $data);
     		
     		if($success){//create a thum image 200 * 200
     		$config1['image_library'] = 'gd2';
			$config1['source_image'] = $file;
			$config1['create_thumb'] = TRUE;
			$arr = explode(".",$upldFileName);

			$config1['maintain_ratio'] = FALSE;
			$config1['width'] = 200;
			$config1['height'] =200;

			$this->load->library('image_lib', $config1);
			$this->image_lib->initialize($config1);
			

			if($this->image_lib->resize())
			{
				$thumbimg = $arr[0]."_thumb.".$arr[1];
			}else {
				$thumbimg="";
			}	
     		$file1    = FCPATH.'Uploads/QImages/'.$thumbimg;
    		if($s3->putObjectFile($file1, $bucket ,$thumbimg, S3::ACL_PUBLIC_READ) )
			{
				$s3thumbFile=$this->_S3Url.$thumbimg;
			}
     	}
     	
       
     	if(!empty($res[3]['ID'])){
     		 $optionData = array('qPalQ_ID'=>$qId,"ID"=>$res[3]['ID'], 'thumb'=>$thumbimg ,'photo'=>$upldFileName);
			//print_r($optionData);die;
     		 $this->setdatamodel->updateOption($optionData);
	    }else{
			$insertOptionData=array("optionName"=>"","qPalQ_ID"=>$qId,"thumb"=>$thumbimg,'photo'=>$upldFileName);
			$this->setdatamodel->insertOptions($insertOptionData);
		}
		    // ended s3
		unlink(FCPATH.'Uploads/QImages/'.$upldFileName);
     	unlink(FCPATH.'Uploads/QImages/'.$thumbimg);
    }//end of Image 4
    
    
    //end of create Q Images
	 
	 $groupMembersData=$this->getdatamodel->getGroupMembersDetails($groupId,0);
	 $nonRegGroupMembersData=$this->getdatamodel->getnonRegGroupMembersDetails($groupId);
	 $nonRegFbMembers=$this->getdatamodel->getnonRegFBGroupMembersDetails($groupId);
	 
     if($groupMembersData){
						foreach($groupMembersData as $rec){
							//karthik - 12/12/2013 - changed by karthik to fix a  BUG .
								
							// BUG -  the Q is  being added  to the RECEIVED Q table of the  sender which is wrong

							if ($userId == $rec['ID'])
							{
								//do nothing bcoz the sender of the Q should not be notified or entry added to RECIEVED Q
									
							}
							else
							{
							

	    $recievedQData=array("user_ID"=>$rec['ID'],"qPalQ_ID"=>$insertedQId);
		$this->setdatamodel->insertRecievedQ($recievedQData);
        $userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$insertedQId,'isNew'=>1);
        $this->setdatamodel->insertQBadges($userQBagesData);
								//To Send Push to Group Member
								//@author Rajesh on 27-11-2013
								if($rec['isPushAlerts']==1){
									$data13 = new StdClass;
									$data13->deviceToken = $rec['pushId'];
									$data13->message = "You have a new Q";
									$data13->typeID = "1";
					                $data13->param = $insertedQId;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data13);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}


							}
						}
					}
	 
	 
	 

	 
     if($nonRegGroupMembersData){

				foreach($nonRegGroupMembersData as $rec2){
							$email=$rec2['email'];
							$insertData=array("qPalQ_ID"=>$insertedQId,'email'=>$email);
							$this->setdatamodel->insertNonRecievedQ($insertData);

						}
					}
	if($nonRegFbMembers){
		foreach($nonRegFbMembers as $rec3){
				$fbId=$rec3['FBID'];
				$insertData=array("FBID"=>$fbId,"qPalQ_ID"=>$insertedQId);
				$this->setdatamodel->insertNonRecievedFbq($insertData);
			}
		}
		
      $fetchPrivateGroupId=$this->getdatamodel->fetchPrivateGroupId($insertedQId);
     $privateGropId=$fetchPrivateGroupId[0]['qPalQGroup_ID'];
					
					if($privateGropId!=0){
						
						$createRoomName="qPalQ_".$insertedQId;
						$this->setdatamodel->updateQRoomName($qId,$createRoomName);
						
					}
					
					
					
     	
					if($groupId){
						//echo $privateGropId;die;
						//echo "kjkjjj";
					$emailArr=array();
					$namesArr=array();
					$groupData=$this->getdatamodel->getGroupDetailsById($privateGropId);
					$groupName=$groupData[0]['name'];
					$regUsersData=$this->getdatamodel->getGroupMembersDetails($privateGropId,1);
					$nonRegUsersData=$this->getdatamodel->getnonRegGroupMembersDetails($privateGropId);
					$nonRegFBUsersData=$this->getdatamodel->getnonRegFBGroupMembersDetails($privateGropId);
					$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
			        $qcreatorUserId= $getQCreatorId[0]['user_ID'];
			        $getMemberData= $this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
				    $qCreatorName=$getMemberData[0]['displayName'];
			 		//print_r($regUsersData);
					if($regUsersData){
						foreach($regUsersData as $rec1){
							
							if($rec1['isEmailAlerts']==1){
								$emailArr[]=$this->convert($rec1['email']);
							}
							$namesArr[]=$rec1['firstName'];
						}
					}
					if($nonRegUsersData){
						foreach($nonRegUsersData as $rec2){
							$emailArr[]=$this->convert($rec2['email']);
							//print_r($emailArr);
							$namesArr[]=$rec2['name'];
						}
					}
					if($nonRegFBUsersData){
						foreach($nonRegFBUsersData as $rec3){
							$namesArr[]=$rec3['name'];
						}
					}
				
					for($i=0;$i< sizeof($emailArr);$i++){
						
						$msgStr="";
						$email=	$emailArr[$i];
						$encrEmail=$this->convert($email);
						$mailData['userName'] 	= $namesArr[$i];
						$namesArr1=$namesArr;
						unset($namesArr1[$i]);
						//print_r($namesArr1);
						$newarr=array();
						foreach($namesArr1 as $name){
							$newarr[]=$name;
						}
						//print_r($newarr);
						for($j=0;$j<sizeof($newarr);$j++){
							if($j==0){
								$msgStr.=$newarr[$j];
							}else if($j<=sizeof($newarr)-2){
								$msgStr.=", ".$newarr[$j];
							}else{
								$msgStr.=" and ".$newarr[$j];
							}
						}
						//echo $msgStr."<br/>";
						
						$mailData['qCreatorName']= $qCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['questionName']=$questionName;
						$mailData['option1']=$option1;
						$mailData['encrEmail']=$encrEmail;
						$mailData['qId']=$qId;
						//$mailData['thumb']= $thumb;
						
						$qImageData=$this->getdatamodel->getQImages($qId);
						if($qImageData){
						$imgName=$qImageData[0]['thumb'];
						//echo $imgName;die;
						if($imgName){
								$mailData['thumb']=$this->_S3Url.$imgName;// set s3Images folder by padmaja 
							}else{
								$mailData['thumb']=base_url()."Uploads/QImages/default_thumb.png";
							}
						}
						$from = $this->_supportEmail;
						//getting the mail content
						//echo "asdasd";
						$mailContet = $this->templatemodel->createQTemplate($mailData);
						$subject = "Q Alert";
						// call mailer function to send mail.
					
						 $data8 = new StdClass;
                                         $data8->from = $from;
                                         $data8->to = $email;
                                         $data8->subject = $subject;
                                         $data8->body = $mailContet;
                                         $message = json_encode($data8);
                                         $this->messagequeue->addMessageToMAILQueue($message);

					$status = true;

					}
						
				}
		
     		if($isFbShare==1 || $isTwitterShare==1 || $isPinterestShare==1){
						
					$countOfImages=$this->getdatamodel->countOfImages($qId);
			
			        if($countOfImages==0 || $countOfImages==1){//only one image or if no image
				    $numberOfImages = 1;
				     $x = 200;
                     $y = 200;
                     $background = imagecreatetruecolor($x, $y);
                     $color = imagecolorallocate($background, 255, 255, 255);//add background color
                     $outputImage = $background;
                     // fill entire image
                    imagefill($background, 0, 0, $color);
				    $getNotNullImages=$this->getdatamodel->getNotNullImages($qId);
				
			        if($getNotNullImages){
                      $getimage=$getNotNullImages[0]['thumb'];
                      $imageUrl=$this->_S3Url.$getimage;
                      $image=imagecreatefromjpeg($imageUrl);	
                   }else{
                      $imageUrl=base_url()."Uploads/QImages/default_thumb.jpg";
                      $image=imagecreatefromjpeg($imageUrl);	
                }
                
                $qImageData=$this->getdatamodel->getQImages($qId);
                $i=1;
                
			    foreach($qImageData as $qImageData){
                $optionName[$i]=$qImageData['optionName'];	
                $font = 6;
                $font_width = ImageFontWidth($font);
                $font_height = ImageFontHeight($font);
                $text_width = $font_width * strlen($optionName[$i]);
                $position_center = ceil(($x - $text_width));
                $text_height = $font_height;
                $position_middle = ceil(($y - $text_height));
             
                if($i==1){		   
		        $text_color = imagecolorallocate($image, 255, 255, 255);
                imagestring($image, $font, 0, 0, $optionName[$i], $text_color);
		       }elseif($i==2){
		     	$text_color1 = imagecolorallocate($image, 255, 255, 255);
                imagestring($image,$font, $position_center, 0, $optionName[$i], $text_color1);
		       }elseif($i==3){		   
		     	$text_color2 = imagecolorallocate($image, 255, 255, 255);
                imagestring($image, $font, $position_center,$position_middle,  $optionName[$i], $text_color2);
		       }elseif($i==4){		   	
		     	$text_color3 = imagecolorallocate($image, 255, 255, 255);
               imagestring($image, $font,0, $position_middle, $optionName[$i], $text_color3);
		      }
             
             $i++;
             }
             imagecopymerge($outputImage,$image,0,0,0,0, $x, $y,100);   
			}else{
			$numberOfImages = 4;
            $x = 200;
            $y = 200;
            $background = imagecreatetruecolor($x*2, $y*2);
            $color = imagecolorallocate($background, 255, 255, 255);
            // fill entire image
            imagefill($background, 0, 0, $color);
            $qImageData=$this->getdatamodel->getQImages($qId);
            $i=1;
            foreach($qImageData as $qImageData){
            	
            $imgName[$i]=$qImageData['thumb'];
            $optionName[$i]=$qImageData['optionName'];
            if($imgName[$i]){
			$Url[$i]=$this->_S3Url.$imgName[$i];
			$image[$i] = imagecreatefromjpeg($Url[$i]);
			}else{
			$Url[$i]=base_url()."Uploads/QImages/default.png";
			$image[$i] = imagecreatefrompng($Url[$i]);			
		   }
		   $outputImage = $background;
		   
		   if($i==1){
		   
		   $text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   imagestring($image[1], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   imagecopymerge($outputImage,$image[$i],0,0,0,0, $x, $y,100);
		   }elseif($i==2){
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);		   
		   	imagestring($image[$i], 5, 10, 180,$optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,0,0,0, $x, $y,100);
		   }elseif($i==3){		   
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],0,$y,0,0, $x, $y,100);
		   }elseif($i==4){		   	
		   	$text_color[$i] = imagecolorallocate($image[$i], 255, 255, 255);
		   	imagestring($image[$i], 5, 10, 180, $optionName[$i], $text_color[$i]);
		   	imagecopymerge($outputImage,$image[$i],$x,$y,0,0, $x, $y,100);
		   }
		   
            $i++;           
            }
			}
						
			$currEncTimestamp = str_split(sha1(microtime()),10);
		    $newFileName = $currEncTimestamp[0];		
		   $upldFileName = $newFileName;
           //$ourFileName ="/home/workstation/Qpals/qpals/Uploads/compositeImages/$upldFileName.jpeg";
           $ourFileName   =FCPATH."Uploads/compositeImages/$upldFileName.jpeg";
        	$s3upldFileName=$upldFileName.'.jpeg';
           	if($s3->putObjectFile($ourFileName, $bucket ,$s3upldFileName, S3::ACL_PUBLIC_READ) )
		   	{
			 
		   $s3file=$this->_S3Url.$s3upldFileName;
		   	}
		   	
		   	//echo $outputImage;echo "<br>";
            imagejpeg($outputImage, $ourFileName );	
            	//echo $outputImage;		
						
	}
		
		
		
		
		if($isFbShare==1){
			$this->setdatamodel->updateFBShare($qId,$isFBShare=1);
			//echo "facebook";
			if($fbId){
				include(BASEPATH.'application/libraries/facebook.php');
				$facebookConfig=array('appId'=>$this->config->item('appId'),'secret'=>$this->config->item('secret'));
			    $fb = new Facebook($facebookConfig);
			    
			 $getFbShare=$this->getdatamodel->getFbShare($userId,$qId);
			         $note=$getFbShare[0]['note'];
					foreach($getFbShare as $question){
                      $quesId=$question['question_ID'];
                  }
                  
                  
                //question name to share
                     $getQQuestion=$this->getdatamodel->getQQuestion($quesId);
                      foreach($getQQuestion as $queName){            	
            	         $questionName=$queName['name'];
            	      }
            	      
            	       //to fetch a Qimage			
			          $qImageData=$this->getdatamodel->getQImages($qId);
			         
			          if($qImageData){
			        // $ourFileName1 =base_url()."Uploads/compositeImages/$upldFileName.jpeg";
			          $s3upldFileName=$upldFileName.'.jpeg';
			         $ourFileName1 =$this->_S3Url.$s3upldFileName;
			          	$imgName=$ourFileName1;
			             if($imgName){
				        $picture=$imgName;
				      }else{
				      $picture=base_url()."Uploads/QImages/default_thumb.png";
				     }
			   }else{
				$picture=base_url()."Uploads/QImages/default_thumb.png";
			 }	
			 $link=base_url()."qwall/viewQ/".$qId."/3";//3 is for facebook source type
			 $params = array(           
             "message" => $questionName,
             "link" => $link,
             "picture" =>$picture,
             "name" => "",
             "caption" => "",
             "description" => $note);
                  
				try {
			 	//post a feed to facebook
			 	$ret = $fb->api('/'.$fbId.'/feed', 'POST', $params);
			 	
			 	if (array_key_exists("id",$ret))
			 	{
			 		//sucessfully posted to Wall
			 		$this->setdatamodel->updateFBShare($qId,$isFBShare=1);
			 		$resArr['result']	= 1;			 		
			 		$resArr['message']	= "Sucessfully posted to facebook";
			 	}
			 	else
			 	{
			 		//do nothing
			 		$this->setdatamodel->updateFBShare($qId,$isFBShare=0);
			 	}
			 	
			 } catch(Exception $e) {
			  	
			 	echo $e->getMessage();
			 }    
                  
                  
				
			}
		}
		
		if($isTwitterShare==1){	
			$this->setdatamodel->updateTwitterShare($qId,$isTwitterShare=1);
			$_SESSION['usertoken']=$accessToken;
			$_SESSION['usertokensecret']=$accessTokenSecret;
			include(BASEPATH.'application/libraries/tmhOAuthExample.php');
		    $tmhOAuth = new tmhOAuthExample();
		    
		    $getTwitterShare=$this->getdatamodel->getTwitterShare($userId,$qId);
		    $note=$getTwitterShare[0]['note'];
		    //to fetch Question id
            foreach($getTwitterShare as $question){
            $quesId=$question['question_ID'];
            }
            
            //question name to share
            $getQQuestion=$this->getdatamodel->getQQuestion($quesId);
            
            foreach($getQQuestion as $queName){
            	
            	$questionName=$queName['name'];
            	
            }
            
            //to fetch a Qimage	
			$pathQImage=$this->config->item('qImageUploadPath');
			//echo $pathQImage;		
			$qImageData=$this->getdatamodel->getQImages($qId);
			$link=base_url()."qwall/viewQ/".$qId."/4";//social sharing using twitter
			
			if($qImageData){				
			 $imgName=$qImageData[0]['thumb'];
			
			
				 if($imgName){
				 	
						$image=$ourFileName;
					}else{
						
						$image=$pathQImage."default_thumb.png";
					}
			  }else{			  
				$image=$pathQImage."default_thumb.png";
			  }	
			  
			 $name  = basename($image);
           $status = $questionName;
          // $twitter_content = $questionName.' '.base_url().'qwall/viewQ/'.$resArr['qId'].'/4';
           //$tweet = preg_replace("/([w]+://[w-?&;#~=./@]+[w/])/", "<a target="" href="$link">$link</a>", $twitter_content); 
           $code = $tmhOAuth->user_request(array(           
           'method' => 'POST',
           'url' => $tmhOAuth->url('1.1/statuses/update_with_media'),
           'params' => array(
            
            'media[]'  => "@{$image};filename={$name}",
            
            'status'   => $status.'-'.$link,
             ),
            'multipart' => true,
             
            ));
		}
		 $responseData=$qId;
		if($isPinterestShare==1){
			$this->setdatamodel->updatePinterestShare($qId,$isPinterestShare=1);
			//$resArr['pinterestUrl']=base_url()."qwall/viewQ/".$qId."/5";
			$questionName=$questionName;
			 $qImageData=$this->getdatamodel->getQImages($qId);
			          if($qImageData){
			          	
			         // $ourFileName1 =base_url()."Uploads/compositeImages/$upldFileName.jpeg";
			          //$ourFileName1 =$this->_S3Url.$upldFileName;
			         	 $s3upldFileName=$upldFileName.'.jpeg';
			        	 $ourFileName1 =$this->_S3Url.$s3upldFileName;
			          	$imgName=$ourFileName1;
			             if($imgName){
				        $picture=$imgName;
				      }else{
				      $picture=base_url()."Uploads/QImages/default_thumb.png";
				     }
			   }else{
				$picture=base_url()."Uploads/QImages/default_thumb.png";
			 }	
			 
			 $compositeImage=$picture;
			 $responseData.="@".$compositeImage;
			 $responseData.="@".$questionName;
		}
	    $unlinkImage =$upldFileName.'.jpeg';
		unlink(FCPATH.'Uploads/compositeImages/'.$unlinkImage);
     	
	
	 echo $responseData;
	 
	 
     	
  }//end of insert Q
  
  
     
     
  /*
   * facebook share
   */
  
  
  function facebookShare(){
  	include(BASEPATH.'application/libraries/facebook.php');
  	 $config = array(
      'appId' => $this->config->item('appId'),
      'secret'=>$this->config->item('secret')
      
   );

    $facebook = new Facebook($config);   
    $user = $facebook->getUser();
    
    $params = array(
   'scope'=> 'email,read_stream, publish_stream',  
   'display'=>'popup');

   $loginUrl = $facebook->getLoginUrl($params);
   $user = $facebook->getUser();
   if (!$user)
		{		
			
      header("location:$loginUrl");      
		}
   else
   {
   	echo $facebook->getUser();
   	echo $access_token=$facebook->getAccessToken();
   
  	//do nothing
   }
  
 }
  
 
 /*
  * twitter share
  */
 
 
function twitterLogin()
	{
		if(isset($_REQUEST['error'])) {
			echo "<script>self.window.close();</script>";
		}else{
		
		$this->load->view('twitter/connect');
		}
	}
	function twtClearSessions()
	{
		$this->load->view('twitter/clearsessions');
	}
	function twitterConnect()
	{
		$this->load->view('twitter/connect');
	}
	function twitterSigin()
	{
		$this->load->view('twitter/redirect');
	}
	function twitterCallback()
	{
		$this->load->view('twitter/callback');
	}
	
function twitterClose()
	{
		echo "<script>self.window.close();</script>";
	}
	
	
	
}//end of class
