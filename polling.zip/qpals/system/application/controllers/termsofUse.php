<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class termsofUse extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');

		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
  /**
	 * Converting string into Encrypt or decrypt format
	 * @author Rajesh on 18-09-2013
	 * @param $str
	 */
	function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	
	
	/*
	 * @Author asha on 13-2-2014
	 * home page
	 */
	
	
	public function terms(){
		$data['active']="";
		$this->load->view('termsofUse',$data);
		
	}
	
	
}