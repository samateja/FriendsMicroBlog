<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// To avoid back button after logout
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0", false);
//header("Cache-Control: post-check=0, pre-check=0", false);
// HTTP/1.0
header("Pragma: no-cache");
// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Asha on 13-02-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class qwall extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
		$this->load->library('form_validation');	
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->library('pagination');
		$this->load->model('messagequeue');
		$sessionlog=$this->session->userdata('userID');
		//print_r($sessionlog); echo "Hello";die;
	    $sourceType=$this->uri->segment(4);
	    
	    	// Added by padmaja
	    $this->_S3Url = $this->config->item('S3Url');
		$this->load->model('qpalsamazons3model');
		$this->load->library('s3upload/S3.php');
	    $bucket = $this->config->item("bucket");
		$awsAccessKey = $this->config->item('awsAccessKey');
		$awsSecretKey = $this->config->item('awsSecretKey');
 
		/*
		if(!$sessionlog && $sourceType!=""){
			 $link = $_SERVER['REDIRECT_URL'];
             $this->session->set_userdata(array('redirectUrl'=> $link));
			redirect('socialSharing');
		}
		
	    if(!$sessionlog){
	    	//echo $sessionlog;
			redirect('home');
		}
		
		*/
       
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
   function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
  
	
	
	public function qwallView($id=''){
		
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$flag=$this->input->post('flag');
		$searchText=$this->input->post('searchAll');
		$data['showAllQs']=$this->getdatamodel->getTotalQsOnQwall($sesUserId,$searchText);//private Qs
		$data['iCreated']=$this->getdatamodel->getMyQsOnQwall($sesUserId,$searchText);	
	    $data['iReplied']=$this->getdatamodel->getrepliedQsOnQwall($sesUserId,$searchText);
		$data['favorites']=$this->getdatamodel->getFavoritesOnQwall($sesUserId,$searchText);
		$data['followed']=$this->getdatamodel->getMyQFollowedOnQwall($sesUserId,$searchText);
		$data['publicQs']=$this->getdatamodel->getPublicQs();
		if($id){
			$data['enableJS']=1;
		}	
		
		$this->load->view('qwall',$data);
	}
	
	public function qwallSearchAllQs(){
		$bucket = $this->config->item("bucket");
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		$showAllQs=$this->getdatamodel->getTotalQsOnQwall($sesUserId,$searchText);
		$response='';
		$response.=' <div class="row-fluid" id="showQs"><div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">';
	    if($showAllQs) { $i=1;
                        
                       foreach($showAllQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
						}
						$qurl=base_url()."qwall/viewQ/$qId";
						
						$response.='<div class="span3 thumbs_group">                      
                      <a href="'.$qurl.'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" />                    
                       </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$qsn.'</div>
                        
                              <div class="comment_bg_qwall"> <p>'.$responseCount.'</p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="">'.$qAge.' by <span class="f_bold_italic">'.$uname.'</span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> ';
						
			if($i%4==0){$response.="</div><div class='row'>";}
         $i++;}}
         $response.="</div></div></div>";
		echo $response;
	}
	
	
	
	
	
   public function qwallSearchIcreated(){
   		$bucket = $this->config->item("bucket");
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		$IcreatedQs=$this->getdatamodel->getMyQsOnQwall($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="showICreated" ><div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">';
	    if($IcreatedQs) { $j=1;
                        
                       foreach($IcreatedQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
						}
						$qurl=base_url()."qwall/viewQ/$qId";
						$response.='<div class="span3 thumbs_group">                      
                       <a href="'.$qurl.'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" />                    
                       </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$qsn.'</div>
                        
                              <div class="comment_bg_qwall"> <p>'.$responseCount.'</p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="">'.$qAge.' by <span class="f_bold_italic">'.$uname.'</span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> ';
						
			if($j%4==0){$response.="</div><div class='row'>";}
         $j++;}}else{
         	$response.="no qs available";
         }
         $response.="</div></div></div>";
		echo $response;
	}
	
	
  public function qwallSearchIReplied(){
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		$repliedQs=$this->getdatamodel->getrepliedQsOnQwall($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="showIReplied" ><div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">';
	    if($repliedQs) { $k=1;
                        
                       foreach($repliedQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
						}
						$qurl=base_url()."qwall/viewQ/$qId";
						$response.='<div class="span3 thumbs_group">                      
                      <a href="'.$qurl.'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" />                    
                       </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$qsn.'</div>
                        
                              <div class="comment_bg_qwall"> <p>'.$responseCount.'</p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="">'.$qAge.'  by <span class="f_bold_italic">'.$uname.'</span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> ';
						
			if($k%4==0){$response.="</div><div class='row'>";}
         $k++;}}else{
         	$response.="no qs available";
         }
         $response.="</div></div></div>";
		echo $response;
	}
	
	
	
 public function qwallSearchFavourites(){
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		$FavouritesQs=$this->getdatamodel->getFavoritesOnQwall($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="showFavorites" ><div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">';
	    if($FavouritesQs) { $l=1;
                        
                       foreach($FavouritesQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
						}
						$qurl=base_url()."qwall/viewQ/$qId";
						$response.='<div class="span3 thumbs_group">                      
                      <a href="'.$qurl.'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" />                    
                       </a>
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$qsn.'</div>
                        
                              <div class="comment_bg_qwall"> <p>'.$responseCount.'</p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="">'.$qAge.'  by <span class="f_bold_italic">'.$uname.'</span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> ';
						
			if($l%4==0){$response.="</div><div class='row'>";}
         $l++;}}else{
         	$response.="no qs available";
         }
         $response.="</div></div></div>";
		echo $response;
	}
	
	
 public function qwallSearchFollowed(){
		$data['active']=4;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		$FollowedQs=$this->getdatamodel->getMyQFollowedOnQwall($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="showFollowed" ><div class="container content_inner h_line_profile" style="overflow:auto;height:600px;">
           
                 <div class="row">';
	    if($FollowedQs) { $m=1;
                        
                       foreach($FollowedQs as $rec){
                       	$qId=$rec['ID'];
                       	$qsn=$rec['name'];
                       	$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
						
						if($getAggregateVotes){
							$opt1 = $getAggregateVotes[0]['opt1'];
					        $opt2 = $getAggregateVotes[0]['opt2'];
					        $opt3 = $getAggregateVotes[0]['opt3'];
					        $opt4 = $getAggregateVotes[0]['opt4'];
					        
						    if ($opt3 == NULL)
					        {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
						
				      $time1 = $rec['timeStamp'];
					  $time1=date("Y-m-d H:i:s", strtotime($rec['timeStamp']." UTC"));
					  $time2 = date('Y-m-d H:i:s');
					  $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					  $userId=$rec['user_ID'];
					  $qImageData=$this->getdatamodel->getQImages($qId);
					  if($qImageData){
					  	$imgName=$qImageData[0]['thumb'];
					  if($imgName){
								$thumb=$this->_S3Url.$imgName;
							}else{
								$thumb=base_url()."Uploads/QImages/default_thumb.png";
						}
					  }else{
							$thumb=base_url()."Uploads/QImages/default_thumb.png";
					  }	
					  
                       $qCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						if($qCreatorDetails){
						
							$uname=$qCreatorDetails[0]['displayName'];
						}else{
							$uname="";
						}
						 $qurl=base_url()."qwall/viewQ/$qId";
						$response.='<div class="span3 thumbs_group">                      
                     <a href="'.$qurl.'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" />                    
                      </a> 
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$qsn.'</div>
                        
                              <div class="comment_bg_qwall"> <p>'.$responseCount.'</p></div>
                        </td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="">'.$qAge.' by <span class="f_bold_italic">'.$uname.'</span>   </div>  </td>                     
                     </tr>                 
                    </table>
                   </div> ';
						
			if($m%4==0){$response.="</div><div class='row'>";}
         $m++;}}else{
         	$response.="no qs available";
         }
         $response.="</div></div></div>";
		echo $response;
	}
	
	//end of qwall
	
	
	/*
	 * view q @Author Asha on 6-3-2014
	 */
	
	public function viewQ($qId=0,$u=0,$Id=0){
		//print_r($qId);
		//print_r($u);
		//print_r($Id); die;
 if ($qId != 0 )
 {
	 if ($u == 0 && $Id == 0 )
	 {
		$data['active']="viewQue";
		//$sesUserId=$this->session->set_userdata($newdata);
		//$data['userId']=$this->session->set_userdata($newdata);
		$sesUserId=$this->session->userdata('userID');
		$data['userId']=$this->session->userdata('userID');
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		//print_r($getQCreatorId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$data['isPublic']=$getQCreatorId[0]['isPublic'];
		$data['isFBShare']=$getQCreatorId[0]['isFBShare'];
		$data['isTwitterShare']=$getQCreatorId[0]['isTwitterShare'];
		$data['isPintrestShare']=$getQCreatorId[0]['isPintrestShare'];		
		$data['qcreatorNotes']= $qcreatorNotes;
		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		$data['getPrivateGroupMembers']=$this->getdatamodel->getPrivateGroupMembers($qId);
		
		$data['getSocialComments']=$this->getdatamodel->getSocialComments($qId,$sesUserId);
		
		$data['shownotification'] = 0;
		$this->load->view('viewQ',$data);
	}
	
		else
		{
			
		$data= $this->getdatamodel->checkunregistereduser($Id);
		$rowID = $data[0]['ID'];  
		if($data == NUll)
		{
			$data['active']="viewQue";
		//$sesUserId=$this->session->set_userdata($newdata);
		//$data['userId']=$this->session->set_userdata($newdata);
		$sesUserId=$this->session->userdata('userID');
		$data['userId']=$this->session->userdata('userID');
		
		
		
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		//print_r($getQCreatorId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$data['isPublic']=$getQCreatorId[0]['isPublic'];
		$data['isFBShare']=$getQCreatorId[0]['isFBShare'];
		$data['isTwitterShare']=$getQCreatorId[0]['isTwitterShare'];
		$data['isPintrestShare']=$getQCreatorId[0]['isPintrestShare'];		
		$data['qcreatorNotes']= $qcreatorNotes;
		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		$data['getPrivateGroupMembers']=$this->getdatamodel->getPrivateGroupMembers($qId);
		
		$data['getSocialComments']=$this->getdatamodel->getSocialComments($qId,$sesUserId);
		
		$data['shownotification'] = 0;
		$this->load->view('viewQ',$data);
		}
		//print_r($rowID); die;
		if ($rowID == $Id)
		{
			$fetchunregistereduser = $this->getdatamodel-> fetchunregistereduser($Id);
			
			foreach ($fetchunregistereduser as $rec)
			{
			$IDArr[]      = $rec['ID'];
			$nameArr[]    = $rec['name'];
			$emailArr[]   = $rec['email'];
			$groupIDArr[] = $rec['group_ID'];
			$timestampArr[] = $rec['timeStamp'];
			} 
			$ID = $IDArr[0]; 
			$name = $nameArr[0]; 
			$email = $emailArr[0]; 
			$groupID = $groupIDArr[0];
			$timestamp= $timestampArr[0];
			$accessCodeGenerator 		        = str_split(sha1(microtime()),7);
			$accessCode				            = $accessCodeGenerator[0];
			$userInsertData['password']			= md5($accessCode);
			//$pass = 1234;
			$password =md5($accessCode);
			$statusID = 1;
			$thumb = "avatar_thumb.png";
			$photo = "photo.png";
			$isEmailAlerts = 1;
			$isPushAlerts = 1;
			$defaultGroup_ID = 0;
			$defaultQuestion_ID = 0;

			$inserttousersdata = $this->getdatamodel -> inserttousersdata($ID,$name,$email,$groupID,$timestamp,$password,$statusID,$thumb,$photo,$isEmailAlerts,$isPushAlerts,$defaultGroup_ID,$defaultQuestion_ID); 
			
			if($inserttousersdata){
				$this->setdatamodel->deleteSecondaryEmail($email);
				$nonRegGroupDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($email);
					if($nonRegGroupDetails){
						foreach($nonRegGroupDetails as $rec){
							$groupMemberData=array('user_ID'=>$ID, 'group_ID' => $groupID, 'status_ID' =>1);
							$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
						}
					}
					$this->setdatamodel->deleteNonRegisteredMemeber($email);
			
			
			}
			//$groupMemberData=array('user_ID'=>$ID, 'group_ID' => $groupID, 'status_ID' =>1);
			//$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);				
			//echo "hello World";
			
			$newdata = array(
				   'userID'  => $ID,
				   'is_logged_in' => true
				   	
               );
        $data['active']="viewQue";
		$sesUserId=$this->session->set_userdata($newdata);
		$data['userId']=$this->session->set_userdata($newdata);
		//print_r($data['userId']);die;
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		//print_r($getQCreatorId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$data['isPublic']=$getQCreatorId[0]['isPublic'];
		$data['isFBShare']=$getQCreatorId[0]['isFBShare'];
		$data['isTwitterShare']=$getQCreatorId[0]['isTwitterShare'];
		$data['isPintrestShare']=$getQCreatorId[0]['isPintrestShare'];		
		$data['qcreatorNotes']= $qcreatorNotes;

		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		$data['getPrivateGroupMembers']=$this->getdatamodel->getPrivateGroupMembers($qId);
		//print_r($data['getPrivateGroupMembers']);
		$data['getSocialComments']=$this->getdatamodel->getSocialComments($qId,$sesUserId);
		
					//$this->load->view('viewQ',$data); 
					
					$this->setdatamodel->deleteNonRecQ($email);
					$from = $this->_supportEmail;
					
					$mailData['userName'] 	= $name;
					$mailData['email'] 		= $email;
					$mailData['password'] 	= $accessCode;
					$mailData['emailpassword'] = $this->convert($email);

					$mailContet = $this->templatemodel->socialSharingunregisterMailTemplate($mailData);
					$subject = "Welcome to QPals";
					// call mailer function to send mail.
					//$status = mailer($from, $email, $subject, $mailContet);
					 $maildata = new StdClass;
					 $maildata->from = $from;
					 $mail = $this->convert($email);
                     $maildata->to = ($mail);
                     $maildata->subject = $subject;
                     $maildata->body = $mailContet;
                     $message = json_encode($maildata);
                     $this->messagequeue->addMessageToMAILQueue($message);
					 $status = true;
					
					if($status){												
						$res=$this->getdatamodel->getUserDetailsByUserID($ID);
						//$this->login_post($email,$password,$osVersion,$appVersion,$deviceType);
						$userData['userId']			= $res[0]['ID'];
						//$userData['firstName']		= $res[0]['firstName'];
						$userData['name']		= $res[0]['displayName'];
						$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
						$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
						$userData['accessToken']	= $res[0]['accessToken'];						
						
						//To get count of group notifications which needs user approval
						$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
                         
						$emailPost = trim($this->input->post('email', TRUE));
			            $password1 = trim($this->input->post('password', TRUE));
			            $email1=$this->convert(strtolower($emailPost));
			
						$res=$this->getdatamodel->login($email1, $password1);				
				        if($res){					
					    $userdata=array('userID'   =>$res[0]['ID'],
					            'firstName'=>$res[0]['firstName'],
					            'lastName' => $res[0]['lastName'],
					            'is_logged_in' => true);
					
					//print_r($data);
					    $this->session->set_userdata($userdata);
					   
						
						//echo "Thank You for registering with Qpals.";
					}
					$data['userId'] = $ID;
					
					$data['shownotification'] = 1;
					$this->load->view('viewQ',$data); 
				}
				else{
					echo "Registration failed.";
				}
		
			
		}
		
		}	
		
	}
}
	
	
	/*
	 * function to vote q
	 * @Author Asha on 10-3-2014
	 */
	
	public function voteQ(){
		$qId =$this->input->post('qId');
		$data['qId']=$this->input->post('qId');
		$sesUserId=$this->session->userdata('userID');
		$voteFor=$this->input->post('optionId');
		$voteSourceType=$this->input->post('voteSource');
	       //  die;
				 $getGroupId =$this->getdatamodel->getUserIdFromQId($qId);
				 $groupIdForQ=$getGroupId[0]['qPalQGroup_ID'];
		         if($groupIdForQ){
				 $groupMembersData=$this->getdatamodel->getGroupMembersDetails($groupIdForQ,0);
				 $getGroupName=$this->getdatamodel->getGroupDetailsById($groupIdForQ);
				 $groupNameDisp=$getGroupName[0]['name'];
		         	if($groupMembersData){
						foreach($groupMembersData as $rec){
							//print_r($rec);
							
							$sesUser=$rec['isCreator'];
							if ($sesUserId == $rec['ID'])
							{  //print_r($rec);
								//echo "asdas";
								//do nothing bcoz the sender of the Q should not be notified or entry added to RECIEVED Q
									
							}
							else
							{   
								 if(!$sesUser){
								$recievedQData=array("user_ID"=>$rec['ID'],"qPalQ_ID"=>$qId);
								$this->setdatamodel->insertRecievedQ($recievedQData);
								}
								//insert user Q Badges 
								//@Author Asha on 14-5-2014

								$getUserQBadges=$this->getdatamodel->getUserQBadge($rec['ID'],$qId);
								$getUserDeatails=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
								$repliedMemberName=$getUserDeatails[0]['displayName'];
								//print_r($getUserQBadges);die;
								if($getUserQBadges){
									//echo "dsf";die;
								//$userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$qId,'isNew'=>1);
								$this->setdatamodel->updateUserQBadgesForVote($rec['ID'],$qId);	
								}else{
								$userQBagesData=array('user_ID'=>$rec['ID'],'qPalQ_ID'=>$qId,'isNew'=>1);
                                $this->setdatamodel->insertQBadges($userQBagesData);
								}
								//To Send Push to Group Member
								//@author Rajesh on 27-11-2013
								//echo "message";
								if($rec['isPushAlerts']==1){
									//print_r($rec['isPushAlerts']);
									$data13 = new StdClass;
									$data13->deviceToken = $rec['pushId'];
									$data13->message = "$repliedMemberName from the $groupNameDisp replied to your Q. Check it now.";
									$data13->typeID = "1";
					                $data13->param = $qId;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data13);
									//print_r($message);
									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}


							}
						}
					}
		         }
		
		
		
		
		
		
		
		$getCountQVotes=$this->getdatamodel->getCountQVotes($qId,$sesUserId);
		$voteQdata=array('qID'=>$qId,'userID'=>$sesUserId,'votedOption'=>$voteFor,'voteSourceType'=>$voteSourceType);
	    if($getCountQVotes[0]['qCount']==0){										
		$insertQVotes=$this->setdatamodel->insertQVotes($voteQdata);		
		}else{
		$updateQVotes=$this->setdatamodel->updateQVotes($voteQdata);
		}
		$data['userId']=$this->session->userdata('userID');
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		ob_start();
        $this->load->view('ajaxViewQType2',$data);
        $membersData=ob_get_contents();
        ob_end_clean();
        echo $membersData;
		
	}
	
	
 public function voteAnswer(){
		$qId =$this->input->post('qId');
		$data['qId']=$this->input->post('qId');
		$sesUserId=$this->session->userdata('userID');
		$voteFor=$this->input->post('optionId');
		$voteSourceType=$this->input->post('voteSource');;
		$getCountQVotes=$this->getdatamodel->getCountQVotes($qId,$sesUserId);
		$voteQdata=array('qID'=>$qId,'userID'=>$sesUserId,'votedOption'=>$voteFor,'voteSourceType'=>$voteSourceType);
	    if($getCountQVotes[0]['qCount']==0){										
		$insertQVotes=$this->setdatamodel->insertQVotes($voteQdata);		
		}else{
		$updateQVotes=$this->setdatamodel->updateQVotes($voteQdata);
		}
		$data['userId']=$this->session->userdata('userID');
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		ob_start();
        $this->load->view('ajaxViewQType3',$data);
        $membersData=ob_get_contents();
        ob_end_clean();
        echo $membersData;
		
	}
	
	
	/*
	 * social comments
	 */
	
	public function socialComments(){
		$bucket = $this->config->item("bucket");
		$qId =$this->input->post('qId');
		$userId=$this->input->post('userId');
		$comments=$this->input->post('comments');
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);		
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$userData=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$qCreatorDisplayName = $userData[0]['displayName'];
        //$qCreatorProfileImageThumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
        $qCreatorProfileImageThumb= $this->_S3Url.$userData[0]['thumb'];// changed by padmaja on 03-07-2014
		$postComments=array('qId'=>$qId,'userId'=>$userId,'comments'=>$comments);
		$commentsId=$this->setdatamodel->setSocialComments($postComments);
		$getSocialComments=$this->getdatamodel->getSocialComments($qId,$userId);
		$response="";
		if($commentsId){

			$response.='<div id="showComments" class="row h_line_gray">
                        <div style="margin-top:1em" class="span6" >';
             if($qcreatorNotes) { 
              /*  ping_box div modified by padmaja 13-05-2014*/
             	 $response.='<div class="ping_box">
             	 			
                           <div class="ping_pic "><img src='.$qCreatorProfileImageThumb.' width="60" height="60" alt="" /></div>
							
							
                           <div class="ping_green">
                         
                           <div class="f_bold_italic">'.$qCreatorDisplayName.'</div>
                           <div style="height:4px"></div>
                            <div class="f_italic" >
                            '.$qcreatorNotes.'
                            </div><br>   </div>
                          </div>';
             }
			
             foreach($getSocialComments as $row){  
             //$thumb=base_url()."Uploads/ProfilePictures/".$row['thumb'];

             	// changed by padmaja on 03-07-2014
             
                if($row['thumb'] != 'avatar_thumb.png'){
                  	//echo "asdas";
                  	$thumb		= $this->_S3Url.$row['thumb'];
                  }else{
                  	$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
                  }
            // $thumb=$row['thumb'];
             $displayName=$row['displayName'];
             $comments=$row['comments']; 
           /*  ping_box div modified by padmaja 13-05-2014*/
             $response.='<div class="ping_box">
             				
                           <div class="ping_pic sfds"><img src='.$thumb.' width="60" height="60" alt="" /></div>
                         
                           
                           <div class="ping_green">
                          
                           <div class="f_bold_italic">'.$displayName.'</div>
                           <div class="f_italic" >
                            '.$comments.'
                            </div><br> </div>
                          </div>';
             }
                          
                         
            $response.='</div>                    
                        <div style="margin-top:1em" class="span6" > 
                      <textarea placeholder="Type here to leave a comment" class="txt_chat" name="comment" id="comment" maxlength="100" style="font-style:italic"></textarea>
                      <button class="btn_small_green" id="postComment" onclick="return postComments();">POST</button>
                      
                       </div>
              
              </div>';
		}
		echo $response;
	}
	
	/*
	 * Added by padmaja
	 */
	
	public function getComments(){
		
		$qId =$this->input->post('qId');
		$userId=$this->input->post('userId');
		$comments=$this->input->post('comments');
		//echo $comments;die;
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);		
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$userData=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$qCreatorDisplayName = $userData[0]['displayName'];
       	//$qCreatorProfileImageThumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
       	// changed by padmaja on 03-07-2014
		$qCreatorProfileImageThumb= $this->_S3Url.$userData[0]['thumb'];
		$postComments=array('qId'=>$qId,'userId'=>$userId,'comments'=>$comments);
		//$commentsId=$this->setdatamodel->setSocialComments($postComments);
		$getSocialComments=$this->getdatamodel->getSocialComments($qId,$userId);
		$response="";
		//echo $postComments;die;
		//if($commentsId){

			$response.='<div id="showComments" class="row h_line_gray">
                        <div style="margin-top:1em" class="span6" >';
           	if($qcreatorNotes) { 
              /*  ping_box div modified by padmaja 13-05-2014*/
             	 $response.='<div class="ping_box">
             	 			
                           <div class="ping_pic"><img src='.$qCreatorProfileImageThumb.' width="60" height="60" alt="" /></div>
							
							
                           <div class="ping_green">
                         
                           <span class="f_bold_italic">'.$qCreatorDisplayName.'</span>
                            <br> <span class="f_italic">
                            '.$qcreatorNotes.'
                            </span><br></div>
                          </div>';
             }
			if($getSocialComments){
             foreach($getSocialComments as $row){  
             	// changed by padmaja on 03-07-2014
	            // $thumb=base_url()."Uploads/ProfilePictures/".$row['thumb'];
	             $thumb=$this->_S3Url.$row['thumb'];
	             $displayName=$row['displayName'];
	             $comments=$row['comments']; 
	           /*  ping_box div modified by padmaja 13-05-2014*/
	             $response.='<div class="ping_box">
	             				
	                           <div class="ping_pic"><img src='.$thumb.' width="60" height="60" alt="" /></div>
	                          
	                           
	                           <div class="ping_green">
	                          
	                           <span class="f_bold_italic">'.$displayName.'</span>
	                            <br> <span class="f_italic">
	                            '.$comments.'
	                            </span><br>  </div>
	                          </div>';
	             }
                          
			}         
            $response.='</div>                    
                        <div style="margin-top:1em" class="span6" > 
                      <textarea placeholder="Type here to leave a comment" class="txt_chat" name="comment" id="comment" maxlength="100" style="font-style:italic"></textarea>
                      <button class="btn_small_green" id="postComment" onclick="return postComments();">POST</button>
                      
                       </div>
              
              </div>';
		//}  
		echo $response;
	}
/* Added by padmaja*/
	public function refreshViewQ($qId=0){
		
		$data['active']="viewQue";
		$qId =$this->input->post('qId');
		$userId=$this->input->post('userId');
		$comments=$this->input->post('comments');
		$sesUserId=$this->session->userdata('userID');
		$data['userId']=$this->session->userdata('userID');
		$getQCreatorId =$this->getdatamodel->getUserIdFromQId($qId);
		//print_r($getQCreatorId);
		$qcreatorUserId= $getQCreatorId[0]['user_ID'];
		$qcreatorNotes= $getQCreatorId[0]['note'];
		$data['isPublic']=$getQCreatorId[0]['isPublic'];
		$data['isFBShare']=$getQCreatorId[0]['isFBShare'];
		$data['isTwitterShare']=$getQCreatorId[0]['isTwitterShare'];
		$data['isPintrestShare']=$getQCreatorId[0]['isPintrestShare'];		
		$data['qcreatorNotes']= $qcreatorNotes;
		$data['qcreatorUserId']= $getQCreatorId[0]['user_ID'];
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($qcreatorUserId);
		$data['getQOptions']=$this->getdatamodel->getQOptions($qId);
		$data['getOptionCount']=$this->getdatamodel->qpalsCountOptions($qId);
		$data['getImgCount']=$this->getdatamodel->qpalsCountImages($qId);
		$data['getPrivateGroupMembers']=$this->getdatamodel->getPrivateGroupMembers($qId);
		$data['getSocialComments']=$this->getdatamodel->getSocialComments($qId,$sesUserId);
		ob_start();
        $this->load->view('ajaxRefreshView',$data);
        $refreshData=ob_get_contents();
        ob_end_clean();
        echo $refreshData;
		
	}
function login(){
		
	 	$data['active']=1;
		$this->form_validation->set_rules('email','Enter Email','trim||required|valid_email');
		$this->form_validation->set_rules('password', 'Enter Password', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		else
		{
			$emailPost = trim($this->input->post('email', TRUE));
			$password = trim($this->input->post('password', TRUE));
			$email=$this->convert(strtolower($emailPost));
			//echo $emailPost;die;
			$isValidEmailAddress   = $this->getdatamodel->checkUserByEmail($email);			
			$isValidSecEmailAddress=$this->getdatamodel->checkSecondaryEmail($email, 1);
			$isValidPassword 	   = $this->getdatamodel->login($email, $password);
			
			if(($isValidEmailAddress || $isValidSecEmailAddress) && $isValidPassword){
				
				$res=$this->getdatamodel->login($email, $password);				
				if($res){					
					$data=array('userID'   =>$res[0]['ID'],
					            'firstName'=>$res[0]['firstName'],
					            'lastName' => $res[0]['lastName'],
					            'is_logged_in' => true);
					
					$this->session->set_userdata($data);	
							
					echo 1;//"success";
					
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					
					//fetch access token
					$getUserData	= $this->getdatamodel->getUserDetailsByUserID($res[0]['ID']);
					$tokenGet=$getUserData[0]['accessToken'];
					
				   if($tokenGet !=""){
				   //$userData['accessToken']	= $getUserData[0]['accessToken'];
					$expiry = $this->config->item('tokenExpiry');					
					foreach($getUserData as $toknes){
					$loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
					$thirty_days_ahead =   date('Y-m-d');
					if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						$this->pdo->where('ID',$userData['userId']);
						$tkn = $this->pdo->update($this->user, $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
						
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $data['userID'],'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($data['userID']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
				
			}
					
				}else{
				    echo "Invalid login details";
				}
				
			}else{
			   if(!$isValidEmailAddress){
			   
					echo "Invalid Email address.";
				}else if(!$isValidPassword){
					echo "The password you entered is incorrect.";
				}
			}
		}
	}
	
	function userRegistration(){
		$data['active']=1;
		
		
		$this->form_validation->set_rules('email', 'Enter Email', 'trim|xss_clean|required|valid_email');		
		$displayName =$this->input->post('displayName');
		$email       =$this->input->post('email');
		
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();die;
		}
		else
		{
			$encEmail			= $this->convert(strtolower($email));
			$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
			$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail,1);
		    if(!empty($isPrimaryEmailExists) || !empty($isSecondaryActivatedEmail)){//if($isPrimaryEmailExists){
		    	
				$userId		= $isPrimaryEmailExists[0]['ID'];
				$isFBUser	= $this->getdatamodel->checkFbUserByUserId($userId);
				if($isFBUser){
					echo "Email-address already registered, please login with your Facebook Account";
				}else{
					echo "Email-address already exists.";
					die;
				}
			}else{				
				
				
				$userInsertData['email']			= $encEmail;
				if($displayName){
				$userInsertData['displayName']		= $displayName;
				}else{
				$getDisplayName=explode('@',$email);
				$userInsertData['displayName']		= $getDisplayName[0];	
				}
				$accessCodeGenerator 		        = str_split(sha1(microtime()),7);
				$accessCode				            = $accessCodeGenerator[0];
				$userInsertData['password']			= md5($accessCode);
				$userInsertData['thumb']			= "avatar_thumb.png";
				$userInsertData['photo']			= "avatar.png";				
				$userInsertData['deviceType_ID']	= 4;//website
				$userInsertData['status_ID']  		= 1;
				
				$insertRes = $this->setdatamodel->registerUser($userInsertData);
				
				$data=array('userID'   =>$insertRes,					            
					         'is_logged_in' => true);
					
				$this->session->set_userdata($data);
				
			if($insertRes){
					$this->setdatamodel->deleteSecondaryEmail($encEmail);
					$nonRegGroupDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($encEmail);
					if($nonRegGroupDetails){
						foreach($nonRegGroupDetails as $rec){
							$groupMemberData=array('user_ID'=>$insertRes, 'group_ID' => $rec['group_ID'], 'status_ID' =>1);
							$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
						}
					}
					$this->setdatamodel->deleteNonRegisteredMemeber($encEmail);
					//Added by Rajesh to Get Non Recieved Q's of user to Map them to Registered account
					//On 28-11-2013
					$nonRecQs=$this->getdatamodel->getNonRecievedQs($encEmail);
					if($nonRecQs){
						foreach($nonRecQs as $rec){
							$recQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
							$this->setdatamodel->insertNonRecievedQ($recQData);
						}
					}
					$this->setdatamodel->deleteNonRecQ($encEmail);
					$from = $this->_supportEmail;

					$mailData['userName'] 	= $userInsertData['displayName'];
					$mailData['email'] 		= $email;
					$mailData['password'] 	= $accessCode;
					//print_r($mailData);
					// getting the mail content
					$mailContet = $this->templatemodel->socialSharingregisterMailTemplate($mailData);
					$subject = "Welcome to QPals";
					// call mailer function to send mail.
					//$status = mailer($from, $email, $subject, $mailContet);
					 $data1 = new StdClass;
					 $data1->from = $from;
                     $data1->to = $email;
                     $data1->subject = $subject;
                     $data1->body = $mailContet;
                     $message = json_encode($data1);
                     $this->messagequeue->addMessageToMAILQueue($message);
					 $status = true;
					if($status){												
						echo 1;
						//echo "Thank You for registering with Qpals.";
					}
				}else{
					echo "Registration failed.";
				}
				
			}
		}
		
	}
	
	
	function deleteQ(){
		
		$qId=$this->input->post('qId');
		$this->setdatamodel->deleteQ($qId);
	}
	
	
	function imageSlider(){
		$thumb= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
		echo '<div class="flexslider">
          <ul class="slides">
            <li>
  	    	    <img src="'.$thumb.'" />
  	    		</li>
  	    		<li>
  	    	    <img src="'.$thumb.'" />
  	    		</li>
  	    		<li>
  	    	    <img src="'.$thumb.'" />
  	    		</li>
  	    		<li>
  	    	    <img src="'.$thumb.'" />
  	    		</li>
          </ul>
        </div>';
	}
	
	
	function getGroupMembersForOption(){
		$bucket = $this->config->item("bucket");
		$optionId=$this->input->post('optionId');
		$qId=$this->input->post('qId');
		$option=$this->input->post('option');
		$getUserIdList=$this->getdatamodel->getVotedPalsForQ($qId,$optionId);
		if($getUserIdList){
		   $groupData='<table width="100%" cellpadding="5">
                     <tr>
                     <td>
                     <span class="f_bold">'.$option.'</span> </span>
                     </td>
                   </tr>
                    <tr>
				    <td> 
					<div style="height:320px; overflow:auto;">

					<table width="100%" class="view_group_pals"><tr>';
		$i=1;  
		foreach($getUserIdList as $row){
				
				$usrArr['userID']      =$row['userID'];
				$userData              =$this->getdatamodel->getUserDetailsByUserID($usrArr['userID']);
		 		if($userData[0]['thumb'] != 'avatar_thumb.png'){
                  	//echo "asdas";
                  	$usrArr['thumb']	= $this->_S3Url.$userData[0]['thumb'];
                  }else{
                  	$usrArr['thumb']= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
                  }
				//$usrArr['thumb']	   ='http://'.$bucket.'.s3.amazonaws.com/'.$userData[0]['thumb'];
				$usrArr['displayName'] =$userData[0]['displayName'];
                $url                   =base_url()."findPals/viewPals/".$usrArr['userID'];
				$groupData.='
               <td>
               <a href="'.$url.'" target="_blank">
               <img src="'.$usrArr['thumb'].'" width="80" height="80" alt="" />
               </a>
                <br>
                <div>'.$usrArr['displayName'].'</div></td>              
               ';
					
			if($i%5==0){$groupData.='<td><tr>';}                      
     	 		$i++;}
		   
		   $groupData.=' </tr></table>	
                       </div> 							
					   </td>
				       </tr>
					</table>';
     	 
          echo $groupData;
		 }
	}
	
	
	function setFavourites(){
		$qId=$this->input->post('qId');
		$userId=$this->input->post('userId');
		$Status=$this->input->post('Status');
		$insertFavourites=$this->setdatamodel->insertFavourites($qId,$userId,$Status);
		$getFavouriteStatus=$this->getdatamodel->getFavouriteStatus($qId,$userId);
	    if($getFavouriteStatus){
		  $likeStatus	                = 1;	
		}else{
		  $likeStatus	                = 0;	
	    }
	    $url                   =base_url()."images/heart_inactive.png";
	    $url1                   =base_url()."images/heart_active.png";
	     if($likeStatus==0) {
	     	$Status=1;
	     	echo '<img src="'.$url.'" width="34" height="34" onclick="return setFavourites('.$qId.','.$userId.','.$Status.');"></img>';
	     }
	     
	     if($likeStatus==1){
	     	$Status=0;
	     	echo '<img src="'.$url1.'" width="34" height="34" onclick="return setFavourites('.$qId.','.$userId.','.$Status.');"></img>';
	     }
		
	}
	
	
}//end of class
