<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class accountPreferences extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');

		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');
        $sessionlog=$this->session->userdata('userID');
	}
	
  /**
	 * Converting string into Encrypt or decrypt format
	 * @author Rajesh on 18-09-2013
	 * @param $str
	 */
	function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	
	function customQuestion(){
		$customQuestionName=$this->input->post('customQuestion');
		$userId=$this->input->post('sessionlog');
		$defaultQuestionId=0;
		$insertData=array("name"=>$customQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$defaultQuestionId);
		$insertedId=$this->setdatamodel->insertQuestion($insertData);
		$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
		$defaultQuestion=$insertedId;
		$resArr['defaultQuestion']	= $defaultQuestion;
		$res=$this->setdatamodel->updateUserData($userData);
	}
	
	function presetQuestion(){
		$questionId=$this->input->post('questionId');
		$userId=$this->input->post('sessionlog');
		$getQuestionName=$this->getdatamodel->getQuestionName($questionId);
		$defaultQuestionName=$getQuestionName[0]['questionDesc'];
		$insertData=array("name"=>$defaultQuestionName,"qType"=>2,"version"=>0,"status_ID"=>1,"user_ID"=>$userId,"isSettingsQuestion"=>1,"presetQuestion_Id"=>$questionId);
		$insertedId=$this->setdatamodel->insertQuestion($insertData);
		$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$insertedId);
		$defaultQuestion=$insertedId;
		$resArr['defaultQuestion']	= $defaultQuestion;
		$res=$this->setdatamodel->updateUserData($userData);
		
	}
	
	function presetCustomQuestion(){
		$questionId=$this->input->post('questionId');
		$userId=$this->input->post('sessionlog');			
		$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>$questionId);
		$defaultQuestion=$insertedId;
		$resArr['defaultQuestion']	= $defaultQuestion;
		$res=$this->setdatamodel->updateUserData($userData);
		
		
	}
	
	function setdefaultGroup(){
		
		$defaultGroup 	= $this->input->post('groupId');
		$userId 	    = $this->input->post('sessionlog');
		$userData=array('ID'=>$userId, 'defaultGroup_ID'=>$defaultGroup);
		$res=$this->setdatamodel->updateUserData($userData);
		
		
	}
	
	function noDefaultQuestion(){
		$userId= $this->input->post('sessionlog');
		$userData=array('ID'=>$userId, 'defaultQuestion_ID'=>0);
		$this->setdatamodel->updateUserData($userData);
	}
	
	function setnoDefaultGroup(){
		$userId= $this->input->post('sessionlog');
		$userData=array('ID'=>$userId, 'defaultGroup_ID'=>0);
		$this->setdatamodel->updateUserData($userData);
	}
	
	function setEmailAlerts(){
		$userId= $this->input->post('sessionlog');
		$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
		$isEmailAlerts	= $userData[0]['isEmailAlerts'];
		echo $isEmailAlerts;
		if($isEmailAlerts==1){
			$userData=array('ID'=>$userId, 'isEmailAlerts'=>0);
		    $res=$this->setdatamodel->updateUserData($userData);
		}else{
			
			$userData=array('ID'=>$userId, 'isEmailAlerts'=>1);
		    $res=$this->setdatamodel->updateUserData($userData);
			
		}
	}
	
	
}