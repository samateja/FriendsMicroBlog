<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// To avoid back button after logout
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0", false);
//header("Cache-Control: post-check=0, pre-check=0", false);
// HTTP/1.0
header("Pragma: no-cache");
// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Asha on 13-02-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class findPals extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
		$this->load->library('form_validation');	
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->library('pagination');
		$sessionlog=$this->session->userdata('userID');
		//Added by Padmaja
		$this->_S3Url = $this->config->item('S3Url');
       
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
   function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
  
	/* Modified by Padmaja */
	
	public function findpals(){
		$data['active']=5;
		$data['popular']='poplr';
		$data['mactive']='mactve';
		$data['newPls']='newPls';
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchAll');
		$data['sesUserId']=$this->session->userdata('userID');
		$data['findPalsData']=$this->getdatamodel->getMostPopularOnWeb($sesUserId,$searchText);
		$this->load->view('findpalsNew',$data);
	}
	/* Added by padmaja */
	
	public function getMostPopularData(){
		$data['active']=5;
		$data['popular']='poplr';
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchAll');
		$data['sesUserId']=$this->session->userdata('userID');
		$data['checkTabId'] = $this->input->post('checkTab');
		//print_r($data['checkTabId']);
		if(!empty($data['checkTabId'])){
			$checkTabId =$data['checkTabId'];
			if($checkTabId==1){
				$data['mostPopular']=$this->getdatamodel->getMostPopularOnWeb($sesUserId,$searchText);
			}elseif($checkTabId==2){
				$data['mostPopular']=$this->getdatamodel->getMostActiveUsersOnWeb($sesUserId,$searchText);
				print_r($data['mostPopular']);
			}elseif($checkTabId==3){
				$data['mostPopular']=$this->getdatamodel->getNewPalsOnWeb($sesUserId,$searchText);
			}
			ob_start();
			$this->load->view('ajaxMostPopular',$data);
			$output = ob_get_contents();
			ob_end_clean();
			echo $output;
		}
		/*$data['mostPopular']=$this->getdatamodel->getMostPopularOnWeb($sesUserId,$searchText);//Most Popular-Max number of followers
		$data['mostActive']=$this->getdatamodel->getMostActiveUsersOnWeb($sesUserId,$searchText);//created max of Q's-MostActive-2
		$data['newPals']=$this->getdatamodel->getNewPalsOnWeb($sesUserId,$searchText);//recently registered order-New Pals-3
		$this->load->view('findpalsNew',$data);*/
		
	}
	/* Added by padmaja */
	
	function getMostActiveData(){
		$data['active']=5;
		$data['mactive']='mactve';
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchAll');
		$data['sesUserId']=$this->session->userdata('userID');
		$data['checkTabId2'] = $this->input->post('checkTab2');
		//print_r($data['checkTabId2']);
		if(!empty($data['checkTabId2'])){
			$checkTabId2 = $data['checkTabId2'];
			if($checkTabId2==2){
				$data['mostActive']=$this->getdatamodel->getMostActiveUsersOnWeb($sesUserId,$searchText);
				//print_r($data['mostActive']);
			}
			ob_start();
			$this->load->view('ajaxMostActiveData',$data);
			$output = ob_get_contents();
			ob_end_clean();
			echo $output;
		}
	}
	/* Added by padmaja */
	function getNewPalsData(){
		$data['active']=5;
		$data['newPls']='newPls';
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchAll');
		$data['sesUserId']=$this->session->userdata('userID');
		$data['checkTabId3'] = $this->input->post('checkTab3');
		//print_r($data['checkTabId3']);
		if(!empty($data['checkTabId3']))
		{
			$checkTabId3 = $data['checkTabId3'];
			if($checkTabId3 == 3){
				$data['newPals']=$this->getdatamodel->getNewPalsOnWeb($sesUserId,$searchText);
				//print_r($data['newPals']);
			}
			ob_start();
			$this->load->view('ajaxNewPalsData',$data);
			$output = ob_get_contents();
			ob_end_clean();
			echo $output;
		}
		
	}
	
	function CheckUserSess()
	{
		$sesUserId=$this->session->userdata('userID');
		if(!empty($sesUserId)){
			echo "1";die;
		}else{
			echo "0";die;
		}
	}
	
	public function findPalsSearchMostPopular(){
		$data['active']=5;
		$bucket = $this->config->item("bucket");
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		//echo $searchText;die;		
		$mostPopular=$this->getdatamodel->getMostPopularOnWeb($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="mostPopular">
        <div class="container content_inner h_line_findPals"  style="overflow:auto;height:600px;">
         <div class="row">';
                 if($mostPopular) { 
                 	    $i=1;                        
                       foreach($mostPopular as $res){
                       $userID=$res['followers_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
				  	    if($getUserDetails[0]['thumb'] != 'avatar_thumb.png'){
				  	    	//echo "asdas";
				  	    	$UserThumbImage		= $this->_S3Url.$getUserDetails[0]['thumb'];
				  	    }else{
				  	    	$UserThumbImage= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
				  	    }
				  	   // $UserThumbImage='http://'.$bucket.'.s3.amazonaws.com/'.$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				$palurl=base_url()."findPals/viewPals/$userID";
              $response.='              
                    <div class="span3 thumbs_group">                      
                     
                      <a href="'.$palurl.'"><img src='.$UserThumbImage.' width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question">'.$displayName.'</div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic">'.$countOfFollowers.' Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic">'.$countOfQCreated.' Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div>'; 
                       if($i%4==0){$response.="</div><div class='row'>";}
         $i++;}} else{
         	$response.="no qs available";
         }               
                 $response.="</div></div></div>";
		
		echo $response;
		
		
	}
	
	
	
public function findPalsSearchMostActive(){
		$bucket = $this->config->item("bucket");
		$data['active']=5;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		//echo $searchText;die;		
		$mostActive=$this->getdatamodel->getMostActiveUsersOnWeb($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="mostPopular">
        <div class="container content_inner h_line_findPals"  style="overflow:auto;height:600px;">
         <div class="row">';
                 if($mostActive) { 
                 	    $i=1;                        
                       foreach($mostActive as $res){
                       $userID=$res['user_ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
                        if($getUserDetails[0]['thumb'] != 'avatar_thumb.png'){
				  	    	//echo "asdas";
				  	    	$UserThumbImage		= $this->_S3Url.$getUserDetails[0]['thumb'];
				  	    }else{
				  	    	$UserThumbImage= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
				  	    }
				  	   // $UserThumbImage='http://'.$bucket.'.s3.amazonaws.com/'.$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				$palurl=base_url()."findPals/viewPals/$userID";
              $response.='              
                    <div class="span3 thumbs_group">                      
                     
                      <a href="'.$palurl.'"><img src='.$UserThumbImage.' width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question">'.$displayName.'</div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic">'.$countOfFollowers.' Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic">'.$countOfQCreated.' Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div>'; 
                       if($i%4==0){$response.="</div><div class='row'>";}
         $i++;}}  else{
         	$response.="no qs available";
         }       
                 $response.="</div></div></div>";
		
		echo $response;
		
		
	}
	
	
	
	
	
public function findPalsSearchNewPals(){
		$data['active']=5;
		$sesUserId=$this->session->userdata('userID');
		$searchText=$this->input->post('searchText');
		//echo $searchText;die;		
		$bucket = $this->config->item("bucket");
		$newPals=$this->getdatamodel->getNewPalsOnWeb($sesUserId,$searchText);
		$response='';
		$response.='<div class="row-fluid" id="mostPopular">
        <div class="container content_inner h_line_findPals"  style="overflow:auto;height:600px;">
         <div class="row">';
                 if($newPals) { 
                 	    $i=1;                        
                       foreach($newPals as $res){
                       $userID=$res['ID'];	
                      
                       	$getUserDetails=$this->getdatamodel->getUserDetailsByUserID($userID);
                       if($getUserDetails){				  	  
				  	    $displayName=$getUserDetails[0]['displayName'];
                        if($getUserDetails[0]['thumb'] != 'avatar_thumb.png'){
				  	    	//echo "asdas";
				  	    	$UserThumbImage		= $this->_S3Url.$getUserDetails[0]['thumb'];
				  	    }else{
				  	    	$UserThumbImage= base_url()."Uploads/ProfilePictures/avatar_thumb.png";
				  	    }
				  	  //  $UserThumbImage='http://'.$bucket.'.s3.amazonaws.com/'.$getUserDetails[0]['thumb'];	
				  	   }else{
				  	  $displayName   ='';
				  	  $UserThumbImage==base_url()."Uploads/ProfilePictures/avtar_thumb.png";
				  	}
				  	
                 $getIsPublic=$this->getdatamodel->getCountOFPublicQ($userID);				
				//check the Q in received Q's
				$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);				
			    if($getIsPublic && !$getReceivedQ){
				//public Q's				
					$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($userID);
					
					if($getCountOFPublicQ){
					$countOfQCreated=$getCountOFPublicQ;	
					}else{
					$countOfQCreated=0;	
					}
			    }
			    
			    
			   if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
					$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($userID,$sesUserId);					
					if($getCountOfReceivedQ){
					$countOfQCreated=$getCountOfReceivedQ;
					}else{
					$countOfQCreated=0;	
					}
			   }
			   
			   
			  if($getIsPublic && $getReceivedQ){
					//public and received Q's

				   $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($userID,$sesUserId);
				   if($getCountOfPublicReceived){
				   $countOfQCreated=$getCountOfPublicReceived;
				   }else{
				   $countOfQCreated=0;
				   }
			  }
			  
				  if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
					$countOfQCreated	= 0;
					
				}
				  	
				  	
				  	
				  	
				  	
				  	//count of followers
				  	
				    $countOfFollowers=$this->getdatamodel->getTotCountOfFollowers($userID);
				    if($countOfFollowers){
				  	$countOfFollowers	=$this->getdatamodel->getTotCountOfFollowers($userID);
				    }else{
				    $countOfFollowers=0;	
				    }
				  	
						
				$palurl=base_url()."findPals/viewPals/$userID";
              $response.='              
                    <div class="span3 thumbs_group">                      
                     
                      <a href="'.$palurl.'"><img src='.$UserThumbImage.' width="200" height="200" alt="" /></a>                    
                       
                      <table class="table_rows">
                     <tr>
                       <td> 
                        <div class="question">'.$displayName.'</div>                       
                       </td>                     
                     </tr> 
                     
                     <tr>
                       <td>
                       <div class="man_findpals">
                       <span class="f_bold_italic">'.$countOfFollowers.' Pals follow me </span> 
                       </div>
                      </td>                     
                     </tr>
                     
                      <tr>
                       <td>
                       <div class="q_findpals">
                       <span class="f_bold_italic">'.$countOfQCreated.' Q’s posted </span>
                       </div> 
                       </td>                     
                      </tr>                  
                    </table>
                   </div>'; 
                       if($i%4==0){$response.="</div><div class='row'>";}
         $i++;}}else{
         	$response.="no qs available";
         }                
                 $response.="</div></div></div>";
		
		echo $response;
		
		
	}
	
	
	//view pals
	
	public function viewPals($friendId=0){
		$data['active']='viewPl';
		$sesUserId=$this->session->userdata('userID');
		$data['palsData']=$this->getdatamodel->getUserDetailsByUserID($friendId);
		$data['getFollowStatus']=$this->getdatamodel->getFollowStatus($sesUserId,$friendId);
	    $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($friendId);				
		if($getCountOfFollowing){
		$data['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($friendId);
		}else{
		$data['countOfFollowing']=0;	
		}
		
	 $getCountOffollowers=$this->getdatamodel->getCountOffollowers($friendId);				
	  if($getCountOffollowers){
		$data['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($friendId);
		}else{
		$data['countOfFollowers']	=0;
	}
		
	//public Q Count
	//check the Q's which are public
	$getIsPublic=$this->getdatamodel->getCountOFPublicQ($friendId);				
				
	$getReceivedQ=$this->getdatamodel->countOfReceivedQForPal($friendId,$sesUserId);				
	if($getIsPublic && !$getReceivedQ){
				//public Q's				
	$getCountOFPublicQ=$this->getdatamodel->getCountOFPublicQ($friendId);
	if($getCountOFPublicQ){
	$data['countOfPalsQ']=$getCountOFPublicQ;	
	}else{
	$data['countOfPalsQ']=0;	
	   }
	 }
			    
	if(!$getIsPublic && $getReceivedQ){
					//not public but received Q's					
	$getCountOfReceivedQ=$this->getdatamodel->countOfReceivedQForPal($friendId,$sesUserId);					
	if($getCountOfReceivedQ){
	$data['countOfPalsQ']=$getCountOfReceivedQ;
	}else{
	$data['countOfPalsQ']=0;	
	}
}
			   
	if($getIsPublic && $getReceivedQ){
					//public and received Q's
     $getCountOfPublicReceived=$this->getdatamodel->getCountOfPublicReceived($friendId,$sesUserId);
	 if($getCountOfPublicReceived){
		$data['countOfPalsQ']=$getCountOfPublicReceived;
		}else{
		$data['countOfPalsQ']=0;
		}
	 }
			  
    if(!$getIsPublic && !$getReceivedQ){
					//then public Qs not available
	$data['countOfPalsQ']		= 0;
 }
 
 
 $data['getIsPublicCount']=$this->getdatamodel->getCountOFPublicQ($friendId);
 $data['getReceivedQCount']=$this->getdatamodel->countOfReceivedQForPal($friendId,$sesUserId);
 $data['getIsPublic']=$this->getdatamodel->getPublicQOnWebsite($friendId);
 $data['getReceivedQ']=$this->getdatamodel->getReceivedQForPalOnWeb($friendId,$sesUserId);
 $data['getPublicReceived']=$this->getdatamodel->getPublicReceived($friendId,$sesUserId);
 $data['getPalFollowers']=$this->getdatamodel->followersOfPals($friendId);
 $data['getFollowingPals']=$this->getdatamodel->followingPal($friendId);		
	$this->load->view('viewPals',$data);
}
	
	
	
	
	public function setFollowStatus(){
		$data['active']="";
		$sesUserId=$this->session->userdata('userID');
		$friendId=$this->input->post('friendId');
		$followStatus=$this->input->post('followStatus');
		$setFollow=$this->setdatamodel->insertFollowers($sesUserId,$friendId,$followStatus);
		
		$getFollowStatus=$this->getdatamodel->getFollowStatus($sesUserId,$friendId);
		
		if($getFollowStatus) {
        $followStatus=0;
        $response='<button class="butn b_findpals span11" onclick="return setFollowStatus('.$followStatus.')" style="background-color:#8D8888">Following</button>';
         }else{ 
         $followStatus=1;         
        $response='<button class="butn b_findpals span11" onclick="return setFollowStatus('.$followStatus.')">FOLLOW ME </button>'; 
       } 
       
       echo $response;
		
	}
	
	
	
	
	
	
}//end of class