<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class resetPassword extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
        
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
function decrypt_blowfish($data,$key){
    $iv=pack("H*" , substr($data,0,16));
    $x =pack("H*" , substr($data,16));
    $res = mcrypt_decrypt(MCRYPT_BLOWFISH, $key, $x , MCRYPT_MODE_CBC, $iv);
    return $res;
    }
	
  /**
	 * Converting string into Encrypt or decrypt format
	 * @author Rajesh on 18-09-2013
	 * @param $str
	 */
	function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	public function resetpass(){
		
		$this->form_validation->set_rules('passwordVal', 'Password', 'required|min_length[6]|matches[confirmPasswordVal]|xss_clean');
		$this->form_validation->set_rules('confirmPasswordVal', 'Confirm Password', 'required|min_length[6]|xss_clean');
	    if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		
		else{
			//echo "sda";die;
			$keyBlow   = md5("QPals");
			$email=$this->decrypt_blowfish($_POST['emailVal'],$keyBlow);
			$email1=trim($email);
			//print_r($email);die;
			$password=$_POST['passwordVal'];
			//echo $password;die;			
			$encEmail= $this->convert(strtolower($email1));			
//		    $passwordenc=md5($password);

		$getUserId= $this->getdatamodel->checkUserByEmail($encEmail);
			$userID		= $getUserId[0]['ID'];			
		    $passwordenc=md5($password);
		    $this->setdatamodel->updatePassword($encEmail,$passwordenc,$userID);
//		    $this->setdatamodel->updatePassword($encEmail,$passwordenc);		    
		    echo 1;		
			
		}
	}
	
	/*
	 * @Author asha on 13-2-2014
	 * home page
	 */
	
	
	public function reset(){
		$data['active']="resetPassword";
		$this->load->view('resetPassword',$data);
		
	}
	
	
}
