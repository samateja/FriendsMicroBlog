<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class socialSharing extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$sessionlog=$this->session->userdata('userID');
		//print_r(userID);
	    
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	

function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	public function index(){
		
		$this->load->view('socialSharing');
		
	}
	
	
function login(){
		
	 	$data['active']=1;
		$this->form_validation->set_rules('email','Enter Email','trim||required|valid_email');
		$this->form_validation->set_rules('password', 'Enter Password', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		else
		{
			$emailPost = trim($this->input->post('email', TRUE));
			$password = trim($this->input->post('password', TRUE));
			$email=$this->convert(strtolower($emailPost));
			//echo $emailPost;die;
			$isValidEmailAddress   = $this->getdatamodel->checkUserByEmail($email);			
			$isValidSecEmailAddress=$this->getdatamodel->checkSecondaryEmail($email, 1);
			$isValidPassword 	   = $this->getdatamodel->login($email, $password);
			
			if(($isValidEmailAddress || $isValidSecEmailAddress) && $isValidPassword){
				
				$res=$this->getdatamodel->login($email, $password);				
				if($res){					
					$data=array('userID'   =>$res[0]['ID'],
					            'firstName'=>$res[0]['firstName'],
					            'lastName' => $res[0]['lastName'],
					            'is_logged_in' => true);
					
					$this->session->set_userdata($data);	
							
					echo 1;//"success";
					
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					
					//fetch access token
					$getUserData	= $this->getdatamodel->getUserDetailsByUserID($res[0]['ID']);
					$tokenGet=$getUserData[0]['accessToken'];
					
				   if($tokenGet !=""){
				   //$userData['accessToken']	= $getUserData[0]['accessToken'];
					$expiry = $this->config->item('tokenExpiry');					
					foreach($getUserData as $toknes){
					$loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
					$thirty_days_ahead =   date('Y-m-d');
					if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						$this->pdo->where('ID',$userData['userId']);
						$tkn = $this->pdo->update($this->user, $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
						
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $data['userID'],'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($data['userID']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
				
			}
					
				}else{
				    echo "Invalid login details";
				}
				
			}else{
			   if(!$isValidEmailAddress){
			   
					echo "Invalid Email address.";
				}else if(!$isValidPassword){
					echo "The password you entered is incorrect.";
				}
			}
		}
	}
	
	function userRegistration(){
		$data['active']=1;
		
		
		$this->form_validation->set_rules('email', 'Enter Email', 'trim|xss_clean|required|valid_email');		
		$displayName =$this->input->post('displayName');
		$email       =$this->input->post('email');
		
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		else
		{
			$encEmail			= $this->convert(strtolower($email));
			$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
			$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail,1);
		    if(!empty($isPrimaryEmailExists) || !empty($isSecondaryActivatedEmail)){//if($isPrimaryEmailExists){
		    	
				$userId		= $isPrimaryEmailExists[0]['ID'];
				$isFBUser	= $this->getdatamodel->checkFbUserByUserId($userId);
				if($isFBUser){
					echo "Email-address already registered, please login with your Facebook Account";
				}else{
					echo "Email-address already exists.";
					die;
				}
			}else{				
				
				
				$userInsertData['email']			= $encEmail;
				if($displayName){
				$userInsertData['displayName']		= $displayName;
				}else{
				$getDisplayName=explode('@',$email);
				$userInsertData['displayName']		= $getDisplayName[0];	
				}
				$accessCodeGenerator 		        = str_split(sha1(microtime()),7);
				$accessCode				            = $accessCodeGenerator[0];
				$userInsertData['password']			= md5($accessCode);
				$userInsertData['thumb']			= "avatar_thumb.png";
				$userInsertData['photo']			= "avatar.png";				
				$userInsertData['deviceType_ID']	= 4;//website
				$userInsertData['status_ID']  		= 1;
				
				$insertRes = $this->setdatamodel->registerUser($userInsertData);
				
			if($insertRes){
					$this->setdatamodel->deleteSecondaryEmail($encEmail);
					$nonRegGroupDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($encEmail);
					if($nonRegGroupDetails){
						foreach($nonRegGroupDetails as $rec){
							$groupMemberData=array('user_ID'=>$insertRes, 'group_ID' => $rec['group_ID'], 'status_ID' =>1);
							$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
						}
					}
					$this->setdatamodel->deleteNonRegisteredMemeber($encEmail);
					//Added by Rajesh to Get Non Recieved Q's of user to Map them to Registered account
					//On 28-11-2013
					$nonRecQs=$this->getdatamodel->getNonRecievedQs($encEmail);
					if($nonRecQs){
						foreach($nonRecQs as $rec){
							$recQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
							$this->setdatamodel->insertNonRecievedQ($recQData);
						}
					}
					$this->setdatamodel->deleteNonRecQ($encEmail);
					$from = $this->_supportEmail;

					$mailData['userName'] 	= $userInsertData['displayName'];
					$mailData['email'] 		= $email;
					$mailData['password'] 	= $accessCode;

					// getting the mail content
					$mailContet = $this->templatemodel->socialSharingregisterMailTemplate($mailData);
					$subject = "Welcome to QPals";
					// call mailer function to send mail.
					$status = mailer($from, $email, $subject, $mailContet);
					if($status){												
						
						echo "Thank You for registering with Qpals.";
					}
				}else{
					echo "Registration failed.";
				}
				
			}
		}
		
	}
	
	
	
}
