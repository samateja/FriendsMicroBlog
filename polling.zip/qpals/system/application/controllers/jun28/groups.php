<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// To avoid back button after logout
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0", false);
//header("Cache-Control: post-check=0, pre-check=0", false);
// HTTP/1.0
header("Pragma: no-cache");
// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Asha on 13-02-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class groups extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
		$this->load->library('form_validation');	
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->library('pagination');
		$this->load->model('messagequeue');
		$sessionlog=$this->session->userdata('userID');
		$sourceType=$this->uri->segment(4);
		
		//echo $_SERVER['REDIRECT_URL'];die;
	    if(!$sessionlog && $sourceType!=""){
			 $link = $_SERVER['REDIRECT_URL'];
			 $this->session->set_userdata(array('redirectGroupUrl'=> $link)); 			             
			 redirect('home');
		}
		
	    if(!$sessionlog){
	    	//echo $sessionlog;
			redirect('home');
		}
       
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
   function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
  
  function encrypt_blowfish($data,$key){
    $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $crypttext = mcrypt_encrypt(MCRYPT_BLOWFISH, $key, $data, MCRYPT_MODE_CBC, $iv);
    return bin2hex($iv . $crypttext);
    }
  
	
	public function mygroups($id=''){
		
		$data['active']=2;
		$sesUserId=$this->session->userdata('userID');
		$searchText = $this->input->post('searchAllGroup');		
		$data['userGroups']=$this->getdatamodel->getUserGroupsOnWeb($sesUserId,$searchText);
		$data['groupsCreatedDetails']=$this->getdatamodel->getUserCreatedGroupsOnWeb($sesUserId, $searchText);
		$data['groupsJoinedDetails']=$this->getdatamodel->getUserJoinedGroupsOnWeb($sesUserId, $searchText);
		if($id){
			$data['enableJS']=1;
		}	
		$this->load->view('mygroups',$data);
	}
	
	public function searchGroups(){
		
		$data['active']=2;
		$sesUserId=$this->session->userdata('userID');
		$searchText = $this->input->post('searchText');
		
		$userGroups=$this->getdatamodel->getUserGroupsOnWeb($sesUserId,$searchText);
		$displayAllGroup="";
		
		$displayAllGroup.='<div class="row-fluid" id="showAll">
		                   <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;" >
		                   <div class="row">';
		if($userGroups){
			foreach($userGroups as $userGroup){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($userGroup['user_ID'], $userGroup['group_ID']);
			if($isNewGroupActivity){
				$isNew=$isNewGroupActivity[0]['isNew'];
			}else{
				$isNew=0;
			}
			$gName			= $userGroup['name'];
			$countString=strlen($gName);
            if($countString > 20){
             $groupName= substr($gName, 0, 20);
             $groupDispaly=$groupName.'...';
                }else{
            $groupDispaly=$gName;
                }
			$thumb			= base_url()."Uploads/GroupImages/".$userGroup['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($userGroup['ID']);
			$url='groups/viewGroup/'.$userGroup['ID'];
			$displayAllGroup.='<div class="span3 thumbs_group"> 
                     <a href="'.base_url($url).'"><img src="'.$thumb.'" width="200" height="200" alt="" /></a>                   
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$groupDispaly.'</div></td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group"><span class="f_bold_italic">'.$membersCount.'</span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>';
			}
		}else{
			$displayAllGroup.='no Groups Available';
		}
		
		$displayAllGroup.='</div></div></div>';
		echo $displayAllGroup;
	}
	
	
	
  public function searchCreatedGroup(){
		
		$data['active']=2;
		$sesUserId=$this->session->userdata('userID');
		$searchText = $this->input->post('searchText');
		
		$groupsCreatedDetails=$this->getdatamodel->getUserCreatedGroupsOnWeb($sesUserId, $searchText);
		$displayAllGroup="";
		
		$displayAllGroup.='<div class="row-fluid" id="showICreated">
		                   <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;">
		                   <div class="row">';
		if($groupsCreatedDetails){
			foreach($groupsCreatedDetails as $groupCreated){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupCreated['user_ID'], $groupCreated['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
			$gName			= $groupCreated['name'];
			
			$countString=strlen($gName);
            if($countString > 20){
             $groupName= substr($gName, 0, 20);
             $groupDispaly=$groupName.'...';
                }else{
            $groupDispaly=$gName;
                }
			
			$thumb			= base_url()."Uploads/GroupImages/".$groupCreated['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($groupCreated['ID']);
			$url='groups/viewGroup/'.$groupCreated['ID'];
			$displayAllGroup.='<div class="span3 thumbs_group"> 
                      <a href="'.base_url($url).'">
                      <img src="'.$thumb.'" width="200" height="200" alt="" /> 
                      </a>                   
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$groupDispaly.'</div></td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group"><span class="f_bold_italic">'.$membersCount.'</span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>';
			}
		}else{
			$displayAllGroup.='no Groups Available';
		}
		
		$displayAllGroup.='</div></div></div>';
		echo $displayAllGroup;
	}
	
	
	
 public function searchJoinedGroup(){
		
		$data['active']=2;
		$sesUserId=$this->session->userdata('userID');
		$searchText = $this->input->post('searchText');
		
		$groupsJoinedDetails=$this->getdatamodel->getUserJoinedGroupsOnWeb($sesUserId, $searchText);
		$displayAllGroup="";
		
		$displayAllGroup.='<div class="row-fluid" id="showJoinedGroups">
		                   <div class="container content_inner h_line_profile" style="overflow:auto;height:500px;">
		                   <div class="row">';
		if($groupsJoinedDetails){
			foreach($groupsJoinedDetails as $groupJoined){
            
        	$isNewGroupActivity	= $this->getdatamodel->getUserGroupBadge($groupJoined['user_ID'], $groupJoined['ID']);
							if($isNewGroupActivity){
								$isNew=$isNewGroupActivity[0]['isNew'];
							}else{
								$isNew=0;
							}
			$gName			= $groupJoined['name'];
			$countString=strlen($gName);
            if($countString > 20){
             $groupName= substr($gName, 0, 20);
             $groupDispaly=$groupName.'...';
                }else{
            $groupDispaly=$gName;
                }
			$thumb			= base_url()."Uploads/GroupImages/".$groupJoined['thumb'];
			$membersCount	= $this->getdatamodel->getGroupMemnbersCount($groupJoined['ID']);
			$url='groups/viewGroup/'.$groupJoined['ID'];
			$displayAllGroup.='<div class="span3 thumbs_group"> 
                     <a href="'.base_url($url).'">
                     <img src="'.$thumb.'" width="200" height="200" alt="" /> 
                     </a>                   
                       
                      <table class="table_rows">
                     <tr>
                        <td> <div class="question">'.$groupDispaly.'</div></td>                     
                     </tr> 
                     
                     <tr>
                       <td><div class="man_group"><span class="f_bold_italic">'.$membersCount.'</span> Pals</div>  </td>                     
                     </tr>                 
                    </table>
                   </div>';
			}
		}else{
			$displayAllGroup.='no Groups Available';
		}
		
		$displayAllGroup.='</div></div></div>';
		echo $displayAllGroup;
	}
	
	
	
	
   public function createGroup(){
   
		$data['active']='grp';
		//$data['activeMenu']='grp';
		$sesUserId=$this->session->userdata('userID');
		$data['followingPals']=$this->getdatamodel->followingPal($sesUserId);
        $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($sesUserId);				
		if($getCountOfFollowing){
		$data['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($sesUserId);
		}else{
		$data['countOfFollowing']=0;	
		}
		
		$data['followers']=$this->getdatamodel->followersOfPals($sesUserId);	
   
	    $getCountOffollowers=$this->getdatamodel->getCountOffollowers($sesUserId);				
		if($getCountOffollowers){
		$data['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($sesUserId);
		}else{
		$data['countOfFollowers']	=0;
		}
			
		//create a group
		
		/*if(isset($_POST['createGroup'])){//start of submit
			//echo "<pre>";print_r($_POST);exit;
			$groupName=$this->input->post('groupName');
			//validations
			$this->form_validation->set_rules('groupName','Please enter a name for your group.','required');
			
			// group photo validation			
			if($_FILES['groupImage']['name']){				
			$filename=$_FILES['groupImage']['name'];
			$ext = substr($filename, strpos($filename,'.'), strlen($filename)-1);
			
			if($ext=='.jpg' || $ext=='.gif' || $ext=='.png' || $ext=='.jpeg'){			
			  //correct format				
			}else{
			  $error="not corect format";
			}
				
		 }//end of group photo validation
		 
		 if($this->form_validation->run()){
		 	
		 $isDuplicateGroup=$this->getdatamodel->isDuplicateGroup($sesUserId, $groupName);		 	
		   if($isDuplicateGroup){					
					$data['errormessage']= "A Group is already existing with the same name.";
				}else{
				
				$insertGroupData 	= array('name'=>$groupName, 'thumb'=>'group_thumb.png',
				'photo'=>'group.png', 'status'=>1, 'user_ID'=> $sesUserId, 'osVersion'=>0, 
				'appVersion'=>0, 'deviceType_ID'=>0);
				$groupInsertRes		= $this->setdatamodel->insertGroup($insertGroupData);
				
				$customEmails		= $this->input->post('customEmail');
				if(!empty($_POST['customEmail'][0])){					
					$implodeCustomEmail=implode("|",$_POST['customEmail']);
					$customEmailsArr=array();
					
				if(isset($_POST['customEmail'])){
					$customEmailsArr=explode("|",$implodeCustomEmail);
				}
				
				if(isset($customEmailsArr)){
					 
				for($i=0;$i<sizeof($customEmailsArr);$i++){
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));								
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('email'=>$customEmail, 'group_ID' => $groupInsertRes, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									
								}
						}
					
				}
					
		}//end of custom emails
				
               
				$data['successMessage']="group created successfully";
					
			}
		 	
		}
			
	}//end of submit*/
		
		$this->load->view('createGroup',$data);
	}
	function emailsData($emails)
	{
		$resultData = array();
		
		if(is_array($emails)){
			foreach($emails as $email){
				
				$result = $this->isEmailAccountCheck($email);
				if($result){
					$resultData['registeredUsers'][]= $email;
				}else{
					$resultData['notregisteredUsers'][]= $email;
				}
			}
			return $resultData;
		}
	}
	function isEmailAccountCheck($email)
	{
		if($email){
			$encrytpdEmail = $this->convert($email);
			$this->pdo->where('email', $encrytpdEmail);
			$query=$this->pdo->get('user');
			//echo $this->pdo->last_query();die;
			if($query->num_rows>0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	//Modified by Padmaja on 25-06-2014
	function insertGroup()
	{  
                 //echo "<pre>";print_r($_FILES);die;
		         $sesUserId=$this->session->userdata('userID');
	             $groupName=$this->input->post('groupName');
		         $insertGroupData 	= array('name'=>$groupName, 'thumb'=>'group_thumb.png',
				'photo'=>'group.png', 'status'=>1, 'user_ID'=> $sesUserId, 'osVersion'=>0, 
				'appVersion'=>0, 'deviceType_ID'=>0);
				$groupInsertRes		= $this->setdatamodel->insertGroup($insertGroupData);
				$groupId=$groupInsertRes;
				if($groupInsertRes) {
				$groupMemberData=array('user_ID'=>$sesUserId, 'group_ID' => $groupInsertRes, 'status_ID' =>1, 'isCreator'=>1);
				$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
				$customEmails		= $this->input->post('customEmail');
				
				
				$mail_Data = $this->emailsData($customEmails);// Added by Padmaja
				
			//print_r($mail_Data);die;
				
				
				
				
				
				
				if(!empty($_POST['customEmail'][0])){					
					$implodeCustomEmail=implode("|",$_POST['customEmail']);
					$customEmailsArr=array();
					
				if(isset($_POST['customEmail'])){
					$customEmailsArr=explode("|",$implodeCustomEmail);
				}
				
				if(isset($customEmailsArr)){
					 
				for($i=0;$i<sizeof($customEmailsArr);$i++){
					            $getCustonName=$customEmailsArr[$i];
					            $explodeCustomName=explode('@',$getCustonName);
					            $customName=$explodeCustomName[0];
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));								
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupInsertRes,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$customName,'email'=>$customEmail, 'group_ID' => $groupInsertRes, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									
								}
						}
					
				}
					
		}//end of custom emails
		
		
		
	//insert following
		if(isset($_POST['checkedFollowing'])){
			
			for($i=0;$i<sizeof($_POST['checkedFollowing']);$i++){
			$groupMemberData=array('user_ID'=>$_POST['checkedFollowing'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkedFollowing'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
			}
			
		}
		
		//insert follower
		
		if(isset($_POST['checkedFollowers'])){
			
			for($i=0;$i<sizeof($_POST['checkedFollowers']);$i++){
				
			$groupMemberData=array('user_ID'=>$_POST['checkedFollowers'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkedFollowers'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
				
			}
			
		}
		
		
	//update Image		
		if($_FILES['groupImage']['name']){
			$groupImgResponse = $this->setdatamodel->uploadImage($_FILES,'groupImage','GroupImages');
		if($groupImgResponse){
				$groupImgName = $groupImgResponse['imgName'];
				$groupThumbName = $groupImgResponse['thumbName'];
				$groupData = array('ID'=>$groupId, 'thumb'=>$groupThumbName ,'photo'=>$groupImgName);
				$this->setdatamodel->updateGroup($groupData);
			}
		}
	 
         
	//emails to group users
	$groupCreatorData=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
					if($groupCreatorData){
						$groupCreatorName=$groupCreatorData[0]['firstName'];
					}else{
						$groupCreatorName="";
					}
	
	
					$emailArr=array();
					$namesArr=array();
					
					$regUsersData=$this->getdatamodel->getGroupMembersDetails($groupInsertRes,1);
					$nonRegUsersData=$this->getdatamodel->getnonRegGroupMembersDetails($groupInsertRes);
					$nonRegFBUsersData=$this->getdatamodel->getnonRegFBGroupMembersDetails($groupInsertRes);
				
					//For adding Push to Message Queue
					//@author Rajesh on 13-11-2013
				//print_r($nonRegUsersData);die;
			
					if($regUsersData){
						foreach($regUsersData as $rec1){
							//@author Asha on 19-12-2013
							//For not showing push alerts for the group creator
							if($sesUserId == $rec1['ID']){
							 //do nothing
							}else{
								if($rec1['isPushAlerts']==1){
									$data12 = new StdClass;
									$data12->deviceToken = $rec1['pushId'];
									$data12->message = "$groupCreatorName has added you to $groupCreatorName's $groupName on Qpals.  Please check your groups.";
									$data12->typeID = "2";
					                $data12->param = $groupInsertRes;
									//$data->badge = $invitations;
									//$data->sound  = "ping.wav";
									$message = json_encode($data12);

									log_message('debug',"hitting message queue $message");			// Check the device type and send push
									if($rec1['deviceType_ID']== 1){ //Android
										log_message('debug',$message);

										$this->messagequeue->addMessageToC2DMQueue($message);

									}
									elseif($rec1['deviceType_ID']== 2){ //Ios

										$this->messagequeue->addMessageToAPNSQueue($message);
									}
									elseif($rec1['deviceType_ID']== 3){ //Windows

										$this->messagequeue->addMessageToWinQueue($message);
									}
								}
							}
						}
					}
//print_r($regUsersData);print_r($nonRegUsersData);die;

					if($regUsersData){
						foreach($regUsersData as $rec1){
							if($rec1['isEmailAlerts']==0){
								$emailArr[]=$this->convert($rec1['email']);
								$emailArr2[]="reg_".$this->convert($rec1['email']);
								$namesArr2[]="reg_".$rec1['firstName'];
								//print_r($rec1['email']);die;
							}
							$namesArr[]=$rec1['firstName'];
						}
					}
					if($nonRegUsersData){
						foreach($nonRegUsersData as $rec2){
							$emailArr[]=$this->convert($rec2['email']);
							$emailArr2[]="non_".$this->convert($rec2['email']);
							$namesArr[]=$rec2['name'];
							$namesArr2[]=$rec2['name'];
						}
					}
					if($nonRegFBUsersData){
						foreach($nonRegFBUsersData as $rec3){
							$namesArr[]=$rec3['name'];
							
						}
					}
					//echo sizeof($emailArr);
					//print_r($emailArr);
					/*for($i=0;$i<sizeof($emailArr);$i++){
							$msgStr="";
							$email=	$emailArr[$i];
							$mailData['userName'] 	= $namesArr[$i];
							$namesArr1=$namesArr;
							//print_r($namesArr);
							$newarr=array();
							$k=1;$msgStr1="";
							foreach($namesArr1 as $name){
								
								if($k == sizeof($namesArr1)){
									$msgStr1.= $name;
								}else{
									$msgStr1.= $name.",";
								}
								$k++;
							}
							echo "<br>";
							//print_r($msgStr1);echo "<br>";echo "sdfsdf";
							echo$msgStr =  str_replace("$namesArr[$i]","", $msgStr1)."--$i--";
							//print_r($msgStr);*/
							/*for($j=1;$j<sizeof($newarr);$j++){
								if($j==1){
									$msgStr.=$newarr[$j];
									
									//$msgStrr=$newarr[0];
									//print_r($newarr[0]);echo "<br>";
									//print_r($msgStr);
								}else if($j<=sizeof($newarr)-1){
									$msgStr.=", ".$newarr[$j];
									//print_r($newarr);echo "xcv.<br>";
								
								}else{
									$msgStr.=" and ".$newarr[$j];
									//print_r($newarr);echo "<br>";
								}
								
							}*/
						//}
						//echo "<pre>";print_r($emailArr2);
						for($i=0;$i<sizeof($emailArr2);$i++){
							
							//Mail Ids
							//$qpal['email'][]		=	$emailArr[$i];
							
							
							
							$totalUserNames			= 	implode(",",$namesArr);
							
							$totalUserNames			= 	preg_replace( "/\+/" , "_" , $totalUserNames);
							
							$target					= 	preg_replace( "/\+/" , "_" , $namesArr[$i]);
							
							$otherUserNames			= 	preg_replace( "/$target/" , "" , $totalUserNames);
							
							
							//echo "<br />";
							
							$userEmail			= 	preg_replace( "/\+/" , "_" , $emailArr2[$i]);
							//echo preg_match("/reg_/",$userEmail);
							if(preg_match("/reg_/",$userEmail)){								
								$qpal['userNames']['reg'][]	=	$otherUserNames;
							}else{
								$qpal['userNames']['nonreg'][]	=	$otherUserNames;
							}
							
							//echo "<pre>";print_r($qpal);
							
						}
						
					for($i=0;$i<sizeof($namesArr2);$i++){
						
																	
							$userEmail1			= 	preg_replace( "/\+/" , "_" , $namesArr2[$i]);
							//echo preg_match("/reg_/",$userEmail);
							if(preg_match("/reg_/",$userEmail1)){								
								$qpals['fnmes']['reg'][]	=	$userEmail1;
							}else{
								$qpals['fnmes']['nonreg'][]	=	$userEmail1;
							}
							
						echo "<pre>";print_r($qpals);
							
						}
						
				//echo $msgStr;
					//die;
						//echo $msgStr."<br/>";die;
					 // end for loop
				// Added by Padmaja on 25-06-2014
					//registered users
				if(!empty($mail_Data['registeredUsers'])){
					//foreach
					$i =0;
					foreach($mail_Data['registeredUsers'] as $registerdGrpsemails){
						//print_r($registerdGrpsemails);
						$Rfname = $rec1['firstName'];
							$userId=$rec1['ID'];
						$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
						//print_r($userDetails);die;
						
						$uname			= $userDetails[0]['firstName'];
						//echo $uname;die;
						$mailData['userName'] 	= $uname;
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						echo $mailData['members']	=$qpal['userNames']['reg'][$i];
						$mailData['groupId']	=$groupInsertRes;
						$mailData['firstName'] =$Rfname;
						//$mailData['firstName']=$uname;
						$mailData['regUsersData']	=$registerdGrpsemails;
						//echo  "<br>";
						//echo "registeredUsers";echo  "<br>";
						//print_r($msgStr);echo  "<br>";
						//$mailData['nonRegUsersData']	=$nonRegUsersData;
						
						
						
						$from = $this->_supportEmail;
						//getting the mail content
						$mailContet = $this->templatemodel->nonRegisteredUserGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						//echo $email;die;
				//		echo $mailContet;
						 $data1 = new StdClass;
                         $data1->from = $from;echo "---";
                        echo $data1->to = $registerdGrpsemails;
                         $data1->subject = $subject;
                         $data1->body = $mailContet;
                         $message = json_encode($data1);
                         $this->messagequeue->addMessageToMAILQueue($message);
						echo "--<br />--";
						$i++;
					}
					
				}
				
				// Non Registered users //
				if(!empty($mail_Data['notregisteredUsers'])){
				//non registered users
					//foreach
					$i =0;
					foreach($mail_Data['notregisteredUsers'] as $notregisterdGrpsemails){
						//echo "asdaaaaaaaa";
						//print_r($notregisterdGrpsemails);
						
						$namesArr1=$namesArr;
						$newarr=array();
							foreach($namesArr1 as $name){
								$newarr[]=$name;
							}
						$Nfname=$rec2['name'];
						$uname			= $rec2['name'];
						$mailData['userName'] 	= $uname;
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						echo$mailData['members']	=$qpal['userNames']['nonreg'][$i];
						$mailData['groupId']	=$groupInsertRes;
						$mailData['firstName'] =$name;
						$mailData['fNme'] =$qpals['fnmes']['nonreg'][$i];
						//$mailData['firstName']=$uname;
						//$mailData['regUsersData']	=$regUsersData;
						$mailData['nonRegUsersData']	=$notregisterdGrpsemails;
						$from = $this->_supportEmail;
						//echo "nonRegUsersData";echo  "<br>";
						//print_r($msgStr);
						//getting the mail content
						$mailContet = $this->templatemodel->unRegisteredGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						//echo $email;die;
						//echo $mailContet;
						 $data1 = new StdClass;
                         $data1->from = $from;echo "---";
                        echo$data1->to = $notregisterdGrpsemails;
                         $data1->subject = $subject;
                         $data1->body = $mailContet;
                         $message = json_encode($data1);
                       $this->messagequeue->addMessageToMAILQueue($message);
						echo "--<br />--";
                       $i++;
					}
					
				}die;
						/*
						$mailData['groupCreator']= $groupCreatorName;
						$mailData['groupName']	= $groupName;
						$mailData['members']	=$msgStr;
						$mailData['groupId']	=$groupInsertRes;
						//$mailData['regUsersData']	=$regUsersData;
						//$mailData['nonRegUsersData']	=$nonRegUsersData;
						$from = $this->_supportEmail;
						//getting the mail content
						$mailContet = $this->templatemodel->nonRegisteredUserGroupMailTemplate($mailData);
						$subject = "$groupCreatorName added you to $groupName on Qpals";
						
						 $data1 = new StdClass;
                         $data1->from = $from;
                         $data1->to = $email;
                         $data1->subject = $subject;
                         $data1->body = $mailContet;
                         $message = json_encode($data1);
                         $this->messagequeue->addMessageToMAILQueue($message);
						*/
					
					}	
					
			
	// End
				
		$data['successMessage']="group created successfully";
		redirect('/groups/mygroups/1');
	}
	
	/*
	 * group validation using ajax
	 */
	
	public function groupValidations(){
		$sesUserId=$this->session->userdata('userID');
		$groupName=$this->input->post('groupName');
	    $groupImage=$_POST['groupImage'];
	    $error="";
	    if($groupImage){
        $filename=$groupImage;
       
			$ext = substr($filename, strpos($filename,'.'), strlen($filename)-1);
			
			if($ext=='.jpg' || $ext=='.gif' || $ext=='.png' || $ext=='.jpeg' || $ext=='.JPG' || $ext=='.JPEG'){			
			  //correct format				
			}else{
			  $error="Please upload correct format";
			}
				
	    }
		
		
		
		$isDuplicateGroup=$this->getdatamodel->isDuplicateGroup($sesUserId, $groupName);
	   if($isDuplicateGroup){					
			$error="A Group is already existing with the same name.";
		}else{
			//do something
		}
		echo $error;
	}
	
	/*
	 * serch a friend in following using ajax
	 */
	public function searchFriendInFollowing(){
		 $sesUserId=$this->session->userdata('userID');
		 $searchText=$_POST['searchFriend'];
		 $email	        = $this->convert($searchText);
		 $getSearchresult=$this->getdatamodel->searchFriend($searchText,$sesUserId,$email);
		 
		 if($getSearchresult){
		 	foreach($getSearchresult as $rec){
		 		
		 		$fUserId=$rec['followers_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
				
				echo "<ul><li>
				       <table cellpadding='4'>
						 <tr>				 	
						   <td><input type='checkbox' name='checkedFollowing[]' id='$fUserId' value='$fUserId' onclick='return isFollowingChecked($fUserId);' /></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	echo "no result found";
		 }
		 
	}
	
	/*
	 * serch a friend in follower using ajax
	 */
	
  public function searchFriendInFollower(){
		 $sesUserId=$this->session->userdata('userID');
		 $searchText=$_POST['searchFriend'];
		 $email	        = $this->convert($searchText);
		 $getSearchresult=$this->getdatamodel->searchFriendInFollower($searchText,$sesUserId,$email);
		 
		 if($getSearchresult){
		 	foreach($getSearchresult as $rec){
		 		
		 		$fUserId=$rec['user_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
				
				echo "<ul><li>
				       <table cellpadding='4'>
						 <tr>
							<td><input type='checkbox' name='checkedFollowers[]' id='$fUserId' value='$fUserId'/></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	echo "no result found";
		 }
		 
	}
	
	/*
	 * tab1 in ajax
	 */
	
	public function followingtab(){
		$sesUserId=$this->session->userdata('userID');
		$followingPals=$this->getdatamodel->followingPal($sesUserId);
		
	if($followingPals){
		 	foreach($followingPals as $rec){
		 		
		 		$fUserId=$rec['followers_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
				
				echo "<ul><li>
				       <table cellpadding='4'>
				       <script type='text/javascript'>
						 	  alert(selectedFollowingArray);
						 	</script>
						 <tr>
							<td><input type='checkbox' name='checkedFollowing[]' id='$fUserId' value='$fUserId' onclick='return isFollowingChecked($fUserId);'/></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	echo "no result found";
		 }
	}
	
	/*
	 * tab2 in ajax
	 */
	
	public function followertab(){
		$sesUserId=$this->session->userdata('userID');
		$followers=$this->getdatamodel->followersOfPals($sesUserId);
	    if($followers){
		 	foreach($followers as $rec){
		 		
		 		$fUserId=$rec['user_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
				
				echo "<ul><li>
				       <table cellpadding='4'>
						 <tr>
							<td><input type='checkbox' name='checkedFollowers[]' id='$fUserId' value='$fUserId' /></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	echo "no result found";
		 }
		
	}
	
	
	/*
	 * 
	 * edit Group
	 */
	
	public function editGroup($groupId=0){
		$data['active']='edit';
		//$data['activeMenu']='edit';
		$sesUserId=$this->session->userdata('userID');
		$data['groupData']=$this->getdatamodel->getGroupDetailsById($groupId);
	    $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($sesUserId);				
		if($getCountOfFollowing){
		$data['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($sesUserId);
		}else{
		$data['countOfFollowing']=0;	
		}
		
	    $getCountOffollowers=$this->getdatamodel->getCountOffollowers($sesUserId);				
		if($getCountOffollowers){
		$data['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($sesUserId);
		}else{
		$data['countOfFollowers']	=0;
		}
		
		
		$data['followingPals']=$this->getdatamodel->followingPal($sesUserId);
		$data['followers']=$this->getdatamodel->followersOfPals($sesUserId);

		//to get checked values that is the members who are already in the group
		
		$data['registeredGroupMemberesData']= $this->getdatamodel->getGroupMembersDetails($groupId,1);
		$data['nonregisteredGroupMembersData']= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
		$data['fbGroupMembersData']= $this->getdatamodel->getnonRegFBGroupMembersDetails($groupId);
		$this->load->view('editGroup',$data);
	}
	
	  public function searchFollowing(){
		
	     $sesUserId=$this->session->userdata('userID');
		 $searchText=$_POST['searchFriend'];
		 $email	        = $this->convert($searchText);
		 $getSearchresult=$this->getdatamodel->searchFriend($searchText,$sesUserId,$email);
		 $groupId=$_POST['groupId'];
		 
		 $registeredGroupMemberesData= $this->getdatamodel->getGroupMembersDetails($groupId);
		 $searchFollowing='';
		 if($getSearchresult){
		 	foreach($getSearchresult as $rec){
		 		
		 		$fUserId=$rec['followers_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
		 	    if($registeredGroupMemberesData){
				foreach ($registeredGroupMemberesData as $groupMember){
				$groupMemberArr[]	= $groupMember['ID'];							           
				 }
				if(in_array($fUserId,$groupMemberArr)){
				$checked=1;
				}else{
				$checked=0;
				}
		 	    }
				$searchFollowing.= "<ul><li>
				       <table cellpadding='4'>
						 <tr>
						 	<script type='text/javascript'>
						 	  alert(selectedFollowingArray);
						 	</script>
						 
							<td><input type='checkbox' name='checkFollowing[]' id='checkFollowing' value='$fUserId'"; 
				            if($checked==1) 
				                 { 
				                 $searchFollowing.=" checked";	
				                 }
				             $searchFollowing.="/></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	$searchFollowing= "no result found";
		 }
		 echo $searchFollowing;
	}
	
	
	
  public function searchFollower(){
		
	     $sesUserId=$this->session->userdata('userID');
		 $searchText=$_POST['searchFriend'];
		 $email	        = $this->convert($searchText);
		 $getSearchresult=$this->getdatamodel->searchFriendInFollower($searchText,$sesUserId,$email);
		 $groupId=$_POST['groupId'];
		 
		 $registeredGroupMemberesData= $this->getdatamodel->getGroupMembersDetails($groupId);
		 $searchFollower='';
		 if($getSearchresult){
		 	foreach($getSearchresult as $rec){
		 		
		 		$fUserId=$rec['user_ID'];
			    $userData=$this->getdatamodel->getUserDetailsByUserID($fUserId);
				$thumb= base_url()."Uploads/ProfilePictures/".$userData[0]['thumb'];
				$displayName= $userData[0]['displayName'];
		 	    if($registeredGroupMemberesData){
				foreach ($registeredGroupMemberesData as $groupMember){
				$groupMemberArr[]	= $groupMember['ID'];							           
				 }
				if(in_array($fUserId,$groupMemberArr)){
				$checked=1;
				}else{
				$checked=0;
				}
		 	    }
				$searchFollower.= "<ul><li>
				       <table cellpadding='4'>
						 <tr>
						 	<script type='text/javascript'>
						 	  alert(selectedFollowingArray);
						 	</script>
						 
							<td><input type='checkbox' name='checkFollower[]' id='checkFollower' value='$fUserId'"; 
				            if($checked==1) 
				                 { 
				                 $searchFollower.=" checked";	
				                 }
				             $searchFollower.="/></td>
							<td><img src='$thumb' width='40' height='40' alt='' /></td>
							<td>$displayName</td>
						</tr>
					</table>                                
                  </li></ul>";
		 		
		 	}
		 }else{
		 	$searchFollower= "no result found";
		 }
		 echo $searchFollower;
	}
	
	public function deleteGroupImage(){
		$groupId=$this->input->post('groupId');
		$groupData	= $this->getdatamodel->getGroupDetailsById($groupId);
	    $groupData	= $this->getdatamodel->getGroupDetailsById($groupId);
	    $thumb      = base_url()."Uploads/GroupImages/group_thumb.png";
		if($groupData){
		if($groupData[0]['photo']!="group.png"){
		@unlink(FCPATH."Uploads/GroupImages/".$groupData[0]['photo']);
		@unlink(FCPATH."Uploads/GroupImages/".$groupData[0]['thumb']);
		}
		$updateGroupData=array('photo'=>"group.png", 'thumb'=>"group_thumb.png",'ID'=> $groupId);
		$this->setdatamodel->updateGroup($updateGroupData);
        echo '<img width="105" height="105" alt="" src="'.$thumb.'">';
		}
	}
	
	
     public function validateGroup(){
		$sesUserId=$this->session->userdata('userID');
		$groupName=$this->input->post('groupName');
		$groupId=$this->input->post('groupId');
	    $groupImage=$_POST['groupImage'];
	    $error="";
	    if($groupImage){
        $filename=$groupImage;
       
			$ext = substr($filename, strpos($filename,'.'), strlen($filename)-1);
			
			if($ext=='.jpg' || $ext=='.gif' || $ext=='.png' || $ext=='.jpeg' || $ext=='.JPG' || $ext=='.JPEG'){			
			  //correct format				
			}else{
			  $error="Please upload correct format";
			}
				
	    }
		
		
		$isDuplicateGroup=$this->getdatamodel->isUserDuplicateGroup($sesUserId, $groupName, $groupId);
	   if($isDuplicateGroup){					
			$error="A Group is already existing with the same name.";
		}else{
			//do nothing
		}
		
		echo $error;
	}
	
	public function updateGroup($groupId=0){
		
		
		$groupName=$this->input->post('groupName');
		
		//update group name
		$insertGroupData 	= array('name'=>$groupName,'ID'=>$groupId );
		$this->setdatamodel->updateGroup($insertGroupData, $groupId);
		
		//update Image		
		if($_FILES['groupImage']['name']){
			$groupImgResponse = $this->setdatamodel->uploadImage($_FILES,'groupImage','GroupImages');
		if($groupImgResponse){
				$groupImgName = $groupImgResponse['imgName'];
				$groupThumbName = $groupImgResponse['thumbName'];
				$groupData = array('ID'=>$groupId, 'thumb'=>$groupThumbName ,'photo'=>$groupImgName);
				$this->setdatamodel->updateGroup($groupData);
			}
		}
		
		//insert following
		if(isset($_POST['checkFollowing'])){
			
			for($i=0;$i<sizeof($_POST['checkFollowing']);$i++){
			//echo "<pre>";print_r($_POST['checkFollowing'][$i]);
			$groupMemberData=array('user_ID'=>$_POST['checkFollowing'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkFollowing'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
			}
			
		}
		
		//insert follower
		
		if(isset($_POST['checkFollower'])){
			
			for($i=0;$i<sizeof($_POST['checkFollower']);$i++){
				
			$groupMemberData=array('user_ID'=>$_POST['checkFollower'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkFollower'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
				
			}
			
		}
		
		
				$customEmails= $this->input->post('customEmail');
				if(!empty($_POST['customEmail'][0])){					
					$implodeCustomEmail=implode("|",$_POST['customEmail']);
					$customEmailsArr=array();
					
				if(isset($_POST['customEmail'])){
					$customEmailsArr=explode("|",$implodeCustomEmail);
				}
				
				if(isset($customEmailsArr)){
					 
				for($i=0;$i<sizeof($customEmailsArr);$i++){
					            $getCustonName=$customEmailsArr[$i];
					            $explodeCustomName=explode('@',$getCustonName);
					            $customName=$explodeCustomName[0];
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));								
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$customName,'email'=>$customEmail, 'group_ID' => $groupId, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									
								}
						}
					
				}
					
		}//end of custom emails
		
		//emails
	$sesUserId=$this->session->userdata('userID');
	$groupCreatorData=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
	if($groupCreatorData){
						$groupCreatorName=$groupCreatorData[0]['firstName'];
					}else{
						$groupCreatorName="";
					}
		//echo $groupCreatorName;die;
		$registeredGroupMemberesData1		= $this->getdatamodel->getGroupMembersDetails($groupId,1);
		$nonregisteredGroupMembersData1		= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
		
		/* Added by Padmaja */
		if($registeredGroupMemberesData1){
			foreach ($registeredGroupMemberesData1 as $uprec){
				$emailArr[]=$this->convert($uprec['email']);
			}
			$namesArr[]=$uprec['firstName'];
			//print_r($emailArr);
		}
		
		if($nonregisteredGroupMembersData1){
				foreach ($nonregisteredGroupMembersData1 as $uprec2){
					$emailArr[]=$this->convert($uprec2['email']);
					
				}
				$namesArr[]=$uprec2['name'];
				//print_r($emailArr);die;
		}
		
		for($i=0;$i<sizeof($emailArr);$i++){
						$msgStr="";
						$email=	$emailArr[$i];
						$mailData['userName'] 	= !empty($namesArr[$i]);
						$namesArr1=$namesArr;
						unset($namesArr1[$i]);
						//print_r($namesArr1);
						$newarr=array();
						foreach($namesArr1 as $name){
							$newarr[]=$name;
						}
						//print_r($newarr);
						for($j=1;$j<sizeof($newarr);$j++){
							if($j==1){
								$msgStr.=$newarr[$j];
							}else if($j<=sizeof($newarr)-1){
								$msgStr.=", ".$newarr[$j];
							}else{
								$msgStr.=" and ".$newarr[$j];
							}
						}
						//echo $msgStr."<br/>";
					}
		if($registeredGroupMemberesData1){
		  $from = $this->_supportEmail;
			foreach ($registeredGroupMemberesData1 as $rec){
			
			if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$groupCreatorName has updated the $groupName.";
								$data->typeID = "2";
		     	                                        $data->param = $groupId;
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}
							
				if($rec['isEmailAlerts']==0){
								$regEmail		= $this->convert($rec['email']);
								$userId=$rec['ID'];
								$this->setdatamodel->updateUserGroupBadgeByUserId($userId, $groupId, 1);
								$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
								$uname			= $userDetails[0]['firstName'];
								$mailData['userName'] 	= $uname;
								$mailData['groupCreator']= $groupCreatorName;
								$mailData['groupName']	= $groupName;
								$mailData['members']	=$msgStr;
								$mailContet = $this->templatemodel->updateGroupMailTemplate($mailData);
								$subject = "$groupCreatorName added you to $groupName on Qpals";
								// call mailer function to send mail.
								$data2 = new StdClass;
								$data2->from = $from;
								$data2->to = $regEmail;
								$data2->subject = $subject;
								$data2->body = $mailContet;
								$message = json_encode($data2);	
								$this->messagequeue->addMessageToMAILQueue($message);
							}
				}
		}
		
	if($nonregisteredGroupMembersData1){
						$from = $this->_supportEmail;
						foreach ($nonregisteredGroupMembersData1 as $rec){
							$regEmail		= $this->convert($rec['email']);
							$uname			= $rec['name'];
							$mailData['userName'] 	= $uname;
							$mailData['members']	=$msgStr;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailContet = $this->templatemodel->NonRegisteredupdateGroupMailTemplate($mailData);
							$subject = "$groupCreatorName added you to $groupName on Qpals";
							// call mailer function to send mail.
							$data3 = new StdClass;
                            $data3->from = $from;
                                                                $data3->to = $regEmail;
                                                                $data3->subject = $subject;
                                                                $data3->body = $mailContet;
                                                                $message = json_encode($data3);
                                                                $this->messagequeue->addMessageToMAILQueue($message);
						}
		}
		//emails end
		
		$url=base_url().'groups/editGroup/'.$groupId.'';
		header('Location:'.$url.'');
		
	}
	
	
	
	public function deleteGroupMember(){
		//echo "sdsadad";die;
		$memberId=$this->input->post('memberId');
		$groupId=$this->input->post('groupId');
		$gName=$this->input->post('gName');
		$deldName=$this->input->post('deldName');
		$deldEmail=$this->input->post('deldEmail');
		//echo $memberId;echo $gName;echo $deldName;
		$res=$this->setdatamodel->deleteUserFromGroup($memberId, $groupId);
		//print_r($res);echo "asdddddddddddddddddddddddddddd";
		$from = $this->_supportEmail;
		 $sesUserId=$this->session->userdata('userID');
		 $userData=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
				$uname=$userData[0]['firstName'];//seesion name
				$groupDetails=$this->getdatamodel->getGroupDetailsById($groupId);
				$groupName=$groupDetails[0]['name'];
		
	if($res){
					$resArr['result']       = 1;
					$registeredGroupMembersData		= $this->getdatamodel->getGroupMembersDetails($groupId, 0);
					//var_dump($registeredGroupMembersData);die;
					if($registeredGroupMembersData){
						foreach ($registeredGroupMembersData as $rec){
							//To Send Push to Newly Added Member
							//@author Rajesh on 13-11-2013
							//print_r($rec);
							if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$uname is no longer a member of $groupName on Qpals.";
								$data->typeID = "0";
					            $data->param = "0";
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}

							$mailData['userName']	= $rec['firstName'];
							$mailData['deletedUser']= $uname;
							$mailData['groupName']	= $groupName;
							$regEmail				= $rec['email'];
							$mailData['deldName']= $deldName;
							//print_r($mailData);die;
							$email=$this->convert($regEmail);
							$delEml=$this->convert($deldEmail);
							
							//$subject = "$uname is no longer a member of $groupName";
							$subject = "Sorry, you are no longer a member of $gName";
							$mailContet=$this->templatemodel->deleteMemberMailTemplate($mailData);
							// call mailer function to send mail.
							//$status = mailer($from, $email, $subject, $mailContet);
							 $data6 = new StdClass;
                                                                $data6->from = $from;
                                                                $data6->to = $delEml;
                                                                $data6->subject = $subject;
                                                                $data6->body = $mailContet;
                                                                $message = json_encode($data6);
                                                                $this->messagequeue->addMessageToMAILQueue($message);


						}
					}
					
				}
		
	}
	
	
	public function deleteNonRegGroupMember(){
		$nonRegId=$this->input->post('nonRegId');
		$groupId=$this->input->post('groupId');
		$this->setdatamodel->deleteNonRegisteredGroupMemebersOnWeb($nonRegId, $groupId);
		
		
	}
	
	/*
	 * 
	 * edit Group end
	 */
	
	
	/*
	 * view Group
	 */
	
	public function viewGroup($groupId = 0){
		$data['active']=3;
		$data['activeMenu']='';
		$keyBlow   = md5("QPals");
		$data['showGroupId']=$this->encrypt_blowfish($groupId,$keyBlow);
		//echo $data['showGroupId'];die;
		$getgroupCreatorId=$this->getdatamodel->getGroupDetailsById($groupId);
		$groupCreatorId=$getgroupCreatorId[0]['user_ID'];
	    $sesUserId=$this->session->userdata('userID');
	    
	    if($groupCreatorId==$sesUserId){
	    	
	    	$data['activeEditGroup']="editGroup";
	    }else{
	    	$data['activeEditGroup']="";
	    }
	    
	    
		$data['groupData']=$this->getdatamodel->getGroupDetailsById($groupId);
		$totalCount=$this->getdatamodel->getGroupMemnbersCount($groupId);
		if($totalCount>1){
         $data['membersCount']=$totalCount;
		}	
		$data['registeredGroupMemberesData']= $this->getdatamodel->getGroupMembersDetails($groupId);
		$data['nonregisteredGroupMembersData']= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
		$data['fbGroupMembersData']= $this->getdatamodel->getnonRegFBGroupMembersDetails($groupId);
		$getQpalQId=$this->getdatamodel->getQPalQID($groupId);
		
	    if($getQpalQId){
	    	$data['qPosts']='';
         foreach($getQpalQId as $getQpalQId){
                 	$qId=$getQpalQId['ID'];
				    $getQdatails=$this->getdatamodel->getQdetails($qId);
					$questionDescription= $getQdatails[0]['name'];
                    $countString=strlen($questionDescription);
                       if($countString > 18){
                       $quesDesc= substr($questionDescription, 0, 18);
                       $qDesc  = $quesDesc.'...';
                       }else{
                      $qDesc = $questionDescription;
                       }
					$getAggregateVotes=$this->getdatamodel->getAggregateVotes($qId);
					if($getAggregateVotes){
					$opt1 = $getAggregateVotes[0]['opt1'];
					$opt2 = $getAggregateVotes[0]['opt2'];
					$opt3 = $getAggregateVotes[0]['opt3'];
					$opt4 = $getAggregateVotes[0]['opt4'];
					if ($opt3 == NULL)
					     {
						      $opt3 = 0;
					        }
					
					        if ($opt4 == NULL)
					        {
						      $opt4 = 0;
					        }
					        
						   if ($opt2 == NULL)
					        {
						      $opt2 = 0;
					        }
					        
					        $result = ($opt1+$opt2+$opt3+$opt4);
					        $responseCount=$result;
						}else{
							$responseCount=0;
						}
					       
					       //get Age of Q
					       $timeStamp= $getQdatails[0]['timeStamp'];
					       $time1=date("Y-m-d H:i:s", strtotime($timeStamp." UTC"));
					       $time2 = date('Y-m-d H:i:s');
					       $qAge=$this->getdatamodel->getQAge($time1,$time2,$precision=6);
					       $quser_ID= $getQdatails[0]['user_ID'];
					       
						   
						   $userData=$this->getdatamodel->getUserDetailsByUserID($quser_ID);
						   $qCreatorDisplayName= $userData[0]['displayName'];
						   
                           $qImageData=$this->getdatamodel->getQImages($qId);

                           if($qImageData){
                           	$imgName=$qImageData[0]['thumb'];
                           if($imgName){
								$qImagethumb=base_url()."Uploads/QImages/$imgName";
							}else{
								$qImagethumb=base_url()."Uploads/QImages/default_thumb.png";
							}
							
							
                          }
						else{
							$qImagethumb=base_url()."Uploads/QImages/default_thumb.png";
							
						}
				$urlViewQ=base_url()."qwall/viewQ/$qId";	
				$data['qPosts'].='<div class="thumbs_group">
                            <ul>

                              <li>
                                <div class="thumbs_list">
                                   <a href="'.$urlViewQ.'">
                                   <img src="'.$qImagethumb.'" width="225" height="225" alt="" />
                                   </a>
                                   <br>
                                   <div>
                                   <div class="question">'.$qDesc.'</div> 
                                   <div class="comment_bg_blue"> <p>'.$responseCount.'</p></div> 
                                   <div class="fleft" style="font-style:italic">'.$qAge.' ago by <span class="bold_italic">'.$qCreatorDisplayName.'</span></div> 
                                   </div> 
                                </div>
                              </li>                              
                              
    
                            </ul>
                            
                         </div>';
						
                 }}else{
					
					$data['qPosts']    ='no Qs available';	
				  }
		
		
		$this->load->view('viewGroup',$data);
		
	}
	
	/*
	 * function to delete group
	 */
	
	function deleteGroup(){
		$groupId=$this->input->post('groupId');
		
		$groupData=$this->getdatamodel->getGroupDetailsById($groupId);
		if($groupData){
			
			$groupName=$groupData[0]['name'];
					$groupCreatorId=$groupData[0]['user_ID'];
					$groupCreatorDetails=$this->getdatamodel->getUserDetailsByUserID($groupCreatorId);
					$groupCreatorName=$groupCreatorDetails[0]['firstName'];
					$registeredGroupMemberesData= $this->getdatamodel->getGroupMembersDetails($groupId, 1);
					if($registeredGroupMemberesData){
						$from = $this->_supportEmail;
						
						foreach ($registeredGroupMemberesData as $rec){	

						if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$groupCreatorName has deleted $groupName group.";
								$data->typeID = "3";
					            $data->param = $groupId;
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}

							$regEmail		= $this->convert($rec['email']);
							$userId=$rec['ID'];
							$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
							$uname			= $userDetails[0]['firstName'];
							$mailData['userName'] 	= $uname;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailContet = $this->templatemodel->deleteGroupMailTemplate($mailData);
							$subject = "$groupCreatorName has deleted $groupName on Qpals";
							// call mailer function to send mail.
							//$status = mailer($from, $regEmail, $subject, $mailContet);
							
							$data4 = new StdClass;
                            $data4->from = $from;
                            $data4->to = $regEmail;
                            $data4->subject = $subject;
                            $data4->body = $mailContet;
                            $message = json_encode($data4);
                            $this->messagequeue->addMessageToMAILQueue($message);
						}
					}
					$this->setdatamodel->deleteGroup($groupId);

					echo "Group has been deleted successfully.";
		}
	}
	
	
}