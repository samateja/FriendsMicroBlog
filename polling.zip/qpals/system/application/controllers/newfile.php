<?php 
public function updateGroup($groupId=0){
		
		
		$groupName=$this->input->post('groupName');
		
		//update group name
		$insertGroupData 	= array('name'=>$groupName,'ID'=>$groupId );
		$this->setdatamodel->updateGroup($insertGroupData, $groupId);
		
		//update Image		
		if($_FILES['groupImage']['name']){
			$groupImgResponse = $this->setdatamodel->uploadImage($_FILES,'groupImage','GroupImages');
		if($groupImgResponse){
				$groupImgName = $groupImgResponse['imgName'];
				$groupThumbName = $groupImgResponse['thumbName'];
				$groupData = array('ID'=>$groupId, 'thumb'=>$groupThumbName ,'photo'=>$groupImgName);
				$this->setdatamodel->updateGroup($groupData);
			}
		}
		
		//insert following
		if(isset($_POST['checkFollowing'])){
			
			for($i=0;$i<sizeof($_POST['checkFollowing']);$i++){
			//echo "<pre>";print_r($_POST['checkFollowing'][$i]);
			$groupMemberData=array('user_ID'=>$_POST['checkFollowing'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkFollowing'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
			}
			
		}
		
		//insert follower
		
		if(isset($_POST['checkFollower'])){
			
			for($i=0;$i<sizeof($_POST['checkFollower']);$i++){
				
			$groupMemberData=array('user_ID'=>$_POST['checkFollower'][$i], 'group_ID' => $groupId, 'status_ID' =>1);
			$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									
			$groupBadgesData=array('user_ID'=>$_POST['checkFollower'][$i], 'group_ID' => $groupId,'isNew'=>1);
			$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
				
			}
			
		}
		
		
		$customEmails= $this->input->post('customEmail');
				if(!empty($_POST['customEmail'][0])){					
					$implodeCustomEmail=implode("|",$_POST['customEmail']);
					$customEmailsArr=array();
					
				if(isset($_POST['customEmail'])){
					$customEmailsArr=explode("|",$implodeCustomEmail);
				}
				
				if(isset($customEmailsArr)){
					 
				for($i=0;$i<sizeof($customEmailsArr);$i++){
					            $getCustonName=$customEmailsArr[$i];
					            $explodeCustomName=explode('@',$getCustonName);
					            $customName=$explodeCustomName[0];
								$customEmail = $this->convert(strtolower($customEmailsArr[$i]));								
								$checkUserByEmail=$this->getdatamodel->checkUserByEmail($customEmail);
								if($checkUserByEmail){
									$userID		= $checkUserByEmail[0]['ID'];
									$res=$this->getdatamodel->getUserDetailsByUserID($userID);
								}else{
									$res="";
								}
								//If user exists then We will insert Group member mapping in groupMembers table
								if($res){
									$groupMemberData=array('user_ID'=>$userID, 'group_ID' => $groupId, 'status_ID' =>1);
									$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
									//Added by Rajesh on 28-10-2013 to store Badges
									$groupBadgesData=array('user_ID'=>$userID, 'group_ID' => $groupId,'isNew'=>1);
									$this->setdatamodel->insertUserGroupBadges($groupBadgesData);
									$registeredGroupMemberEmails[]=$res[0]['email'];
									$registeredGroupMemberNames[]=$res[0]['firstName'];
								}
								// If user not exists We will insert Group member mapping in nonRegisteredGroupMembers
								else{
									$groupMemberData=array('name'=>$customName,'email'=>$customEmail, 'group_ID' => $groupId, 'status_ID' =>0);
									$this->setdatamodel->insertNonRegisteredGroupMember($groupMemberData);
									$nonRegisteredGroupMemberEmails[]=$customEmail;
									
								}
						}
					
				}
					
		}//end of custom emails
		
		//emails
		$sesUserId=$this->session->userdata('userID');
	$groupCreatorData=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
	if($groupCreatorData){
						$groupCreatorName=$groupCreatorData[0]['firstName'];
					}else{
						$groupCreatorName="";
					}
		//echo $groupCreatorName;die;
		$registeredGroupMemberesData1		= $this->getdatamodel->getGroupMembersDetails($groupId,1);
		$nonregisteredGroupMembersData1		= $this->getdatamodel->getnonRegGroupMembersDetails($groupId);
		if($registeredGroupMemberesData1){
		  $from = $this->_supportEmail;
			foreach ($registeredGroupMemberesData1 as $rec){
			
			if($rec['isPushAlerts']==1){
								$data = new StdClass;
								$data->deviceToken = $rec['pushId'];
								$data->message = "$groupCreatorName has updated the $groupName.";
								$data->typeID = "2";
		     	                                        $data->param = $groupId;
								//$data->badge = $invitations;
								//$data->sound  = "ping.wav";
								$message = json_encode($data);

								log_message('debug',"hitting message queue $message");			// Check the device type and send push
								if($rec['deviceType_ID']== 1){ //Android
									log_message('debug',$message);

									$this->messagequeue->addMessageToC2DMQueue($message);

								}
								elseif($rec['deviceType_ID']== 2){ //Ios

									$this->messagequeue->addMessageToAPNSQueue($message);
								}
								elseif($rec['deviceType_ID']== 3){ //Windows

									$this->messagequeue->addMessageToWinQueue($message);
								}
							}
							
				if($rec['isEmailAlerts']==1){
								$regEmail		= $this->convert($rec['email']);
								$userId=$rec['ID'];
								$this->setdatamodel->updateUserGroupBadgeByUserId($userId, $groupId, 1);
								$userDetails=$this->getdatamodel->getUserDetailsByUserID($userId);
								$uname			= $userDetails[0]['firstName'];
								$mailData['userName'] 	= $uname;
								$mailData['groupCreator']= $groupCreatorName;
								$mailData['groupName']	= $groupName;
								$mailContet = $this->templatemodel->updateGroupMailTemplate($mailData);
								$subject = "Group $groupName updated";
								// call mailer function to send mail.
								$data2 = new StdClass;
								$data2->from = $from;
								$data2->to = $regEmail;
								$data2->subject = $subject;
								$data2->body = $mailContet;
								$message = json_encode($data2);	
								$this->messagequeue->addMessageToMAILQueue($message);
							}
				}
		}
		
	if($nonregisteredGroupMembersData1){
						$from = $this->_supportEmail;
						foreach ($nonregisteredGroupMembersData1 as $rec){
							$regEmail		= $this->convert($rec['email']);
							$uname			= $rec['name'];
							$mailData['userName'] 	= $uname;
							$mailData['groupCreator']= $groupCreatorName;
							$mailData['groupName']	= $groupName;
							$mailContet = $this->templatemodel->updateGroupMailTemplate($mailData);
							$subject = "Group $groupName updated";
							// call mailer function to send mail.
							$data3 = new StdClass;
                            $data3->from = $from;
                                                                $data3->to = $regEmail;
                                                                $data3->subject = $subject;
                                                                $data3->body = $mailContet;
                                                                $message = json_encode($data3);
                                                                $this->messagequeue->addMessageToMAILQueue($message);
						}
		}
		//emails end
		
		$url=base_url().'groups/editGroup/'.$groupId.'';
		header('Location:'.$url.'');
		
	}
	
	