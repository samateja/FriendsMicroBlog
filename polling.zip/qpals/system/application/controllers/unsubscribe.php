<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Padmaja on 09-07-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class Unsubscribe extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');

		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
     function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
  
  function encrypt_blowfish($data,$key){
    $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $crypttext = mcrypt_encrypt(MCRYPT_BLOWFISH, $key, $data, MCRYPT_MODE_CBC, $iv);
    return bin2hex($iv . $crypttext);
    }
	
	/*
	 * @Author Padmaja on 08-07-2014
	 * unsubscribe page
	 */
	
	
	public function index(){
		$data['active']="unsubscribe";
		$data['message']="hello";
		//echo $getId;
		//print_r($getId);die;
		$this->load->view('unsubscribe',$data);
		
	}
  
	/*For loading unsubscribeview
	 * Padmaja on 09-07-2014
	 */
	function unsubscribeUser($rowID){
		echo $rowID;
		$getId='';
		$getID=$this->getdatamodel->getUserDetailsByUserID($rowID);
		//print_r($getID);
		$data['Id']=$getID[0]['ID'];
		$data['email']=$getID[0]['email'];
		$el=$data['email'];
		$data['emil'] =$this->convert($el);
		$data['fname']=$getID[0]['firstName'];
		$data['active']="unsubscribe";
		$this->load->view('unsubscribe',$data);
	}
	
	/*For loading unsubscribeview
	 * Padmaja on 09-07-2014
	 */
	function unRegisteredUser($rowID){
		
		$getId='';
		$getID=$this->getdatamodel->getNonRegDetails($rowID);
		//print_r($getID);
		$data['NonRegId']=$getID[0]['ID'];
		$data['email']=$getID[0]['email'];
		$el=$data['email'];
		$data['emil'] =$this->convert($el);
		$data['name']=$getID[0]['name'];
		$data['unReg']='unRegisterd';
		$data['active']="unsubscribe";
		$this->load->view('unsubscribe',$data);
	}
	/*For emails settings
	 * Padmaja on 09-07-2014
	 */
	function setEmailAlerts(){
		//echo "hello";
		
		$userId= $this->input->post('sessionlog');
		$userData=$this->getdatamodel->getUserDetailsByUserID($userId);
		
	//	print_r($userData);
		$isEmailAlerts	= $userData[0]['isEmailAlerts'];
		//echo $isEmailAlerts;
		if($isEmailAlerts==1){
			//echo "hellooo";
			$userData=array('ID'=>$userId, 'isEmailAlerts'=>0);
			$res=$this->setdatamodel->updateUserData($userData);
		}else{
				
			$userData=array('ID'=>$userId, 'isEmailAlerts'=>1);
			$res=$this->setdatamodel->updateUserData($userData);
				
		}
		
	}
	
	/*
	 * @author:Padmaja
	 */
	function registeredEmailAlerts(){
		$regID =$this->input->post('id');
		if($regID){
			
			$regUserData=$this->getdatamodel->getUserDetailsByUserID($regID);
			$isEmailAlerts =$regUserData[0]['isEmailAlerts'];
			if($isEmailAlerts==1){
				//echo "hellooo";
				$userData=array('ID'=>$regID, 'isEmailAlerts'=>0);
				$res=$this->setdatamodel->updateUserData($userData);
			}
		}
	}
	function unRegisteredEmailAlerts(){
		$nonRegID =$this->input->post('nonRegID');
		if($nonRegID){
			
			$nonUserData=$this->getdatamodel->getNonRegDetails($nonRegID);
			$isEmailAlerts =$nonUserData[0]['isEmailalerts'];
			if($isEmailAlerts==1){
				//echo "hellooo";
				$userData=array('ID'=>$nonRegID, 'isEmailalerts'=>0);
				$res=$this->setdatamodel->updateunRegisterdData($userData);
			}
		
		}
	}
	/*For emails Registration for Non registered
	 * Padmaja on 09-07-2014
	 */
	function emailRegistration(){
		$data['active']="emailRegistrion";
		$this->load->view('emailRegistration',$data);
	}
	

}
