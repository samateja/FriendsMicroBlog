<?php
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Rajesh on 18-09-2013
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class home extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
			
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->model('messagequeue');

		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');
      
	}
	
  /**
	 * Converting string into Encrypt or decrypt format
	 * @author Rajesh on 18-09-2013
	 * @param $str
	 */
	function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
	
	
	/*
	 * @Author asha on 13-2-2014
	 * home page
	 */
	
	
	public function index(){
		
		$data['active']="home";
		$this->load->view('homeView',$data);
		
	}
	
	
	
	
	function fbLogin()
	{
		
	include(BASEPATH.'application/libraries/facebook.php'); 
	//session_start();
		
 
 
   $config = array(
      'appId' => $this->config->item('appId'),
      'secret' =>$this->config->item('secret')
      
  );

  $facebook = new Facebook($config);
   
  //$user = $facebook->getUser();
 
 
  $params = array(
  'scope'=> 'email,read_stream, publish_stream',
  
  'display'=>'popup');

  $loginUrl = $facebook->getLoginUrl($params);
  $user = $facebook->getUser();
  
  if (!$user)
		{
      header("location:$loginUrl");  
       
		}
  else
  {//if user is already loogedin
  	//var_dump($_REQUEST);
 //die;  
	$fbid=$facebook->getUser(); 
	$access_token=$facebook->getAccessToken();
	$checkUserByFBID=$this->getdatamodel->checkUserByFBID($fbid);
	$fql1   =   "SELECT first_name,last_name,email,name,sex,hometown_location FROM user WHERE uid='$fbid'";
	$param  =   array(
                'method'    => 'fql.query',
                'query'     => $fql1,
                'callback'  => '',
                'access_token'=>$access_token
                        );
                        $fqlres   =   $facebook->api($param);
                    //print_r($fqlres);die;   
                        $firstName = $fqlres[0]['first_name'];
                        $lastName = $fqlres[0]['last_name'];
                        $email = $fqlres[0]['email'];
                        $encEmail=$this->convert(strtolower($email));
	
	if($checkUserByFBID){
		//do nothing
	if($fbid){		
	  $data=array('userID'   =>$checkUserByFBID[0]['user_ID'],					            
					            'is_logged_in' => true);					
	  $this->session->set_userdata($data);
	  redirect('qwall/qwallView');	
	}
		
	}else{
	
     $isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
     $isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail, 1);
     if($isPrimaryEmailExists || $isSecondaryActivatedEmail){
     if($isPrimaryEmailExists){
		$userId=$isPrimaryEmailExists[0]['ID'];
		}else if($isSecondaryActivatedEmail){
		 $userId=$isSecondaryActivatedEmail[0]['user_ID'];
		}
		
		$res=$this->getdatamodel->getUserDetailsByUserID($userId);
		$updateUserData=array('FBID'=>$fbid, 'status_ID'=>1, 'user_ID'=> $userId);
		$this->setdatamodel->userFBMapping($updateUserData);
		
	}else{
		$checkUserByFBID=$this->getdatamodel->checkUserByFBID($fbid);
		$userID=$checkUserByFBID[0]['user_ID'];
		
		
		$passwordgenerator = str_split(sha1(microtime()),13);
		$password = $passwordgenerator[0];
		$userInsertData['firstName']		= $firstName;
		$userInsertData['lastName']			= $lastName;
		$userInsertData['displayName']		= $firstName;
		$userInsertData['email']			= $encEmail;
		$userInsertData['password']			= md5($password);
		$userInsertData['thumb']			= "avatar_thumb.png";
		$userInsertData['photo']			= "avatar.png";
		$userInsertData['OSVersion']		= '';
		$userInsertData['appVersion']		= '';
		$userInsertData['deviceType_ID']	= '';
		$userInsertData['deviceId']			= '';
		$userInsertData['status_ID']  		= 1;
		$userInsertData['accessToken']		= '';
		$userInsertData['tokenTimeStamp']	= '';
		$insertRes = $this->setdatamodel->registerUser($userInsertData);
		if($insertRes){
			$this->setdatamodel->deleteSecondaryEmail($encEmail);
			$this->setdatamodel->deleteNonRegisteredFBMemeber($fbid);
			$nonRecFBQs=$this->getdatamodel->getNonRecievedFBQs($fbid);
		if($nonRecFBQs){
			foreach($nonRecQs as $rec){
					$recFBQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
					$this->setdatamodel->insertNonRecievedFbq($recFBQData);
			}
		}
		
		$this->setdatamodel->deleteNonRecFBQ($fbid);
		$from = $this->_supportEmail;
		$mailData['userName'] 	= $firstName;
		$mailData['email'] 		= $email;
		$mailData['password'] 	= $password;
		$mailContet = $this->templatemodel->fbSigninMailTemplate($mailData);
		$subject = "Welcome to Qpals";
		$data = new StdClass;
                                                                $data->from = $from;
                                                                $data->to = $email;
                                                                $data->subject = $subject;
                                                                $data->body = $mailContet;
                                                                $message = json_encode($data);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

		$insertData=array('FBID'=>$fbid, 'status_ID'=>1, 'user_ID'=>$insertRes);
		$insertFbUserMapping=$this->setdatamodel->inserUserFBMapping($insertData);		
		
		
		$data=array('userID'   =>$insertRes,					            
					            'is_logged_in' => true);					
	    $this->session->set_userdata($data);
	    
		  }//end of insertion
		
	     redirect('qwall/qwallView');	
       } //end of facebook logIn for new user                  
    
	 }//end of facebook sdk
	
  }
}//end of facebook login




	
	/*
	 * @Author Asha on 13-2-2014
	 * login with ajax
	 */
	
	
	 function login(){
		echo "Hello World";
	 	$data['active']=1;
		$this->form_validation->set_rules('email','The Enter Email field is required. ','trim||required|valid_email|xss_clean');
		$this->form_validation->set_rules('password', 'The Enter Password field is required.', 'trim|required|xss_clean');
		
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		else
		{
			$emailPost = trim($this->input->post('email', TRUE));
			$password = trim($this->input->post('password', TRUE));
			$email=$this->convert(strtolower($emailPost));
			
			$isValidEmailAddress   = $this->getdatamodel->checkUserByEmail($email);			
			$isValidSecEmailAddress=$this->getdatamodel->checkSecondaryEmail($email, 1);
			$isValidPassword 	   = $this->getdatamodel->login($email, $password);
			
			if(($isValidEmailAddress || $isValidSecEmailAddress) && $isValidPassword){
				
				$res=$this->getdatamodel->login($email, $password);				
				if($res){					
					$data=array('userID'   =>$res[0]['ID'],
					            'firstName'=>$res[0]['firstName'],
					            'lastName' => $res[0]['lastName'],
					            'is_logged_in' => true);
					//print_r($data);
					$this->session->set_userdata($data);					
					echo 1;//"success";
					
					$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					
					//fetch access token
					$getUserData	= $this->getdatamodel->getUserDetailsByUserID($res[0]['ID']);
					$tokenGet=$getUserData[0]['accessToken'];
					
				   if($tokenGet !=""){
				   //$userData['accessToken']	= $getUserData[0]['accessToken'];
					$expiry = $this->config->item('tokenExpiry');					
					foreach($getUserData as $toknes){
					//print_r($toknes);
					$loggedInDate = date("m/d/Y", strtotime($toknes['tokenTimeStamp'])) . "+$expiry days";					
					$thirty_days_ahead =   date('Y-m-d');
					$userData['userId'] =$toknes['ID'];
					if(strtotime($loggedInDate) < strtotime($thirty_days_ahead)){//if expired						
						$ary = array(
                              'accessToken'=>$authToken,
                              'tokenTimeStamp'=>date("Y-m-d H:i:s")
						);
						
						$this->pdo->where('ID',$toknes['ID']);
						$tkn = $this->pdo->update('user', $ary);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($userData['userId']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						//if less than 30 days
						$userData['accessToken'] = $toknes['accessToken'];						
					}
				}
						
			}else{ //if access token is empty i.e login for first time
				
			if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $data['userID'],'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($data['userID']);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$resArr['message']="Invalid Auth Token.";
					}
				
			}
					
				}else{
				    echo "Invalid login details";
				}
				
			}else{
			   if(!$isValidEmailAddress){
					echo "Invalid Email address.";
				}else if(!$isValidPassword){
					echo "The password you entered is incorrect.";
				}
			}
		}
	}
	
	/*
	 * @Author asha on 13-2-2014
	 * user registration
	 */
	
	function userRegistration(){
		 
		$data['active']=1;
		$this->form_validation->set_rules('firstName','The First Name field is required.','trim|required|xss_clean');			
		$this->form_validation->set_rules('email', 'The Email field is required.', 'trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('password', 'The Password field is required.', 'trim|required|min_length[6]|max_length[16]|xss_clean');		
		$firstName  =$this->input->post('firstName');
		$lastName   =$this->input->post('lastName');
		//$displayName =$this->input->post('displayName');
		$email       =$this->input->post('email');
		$displayNameExplode=explode("@",$email);
		$displayName=$displayNameExplode[0];
		$password    =$this->input->post('password');
		if ($this->form_validation->run() == FALSE)
		{
			echo validation_errors();
		}
		else
		{
			$encEmail			= $this->convert(strtolower($email));
			$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
			$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail,1);
		    if(!empty($isPrimaryEmailExists) || !empty($isSecondaryActivatedEmail)){//if($isPrimaryEmailExists){
		    	
				$userId		= $isPrimaryEmailExists[0]['ID'];
				$isFBUser	= $this->getdatamodel->checkFbUserByUserId($userId);
				if($isFBUser){
					echo "Email-address already registered, please login with your Facebook Account";
				}else{
					echo "Email-address already exists.";
					die;
				}
			}else{				
				$userInsertData['firstName']		= $firstName;
				$userInsertData['lastName']			= $lastName;
				$userInsertData['displayName']		= $displayName;
				$userInsertData['email']			= $encEmail;
				$userInsertData['password']			= md5($password);
				$userInsertData['thumb']			= "avatar_thumb.png";
				$userInsertData['photo']			= "avatar.png";				
				$userInsertData['deviceType_ID']	= 0;//website
				$userInsertData['status_ID']  		= 1;
				
				$insertRes = $this->setdatamodel->registerUser($userInsertData);
				
			if($insertRes){
					$this->setdatamodel->deleteSecondaryEmail($encEmail);
					$nonRegGroupDetails=$this->getdatamodel->getnonRegGroupMemberByEmail($encEmail);
					if($nonRegGroupDetails){
						foreach($nonRegGroupDetails as $rec){
							$groupMemberData=array('user_ID'=>$insertRes, 'group_ID' => $rec['group_ID'], 'status_ID' =>1);
							$this->setdatamodel->insertRegisteredGroupMemberMapping($groupMemberData);
						}
					}
					$this->setdatamodel->deleteNonRegisteredMemeber($encEmail);
					//Added by Rajesh to Get Non Recieved Q's of user to Map them to Registered account
					//On 28-11-2013
					$nonRecQs=$this->getdatamodel->getNonRecievedQs($encEmail);
					if($nonRecQs){
						foreach($nonRecQs as $rec){
							$recQData=array('user_ID'=>$insertRes, 'qPalQ_ID' => $rec['qPalQ_ID'],'isVoted'=>0, 'status' =>1);
							$this->setdatamodel->insertNonRecievedQ($recQData);
						}
					}
					$this->setdatamodel->deleteNonRecQ($encEmail);
					$from = $this->_supportEmail;

					$mailData['userName'] 	= $firstName;
					$mailData['email'] 		= $email;
					$mailData['password'] 	= $password;
					$mailData['encEmail'] 	= $encEmail;

					// getting the mail content
					$mailContet = $this->templatemodel->registerMailTemplate($mailData);
					$subject = "Welcome to QPals";
					// call mailer function to send mail.
					//$status = mailer($from, $email, $subject, $mailContet);
					$data = new StdClass;
					 $data->from = $from;
                     $data->to = $email;
                     $data->subject = $subject;
                     $data->body = $mailContet;
                     $message = json_encode($data);
                     $this->messagequeue->addMessageToMAILQueue($message);
					 $status = true;
					if($status){
						$res=$this->getdatamodel->getUserDetailsByUserID($insertRes);
						//$this->login_post($email,$password,$osVersion,$appVersion,$deviceType);
						$userData['userId']			= $res[0]['ID'];
						//$userData['firstName']		= $res[0]['firstName'];
						$userData['name']		= $res[0]['displayName'];
						$userData['photo']			= base_url()."Uploads/ProfilePictures/".$res[0]['photo'];
						$userData['thumb']			= base_url()."Uploads/ProfilePictures/".$res[0]['thumb'];
						$userData['accessToken']	= $res[0]['accessToken'];						
						
						//To get count of group notifications which needs user approval
						$userData['notifications']	= $this->getdatamodel->getGroupNotificationCount($res[0]['ID']);
                         
						$emailPost = trim($this->input->post('email', TRUE));
			            $password1 = trim($this->input->post('password', TRUE));
			            $email1=$this->convert(strtolower($emailPost));
			
						$res=$this->getdatamodel->login($email1, $password1);				
				        if($res){					
					    $data=array('userID'   =>$res[0]['ID'],
					            'firstName'=>$res[0]['firstName'],
					            'lastName' => $res[0]['lastName'],
					            'is_logged_in' => true);
					
					    $this->session->set_userdata($data);
					   
				       }
						echo 1;
						//echo "Thank You for registering with Qpals.";
					}
				}else{
					echo "Registration failed.";
				}
				
			}
		}
		
	}
	
	
	function forgotPassword(){
		$email=$this->input->post('EmailId');
		$this->form_validation->set_rules('EmailId','Email ID is required','trim||required|valid_email');
		if ($this->form_validation->run() == FALSE)
		{
			$response=validation_errors();
		}
		else
		{
		$encEmail=$this->convert($email);
		$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
	    if($isPrimaryEmailExists){					
				$encEmail=$this->convert($email);
				
				$userId					= $isPrimaryEmailExists[0]['ID'];
				$accessCodeGenerator 	= str_split(sha1(microtime()),7);
				$accessCode				= $accessCodeGenerator[0].$userId;
				$from 					= $this->_supportEmail;
				$mailData['userName'] 	= $isPrimaryEmailExists[0]['firstName'];
				//$mailData['password'] 	= $password;
				$mailData['email'] 		= $email;
				$mailData['accessCode']	= $accessCode;			
				$mailData['encEmail'] 	= $encEmail;	

				// getting the mail content
				$mailContet 			= $this->templatemodel->forgotPasswordMailTemplate($mailData);
				//echo $mailContet;die;
				$subject 				= "Forgot Password";
				// call mailer function to send mail.
				//$status 				= mailer($from, $email, $subject, $mailContet);
				$data = new StdClass;
				$data->from = $from;
				$data->to = $email;
				$data->subject = $subject;
				$data->body = $mailContet;
				$message = json_encode($data);
				$this->messagequeue->addMessageToMAILQueue($message);
				$status = true;
				//$status=1;
				if($status){
					$updateUserData			= array('ID'=>$userId, 'changePasswordCode'=>$accessCode);
					$this->setdatamodel->updateUserData($updateUserData);					
					$response		= "<p style='color:green;'>Please check your email for a change password link.</p>";
				}
			}else{
				$response		= "Sorry, you entered an unregistered email address.";
			}
		}
			echo $response;
	}
	
	/*
	 * @Asha on 24-2-2014
	 * logout
	 */
	
	function logout(){
	    
	include(BASEPATH.'application/libraries/facebook.php'); 
	//session_start();
		
    $config = array(
      'appId' => $this->config->item('appId'),
      'secret' =>$this->config->item('secret')
      
   );

  $facebook = new Facebook($config); 
  $user = $facebook->getUser();
  
  if ($user)
		{
	 $this->session->sess_destroy();	
	 $facebook->destroySession();
	  //print_r($_SESSION);die;
      redirect('home'); 
       
		}else{	
		$this->session->sess_destroy();		
		redirect('home');
		}
	}
	
	
	
	/**
	 * To show Change Password view
	 * @author Rajesh on 19-09-2013
	 * @param string $accessCode
	 */
	/*function forgotPassword($accessCode="")
	{
		$data=array();
		if(isset($_POST['submit'])){
			$data['formData'] = $_POST;
			$this->form_validation->set_rules('newPassword', 'New password', 'trim|required||min_length[6]|max_length[12]|xss_clean');
			$this->form_validation->set_rules('confirmPassword', 'Confirm password', 'trim|required||min_length[6]|max_length[12]|matches[newPassword]|xss_clean');
			if ($this->form_validation->run()){
			
					$extractedArr=str_split($accessCode, 7);
					$userId=$extractedArr[1];
					$userRes=$this->getdatamodel->getUserDetailsByUserID($userId);
					if($userRes){
						$storedAceessCode=$userRes[0]['changePasswordCode'];
						if($storedAceessCode==$accessCode){
							$newPassword=$this->input->post('newPassword');
							$updateData=array('password'=>md5($newPassword),'changePasswordCode'=>'','ID'=>$userId);
						$this->setdatamodel->updateUserData($updateData);
						$data['succMsg']="Password changed successfully.";
						}else{
						$data['errorMsg']="You are not an authorised user.";	
						}
					}else{
					$data['errorMsg']="You are not an authorised user.";	
					}
					
			}
		}
			if($accessCode==""){
				$data['errorMsg']="You are not an authorised user.";
			}
		$this->load->view('forgotPasswordView', $data);
	}*/
	/**
	 * To Show Secondary Email activation view
	 * @author Rajesh on 08-11-2013
	 * @param $activationCode
	 */
	function secondaryEmailActivation($activationCode="")
	{
		//$data=array();
		$extractedArr=str_split($activationCode, 7);
		$userId=$extractedArr[1];
		$checkSecondaryEmail=$this->getdatamodel->getSecondaryEmail($userId, $activationCode);
		//var_dump($checkSecondaryEmail);die;
		if($checkSecondaryEmail){
			$isActivated=$checkSecondaryEmail[0]['status_ID'];
			if($isActivated){
				echo "You have already activated secondary email";
			}else{
				$this->setdatamodel->updateSecondaryEmailStatus($userId, $activationCode);
				echo "You have successfully activated secondary email.";
			}
		}else{
			echo "No secondary Email exists.";
		}
		//$this->load->view('secEmailActivationView',$data);
	}
	/*Image  upload Test
	 * 
	 */
	function uploadImage()
	{
		$this->load->view("imgUploadTest");
	}
	/*
	 * Registratation for Non registered members
	 * @author:Padmaja on 9-07-2014
	 */
	function registration()
	{
		$data['active']="emailRegistration";
		$this->load->view("emailRegistration",$data);
		//$unsubscribeLink =base_url()."unsubscribe/unsubscribeUser/$rowID";
		
	}
	
	function registrationmail($rowID){
		
		$data= $this->getdatamodel->getNonRegEmailId($rowID);
		//$data= $this->getdatamodel->getGroupID($rowID);
		if ($data == Null)
		{
		$this->load->view("EmailNoLongerValid");	
		}
		else{
		//print_r($data);
		
		foreach ($data as $rec)
		{
		$emailArr[]=$this->convert($rec['email']);
		$grpidArr[] = $rec['group_id'];
		}
		$emailID = $emailArr[0];
		$grpID = $grpidArr[0]; 
			
		//echo $emailID;
		$data['emailID'] = $emailID;
		$data['grpID'] = $grpID;
		$data['active']="emailRegistration";
		$this->load->view("emailRegistration",$data);
		}
	}
	
	function how(){
		$this->load->view("how");
	}
	
	function TipsandTracks(){
		$this->load->view("TipsandTracks");
	}
	/*
	function testmail()
	{
			$to = 'web.teja1991@gmail.com';
		if ( mail( $to, 'Postfix mail', "It is just a test mail.") ) {
		echo "Mail sent successfully!<br>\n";
		} else {
		echo "Mail sending failed :(<br>\n";
	}
	}
	
	*/
	
	
}
