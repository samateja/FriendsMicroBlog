<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// To avoid back button after logout
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0", false);
//header("Cache-Control: post-check=0, pre-check=0", false);
// HTTP/1.0
header("Pragma: no-cache");
// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
/**
 * Class home
 *
 * @package     Qpals
 * @subpackage  Controllers
 * @category    Authentication
 * @author      Asha on 13-02-2014
 * @copyright   Copyright (c) 2013
 * @license
 * @link
 * @version 	0.1
 */
class profile extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		//load the pdo for db connection
		$this->pdo = $this->load->database('pdo', true);

		$this->load->library('form_validation');

		//$this->load->helper('form','url');
		$this->_supportEmail = $this->config->item('supportEmail');
		$this->_websiteName = $this->config->item('websiteName');
		$this->load->library('form_validation');	
		// load the models
		$this->load->model('getdatamodel');
		$this->load->model('setdatamodel');
		$this->load->model('templatemodel');
		$this->load->library('session');
		$this->load->library('pagination');
		$this->load->model('messagequeue');
		$sessionlog=$this->session->userdata('userID');
		$this->_S3Url = $this->config->item('S3Url');
		//print_r($sessionlog);die;
		
			// Added by padmaja
		//$this->load->model('qpalsamazons3model');
		$this->load->library('s3upload/S3.php');
		
	    if(!$sessionlog){
	    	//echo $sessionlog;
			redirect('home');
		}
       
		//include(BASEPATH.'application/libraries/PHPMailer/sendemail.php');

	}
	
   function convert($str){
		$ky	=	$this->config->item('encryption_key');
		if($ky=='')return $str;
		$ky=str_replace(chr(32),'',$ky);
		if(strlen($ky)<5)exit('key error');
		$kl=strlen($ky)<32?strlen($ky):32;
		$k=array();for($i=0;$i<$kl;$i++){
			$k[$i]=ord($ky{$i})&0x1F;}
			$j=0;for($i=0;$i<strlen($str);$i++){
				$e=ord($str{$i});
				$str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e);
				$j++;$j=$j==$kl?0:$j;}
				return $str;
	}
  
  
	
	/*
	 * @Asha on 13-2-2014
	 * view Profile
	 */
	
	/*public function viewProfile(){	 
		
	   $sesUserId=$this->session->userdata('userID');
	   $data['userData']=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
	   $email	        = $this->convert($data['userData'][0]['email']);
	   $data['userEmail']=$email;
	   $config['base_url']=base_url().'profile/viewProfile';
       $config['total_rows']=$this->getdatamodel->getTotCountOfRecievedQs($sesUserId);
       $config['per_page']=5;
       $this->pagination->initialize($config);
       $page=($this->uri->segment(3))?$this->uri->segment(3):0;
	   //received Qs
	   $offset=2;
	   $data['receivedQ']=$this->getdatamodel->getrecievedQs($sesUserId,$page);
	   
	   //pagination
	   
	   $this->load->view('profileView',$data);
	}*/
	
	public function viewProfile(){
		$data['active']='viewPrfile';
		$sesUserId=$this->session->userdata('userID');
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
	    $email	        = $this->convert($data['userData'][0]['email']);
	    $data['userEmail']=$email;
	    $data['Icreated']=$this->getdatamodel->getMyQsCreated($sesUserId);
	    //print_r($data['Icreated']);	   	    
		$data['receivedQ']=$this->getdatamodel->getUserRecievedQs($sesUserId);
		$data['followingPals']=$this->getdatamodel->followingPal($sesUserId);
		$data['followers']=$this->getdatamodel->followersOfPals($sesUserId);
		$data['iCreated']=$this->getdatamodel->getTotCountOfMyQs($sesUserId);
		$data['iRecieved']=$this->getdatamodel->getTotCountOfRecievedQs($sesUserId);
		
	    //following count
	   $getCountOfFollowing=$this->getdatamodel->countOFfollowingPals($sesUserId);				
		if($getCountOfFollowing){
		$data['countOfFollowing']=$this->getdatamodel->countOFfollowingPals($sesUserId);
		}else{
		$data['countOfFollowing']=0;	
		}
				
		//followers count
	    $getCountOffollowers=$this->getdatamodel->getCountOffollowers($sesUserId);				
		if($getCountOffollowers){
		$data['countOfFollowers']	=$this->getdatamodel->getCountOffollowers($sesUserId);
		}else{
		$data['countOfFollowers']	=0;
		}
		$data['active']='viewPrfile';
		$this->load->view('profileView',$data);
	}
	
	
	/*
	 * @Asha on 15-2-2014
	 * edit profile
	 */
	
	public function editProfile(){
		$data['active']='editPrfile';		
		$sesUserId=$this->session->userdata('userID');
		//delete image
		if(isset($_POST['isDelProfilePic'])){	
			
		$userData	= $this->getdatamodel->getUserDetailsByUserID($sesUserId);
			if($userData){
				$resArr['result']	= 1;
				if($userData[0]['photo']!="avatar.png"){
				@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['photo']);
				@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['thumb']);
				}
			$updateUserData=array('photo'=>"avatar.png", 'thumb'=>"avatar_thumb.png",'ID'=> $sesUserId);
			
			$this->setdatamodel->updateUserData($updateUserData);
			echo "success fully deleted";		
			}
		}
		
		//secondary emails
		
		$secEmailData=$this->getdatamodel->getSecondaryEmails($sesUserId);
		$secEmailArr="";
	    if($secEmailData){
						foreach ($secEmailData as $rec){
							$email=$this->convert($rec['email']);
							$secId=$rec['ID'];
							$secArr='<tr id="secEmail_'.$secId.'">
	                        <td width="100" class="lable_profile">&nbsp;</td>
	                        <td width="40"></td>	                        
	                        <td>
	                    	 <input type="text"  style="width:100%;" name="userSecondaryEmail" value="'.$email.'" readonly /></input>
	                         <div  class="icon_add">
	                        <div><img  src="'.base_url().'images/delete_icon.png" width="22" height="22" alt="" onclick="return deleteSecEmail('.$secId.');"/></div>
	                       
                         </td>
                         </div>
	                     </tr>';
						$secEmailArr.=$secArr;
						}
						$data['displaySecondaryEmails'] =$secEmailArr;
					}else{
						$data['displaySecondaryEmails'] ="";
					}
		
		//update profile submit
		if(isset($_POST['updateProfile'])){			
			//echo "<pre>";print_r($_POST);exit;
			$firstName		= $this->input->post('firstName');
			$lastName		= $this->input->post('lastName');
			$displayName	= $this->input->post('displayName');
			$biography		= $this->input->post('biography');
			$location		= $this->input->post('location');
			$gender			= $this->input->post('gender');
			$currentPwd	    = $this->input->post('currentPassword');
			$newPwd		    = $this->input->post('newPassword');
			$confirmPassword= $this->input->post('confirmPassword');
			$isDelProfilePic= $this->input->post('isDelProfilePic');
			$updateProfile  = $this->input->post('imageUpload');
			$data['message']= "";
			$isFail="";
			//validations
			
			$this->form_validation->set_rules('firstName', 'Please enter your first name.', 'trim|required|xss_clean');			
			$this->form_validation->set_rules('displayName', 'Please enter a display name.', 'trim|required|xss_clean');
			
			if($_POST['currentPassword']!="" && $_POST['currentPassword']!="Current password" ){
				
			//$this->form_validation->set_rules('currentPassword', 'Please enter your current Password.', 'required');			
			$this->form_validation->set_rules('newPassword', 'The new password field is required', 'required|min_length[6]|max_length[16]|matches[confirmPassword]|xss_clean');
			$this->form_validation->set_rules('confirmPassword', 'The confirm password field is required', 'required|min_length[6]|max_length[16]|xss_clean');
			}
			
			//upload image			
			if($_FILES['profileImage']['name']){
				
			$filename=$_FILES['profileImage']['name'];
			//$ext = substr($filename, strpos($filename,'.'), strlen($filename)-1);
			$ext = ".".pathinfo($filename, PATHINFO_EXTENSION);
			if($ext=='.jpg' || $ext=='.gif' || $ext=='.png' || $ext=='.jpeg'  || $ext=='.JPG' || $ext=='.JPEG'){
				
				/* Added for s3 amazon images
				 * Added by Padmaja on 1-07-2014
				 */
				$profileImgResponse =$this->setdatamodel->uploadImage($_FILES,'profileImage','ProfilePictures');
				//$profileImgResponse = $this->setdatamodel->uploadImage($_FILES,'profileImage','ProfilePictures');
				//echo "<pre>";
				//print_r($profileImgResponse);
				if($profileImgResponse){
				$isFail=0;
				$profileImgName = $profileImgResponse['imgName'];
				//$baseprofileImgName = basename($profileImgName);
				$profileThumbName = $profileImgResponse['thumbName'];
				//$baseprofileThumbName = basename($profileThumbName);
				$userData = array('ID'=>$sesUserId, 'thumb'=>$profileThumbName ,'photo'=>$profileImgName);
				//echo "<pre>";
				//print_r($userData);die;
				$this->setdatamodel->updateUserData($userData);
				$bucket = $this->config->item("bucket");
				$resArr['result']		= 1;
				$resArr['message']		= "Profile image uploaded successfully.";
				$profileImageData['profileImage'] = $this->_S3Url.$profileImgName;
				$profileImageData['profileThumb'] = $this->_S3Url.$profileThumbName;
				$resArr['data']		  		  =  $profileImageData;
			}else{
				$isFail=1;
				  $data['errormessage']		= "Profile image not uploaded ";
			}
		}else{
					$isFail=1;
			      $data['errormessage']		= "Not correct format";
			      
		}
				
		}
			
			//delete profile pic
			
		if($isDelProfilePic){
					$userData	= $this->getdatamodel->getUserDetailsByUserID($sesUserId);
					if($userData){
						$resArr['result']	= 1;
						if($userData[0]['photo']!="avatar.png"){
							@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['photo']);
							@unlink(FCPATH."Uploads/ProfilePictures/".$userData[0]['thumb']);
						}
						$updateUserData=array('photo'=>"avatar.png", 'thumb'=>"avatar_thumb.png",'ID'=> $sesUserId);
						$this->setdatamodel->updateUserData($updateUserData);
							
					}
				}
			//secondary Email code start
			$primaryEmailError= 0;
			$secondaryEmailError=0;
			if(isset($_POST['secondaryEmail'])){
			$implodeSecEmail=implode("|",$_POST['secondaryEmail']);
			
		    $secEmailArr=array();
				if(isset($_POST['secondaryEmail'])){
					$secEmailArr=explode("|",$implodeSecEmail);
				}
				
		    if($secEmailArr){
					for($i=0;$i<sizeof($secEmailArr);$i++){
						$encEmail=$this->convert($secEmailArr[$i]);
						$isPrimaryEmailExists=$this->getdatamodel->checkPrimaryEmail($encEmail);
						if($isPrimaryEmailExists){
							$primaryEmailError= 1;
						}
						$isSecondaryActivatedEmail=$this->getdatamodel->checkSecondaryEmail($encEmail, 1);
						//var_dump($isSecondaryActivatedEmail);
						if($isSecondaryActivatedEmail){
							$secondaryEmailError=1;
						}
					}
			}
			

		   if($primaryEmailError){
					$data['errormessage']= "Email already registered.";
				}if($secondaryEmailError){
					$data['errormessage']= "Email already registered.";
			}
		}//secondary email code end

		//change current password code start
		$error			= 0;
		if(isset($_POST['currentPassword']) && $_POST['currentPassword']!=""){

			        if($confirmPassword != $newPwd)
			        {
			        	$data['errormessage']		= "Current password and new password doesnot match.";
			        }else{
					$userData	= $this->getdatamodel->getUserDetailsByUserID($sesUserId);
					$userPassword= $userData[0]['password'];
					//print_r($userData[0]['email']);die;
					$dbmail      =$userData[0]['email'];
					$email		= $this->convert($userData[0]['email']);
					/*$oauthProvider                  = new OAuthProvider();
					$authTokengen                   = $oauthProvider->generateToken(64);
					$authToken                      = bin2hex($authTokengen);
					 
					if($authToken){
						$datetime=date('Y-m-d H:i:s');
						$tokenData=array('ID'=> $sesUserId,'accessToken'=>$authToken,'tokenTimeStamp'=>$datetime);
						$this->setdatamodel->updateAuthToken($tokenData);
						$getTokenData	= $this->getdatamodel->getUserDetailsByUserID($sesUserId);
						$userData['accessToken']	= $getTokenData[0]['accessToken'];
					}else{
						$data['message']="Invalid Auth Token.";
					}*/
					//echo md5($currentPwd);die;
					if(md5($currentPwd)==$userPassword){
						$updateData['password']	= md5($newPwd);
					}else{
						$error 	= 1;
						$data['errormssge']		= "Incorrect current password.";
					}
			   }
			
		}//change current password end
		

		if($this->form_validation->run() && !$error && !$primaryEmailError && !$secondaryEmailError && !$data['message'] && !$isFail){
					//echo "qweqwe";die;
					$resArr['result']	= 1;
					$updateData['firstName']	= $firstName;
					$updateData['lastName']		= $lastName;
					$updateData['displayName']	= $displayName;
					$updateData['biography']	= $biography;
					$updateData['locationName']	= $location;
					$updateData['gender']		= $gender;
					$updateData['ID']			= $sesUserId;
					$from = $this->_supportEmail;
					//$res=0;
					$res=$this->setdatamodel->updateUserData($updateData);
					if($res && (isset($_POST['currentPassword']) && $_POST['currentPassword']!="")){
						
						$mailData['userName']	= $firstName;
						$mailData['email']		= $email;
						$mailData['password']	= $newPwd;
						$mailData['dbMail']    	= $dbmail;
						$subject = "Request to change password on Qpals";
						//print_r($mailData);die;
						$mailContet=$this->templatemodel->changePasswordMailTemplate($mailData);
						// call mailer function to send mail.
						 $data7 = new StdClass;
						 $data7->from = $from;
						 $data7->to = $email;
						 $data7->subject = $subject;
						 $data7->body = $mailContet;
						 $message = json_encode($data7);
						 $this->messagequeue->addMessageToMAILQueue($message);
						 
					}
					if(!empty($_POST['secondaryEmail'][0])){
						//echo "sd";die;
						for($i=0;$i<sizeof($secEmailArr);$i++){
							$encEmail=$this->convert($secEmailArr[$i]);
							$activationCodeGenerator 	= str_split(sha1(microtime()),7);
							$activationCode				= $activationCodeGenerator[0].$sesUserId;
							$email = $secEmailArr[$i];
							$userNameArr=explode("@",$secEmailArr[$i]);
							$userName=$userNameArr[0];
							$mailData['userName']=$userName;
							$mailData['email']=$email;
							$mailData['encEmail']=$encEmail;
							$mailData['activationCode']=$activationCode;
							$insertData=array('email'=>$encEmail,'activationCode'=>$activationCode,'user_ID'=>$sesUserId);
							$res=$this->setdatamodel->insertSecondaryEmail($insertData);
							//die;
							$subject	= "Secondary Email Activation";
							$mailContent=$this->templatemodel->secondaryEmailActivationMailTemplate($mailData);
							$data8 = new StdClass;
                                                                $data8->from = $from;
                                                                $data8->to = $email;
                                                                $data8->subject = $subject;
                                                                $data8->body = $mailContent;
                                                                $message = json_encode($data8);
                                                                $this->messagequeue->addMessageToMAILQueue($message);

						}

						
					}
					$data['successMessage']		= "Profile updated.";
				}
			
				
		
				
			
		}
		
		
		$data['userData']=$this->getdatamodel->getUserDetailsByUserID($sesUserId);
		$email	        = $this->convert($data['userData'][0]['email']);
	    $data['userEmail']=$email;
		$this->load->view('editProfile',$data);
		
	}
	
	/*
	 * delete Secondary Email
	 * @Author asha on 22-2-2014
	 */
    public function deleteSecEmail()
	{
		
		$Id   =$_POST['id'];
		//echo $Id;die;
		$this->setdatamodel->deleteSecondaryEmailById($Id);
		
	}
	
	
	
}